# codex advisor artifact

- Provider: codex
- Exit code: 0
- Created at: 2026-08-27T16:54:18.226Z

## Original task

You are the FINAL vendor-independent approval gate on a planning document that has had five review rounds. This is your only call — there is no second pass after you.

Work from this directory and run commands here. Do NOT cd to the parent checkout /Users/kein/Documents/workspace/dev/descvi/repo, and never read or reason about the sibling worktree phase-47-drag-reorder-in-kein — a different harness owns it.

READ .omc/state/phase47-codex-final.md FIRST. It is your complete brief: what to read, hard constraints, what is already CLOSED and must not be re-derived, the four seams where this call is worth most, the one thing to hold to the full bar, and the required report format. Follow it literally — including the instruction not to read the other .omc/state/ files, because your value here is that you are reading the artifact rather than five rounds of argument about it.

The single most important instruction in that brief: where the plan makes a claim about what shipped code does or what the corpus contains, DRIVE IT rather than reasoning about it, and positive-control your instrument before any number leaves your hands. A zero is evidence only after you have shown the probe can produce a non-zero. Every defect worth having across five rounds was found by running something — a composer that threw, a headless browser that falsified a CSS model, a timing decomposition that was off by 2.2x, a live sweep that dissolved a claimed population. None was found by reading.

The plan's own status block records that every unreviewed addition in this round carried a defect, four for four. The last revision is itself unreviewed, roughly 1,400 words of undriven prose. Hold it to the full bar.

End with an explicit verdict: APPROVE or REVISE. A conditional approve is a REVISE. Say what your verdict rests on — if you approve, name what you checked hardest so the record shows what this pass actually covered; if you revise, RANK the items, because with no second vendor pass the lead must know which genuinely block and which can ride into execution under the phase's RED-first gate obligation.

## Final prompt

---
name: architect
description: Strategic Architecture & Debugging Advisor (Opus, READ-ONLY)
model: opus
level: 3
disallowedTools: Write, Edit
---

<Agent_Prompt>
  <Role>
    You are Architect. Your mission is to analyze code, diagnose bugs, and provide actionable architectural guidance.
    You are responsible for code analysis, implementation verification, debugging root causes, and architectural recommendations.
    You are not responsible for gathering requirements (analyst), creating plans (planner), reviewing plans (critic), or implementing changes (executor).
  </Role>

  <Why_This_Matters>
    Architectural advice without reading the code is guesswork. These rules exist because vague recommendations waste implementer time, and diagnoses without file:line evidence are unreliable. Every claim must be traceable to specific code.
  </Why_This_Matters>

  <Success_Criteria>
    - Every finding cites a specific file:line reference
    - Root cause is identified (not just symptoms)
    - Recommendations are concrete and implementable (not "consider refactoring")
    - Trade-offs are acknowledged for each recommendation
    - Analysis addresses the actual question, not adjacent concerns
    - In ralplan consensus reviews, strongest steelman antithesis and at least one real tradeoff tension are explicit
  </Success_Criteria>

  <Constraints>
    - You are READ-ONLY. Write and Edit tools are blocked. You never implement changes.
    - Never judge code you have not opened and read.
    - Never provide generic advice that could apply to any codebase.
    - Acknowledge uncertainty when present rather than speculating.
    - Hand off to: analyst (requirements gaps), planner (plan creation), critic (plan review), qa-tester (runtime verification).
    - In ralplan consensus reviews, never rubber-stamp the favored option without a steelman counterargument.
  </Constraints>

  <Investigation_Protocol>
    1) Gather context first (MANDATORY): Use Glob to map project structure, Grep/Read to find relevant implementations, check dependencies in manifests, find existing tests. Execute these in parallel.
    2) For debugging: Read error messages completely. Check recent changes with git log/blame. Find working examples of similar code. Compare broken vs working to identify the delta.
    3) Form a hypothesis and document it BEFORE looking deeper.
    4) Cross-reference hypothesis against actual code. Cite file:line for every claim.
    5) Synthesize into: Summary, Diagnosis, Root Cause, Recommendations (prioritized), Trade-offs, References.
    6) For non-obvious bugs, follow the 4-phase protocol: Root Cause Analysis, Pattern Analysis, Hypothesis Testing, Recommendation.
    7) Apply the 3-failure circuit breaker: if 3+ fix attempts fail, question the architecture rather than trying variations.
    8) For ralplan consensus reviews: include (a) strongest antithesis against favored direction, (b) at least one meaningful tradeoff tension, (c) synthesis if feasible, and (d) in deliberate mode, explicit principle-violation flags.
  </Investigation_Protocol>

  <Tool_Usage>
    - Use Glob/Grep/Read for codebase exploration (execute in parallel for speed).
    - Use lsp_diagnostics to check specific files for type errors.
    - Use lsp_diagnostics_directory to verify project-wide health.
    - Use ast_grep_search to find structural patterns (e.g., "all async functions without try/catch").
    - Use Bash with git blame/log for change history analysis.
    <External_Consultation>
      When a second opinion would improve quality, spawn a Claude Task agent:
      - Use `Task(subagent_type="oh-my-claudecode:critic", ...)` for plan/design challenge
      - Use `/team` to spin up a CLI worker for large-context architectural analysis
      Skip silently if delegation is unavailable. Never block on external consultation.
    </External_Consultation>
  </Tool_Usage>

  <Execution_Policy>
    - Runtime effort inherits from the parent Claude Code session; no bundled agent frontmatter pins an effort override.
    - Behavioral effort guidance: high (thorough analysis with evidence).
    - Stop when diagnosis is complete and all recommendations have file:line references.
    - For obvious bugs (typo, missing import): skip to recommendation with verification.
  </Execution_Policy>

  <Output_Format>
    ## Summary
    [2-3 sentences: what you found and main recommendation]

    ## Analysis
    [Detailed findings with file:line references]

    ## Root Cause
    [The fundamental issue, not symptoms]

    ## Recommendations
    1. [Highest priority] - [effort level] - [impact]
    2. [Next priority] - [effort level] - [impact]

    ## Trade-offs
    | Option | Pros | Cons |
    |--------|------|------|
    | A | ... | ... |
    | B | ... | ... |

    ## Consensus Addendum (ralplan reviews only)
    - **Antithesis (steelman):** [Strongest counterargument against favored direction]
    - **Tradeoff tension:** [Meaningful tension that cannot be ignored]
    - **Synthesis (if viable):** [How to preserve strengths from competing options]
    - **Principle violations (deliberate mode):** [Any principle broken, with severity]

    ## References
    - `path/to/file.ts:42` - [what it shows]
    - `path/to/other.ts:108` - [what it shows]
  </Output_Format>

  <Final_Response_Contract>
    - Your LAST assistant message is the deliverable surfaced to callers. It MUST contain the full structured output above, including Summary, Analysis, Root Cause, Recommendations, Trade-offs, and References as applicable.
    - Do not put the substantive review only in earlier messages or tool commentary. If you draft findings earlier, repeat the final verdict/findings structure in the LAST message.
    - Never end with a content-free sign-off such as "done", "complete", "nothing further", "looks good", or "no further comments". A final response without the structured deliverable violates this agent contract.
  </Final_Response_Contract>

  <Failure_Modes_To_Avoid>
    - Armchair analysis: Giving advice without reading the code first. Always open files and cite line numbers.
    - Symptom chasing: Recommending null checks everywhere when the real question is "why is it undefined?" Always find root cause.
    - Vague recommendations: "Consider refactoring this module." Instead: "Extract the validation logic from `auth.ts:42-80` into a `validateToken()` function to separate concerns."
    - Scope creep: Reviewing areas not asked about. Answer the specific question.
    - Missing trade-offs: Recommending approach A without noting what it sacrifices. Always acknowledge costs.
  </Failure_Modes_To_Avoid>

  <Examples>
    <Good>"The race condition originates at `server.ts:142` where `connections` is modified without a mutex. The `handleConnection()` at line 145 reads the array while `cleanup()` at line 203 can mutate it concurrently. Fix: wrap both in a lock. Trade-off: slight latency increase on connection handling."</Good>
    <Bad>"There might be a concurrency issue somewhere in the server code. Consider adding locks to shared state." This lacks specificity, evidence, and trade-off analysis.</Bad>
  </Examples>

  <Final_Checklist>
    - Did I read the actual code before forming conclusions?
    - Does every finding cite a specific file:line?
    - Is the root cause identified (not just symptoms)?
    - Are recommendations concrete and implementable?
    - Did I acknowledge trade-offs?
    - If this was a ralplan review, did I provide antithesis + tradeoff tension (+ synthesis when possible)?
    - In deliberate mode reviews, did I flag principle violations explicitly?
  </Final_Checklist>
</Agent_Prompt>

You are the FINAL vendor-independent approval gate on a planning document that has had five review rounds. This is your only call — there is no second pass after you.

Work from this directory and run commands here. Do NOT cd to the parent checkout /Users/kein/Documents/workspace/dev/descvi/repo, and never read or reason about the sibling worktree phase-47-drag-reorder-in-kein — a different harness owns it.

READ .omc/state/phase47-codex-final.md FIRST. It is your complete brief: what to read, hard constraints, what is already CLOSED and must not be re-derived, the four seams where this call is worth most, the one thing to hold to the full bar, and the required report format. Follow it literally — including the instruction not to read the other .omc/state/ files, because your value here is that you are reading the artifact rather than five rounds of argument about it.

The single most important instruction in that brief: where the plan makes a claim about what shipped code does or what the corpus contains, DRIVE IT rather than reasoning about it, and positive-control your instrument before any number leaves your hands. A zero is evidence only after you have shown the probe can produce a non-zero. Every defect worth having across five rounds was found by running something — a composer that threw, a headless browser that falsified a CSS model, a timing decomposition that was off by 2.2x, a live sweep that dissolved a claimed population. None was found by reading.

The plan's own status block records that every unreviewed addition in this round carried a defect, four for four. The last revision is itself unreviewed, roughly 1,400 words of undriven prose. Hold it to the full bar.

End with an explicit verdict: APPROVE or REVISE. A conditional approve is a REVISE. Say what your verdict rests on — if you approve, name what you checked hardest so the record shows what this pass actually covered; if you revise, RANK the items, because with no second vendor pass the lead must know which genuinely block and which can ride into execution under the phase's RED-first gate obligation.

## Raw output

```text
## Summary

최종 판정은 **REVISE**입니다. Anchor receipt의 기본 방향·거리 계산은 성립하지만, non-self no-op receipt가 서버 검증에서 빠져 있습니다. 또한 refusal 대안 문구 하나가 충분조건을 약속하고, scoped-zero 측정이 여러 곳에서 다시 corpus 전체의 절대값으로 서술됩니다.

## Analysis

### MUST-FIX

#### 1. Anchor receipt의 non-self no-op 누락 — 최우선 blocker

- **계획의 주장:** “`anchorOid === the subject's own oid` is a 400”; “a direction disagreeing with the wire verb is a 400.”
- **실제:** self-anchor가 아니어도 현재 위치를 표현할 수 있습니다. `[A,B,C]`에서 B의 목적지를 `trailing(A)` 또는 `leading(C)`로 지정하면 displacement는 0입니다. 이때 `move-up`/`move-down` 어느 쪽도 유효하지 않습니다.
- **검증:** 길이 2–7의 모든 chain에서 subject·anchor·side 조합을 exhaustive 실행했습니다. self-anchor를 제외한 224 receipts 중 **42개가 non-self no-op**였습니다. 잘못된 pre-removal anchor-index 공식을 심은 양성 대조는 112회 발화했습니다. 나머지 182개 non-noop receipt에서는 splice 전 방향 판정과 결과 순서에서의 `k` 복원이 모두 일치했습니다.
- **수정 요구:** §4.3에 `destinationIndex === sourceIndex ⇒ 400`을 명시하고 G47-10b에 adjacent-anchor no-op 두 형태를 추가해야 합니다. `resolveMoveDestination`은 splice 전에 normalized `{sourceIndex, destinationIndex, direction, appliedK}`를 만들고, zero와 verb-sign 불일치를 모두 거절해야 합니다.

#### 2. `parent-has-no-flow-axis`의 대안 약속이 충분조건이 아님 — blocker

- **계획의 주장:** “부모를 auto-layout(flex)으로 바꾸면 가능합니다 / make the parent an auto-layout (flex) container first.”
- **실제:** flex는 필요조건일 뿐 충분조건이 아닙니다. 같은 부모가 `rtl`, vertical writing mode 또는 unequal `order`를 가지면 flex로 바꾼 뒤에도 `layout-not-modelled`에서 거절됩니다.
- **검증:** headless Chromium에서 `display:block; direction:rtl` 부모를 `display:flex`로만 변경했지만 계획의 admissibility conjunction은 계속 false였습니다. 같은 probe의 LTR/horizontal/equal-order 양성 대조는 true였습니다.
- **수정 요구:** paint-time에 검증 가능한 불변식으로 바꾸십시오. E1이 이미 통과했으므로 다음 문구가 정확합니다:  
  `부모에 끌기 순서를 정할 흐름 축이 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다.`  
  `This parent has no flow axis for drag-to-reorder. The panel's ↑ / ↓ still work here.`

#### 3. Scoped zero가 downstream에서 다시 절대 corpus claim으로 바뀜 — blocker

- **계획의 주장:** R47-11의 “MEASURED AT ZERO in this corpus … nothing is lost today”와 Consequences의 “all with zero subjects in this corpus.”
- **실제:** status block은 올바르게 “no sweep has enumerated the state space”라고 밝히지만, §4.2, R47-11, S47-0 및 Consequences는 다시 무범위 절대 표현을 사용합니다.
- **검증:** 기본 상태 sweep은 양성 대조가 있는 상태에서 **112/235 chains가 zero-render**, 123개가 nonzero임을 재현했습니다. conditional-container가 있는 10 routes에서 기본 상태와 24개 단일-button 상태를 조사했고, 23개를 실제 클릭했습니다. Render-inert drag는 계획과 동일한 `shop/member-detail`의 `omy3i9,0cyt4v,z76fvu,d29ipo` chain만 검출됐습니다. 이는 조사한 범위에서의 재확인이지, 미도달 복합 상태까지 포함한 부재 증명은 아닙니다.
- **수정 요구:** 모든 zero claim을 probe scope와 결합하십시오. 예: “zero among the 930 elements observed by round 3” 및 “no additional subject in default plus single-button states driven by the final vendor sweep.” 특히 R47-11의 미측정 범위는 “future corpus growth”뿐 아니라 **현재 corpus의 unobserved states**도 포함해야 합니다.

### WORTH-CONSIDERING

#### Applied `k`의 결과 타입을 명시

- **계획의 주장:** “the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`.”
- **실제:** 계산은 가능합니다. Exhaustive probe에서 모든 182 nonzero receipt의 결과 순서로부터 `k`가 정확히 복원됐습니다. 다만 현재 계획은 “RESULT”가 어떤 타입인지 명시하지 않습니다.
- **권고:** `StructuralWritePlan` 또는 one-splice composer 결과에 `appliedK`를 명시적으로 포함시키고, response와 log가 그 필드만 읽도록 고정하십시오. 이는 실행 중 타입 설계로 처리할 수도 있지만, #1 수정과 함께 적으면 gate가 더 명확해집니다.

## Root Cause

마지막 수정은 개별 발견을 국소적으로 고쳤지만 동일 의미의 다른 표현까지 정규화하지 않았습니다.

- Anchor 검증은 “self-anchor”라는 입력 모양만 금지하고, 정규화된 destination의 의미인 zero displacement를 금지하지 않았습니다.
- Refusal 문구는 가능한 개선책을 충분조건으로 승격했습니다.
- Scope qualification은 status block에만 남고 risks·stories·consequences의 절대 표현으로 전파되지 않았습니다.

## Recommendations

1. **Non-self zero displacement를 400으로 규정하고 G47-10b에 RED mutation 추가** — 낮은 노력, 계약 blocker 제거.
2. **`parent-has-no-flow-axis`의 두 언어 문구를 panel-button 불변식으로 교체** — 낮은 노력, 거짓 대안 제거.
3. **`zero`/`0/930`/`zero subjects in this corpus`를 by-cause grep하여 관찰 범위로 한정** — 낮은 노력, 네 SYNTHETIC 선언의 증거 경계 복구.
4. **Normalized destination/result 타입에 direction과 `appliedK` 명시** — 낮은 노력, 구현 및 observability 오해 방지.

## Trade-offs

| Option | Pros | Cons |
|---|---|---|
| Zero displacement → 400 | 무의미한 journal entry와 `k=0` 성공 응답 방지 | 서버 검증 및 gate 두 행 추가 |
| Zero displacement → 200 no-op | 구현이 단순함 | verb 계약과 one-request/one-undo 의미를 흐림 |
| Flex 안내 유지 | 구체적인 사용자 조언 | 다른 E2 조건 때문에 거짓 약속 가능 |
| Panel ↑/↓ 안내 | E1 이후 항상 검증 가능한 대안 | auto-layout 교육성은 감소 |
| Scope-qualified zero | 측정과 주장이 정확히 대응 | 반복 문구가 조금 길어짐 |
| Corpus-wide zero | 간결함 | 현재 probe가 증명하지 않은 범위를 주장 |

## Consensus Addendum

- **Antithesis (steelman):** `k=1`로 제한하면 기존 `moveAdjacent` 경로를 그대로 사용하고 anchor normalization, no-op receipt, applied-`k` observability를 모두 제거할 수 있습니다.
- **Tradeoff tension:** 다중 위치 drag의 UX 가치와 서버 계약·composer 복잡성 사이의 긴장입니다.
- **Synthesis:** 다중 위치 anchor 설계는 유지하되, 서버가 receipt를 normalized displacement로 변환한 뒤 zero/sign 검증을 완료하고 그 결과 객체를 splice·response·log의 단일 권위로 사용하십시오.
- **Principle violations:** P47-5 위반 가능성 높음—현재 G47-10b는 non-self no-op mutation에서 RED가 되도록 규정되지 않았습니다. Standing evidence rule 위반은 중간 수준—status의 scope가 downstream 절대 주장에 전파되지 않았습니다.

## References

- `packages/descvi/src/sidecar/server.ts#function parseExpectForOp(` — 현재 per-op receipt parser의 기준 구조.
- `packages/descvi/src/sidecar/server.ts#export function computeStructuralEdit(` — 현재 move write plan과 response 결과의 출발점.
- `packages/descvi/src/extractor/structural-edit.ts#function adjacentOpUnit(` — origin baseline과 source chain adjacency의 권위.
- `packages/descvi/src/extractor/structural-edit.ts#export function moveAdjacent(` — 현재 단일-step composer.
- `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` — 확인된 render-inert chain의 flex parent.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §4.3 — anchor receipt 서버 계약.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §4.5 — bilingual refusal map.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §7 — scoped-zero reachability risk.

검토 중 파일은 수정하지 않았고, 실행한 Vite 서버는 종료했습니다. tracked diff와 잔류 listener는 없으며 `git status --short`에는 계획 파일 자체만 untracked로 남아 있습니다.

**VERDICT: REVISE**

판정은 순서대로 (1) non-self no-op anchor receipt의 서버 계약 누락, (2) 검증 불가능한 flex 대안 약속, (3) scoped-zero의 절대 corpus claim 재발에 근거합니다. Render-inert 모집단은 제가 구동한 기본 및 단일-button 상태 범위에서는 계획의 한 chain만 재확인됐습니다.


OpenAI Codex v0.150.1
--------
workdir: /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
model: gpt-5.6-sol
provider: openai
approval: never
sandbox: danger-full-access
reasoning effort: medium
reasoning summaries: none
session id: 01a0441b-f3ba-71c2-a6c5-c4f379365c2d
--------
user
---
name: architect
description: Strategic Architecture & Debugging Advisor (Opus, READ-ONLY)
model: opus
level: 3
disallowedTools: Write, Edit
---

<Agent_Prompt>
  <Role>
    You are Architect. Your mission is to analyze code, diagnose bugs, and provide actionable architectural guidance.
    You are responsible for code analysis, implementation verification, debugging root causes, and architectural recommendations.
    You are not responsible for gathering requirements (analyst), creating plans (planner), reviewing plans (critic), or implementing changes (executor).
  </Role>

  <Why_This_Matters>
    Architectural advice without reading the code is guesswork. These rules exist because vague recommendations waste implementer time, and diagnoses without file:line evidence are unreliable. Every claim must be traceable to specific code.
  </Why_This_Matters>

  <Success_Criteria>
    - Every finding cites a specific file:line reference
    - Root cause is identified (not just symptoms)
    - Recommendations are concrete and implementable (not "consider refactoring")
    - Trade-offs are acknowledged for each recommendation
    - Analysis addresses the actual question, not adjacent concerns
    - In ralplan consensus reviews, strongest steelman antithesis and at least one real tradeoff tension are explicit
  </Success_Criteria>

  <Constraints>
    - You are READ-ONLY. Write and Edit tools are blocked. You never implement changes.
    - Never judge code you have not opened and read.
    - Never provide generic advice that could apply to any codebase.
    - Acknowledge uncertainty when present rather than speculating.
    - Hand off to: analyst (requirements gaps), planner (plan creation), critic (plan review), qa-tester (runtime verification).
    - In ralplan consensus reviews, never rubber-stamp the favored option without a steelman counterargument.
  </Constraints>

  <Investigation_Protocol>
    1) Gather context first (MANDATORY): Use Glob to map project structure, Grep/Read to find relevant implementations, check dependencies in manifests, find existing tests. Execute these in parallel.
    2) For debugging: Read error messages completely. Check recent changes with git log/blame. Find working examples of similar code. Compare broken vs working to identify the delta.
    3) Form a hypothesis and document it BEFORE looking deeper.
    4) Cross-reference hypothesis against actual code. Cite file:line for every claim.
    5) Synthesize into: Summary, Diagnosis, Root Cause, Recommendations (prioritized), Trade-offs, References.
    6) For non-obvious bugs, follow the 4-phase protocol: Root Cause Analysis, Pattern Analysis, Hypothesis Testing, Recommendation.
    7) Apply the 3-failure circuit breaker: if 3+ fix attempts fail, question the architecture rather than trying variations.
    8) For ralplan consensus reviews: include (a) strongest antithesis against favored direction, (b) at least one meaningful tradeoff tension, (c) synthesis if feasible, and (d) in deliberate mode, explicit principle-violation flags.
  </Investigation_Protocol>

  <Tool_Usage>
    - Use Glob/Grep/Read for codebase exploration (execute in parallel for speed).
    - Use lsp_diagnostics to check specific files for type errors.
    - Use lsp_diagnostics_directory to verify project-wide health.
    - Use ast_grep_search to find structural patterns (e.g., "all async functions without try/catch").
    - Use Bash with git blame/log for change history analysis.
    <External_Consultation>
      When a second opinion would improve quality, spawn a Claude Task agent:
      - Use `Task(subagent_type="oh-my-claudecode:critic", ...)` for plan/design challenge
      - Use `/team` to spin up a CLI worker for large-context architectural analysis
      Skip silently if delegation is unavailable. Never block on external consultation.
    </External_Consultation>
  </Tool_Usage>

  <Execution_Policy>
    - Runtime effort inherits from the parent Claude Code session; no bundled agent frontmatter pins an effort override.
    - Behavioral effort guidance: high (thorough analysis with evidence).
    - Stop when diagnosis is complete and all recommendations have file:line references.
    - For obvious bugs (typo, missing import): skip to recommendation with verification.
  </Execution_Policy>

  <Output_Format>
    ## Summary
    [2-3 sentences: what you found and main recommendation]

    ## Analysis
    [Detailed findings with file:line references]

    ## Root Cause
    [The fundamental issue, not symptoms]

    ## Recommendations
    1. [Highest priority] - [effort level] - [impact]
    2. [Next priority] - [effort level] - [impact]

    ## Trade-offs
    | Option | Pros | Cons |
    |--------|------|------|
    | A | ... | ... |
    | B | ... | ... |

    ## Consensus Addendum (ralplan reviews only)
    - **Antithesis (steelman):** [Strongest counterargument against favored direction]
    - **Tradeoff tension:** [Meaningful tension that cannot be ignored]
    - **Synthesis (if viable):** [How to preserve strengths from competing options]
    - **Principle violations (deliberate mode):** [Any principle broken, with severity]

    ## References
    - `path/to/file.ts:42` - [what it shows]
    - `path/to/other.ts:108` - [what it shows]
  </Output_Format>

  <Final_Response_Contract>
    - Your LAST assistant message is the deliverable surfaced to callers. It MUST contain the full structured output above, including Summary, Analysis, Root Cause, Recommendations, Trade-offs, and References as applicable.
    - Do not put the substantive review only in earlier messages or tool commentary. If you draft findings earlier, repeat the final verdict/findings structure in the LAST message.
    - Never end with a content-free sign-off such as "done", "complete", "nothing further", "looks good", or "no further comments". A final response without the structured deliverable violates this agent contract.
  </Final_Response_Contract>

  <Failure_Modes_To_Avoid>
    - Armchair analysis: Giving advice without reading the code first. Always open files and cite line numbers.
    - Symptom chasing: Recommending null checks everywhere when the real question is "why is it undefined?" Always find root cause.
    - Vague recommendations: "Consider refactoring this module." Instead: "Extract the validation logic from `auth.ts:42-80` into a `validateToken()` function to separate concerns."
    - Scope creep: Reviewing areas not asked about. Answer the specific question.
    - Missing trade-offs: Recommending approach A without noting what it sacrifices. Always acknowledge costs.
  </Failure_Modes_To_Avoid>

  <Examples>
    <Good>"The race condition originates at `server.ts:142` where `connections` is modified without a mutex. The `handleConnection()` at line 145 reads the array while `cleanup()` at line 203 can mutate it concurrently. Fix: wrap both in a lock. Trade-off: slight latency increase on connection handling."</Good>
    <Bad>"There might be a concurrency issue somewhere in the server code. Consider adding locks to shared state." This lacks specificity, evidence, and trade-off analysis.</Bad>
  </Examples>

  <Final_Checklist>
    - Did I read the actual code before forming conclusions?
    - Does every finding cite a specific file:line?
    - Is the root cause identified (not just symptoms)?
    - Are recommendations concrete and implementable?
    - Did I acknowledge trade-offs?
    - If this was a ralplan review, did I provide antithesis + tradeoff tension (+ synthesis when possible)?
    - In deliberate mode reviews, did I flag principle violations explicitly?
  </Final_Checklist>
</Agent_Prompt>

You are the FINAL vendor-independent approval gate on a planning document that has had five review rounds. This is your only call — there is no second pass after you.

Work from this directory and run commands here. Do NOT cd to the parent checkout /Users/kein/Documents/workspace/dev/descvi/repo, and never read or reason about the sibling worktree phase-47-drag-reorder-in-kein — a different harness owns it.

READ .omc/state/phase47-codex-final.md FIRST. It is your complete brief: what to read, hard constraints, what is already CLOSED and must not be re-derived, the four seams where this call is worth most, the one thing to hold to the full bar, and the required report format. Follow it literally — including the instruction not to read the other .omc/state/ files, because your value here is that you are reading the artifact rather than five rounds of argument about it.

The single most important instruction in that brief: where the plan makes a claim about what shipped code does or what the corpus contains, DRIVE IT rather than reasoning about it, and positive-control your instrument before any number leaves your hands. A zero is evidence only after you have shown the probe can produce a non-zero. Every defect worth having across five rounds was found by running something — a composer that threw, a headless browser that falsified a CSS model, a timing decomposition that was off by 2.2x, a live sweep that dissolved a claimed population. None was found by reading.

The plan's own status block records that every unreviewed addition in this round carried a defect, four for four. The last revision is itself unreviewed, roughly 1,400 words of undriven prose. Hold it to the full bar.

End with an explicit verdict: APPROVE or REVISE. A conditional approve is a REVISE. Say what your verdict rests on — if you approve, name what you checked hardest so the record shows what this pass actually covered; if you revise, RANK the items, because with no second vendor pass the lead must know which genuinely block and which can ride into execution under the phase's RED-first gate obligation.
hook: SessionStart
hook: SessionStart Completed
hook: UserPromptSubmit
hook: UserPromptSubmit Completed
codex
지정하신 최종 승인 게이트를 읽기 전용으로 수행하겠습니다. 먼저 `using-superpowers`와 이 저장소의 `omc-reference` 지침을 적용한 뒤, 저장소 파일 중에서는 요청대로 `.omc/state/phase47-codex-final.md`만 가장 먼저 읽고 그 브리프가 지정한 범위만 실측 검증하겠습니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,240p' /Users/kein/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/using-superpowers/SKILL.md && sed -n '1,260p' .agents/skills/omc-reference/SKILL.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
---
name: using-superpowers
description: Use when starting any conversation - establishes how to find and use skills, requiring skill invocation before ANY response including clarifying questions
---

<SUBAGENT-STOP>
If you were dispatched as a subagent to execute a specific task, ignore this skill.
</SUBAGENT-STOP>

<EXTREMELY-IMPORTANT>
If you think there is even a 1% chance a skill might apply to what you are doing, you ABSOLUTELY MUST invoke the skill.

IF A SKILL APPLIES TO YOUR TASK, YOU DO NOT HAVE A CHOICE. YOU MUST USE IT.

This is not negotiable. You cannot rationalize your way out of this.
</EXTREMELY-IMPORTANT>

## The Rule

**Invoke relevant or requested skills BEFORE any response or action** — including clarifying questions, exploring the codebase, or checking files. If it turns out wrong for the situation, you don't have to use it.

**Before entering plan mode:** if you haven't already brainstormed, invoke the brainstorming skill first.

Then announce "Using [skill] to [purpose]" and follow the skill exactly. If it has a checklist, create a todo per item.

## Skill Priority

When multiple skills apply, process skills come first — they set the approach, then implementation skills (frontend-design, etc.) carry it out. Brainstorming and systematic-debugging are Superpowers' most common process skills, but the rule holds for any of them.

- "Let's build X" → superpowers:brainstorming first, then implementation skills.
- "Fix this bug" → superpowers:systematic-debugging first, then domain skills.

## Red Flags

These thoughts mean STOP—you're rationalizing:

| Thought | Reality |
|---------|---------|
| "This is just a simple question" | Questions are tasks. Check for skills. |
| "I need more context first" | Skill check comes BEFORE clarifying questions. |
| "Let me explore the codebase first" | Skills tell you HOW to explore. Check first. |
| "I can check git/files quickly" | Files lack conversation context. Check for skills. |
| "Let me gather information first" | Skills tell you HOW to gather information. |
| "This doesn't need a formal skill" | If a skill exists, use it. |
| "I remember this skill" | Skills evolve. Read current version. |
| "This doesn't count as a task" | Action = task. Check for skills. |
| "The skill is overkill" | Simple things become complex. Use it. |
| "I'll just do this one thing first" | Check BEFORE doing anything. |
| "This feels productive" | Undisciplined action wastes time. Skills prevent this. |
| "I know what that means" | Knowing the concept ≠ using the skill. Invoke it. |

## Platform Adaptation

If your harness appears here, read its reference file for special instructions:

- Codex: `references/codex-tools.md`
- Pi: `references/pi-tools.md`
- Antigravity: `references/antigravity-tools.md`
- Hermes Agent: `references/hermes-tools.md`

## User Instructions

User instructions (CLAUDE.md, AGENTS.md, GEMINI.md, etc, direct requests) take precedence over skills, which in turn override default behavior. Only skip skill workflows or instructions when your human partner has explicitly told you to.
---
name: omc-reference
description: OMC agent catalog, available tools, team pipeline routing, commit protocol, and skills registry. Auto-loads when delegating to agents, using OMC tools, orchestrating teams, making commits, or invoking skills.
user-invocable: false
---

# OMC Reference

Use this built-in reference when you need detailed OMC catalog information that does not need to live in every `AGENTS.md` session.

## Agent Catalog

Prefix: `oh-my-Codex:`. See `agents/*.md` for full prompts.

- `explore` (haiku) — fast codebase search and mapping
- `analyst` (opus) — requirements clarity and hidden constraints
- `planner` (opus) — sequencing and execution plans
- `architect` (opus) — system design, boundaries, and long-horizon tradeoffs
- `debugger` (sonnet) — root-cause analysis and failure diagnosis
- `executor` (sonnet) — implementation and refactoring
- `verifier` (sonnet) — completion evidence and validation
- `tracer` (sonnet) — trace gathering and evidence capture
- `security-reviewer` (sonnet) — trust boundaries and vulnerabilities
- `code-reviewer` (opus) — comprehensive code review
- `test-engineer` (sonnet) — testing strategy and regression coverage
- `designer` (sonnet) — UX and interaction design
- `writer` (haiku) — documentation and concise content work
- `qa-tester` (sonnet) — runtime/manual validation
- `scientist` (sonnet) — data analysis and statistical reasoning
- `document-specialist` (sonnet) — SDK/API/framework documentation lookup
- `git-master` (sonnet) — commit strategy and history hygiene
- `code-simplifier` (opus) — behavior-preserving simplification
- `critic` (opus) — plan/design challenge and review

## Model Routing

- `haiku` — quick lookups, lightweight inspection, narrow docs work
- `sonnet` — standard implementation, debugging, and review
- `opus` — architecture, deep analysis, consensus planning, and high-risk review

## Tools Reference

### External AI / orchestration
- `/team N:executor "task"`
- `omc team N:codex|gemini "..."`
- `omc ask <Codex|codex|gemini>`
- `/ccg`

### OMC state
- `state_read`, `state_write`, `state_clear`, `state_list_active`, `state_get_status`

### Team runtime
- `TeamCreate`, `TeamDelete`, `SendMessage`, `TaskCreate`, `TaskList`, `TaskGet`, `TaskUpdate`

### Notepad
- `notepad_read`, `notepad_write_priority`, `notepad_write_working`, `notepad_write_manual`

### Project memory
- `project_memory_read`, `project_memory_write`, `project_memory_add_note`, `project_memory_add_directive`

### Code intelligence
- LSP: `lsp_hover`, `lsp_goto_definition`, `lsp_find_references`, `lsp_diagnostics`, and related helpers
- AST: `ast_grep_search`, `ast_grep_replace`
- Utility: `python_repl`

## Skills Registry

Invoke built-in workflows via `/oh-my-Codex:<name>`.

### Workflow skills
- `autopilot` — full autonomous execution from idea to working code
- `ralph` — persistence loop until completion with verification
- `ultrawork` — high-throughput parallel execution
- `visual-verdict` — structured visual QA verdicts
- `team` — coordinated team orchestration
- `ccg` — Codex + Gemini + Codex synthesis lane
- `ultraqa` — QA cycle: test, verify, fix, repeat
- `omc-plan` — planning workflow and `/plan`-safe alias
- `ralplan` — consensus planning workflow
- `sciomc` — science/research workflow
- `external-context` — external docs/research workflow
- `deepinit` — hierarchical AGENTS.md generation
- `deep-interview` — Socratic ambiguity-gated requirements workflow
- `ai-slop-cleaner` — regression-safe cleanup workflow

### Utility skills
- `ask`, `cancel`, `note`, `skillify`, `learner` (deprecated alias), `omc-setup`, `mcp-setup`, `hud`, `omc-doctor`, `trace`, `release`, `project-session-manager`, `skill`, `writer-memory`, `configure-notifications`

### Keyword triggers kept compact in AGENTS.md
- `"autopilot"→autopilot`
- `"ralph"→ralph`
- `"ulw"→ultrawork`
- `"ccg"→ccg`
- `"ralplan"→ralplan`
- `"deep interview"→deep-interview`
- `"deslop" / "anti-slop"→ai-slop-cleaner`
- `"deep-analyze"→analysis mode`
- `"tdd"→TDD mode`
- `"deepsearch"→codebase search`
- `"ultrathink"→deep reasoning`
- `"cancelomc"→cancel`
- Team orchestration is explicit via `/team`.

## Team Pipeline

Stages: `team-plan` → `team-prd` → `team-exec` → `team-verify` → `team-fix` (loop).

- Use `team-fix` for bounded remediation loops.
- `team ralph` links the team pipeline with Ralph-style sequential verification.
- Prefer team mode when independent parallel lanes justify the coordination overhead.

## Commit Protocol

Use git trailers to preserve decision context in every commit message.

### Format
- Intent line first: why the change was made
- Optional body with context and rationale
- Structured trailers when applicable

### Common trailers
- `Constraint:` active constraint shaping the decision
- `Rejected:` alternative considered | reason for rejection
- `Directive:` forward-looking warning or instruction
- `Confidence:` `high` | `medium` | `low`
- `Scope-risk:` `narrow` | `moderate` | `broad`
- `Not-tested:` known verification gap

### Example
```text
feat(docs): reduce always-loaded OMC instruction footprint

Move reference-only orchestration content into a native Codex skill so
session-start guidance stays small while detailed OMC reference remains available.

Constraint: Preserve AGENTS.md marker-based installation flow
Rejected: Sync all built-in skills in legacy install | broader behavior change than issue requires
Confidence: high
Scope-risk: narrow
Not-tested: End-to-end plugin marketplace install in a fresh Codex profile
```

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,260p' /Users/kein/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/using-superpowers/references/codex-tools.md && sed -n '1,320p' .omc/state/phase47-codex-final.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
## Subagent dispatch requires multi-agent support

Add to your Codex config (`~/.codex/config.toml`):

```toml
[features]
multi_agent = true
```

This enables the multi-agent tools that skills like
`dispatching-parallel-agents` and `subagent-driven-development` use.
Which tools you get depends on the multi-agent version your model
preset selects (current presets run V2; older ones run V1). Trust your
actual tool list over any table — including this one — when they
disagree.

- **Spawning:** give children a clean context with
  `spawn_agent {fork_turns: "none"}`; the default `"all"` copies your
  entire transcript into the child. On Codex 0.145+, role files under
  `~/.codex/agents/` attach to isolated forks via `agent_type`.
  Full-history forks accept `model` and `reasoning_effort` overrides
  (only `agent_type` is refused there) — isolated forks are the SDD
  default for context hygiene, not because overrides require them.
- **Fix rounds:** resume the implementer with `followup_task` — it
  delivers your message, triggers a turn, and transparently reloads a
  child the harness evicted. Never dispatch a fresh implementer on the
  theory that a spawned agent cannot be messaged again; on V2 it
  always can.
- **Lifecycle:** V2 has no `close_agent`. Finished children are
  evicted automatically when slots are needed; leaving them unclosed
  costs nothing. Only V1 sessions have `close_agent` — there, close
  reviewers when their review returns, and close each implementer
  after its task's review passes.
- **Model names:** never copy a model name from a skill, table, or old
  session into `spawn_agent` without checking it against your current
  spawn allowlist — V2 accepts only V2-capable presets and hard-errors
  on the rest.

## Waiting on children

`wait_agent` is an event subscription, not a poll: a long wait wakes
the moment a child produces mailbox activity, with the same latency as
a short one. Short-timeout polling buys nothing and costs a tool call —
and a context rebill — per poll. In measured sessions, roughly
two-thirds of all wait calls were short polls that timed out.

- While you still have local work, do not wait at all. A completed
  child's final answer is pushed into your mailbox and arrives with
  your next turn.
- When you are genuinely idle with children outstanding, wait in
  bounded stretches: `wait_agent` with `timeout_ms` 300000-600000
  (5-10 minutes). After each stretch — wake or timeout — post one
  status line, run `list_agents`, and chase any child that finished
  without reporting. Never stack polls shorter than five minutes; the
  event subscription wakes a bounded stretch just as fast as a short
  one.
- Completion mail cannot wake an idle controller (it is delivered
  without triggering a turn); covering that idle window is
  `wait_agent`'s only job. A stretch that times out with no activity
  is your cue to reconcile, not to shorten the next stretch.

## Model routing on spawns

Every `spawn_agent` you issue — including when you are yourself a
spawned child running a fan-out — sets `model` AND `reasoning_effort`
explicitly, per the Model Selection rules of the skill you are
executing. Setting `model` alone is a trap: the child's effort
silently resets to that model's default, not to yours.

Ask your human partner to add a machine-level backstop to
`~/.codex/config.toml` so any spawn that slips through still routes to
a deliberate tier instead of silently inheriting the session's most
expensive model:

```toml
[agents]
default_subagent_model = "<a mid-tier model from your spawn allowlist>"
default_subagent_reasoning_effort = "medium"
```

## Environment Detection

Skills that create worktrees or finish branches should detect their
environment with read-only git commands before proceeding:

```bash
GIT_DIR=$(cd "$(git rev-parse --git-dir)" 2>/dev/null && pwd -P)
GIT_COMMON=$(cd "$(git rev-parse --git-common-dir)" 2>/dev/null && pwd -P)
BRANCH=$(git branch --show-current)
```

- `GIT_DIR != GIT_COMMON` → already in a linked worktree (skip creation)
- `BRANCH` empty → detached HEAD (cannot branch/push/PR from sandbox)

See `using-git-worktrees` Step 0 and `finishing-a-development-branch`
Step 1 for how each skill uses these signals.

## Codex App Finishing

When the sandbox blocks branch/push operations (detached HEAD in an
externally managed worktree), the agent commits all work and informs
the user to use the App's native controls:

- **"Create branch"** — names the branch, then commit/push/PR via App UI
- **"Hand off to local"** — transfers work to the user's local checkout

The agent can still run tests, stage files, and output suggested branch
names, commit messages, and PR descriptions for the user to copy.
# phase-47 ralplan — FINAL VENDOR-INDEPENDENT REVIEW

You are the **final approval gate** on a plan that has had five review rounds. This project's planning contract requires unanimous approval from Claude lanes **and** an independent vendor on the text as it now stands. The Claude side is done. **You are the vendor side, and this is your only call — there is no second pass after you.**

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout `/Users/kein/Documents/workspace/dev/descvi/repo`, and never read or reason about the sibling worktree `phase-47-drag-reorder-in-kein` — a different harness owns it.

## Read

1. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the plan (555 lines). This is what you approve or reject.
2. **`AGENTS.md`** — binding project rules. Its verification-gates and workflow sections are the bar.
3. **`docs/prompt/worker-brief.md`** — the rules you work under.

Do not read other files under `.omc/state/` — they are five rounds of review history, and your value here is that you are reading the artifact rather than the argument about it.

## Hard constraints

Do not edit the plan or any file. Do not run any git command that writes (no commit, add, stash, checkout, branch, reset). Do not spawn sub-agents that write. Scratch under `.omc/state/` (gitignored). **Your report is your final message.**

## What is CLOSED — do not spend this call re-deriving it

Each of these has been independently reproduced by two or more lanes, several of them by execution rather than reading. Re-deriving them costs the one thing this call is for.

- **The census and every number in §3.1.** Reproduced five times by five instruments, including the internal 578 = 578 control.
- **The one-splice composer, its parse counts (2 vs 2k, measured with an instrumented `parseSync`), and R47-4's 12 ms threshold.** Built and run twice, byte-exact against the naive fold in both directions including an interior up-move.
- **The drop-on-absence ruling (iii)** and its sub-floor key. Its shipped subject was confirmed unique by a whole-corpus live sweep.
- **DR47-4(f), the anchor-vs-gap receipt shape.** Settled.
- **DR47-8 and the owner ruling** on the drag readout.
- **The live measurements**: stage-host `setPointerCapture` (with a paired no-capture control), the 91/144 parent-layout census, and the zero-population findings for the CSS exclusions and the reversal branch.
- **The conditions count, the `styleReadout` costs, the ontology preamble correction, the Cmd+Z guard order.**

If you believe one of these is wrong, say so — but say that you are contradicting a settled item, and bring the command that shows it.

## Where this call is worth most — four targets

These are the seams no lane has been able to reach. The first is the largest.

1. **The server contract of the anchor receipt — the one substantial thing NOBODY has driven.** §4.3(2)–(3) and (7). Every measurement in five rounds has been client-side geometry or composer bytes; this seam is pure contract reasoning, which is where an independent vendor is worth most. Specifically: can the destination resolution always express a destination that the `move-up`/`move-down` verb ladder plus the **origin** `expect` can validate? Is the direction-disagreement 400 derivable **before** the splice or only after? Is the **applied** `k` recoverable from the result rather than from the request?

2. **The refusal map's Korean, as a second reader.** Does any row promise an alternative the refusal cannot verify at paint time? Is any row's second clause inconsistent with its class? ⚠ **Do not re-open wording rule 1 or the bilingual rule** — both are settled and the newest row was confirmed to satisfy them.

3. **The render-inert drag's population — re-derive it, do not trust the plan's answer.** The constraint, not the conclusion: §4.2(6) now names one flex-parented subject that constructs a source-effective, render-inert drag. **Find another or prove there is none.** The corpus's conditional members are enumerable from `.descvi/edit-map.json` via `opUnitKind: 'conditional-container'`, and 112 of 235 chains render nothing in default state. If you land on the same subject, the finding is confirmed twice; if you land elsewhere, the population is larger than anyone thinks.

4. **§7's reachability seam.** Three sweeps with three different scopes are now named side by side. **Four SYNTHETIC gate-subject declarations rest on their zero-counts.** Judge whether the plan states the scope honestly enough that a later lane cannot mistake a scoped zero for an absolute one.

## ⚠ One thing to hold to the full bar

**The last revision is itself unreviewed** — roughly 1,400 words of new prose, none of it driven, written after the last Claude lane reported. The plan's own status block now records that **every unreviewed addition in this planning round carried a defect, four for four, and every one was caught by building or driving it rather than by reading.** The author states plainly that this revision is subject to the same rate.

So: **where the plan makes a claim about what shipped code does, or about what the corpus contains, drive it rather than reasoning about it** — and positive-control your instrument before any number leaves your hands. A zero is evidence only after you have shown the probe can produce a non-zero. Every defect worth having in five rounds was found by running something.

## Report

Separate **MUST-FIX** from **WORTH-CONSIDERING**. For each: quote the claim, state what is actually true, say how you established it (the command you ran or the exact source text you read), and say what the plan should say instead. Cite code by file plus function name or by exact source text, **never by line number** — this project bans line-number citations and gates against them, because 19 of 20 pins into one file were wrong within eight commits.

End with an explicit verdict: **APPROVE** or **REVISE**. A conditional approve is a REVISE.

⚠ **Say what your verdict rests on.** If you APPROVE, name the two or three things you checked hardest, so the record shows what the vendor-independent pass actually covered. If you REVISE, rank the items — because there is no second vendor pass, the lead has to know which ones genuinely block and which can ride into execution and be caught by the phase's own RED-first gate obligation.

hook: PostToolUse
hook: PostToolUse Completed
codex
브리프를 확인했습니다. 이번 검토에서는 닫힌 항목을 재논증하지 않고, 서버 anchor receipt 계약·거부 맵의 한국어 의미·render-inert drag 모집단·§7 scoped-zero 표현을 집중적으로 검증하겠습니다. 계획의 수치나 shipped-code 주장은 양성 대조가 가능한 실행 결과만 증거로 쓰겠습니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,620p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '1,320p' AGENTS.md
sed -n '1,320p' docs/prompt/worker-brief.md
rg -n \"phase-47|drag reorder|render-inert|anchor receipt\" /Users/kein/.codex/memories/MEMORY.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 exited 1 in 0ms:
# RALPLAN — phase-47 (E3 v3.5): drag-to-reorder, the drag readout, and `undo-focus-ownership`

> **Status: REVISION 3 (final).** Written against `.omc/state/phase47-revision-r3.md` — a primed closure audit, a fresh unprimed reviewer, and a **live probe lane that drove a real browser** — on top of r2's owner ruling (`.omc/state/phase47-owner-ruling-drag-readout.md`).
>
> **THE STANDING EVIDENCE RULE (r2 §E): every population claim and every timing number names the probe that produced it and its control, and each number lives in exactly ONE section.** Static probes: `.omc/state/scratch-r2/*.mjs`, re-run by this lane in r2 against an edit-map built by `buildEditMap` over every `src/app/**/page.tsx` with a sibling `spec.ts`. Live probes: round 3's lane.
>
> ### What has been DRIVEN, and on what
>
> **Browser: Chromium 148.0.7778.96, headless and headed, agreeing exactly. Hosts: `descvi:dev` :3001 with the sidecar on :7331, and the plain view :3000. Both ports free before, both stopped after; tree clean; `.descvi/screens.json` byte-identical.** Every live number below carries a planted positive control.
>
> - **Capture on `#dsh-stage` holds off-frame** (§4.1(e)) — with the paired no-capture control that makes it evidence.
> - **The live parent-layout census** (§3.1) — **91 flex / 144 non-flex of 235, 61.3 % non-flex**, cross-tabulated against the authored proxy with **zero misclassifications in either direction**.
> - **Zero-population findings for four clauses this plan keeps anyway** (§4.2(2), §4.2(3), §4.2(5)) and small non-zero counts for two tie-breaks (§4.2(4)).
> - **The one-splice composer, measured byte-exact against the naive fold with controls in both directions** (§3.3).
> - The census reproduces a **fifth** time.
>
> ⚠ **A CONTROL CAUGHT THE LIVE LANE'S OWN INSTRUMENT, AND THAT IS RECORDED RATHER THAN SMOOTHED.** Its first wrap detector counted distinct cross-axis offsets and reported **37** wrapped parents; an `items-center` row with unequal-height children produces that reading without wrapping. **The corrected count is 3**, and §4.2(4) carries the corrected number.
>
> ### What remains UNMEASURED, precisely
>
> - **Other browser engines.** Firefox and WebKit are not in this repo's Playwright cache and the repo's own e2e is Chromium-only.
> - **A real cross-application pointer drag-out.** CDP input always targets the page, so §4.1(e) measures *the browser honouring off-viewport coordinates*, **not** the OS handing the pointer to another application.
> - **Viewport-dependence of the wrap and overlap counts** (§4.2(4)) — measured at one viewport.
> - **Any chain hidden behind an in-page control a sweep did not reach.** ⚠ **THE BOUND IS SCOPE-QUALIFIED, AND r3 STATED IT WITHOUT ITS SCOPE (r5). Three sweeps ran under three different scopes and the figures are NOT interchangeable:** **round 3** swept multiple observed states over 235 chains and found **exactly 1 never reachable in any state it observed** — that is the origin of the *"1 of 235"* figure, and it is a bound **over the states that sweep drove**, not over all states; **round 4's delta lane** enumerated **215** of 235 (naive screen-id derivation, no `::` sub-screens) and swept **DEFAULT STATE ONLY**, so its zero-counts are lower bounds on coverage and it said so; **round 5's pre-codex sweep** found **112 of 235 chains render zero instances in default state.** **No figure here is wrong; what was missing is which states each was driven under, and this lane does not guess.** The honest reading: *at least* one chain is unreachable in every state anyone drove, roughly half render nothing at default, and **no sweep has enumerated the state space.** ⚠ **This matters because four SYNTHETIC gate-subject declarations rest on zero-counts, and a zero measured under an unstated scope is the seam §4.2(6)'s own falsification crawled out of** — the r4 lane read one tab of a two-tab screen and wrote a universal. **S47-0's subject audit therefore states the scope of every count it reports, per §E.**
> - **Every claim about how the gesture FEELS.** §8 routes those.
>
> ⚠ **THE PROCESS NOTE, KEPT BECAUSE IT HAS COST THIS PHASE FOUR TIMES — AND THE COUNT IS KEPT EQUAL TO THE LIST, BECAUSE P47-5's OWN STANDARD IS THAT A COUNT OMITTING ITS FRESHEST INSTANCE IS THE FAILURE IT DESCRIBES.** `AGENTS.md`: *"Cite what you re-read, not what you remember."* R0 inherited a false claim about the shield's docblock without re-opening it (§0); **r1 repeated the error inside the correction for it** (the oid-reconciliation reasons); **r2 asserted an ontology sentence was *"still literally true"* without re-running its grep — it is false at HEAD** (§4.7); **and r4 wrote that no flex-parented subject could construct the render-inert drag, having read one tab of a two-tab screen** (§4.2(6)). ⚠ **THE FOURTH IS THE MOST INSTRUCTIVE, BECAUSE IT HAPPENED INSIDE THE EDIT THAT DOCUMENTS THE FAILURE MODE (pre-mortem 4).** ⚠ **AND THE BASE RATE IS THE MOST PORTABLE THING THIS PLANNING ROUND PRODUCED, SO IT IS RECORDED HERE RATHER THAN LEFT IN A REVIEW NOTE: EVERY UNREVIEWED ADDITION MADE IN THIS ROUND HAS CARRIED A DEFECT — FOUR FOR FOUR — AND EVERY ONE WAS CAUGHT BY BUILDING OR DRIVING IT, NEVER BY READING IT.** The operative consequence for whoever implements this plan: **a paragraph nobody has executed is not evidence, however carefully it was reasoned** — which is `AGENTS.md`'s own *"a fact checked against an ARTIFACT is not verified until it is checked against the RUNNING APP"*, one level up, applied to prose. This revision re-opened every source claim it repeats and drove none of them; **it is therefore subject to the same rate.**

---

## 0. The corrected arm-table record, and what it changes

The record in `use-canvas-selection-shield.ts`, re-verified at source: **ONE** occasion on which the arm table itself was wrong — `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, so `#dsh-stage`'s own `tabIndex={-1}` made every handle, strip and apron take ROW P and retired phase-42's entire ROW D as unreachable code. **That failure is PREDICATE BREADTH, not order of arms.** The two other recorded items are wrong claims *about* the table.

**Downstream:** P47-4's ground; D47-3's count and class; **R47-1's MECHANISM** (a mechanism aimed at arm order would not have caught the failure that happened); pre-mortem 1; and **G47-1's rebuild**.

**Phase-47 adds no arm, and the reason is what the table is a partition OF.** It classifies by **target ownership** — ROW D means *this target owns its own pointer*, ROW P *its own caret*. Reorderability is a **gesture state on an ordinary target**, decided after the press by travel, and a sub-threshold press must retain **ordinary click semantics in full**. A partition by target cannot express a distinction that only exists after the target has been claimed. C45-5 is the precedent for TOPOLOGY only.

⚠ **The phase's edit to that file is TWO edits: (i) one call on the ordinary arm, and (ii) one call-site swap at `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      terminateActiveResizeGesture();` plus its import. The predicate-breadth obligation attaches to (i) alone**; (ii) is mechanical and is policed by G47-14.

---

## 1. RALPLAN-DR summary

### Principles (5)

- **P47-1 — THE ARTIFACT OWNS ORDER AND MEMBERSHIP; THE DOM OWNS GEOMETRY AND LIVE LAYOUT.** `StructureSection.tsx`'s prohibition is about re-deriving the **engine's op-unit eligibility**, a source-shape verdict the artifact publishes; this phase never re-derives it (`packages/descvi/src/react/overlay/engine/source-resolver.ts#export interface StructureEditInfo {`, produced by `packages/descvi/src/extractor/structural-edit.ts#function adjacentOpUnit(` — the same function the server re-derives the write baseline from). What IS computed client-side is whether the parent lays its children out along an axis right now: a RENDER fact the artifact does not publish and the sidecar has no DOM to answer, so **there is no second implementation for it to diverge from**.
- **P47-2 — ONE GESTURE, ONE REQUEST, ONE JOURNAL ENTRY, ONE Cmd+Z.** `packages/descvi/src/sidecar/commit-write.ts#export type JournalSubject =`: *"an undo unit is an ENTRY, so N entries would be N undos however the write was folded."*
- **P47-3 — A REFUSAL NAMES THE RELATIONSHIP THAT REFUSED, IS TOTAL OVER THE PRODUCER'S VOCABULARY, AND IS BILINGUAL.** ⚠ This plan broke each half at least once in its own text (r1's generic arm named the element; r1's `no-reorderable-sibling` was false for 108 of 130 subjects). §4.5 is where all three are closed.
- **P47-4 — THE ARM TABLE PARTITIONS BY TARGET OWNERSHIP; REORDERABILITY IS NOT A TARGET-OWNERSHIP CLASS.** The risk is undiminished and it is **predicate breadth**.
- **P47-5 — A GATE THAT HAS NOT BEEN SHOWN RED HAS NOT BEEN BUILT; A GATE WHOSE MUTATION THE CONTRACT CANNOT EXPRESS IS NOT A GATE; AND A GATE WITH NO SATISFIABLE SUBJECT IS NOT A GATE EITHER.** All three have now occurred in this plan's own text, **FIVE times, and the enumeration is kept complete because a count that omits its own freshest instance is the failure it describes**: **mutation class** — r0's G47-1 (a mutation the contract could not express), r1's G47-11b leg (i) (green on the defect and on the correct behaviour alike), **and r3's G47-16 leg (ii), which is this plan's most recent one and was described in the identical words** (§4.1(h), M4); **subject class** — r2's G47-11c and r2's G47-19, both naming shipped subjects that measurement showed cannot fire. ⚠ **The remedy for the third is the `unequal-indent` rider this plan already carries: keep the clause, declare the subject SYNTHETIC, and make authoring it an unconditional S47-0 obligation.**

### Decision drivers (top 3)

- **D47-1 — THE SUBJECT POPULATION IS SMALL AND SHALLOW, WHICH PRICES OUT EVERY PER-STEP DESIGN.** The figures live once, in §3.1.
- **D47-2 — THE NO-FLOW-AXIS REFUSAL IS THE MAJORITY CASE. ⚠ NOW VERIFIED LIVE, AND THE UNVERIFIED LABEL r2 ATTACHED IS RETIRED.** §3.1 carries the number and its control. The ontology contract already owed the refusal regardless of prevalence (`.omc/specs/interaction-ontology.md` §3.F-1 rules the non-flex case *"Reorder ambiguous (no flow axis)"* with gate *"undefined blue-line; clarify at gate"*) — **prevalence decides how much surface it deserves, and the answer is: a first-class one.** The `canInsertChild` history is the precedent: a plan justification of *"a rare refusal arrives as a 422"* was false by measurement, the refusal being the majority case.
- **D47-3 — FOUR SHIPPED, GATED MECHANISMS MEET ON THE ORDINARY CANVAS PRESS.** (i) the arm table and its one recorded predicate-breadth failure; (ii) phase-45's travel guard (`packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#        maxTravelRef.current >= POINTER_DRAG_THRESHOLD_PX`); (iii) phase-42's one-shot trailing-click latch; (iv) the shared active-drag guard, consulted at **7 production sites across 4 files**.

### Real decisions, with options

| # | Decision | Options considered | Chosen | Why the losers lost |
|---|---|---|---|---|
| **DR47-1** | Where the reorder press is recognised | **(a)** a FOURTH arm-table row; **(b)** a second capture listener on `#dsh-stage`; **(c)** a `document`-capture listener; **(d)** ONE call inside the shield's existing ordinary arm, beside `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (e instanceof MouseEvent) beginTravelRecording(e);` | **(d)** | **(a)** loses on what the table partitions by (§0). **(b)** works in the spec — `packages/descvi/src/react/overlay/canvas/selection-shield.ts#export function suppressShieldPointer(event: ShieldEvent): void {` calls `stopPropagation`, never `stopImmediatePropagation` — but gives one press two owners on one node, ordered by effect registration. **(c)** is (b) with a wider blast radius. |
| **DR47-2** | How the trailing click is suppressed | **(a)** widen phase-45's travel consumption; **(b)** arm phase-42's shipped one-shot at a terminal that **issued a request**; **(c)** a second one-shot cell | **(b)** | **(a)** moves a shipped, gated condition phase-45 spent four revisions making evaluable at its pinned point. **(c)** adds a second drop site to the unconditional `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      void takeTrailingClickSuppression();`. **(b)'s cost is two producers for one boolean**; co-occurrence needs two simultaneous pointers (disjoint targets). ⚠ Its docstring contract widens — `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#/** Called by the terminal path when a gesture ended with the primary button still down. */` is untrue of a reorder terminal; keep the name, correct the docstring. |
| **DR47-3** | What the drag shows | **(a)** live DOM reorder preview; **(b)** a drag GHOST plus the indicator; **(c)** the indicator ALONE | **(c)**; (b) a follow-up | **(a)** is refused structurally: `#dsh-screen`'s children are React's. **(b)** is a second render surface with its own theme, clipping and stacking questions. ⚠ **AND THE CLIPPING COST IS NOT ONLY THE GHOST'S (M9):** `packages/descvi/src/react/overlay/OverlayShell.tsx#              className="z-40 absolute inset-0 overflow-hidden pointer-events-none"` clips the ring layer at the frame edge, so **a pointer-following readout is clipped too** — ruled at §4.4 rather than left for U1 to discover. |
| **DR47-4** | The wire shape of an n-position move | **(a)** N sequential POSTs; **(b)** `steps: number`; **(c)** a new verb `move-to`; **(d)** a `{prevOid, nextOid}` GAP receipt; **(e)** clamp to k = 1; **(f)** an **ANCHOR receipt `{anchorOid, side}`** | **(f)** | **(d) is unbuildable by its second producer**: `StructureSection` holds ONE LINK, not a chain, so moving B up in `[A,B,C,D]` needs `prev(A)`, which lives in A's entry — every shipped ↑/↓ click would 400. **(f)** is constructible from the panel's own two fields (`prevOid`+`leading` / `nextOid`+`trailing`) and is **exactly what the hit-test produces**. **(a)** fails on undo count, round-trips (`packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export async function applyStructureEdit(` re-fetches on every outcome) and atomicity. **(b)** fails the D7 principle: a count is unverifiable against a stale chain, a coordinate 409s. **(c)** costs a new `StructuralOp` member rippling into `STRUCTURAL_OPS`, the flag ladder, `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string \| null {`'s `never` tail and `REASON_TEXT`. **(e)** — the round-1 steelman from two lanes — **rejected: the phase's most expensive instrument is the owner's live pass and a clamped gesture measures a crippled one**; its cost half is gone anyway (§3.3). ⚠ **(f) EARNED A SECOND DIVIDEND NOBODY PLANNED, AND IT DECIDES §4.2(2):** because the client names a rendered sibling instead of computing an index, **a chain member that does not render costs nothing** — which is what dissolves the conditional-sibling refusal the live lane found. |
| **DR47-5** | How the drop position is computed | **(a)** a geometric ordinal; **(b)** by IDENTITY — hit-test which sibling's box the pointer is nearest and which HALF | **(b)** | **(a)** is silently wrong on reverse order and on wrapping parents. **(b)** makes both fall out. |
| **DR47-6** | How the gesture learns flow, axis and reversal | **(a)** extend `ParentContext`; **(b)** read `getComputedStyle` in the reorder module; **(c)** refuse under reverse parents; **(d)** `packages/descvi/src/react/overlay/panel/parent-context.ts#  directionToken: string \| null;` with a computed fallback; **(e)** model full logical flow | **(b)**, with **admissibility SCOPED to the subset actually modelled** | (a)/(d) closed in round 1: `directionToken` is assigned only inside the `orderedBases` loop, so it is silent on exactly the variant/computed population M3 proved broken, and `flexDirection` comes off the same `CSSStyleDeclaration` the mandatory `display` read creates. **(c)** refuses a well-defined gesture for convenience. **(e)** loses on scope: codex drove headless Chromium and measured that `direction: rtl` reverses visual order with `flexDirection` still `row`, `writing-mode: vertical-rl` makes that `row` advance on y, and unequal child `order` makes a source reorder produce no visual movement — with a positive control in the same run. **Ruling: admit only the modelled subset and refuse otherwise**, three independent RED-whens. ⚠ **Round 3 measured all three exclusions at ZERO subjects in this corpus (§4.2(3)) — which changes their GATE SUBJECTS, not their correctness.** |
| **DR47-7** | Where the refusal is surfaced | **(a)** the panel's Korean-only `REASON_TEXT`; **(b)** a CANVAS readout, bilingual, non-operable; **(c)** silence | **(b)** for an ARMED gesture; **(c)** only below the threshold | **(a)** is the wrong surface and the wrong channel (`title` is a user-facing app string; `AGENTS.md` requires ko+en; phase-46 S46-4 reversed a Korean-only proposal on that ground). **(c) alone** teaches the user the feature is broken — at 61.3 % non-flex (§3.1) that is the majority experience. ⚠ The panel's ↑/↓ buttons are not weakened: the flow-axis refusal is a GESTURE policy, not a write constraint. |
| **DR47-8** | What the drag readout is | **(a)** a W×H readout on the RESIZE drag; **(b)** a DROP-POSITION readout on the REORDER drag | **(b)**, **owner-ruled 2026-08-27** | **The phase does (b) because the owner ruled (b)**, not because the v3 CLOSE sentence was correctly parsed — **the owner does not remember making that ruling**, so it is a weaker authority than r0/r1 treated it as and the fresh input is the strong one. The v3 CLOSE record is **not edited**. **(a) is not cancelled**: it is routed back to B-Q4's row with the ruling recorded, no phase number invented (§9.1). |
| **DR47-9** | `undo-focus-ownership` | **(a)** default focus to `#dsh-screen`; **(b)** widen the OWNERSHIP guard so `document.body` counts as owned; **(c)** restore focus by hand at the remount site; **(e)** call the shipped `packages/descvi/src/react/overlay/engine/use-preview-session.ts#export function focusStageIfOrphaned(stage: HTMLElement \| null): void {` from the panel value-commit path | **(b) is the fix; (e) rides as a placement improvement, correctly sited** | The backlog row names `document.body` as the mechanism for **both** dead windows, so **(b) alone restores Cmd+Z in both**. **(e) as r1 sited it cannot fire**: `focusStageIfOwned`'s measured table records that *"the remount lands on a LATER flush than this callback"*, so at the commit callback `orphaned` is false. **(a)** loses on host: `#dsh-stage` already carries `tabIndex={-1}`; `#dsh-screen` would need one, putting a new `[tabindex]` node inside the stage. **(c)** is (e) hand-rolled. ⚠ The evidence lives at `packages/descvi/src/react/overlay/OverlayShell.tsx#const focusStageIfOwned = useCallback(`, where a text-entry guard **was built and rejected** with two rows measured STICKY. |
| **DR47-10** | The drag subject vs `selectedTarget` | **(i)** arm only when pressed oid == selected oid; **(ii)** resolve pending edits at threshold, asynchronously; **(iii)** pass an explicit subject through the handoff; **(iv)** arm on any eligible element, switch selection **synchronously** at threshold, decline to arm unless the controller is settled-and-clean | **(iv)** | `packages/descvi/src/react/overlay/engine/use-preview-session.ts#      const oidOfTarget = selectedTarget.oid ?? selectedTarget.specId;` makes `selectedTarget` the sole subject of the post-save handoff, and the latch makes the release click return before selection resolution. **(i)** costs two gestures per reorder (this shield selects on CLICK). **(ii)** loses on a phase-42 defect that was found and **FIXED** — the hazard CLASS survives: an async commit mid-gesture can invalidate an armed gesture through an HMR reseed. **(iii)** leaves the dirty-draft bypass. ⚠ The predicate is the shipped two-reader one, `packages/descvi/src/react/overlay/panel/use-classname-commit.ts#    const settledAndClean = hasPendingEdits?.() !== true && isSettled?.() !== false;` — **`hasPendingEdits()` alone is the predicate KI-46 was filed against.** |
| **DR47-11** | The shared active-drag guard | **(a)** register with the shipped `resizeGestureGuard`; **(b)** a second guard behind ONE wrapper at all 7 boundaries; **(c)** a keyed terminal registry; **(d)** do not register | **(b)** | **(d)** is disqualified by the shield's own comment: *"reachable exactly when pointer CAPTURE FAILS … the shield would resolve a selection mid-gesture and produce a second POST for one drag."* **(a) is fatal twice**: `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#  registerTerminal(run: () => void): () => void;` documents *"registering replaces"* and registration happens at machine creation, so a reorder machine would permanently replace the resize terminal; and the guard publishes `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#export type GestureState = "idle" \| "armed-pending" \| "armed" \| "dragging" \| "terminal";` plus `armedBaseline()` to the reseed choke with *resize* semantics. **(c)** relocates the second problem. **(b)'s cost is answered by a mechanism** — one wrapper, 7 sites migrated in S47-3's commit, G47-14. |

---

## 2. What this phase ships, inherits, does not touch, and is EXCLUDED from

**The scope line, quoted from `docs/e3/tracker.md` §"v3 CLOSE (2026-08-24)" — byte-identical, and NOT edited:**

> **Drag-to-reorder → IN, as phase-47 of a v3.5 follow-up pair.** The gesture rides v2's existing `move-up`/`move-down` verbs (no new write class) with the blue insertion indicator, and carries the cheap B-Q4 mitigation (a W×H readout during drag) since this gesture is where dragging blind bites.

⚠ **This quote's authority is weaker than r0 and r1 treated it as: the owner does not remember making the ruling.** The readout half is now governed by the fresh input of 2026-08-27 (DR47-8). The rest — riding the existing verbs, no new write class, the blue insertion indicator — is unchallenged and is what this phase builds, as is the v3.5 line's *"undo-focus-ownership belongs with 47"*.

**Also lands here, ruled in §4:** the gesture's arming, subject rule, one-per-press rule and terminal (§4.1); the drop resolution, its total hit-test and its scoped layout admissibility (§4.2); the anchor-receipted single-request move over a **one-splice composer** (§4.3); the indicator and the drop-position readout (§4.4); the refusal set (§4.5); `undo-focus-ownership` (§4.6); the ontology amendments (§4.7).

**Inherits without change:** `packages/descvi/src/extractor/structural-edit.ts#export const STRUCTURAL_OPS: readonly StructuralOp[] = ['delete', 'move-up', 'move-down', 'duplicate', 'insert-after'];`; the five-verb flag ladder; `packages/descvi/src/extractor/structural-edit.ts#function baselineFor(ctx: ModuleContext, loc: OpUnitLocation): StructuralBaseline {` and the D7 receipt semantics; the shield's three-arm table **unchanged in every arm**; phase-45's travel guard **unchanged**; `deriveParentContext`'s field set; the spacing family; KI-10's inheritance.

⚠ **`POINTER_DRAG_THRESHOLD_PX`'s stale header is corrected as a free rider**: it says *"ONE SYMBOL, THREE CONSUMERS"*; four modules import it today, so reorder is the **fifth importer and the fourth drag classifier**.

**Does NOT touch:** any serializer; `ParentContext`'s shape; the panel's `StructureSection` affordance record — **no exceptions**, because the anchor receipt needs only the two fields the panel already holds; the handle-geometry admission rules (phase-48); `.descvi/screens.json`'s content **except** for S47-0's fixture authoring.

**EXCLUDED, each with its reason and its destination:**
1. **B-Q5** → **phase-48**, owner ruling 2026-08-25.
2. **Marquee / rubber-band** → **deferred-v4**. §4.1's arming requires the press to resolve to a `[data-oid]` element inside `#dsh-screen`, so the stage background stays unclaimed. **G47-2 keeps that true.**
3. **Cross-parent drag** → `deferred-v2 (hard)`. §4.2's chain is scoped to ONE `parentOid` by construction.
4. **Alt / Cmd / Ctrl + drag** → unchanged. A modifier-held press **does not arm reorder; existing click behaviour is unchanged.** A modifier acquired mid-gesture is ruled at §4.1(f).
5. **Multi-select drag (N > 1)** → OUT; §4.1(b) carries the argument, which is about the click arm's ORDER.
6. **`selection-ring-treatment`, `spacing-affordance-mark`, KI-54** → not picked up.
7. **KI-47** → **NOT TAKEN, lead-ruled** (§9.2): it needs a fresh owner input, not a lead inference.
8. **The resize W×H readout** → routed back to B-Q4's row, **excluded but NOT cancelled** (§9.1).
9. ⚠ **Modelling `rtl` / vertical writing modes / unequal `order`** → out by DR47-6(e); the gesture refuses on them and names the panel as the working alternative. **Zero subjects in this corpus (§4.2(3))**, so nothing is lost today.

---

## 3. Repo facts

### 3.1 The census, the singleton split, and the parent-layout split — the ONE home for all of these numbers

**Static probes** (`.omc/state/scratch-r2/{census,singletons,split,tally}.mjs`, re-run by this lane in r2; reproduced independently five times across rounds 1–3):

| Quantity | Value |
|---|---|
| oid entries / entries with `canMoveUp \|\| canMoveDown` | 770 / **578** |
| chain components / orphans | **427** / 0 |
| admissible multi-member chains (≥2) / members in them | **235 / 578** |
| chains of ≥3 / ≥4 / longest | **62 / 21 / 7** |
| component-length histogram | 1×192, 2×173, 3×41, 4×7, 5×6, 6×5, 7×3 |

**Internal control:** *members in multi-member chains* equals *entries with `canMoveUp || canMoveDown`* exactly (578 = 578), by two independent paths.

**The 192 singletons split three ways by refusal PAIR** (rows sum to 192): **22** `no-adjacent-sibling` both ways — genuinely no neighbour; **108** where a neighbour exists and is not an editable op-unit (57 + 39 + 12); **62** structurally ineligible (26 `unsupported-parent`, 24 `target-bears-data-screen`, 9 `unsupported-container`, 3 `non-canonical-separator`). **The cause of the 108 was DRIVEN:** in `src/app/lab/tests/style-edit/page.tsx`, `v002k2`/`5pznp9`/`sms60s`/`hakgqo` are four *visibly adjacent* children of a `flex flex-col` parent each reporting `unsupported-sibling` with `prev=null next=null`; **strip the intervening `{/* … */}` JSX comments and re-run `buildEditMap` and `v002k2` reads `prev=5n09bh next=5pznp9`, fully eligible.** A JSX comment severs the chain, because `adjacentOpUnit` requires one canonical separator and a comment is not one — **and the user cannot see it.**

⚠ **All 192 carry a typed reason for BOTH move ops, so §4.5's `undefined` arm is measured at ZERO occurrences today.** It exists because the producer's TYPE admits it (`reasons?: Partial<Record<StructuralOp, StructuralRefusalReason>>`, omitted when empty) and because the shipped panel carries the equivalent at `packages/descvi/src/react/overlay/panel/StructureSection.tsx#function fallbackReason(op: StructureOp, structure: StructureEditInfo): string {`.

**The refusal tally over `move-up`/`move-down` across `src/app` — 854 REFUSALS (not entries):** `no-adjacent-sibling` 541 · `unsupported-sibling` 189 · `unsupported-parent` 52 · `target-bears-data-screen` 48 · `unsupported-container` 18 · `non-canonical-separator` 6 · **`unequal-indent` 0** (positive-controlled: re-indenting a real line makes it 4). ⚠ **`unsupported-sibling`'s 189 splits by MOMENT (M9): 165 arm-time (on singletons) and 24 fold-step (on multi-member chain members)** — so §4.5's wording must be true at **both** moments, not merely re-scoped from one wrong moment to another.

**THE PARENT-LAYOUT CENSUS — LIVE, and it is the authoritative reading.** Round 3's lane measured computed layout on the running app over all 235 multi-member chains: **91 flex / 144 non-flex — the no-flow-axis refusal is the majority case at 61.3 %.** Cross-tabulated against the authored-class proxy: **zero misclassifications in either direction**; all movement is the proxy's 19 unknowns resolving **8 flex / 11 block**. ⚠ **Both of the proxy's stated edges held as edges**: 83 was a lower bound on flex (→ 91) and 133 + 19 an upper bound on non-flex (→ 144). **The proxy is kept beside the live number as the corroborating reading** — 133 non-flex / 83 flex / 19 unknown, of the 133: 54 `no-class`, 79 real non-flex className **of which 15 are `grid`**, which is the figure §4.5's wording rule 2 rests on. ⚠ *(The `no-class` classification survives here empirically because `src/app/globals.css` contains zero `display:` declarations and zero occurrences of `flex` — an empirical fact about this tree, not a general rule.)*

⚠ **The oid reconciliation, re-opened at source in r2 because r1 carried both of its reasons without re-reading them and both were false:** `798` static `data-oid=` − `24` (`src/app/page.tsx`, the one page with no sibling `spec.ts`) − `3` (`insert-scratch`'s three occurrences are `data-oid="…"` **ellipses in a file-header docblock**, not duplicate oids) − `1` (`wcall1`, one real element plus one docblock mention) = **770**. **The corpus has exactly one duplicated oid string and it is a comment.**

### 3.2 The engine's published chain, and what terminates it (READ)

The chain links only across **exactly one canonical separator** to a `JSXElement` **or an admissible `{cond && <el/>}` container** bearing a well-formed oid, per `(parent, screen partition)`. ⚠ **That parenthetical is load-bearing and §4.2(2) is where it lands: the artifact links siblings the DOM can never show together.**

⚠ **`adjacentOpUnit` and `locateOpUnit` are NOT exported.** S47-2 does not export them; it adds one exported entry point beside them — `resolveMoveDestination(ctx, screenId, oid, anchorOid, side)` — so the chain walk stays in the module that owns `adjacentOpUnit`.

⚠ **`.map()` BODIES ARE ORDINARY SUBJECTS.** The container is not an op-unit, but elements inside it are: `src/app/sandbox/resize-repeat-list/page.tsx#      <ul data-oid="smlist" className="flex flex-col gap-2">` holds a chain, and `smcell`/`smname`/`smtagg` form a three-member chain under `smroww`, rendered four times. ⚠ **`smroww` itself is a SINGLETON (`canMoveUp: false, canMoveDown: false`, no parent, no neighbours) and can never be a drag subject** — which is what falsified r2's G47-19 (§4.4).

### 3.3 One request, one journal entry; and the composer that actually runs (READ + RUN)

`packages/descvi/src/sidecar/server.ts#        { files: [absSpec, absPage], subject: structureSubjectFor(intent.op, screenId, oidValue), journal: { mode: 'push' } },` — one `push` per request. `packages/descvi/src/sidecar/server.ts#export function computeStructuralEdit(` runs inside `commitWrite`'s `prepare`; its move arm returns `{ nextPage, nextSpec: null }` — a move touches `pageSource` only, and the fold belongs inside that arm. `JournalEntry` stores whole-file `before` bytes for **both** declared files, which is why one Cmd+Z restores byte-for-byte rather than replaying k inverse moves.

⚠ **THE k-SWAP FOLD r2 SPECIFIED DOES NOT RUN, AND TWO LANES WATCHED IT THROW.** `spelled composer k=1: equals naive → true; k=2, k=3, k=6 → THREW span-sentinel-failed` (on `shop/member-list`, `reparse-failed` at k=2). **`resolveJsxChildOp` derives spans from `ctx.mod`, whose offsets address the buffer `moduleContext` parsed; `swapSpans` swaps spans of unequal length, so every later offset shifts and step 2 hands stale spans to a buffer they no longer describe. The parse is not per-step overhead to be hoisted — it is what makes each step's spans valid.** ⚠ **And the failure is `span-sentinel-failed`, an INTERNAL error, so §4.3(5)'s *"any step's typed refusal aborts `prepare`"* does not catch it.**

⚠ **THIS REPO HAD ALREADY WRITTEN THE LESSON DOWN, IN THE SAME FILE, AND THE PLAN REACHED PAST IT.** `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` — `cutSpans`'s own docblock, which exists because *"Removes N disjoint spans from `source` in ONE pass and ONE re-parse."* **The correct shape is ONE-SPLICE, not a k-swap loop.**

**Measured, with controls in both directions** (round-3 lane, subject `src/app/shop/order-detail/page.tsx`, the 7-member chain `kh1mfx…thbzev`, page **40,979 bytes** — ⚠ *r3 wrote "39.8 KB", which is that file's JS string length and not its byte size; two units in one sentence, inside the acceptance criterion for a byte-oriented composer*):

| reading | value |
|---|---|
| one-splice k = 6 equals the naive 6-step fold, byte for byte | **true** |
| CONTROL — no move (0→0) is byte-identical to source | **true** |
| CONTROL — wrong destination (0→5) differs from the naive k = 6 | **true** |
| naive k = 6 fold, median | **34.436 ms** |
| one-parse one-splice k = 6 (no verify reparse), median | **4.538 ms** |
| `moduleContext` / `resolveJsxChildOp` warm / `swapSpans` incl. its own reparse | **2.628 / 0.233 / 2.911 ms** |

⚠ **ROUND 4 BUILT THE ONE-SPLICE COMPOSER AND CONFIRMED IT.** Byte-exact against the naive fold **in both directions, including an interior up-move (index 3 → 1) that no earlier round had tested**; **2 parses against the naive fold's 12, measured with an instrumented `parseSync` rather than derived arithmetically**; **6.803 ms** against R47-4's pre-committed 12 ms.

⚠ **`swapSpans` ends on `reparseOrThrow`, so ONE `moveAdjacent` is TWO parses** (`packages/descvi/src/extractor/structural-edit.ts#export function swapSpans(`), and the timings confirm it arithmetically: `5.616 ≈ 2.628 + 0.233 + 2.911`. **A correct k-swap fold's best case is therefore 21.49 ms.** ⚠ **These numbers are page-size dependent — on `shop/member-list` (9,656 B) the same three read 0.662 / 1.490 / 9.041 ms** — which is why R47-4 names its subject.

### 3.4 Neither the authored reader nor a naive live read is sufficient (READ + RUN)

`packages/descvi/src/react/overlay/panel/parent-context.ts#  if (variantControlsDirection) {` is tested **before** `baseIsFlex` and `computedIsFlex`, so a parent carrying `md:flex-row` below the `md` breakpoint reports `directionSource: "variant"` and never reaches `"unresolved"` while its computed `display` is `block`. `packages/descvi/src/react/overlay/engine/tailwind-class-model.ts#export type ParentDirection = "row" | "col" | "unset" | "unsupported";` has four members and `"unsupported"` is reachable without `"unresolved"`. §4.2(3)'s live read makes both moot.

⚠ **And the live read alone is not sufficient either — driven in headless Chromium:** `flexDirection` reads `row` while `direction: rtl` reverses visual order; `writing-mode: vertical-rl` makes that `row` advance on y; unequal child `order` makes a DOM reorder produce no visual movement. Positive control in the same run: plain LTR flex, moving C to the first DOM position moved it x=48 → x=8.

### 3.5 The shield's ordinary arm and click arm, in order (READ)

Press: zero `maxTravelRef`; drop the trailing-click latch; return if ROW P; `preventDefault()` and return if ROW D; else `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      suppressShieldPointer(e);`; then `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (e instanceof MouseEvent) beginTravelRecording(e);`. Bound for **`mousedown` AND `pointerdown`** at capture on `#dsh-stage`.

Click, in order: `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      const trailing = takeTrailingClickSuppression();` → `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (trailing || isResizeHandleEvent(e)) {` (suppress and return) → **only then** the travel check. **The latch branch precedes the travel check.**

### 3.6 The Cmd+Z guard order, and the two focus mechanisms (READ)

In order: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` → text-entry return → `if (!stage?.isConnected) return;` → `packages/descvi/src/react/overlay/OverlayShell.tsx#const owned = stage.contains(active)` with its host disjunct. **A `null` `activeElement` bails at the FIRST guard**, above the text-entry guard.

`focusStageIfOrphaned` (predicate `active === null || active === document.body || active.isConnected === false`) is called from exactly one site, `packages/descvi/src/react/overlay/engine/use-preview-session.ts#      focusStageIfOrphaned(stageRef.current);`. Its sibling `focusStageIfOwned` carries a measured three-row table: *"the remount lands on a LATER flush than this callback. At restore time the ticket element is connected and focused on EVERY path."* **That table also records that the three panel controls differ**: the chip add-input is keyed and remounts; `EditableDescription` and `#dsh-name-input` re-seed in place and **keep focus**. A text-entry guard **was built on that path and rejected**, two rows measured STICKY.

### 3.7 The drag subject is not `selectedTarget`, and the panel holds one link (READ)

`packages/descvi/src/react/overlay/engine/use-preview-session.ts#      const oidOfTarget = selectedTarget.oid ?? selectedTarget.specId;` is the sole subject of the post-save handoff. `StructureSection` receives only the selected oid's `StructureEditInfo` — one link, not a chain. The dirty predicate is `packages/descvi/src/react/overlay/panel/use-classname-commit.ts#    const settledAndClean = hasPendingEdits?.() !== true && isSettled?.() !== false;`, the shipped repair for **KI-46**.

### 3.8 The readout family, and where its nodes actually live (READ)

`packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function styleReadout(node: HTMLElement, isDark: boolean): void {` is module-private with **THREE** call sites in its own file, and: its base tone is the **REFUSAL's palette** with two callers each overriding three colour lines **in a specific order** because the `border` shorthand resets all four sides; it hard-codes `zIndex = "41"` — ⚠ **but the family's DRAG member is 44**: the independent copy in `use-spacing-drag.ts` sets 44 with `packages/descvi/src/react/overlay/canvas/use-spacing-drag.ts#      popup.style.zIndex = "45";` above it; `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#const READOUT_ACCENT_PX = 3;` is module-private in **both** files and read as TEXT by a shipped gate (`packages/descvi/src/react/overlay/__tests__/spacing-readout-accent.test.ts#      const m = /const READOUT_ACCENT_PX = (\d+);/.exec(source);`) that requires **both** declarations and requires the spacing copy to survive; and `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function layoutReadouts(` places the family as a selection-anchored STACK a pointer-following readout cannot join.

⚠ **AND ALL THREE READOUTS ARE CHILDREN OF `#dsh-handle-layer`, NOT OF THE RING LAYER (M4).** `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#      const hint = ensureReadout(host, INSTANCE_HINT_ID);` — and `host` is `handleLayerRef.current`. **`visibility` inherits, so hiding the handle layer hides the instance hint**, which is exactly the node §4.1(h) says it keeps visible.

⚠ **`#dsh-ring-layer` carries `overflow-hidden`** (`packages/descvi/src/react/overlay/OverlayShell.tsx#              className="z-40 absolute inset-0 overflow-hidden pointer-events-none"`), so anything in it is clipped at the frame edge.

---

## 4. The design

### 4.1 Arming, ownership, subject and terminal (RULED — DR47-1, DR47-2, DR47-10, DR47-11 — C47-1)

**C47-1.** A headless `canvas/reorder-drag-machine.ts` and a wiring hook `canvas/use-reorder-drag.ts`; **two edits to `use-canvas-selection-shield.ts`** (§0). The arm table is unchanged in every arm.

**(a) CANDIDATE vs ELIGIBLE.** A press becomes a **CANDIDATE** iff: (1) it took the ordinary arm; (2) **no modifier at the press**; (3) the selection holds at most one member, read from the pinned mirror `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#  const selectionRef = useRef<readonly SelectionMember[]>(EMPTY_SELECTION);`; (4) it resolves through the shield's own container-scoped resolution to a `[data-oid]` element inside `#dsh-screen`; (5) **the controller is SETTLED AND CLEAN** — the shipped two-reader predicate (§3.7). ⚠ Term 5 does not *guarantee* cleanliness; **it declines to arm in the window where the controller's confirmed string is stale**, which is where §4.1(c)'s synchronous selection switch would move `identityRef` under an in-flight commit and make its R1 guard **drop the write — a committed token disappearing silently.**

A candidate that crosses `packages/descvi/src/react/overlay/canvas/pointer-thresholds.ts#export const POINTER_DRAG_THRESHOLD_PX = 4;` becomes **ARMED**, and arming evaluates **ELIGIBILITY**; an ineligible arm **arms into a REFUSING state**.
- **E1 — a reorderable neighbour exists.** Failure splits three ways per §3.1: **22** → `no-reorderable-sibling`; **108** → `sibling-not-editable`; **62** → the engine's own reason through §4.5's total map.
- **E2 — the parent is a live flow container in the modelled subset** (§4.2(3)).
- **E3 — the drop table can be built** (§4.2(2)). **Failure splits two ways: AMBIGUITY → `chain-member-not-locatable`; FEWER THAN TWO RESOLVED MEMBERS IN THIS COPY → `no-sibling-in-this-copy` (r4).** ⚠ **E3 is the only one of the three that is INSTANCE-SCOPED** — E1 is a property of the source chain and E2 of the parent, while E3 is a property of *which rendered copy the user pressed*, and that is why its second arm's sentence names the copy.

⚠ **WHY NO SETTLEMENT BARRIER, stated because the sibling gesture has one.** `resize-gesture-guard.ts`'s `armed-pending` state exists because a resize gesture **captures a className baseline it will compose on**. A reorder gesture composes nothing from the className; its baseline is the structural one, re-derived server-side under the write lock. The barrier's purpose does not apply, and the interaction that remains — the arm-time selection switch against an in-flight commit — is what term 5 **declines** rather than awaits.

⚠ **What the new predicate must NOT match** (the S47-3 brief must have the implementer state it back): any target under `[data-dsh-handle]`; the stage background or any `#dsh-stage` descendant outside `#dsh-screen`; any node under `#dsh-ring-layer`; a press carrying any modifier.

**(b) THE MULTI-SELECT EXCLUSION — SUSTAINED ON THE CLICK ARM'S ORDER.** A press-time modifier read is legitimate for *arming*, a gesture-start question. The case phase-45's ruling exists for — Shift acquired between press and release — is covered twice and neither cover is that read: if the gesture issued a request the latch is armed and the click arm suppresses **before** the travel check; if it issued none, the travel check swallows it on `shiftKey && travel ≥ threshold`. At N > 1 the gesture never becomes a candidate.

**(c) THE SUBJECT.** At arming — synchronously — the machine switches the selection to the drag subject through the shipped `applySelection` path, so **subject ≡ `selectedTarget` by construction** and the post-save handoff is correct **without being changed**.

**(d) ONE ARM PER PRESS, AND THE `pointerId` PRECONDITION.** Idempotent over the `mousedown`/`pointerdown` pair on `pointerId`, in `beginTravelRecording`'s shape. A **precondition, not defence in depth**: `setPointerCapture(e.pointerId)` is not expressible from a `mousedown`.

**(e) CAPTURE ON `#dsh-stage` — MEASURED HERE, NOT INHERITED.** ⚠ **r0–r2 declined to claim phase-42's handle-host measurement for a stage host; round 3 measured the stage host directly.** Chromium 148.0.7778.96, headless and headed agreeing: dragging 500 px past all four edges and the corner, `pointermove` keeps arriving, `pointerup` arrives at the off-frame coordinate with `pointerId 1`, `target === #dsh-stage`, capture still held, and **`pointercancel` 0 in 15 drags**. **The paired control is what makes it evidence: same host, same listeners, capture removed → `outsideViewport = 0` and `pointerup = 0`.** ⚠ **Two limitations carried verbatim: CDP input always targets the page, so this measures the browser honouring off-viewport coordinates and NOT the OS handing the pointer to another application; and only Chromium was measured** — Firefox and WebKit are not in this repo's Playwright cache and its e2e is Chromium-only.

**(f) THE TERMINAL** is one idempotent transition over: `pointerup`, `pointercancel`, `Escape` at `document` capture, **the shared active-drag guard's consultation** (DR47-11 — what delivers "selection change"), screen change, edit-mode off, and **unmount**; its final act returns the machine to `idle`. ⚠ **UNMOUNT IS A SEPARATE OBLIGATION FROM THE 7 BOUNDARY CALLS (M9):** the reorder guard needs its own `reset…()` counterpart to `resetResizeGestureGuard()`, which drops the registration and clears the latch after an unmount mid-gesture — and that module's docblock states why `terminate()` cannot be it (*"a teardown that left one behind would hand the next mount"* a live gesture nobody is performing). **S47-3 ships it.** ⚠ A modifier acquired **mid-gesture does not abort**: aborting would make the outcome depend on a key state whose effect is invisible until release, and the meanings it would defer to are deferred-v2/v4 and unimplemented.

**(g) THE LATCH IS ARMED ONLY ON A TERMINAL THAT ISSUED A REQUEST.** Arming on every armed drag composes with §4.2(6)'s no-op detection into a live regression: a 5 px out-and-back on a reorderable element would suppress a selection that happens today, across the majority of the canvas. **G47-15 is the row; §8 U3 carries the harm.**

**(h) FURNITURE DURING THE DRAG — `visibility`, never unmount, WITH ONE EXPLICIT RE-DECLARATION.** Hidden for the duration and restored at the terminal: `#dsh-hover-ring`, `#dsh-selection-ring`, `#dsh-selection-ring-pool`, `#dsh-selection-badge`, `#dsh-handle-layer`, `#dsh-spacing-layer`.
⚠ **`#dsh-ring-instance-hint` IS A CHILD OF `#dsh-handle-layer` AND `visibility` INHERITS (§3.8), SO r2's RULE HID THE VERY NODE IT SAID IT KEPT (M4).** R47-8's only mechanism was inoperative and G47-16 leg (ii) was green on the defect and on the correct behaviour alike. **The fix is an explicit `visibility: visible` re-declaration on the hint, named here in C47-1**, and G47-16(ii) is re-aimed at deleting that override. The two other readouts in that layer — `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint` — are **left to inherit the hide**, which is what we want.
⚠ **The hiding is `visibility: hidden`, never removal**, because `e2e/resize-handles.spec.ts#    const handleLayerEl = document.getElementById("dsh-handle-layer") ?? layerEl;` falls back precisely when that node is **absent**; an unmount would make phase-47 the first runtime mechanism that makes a never-fired fallback reachable. **§9.5's F46-D disposition rests on this mechanism.**
⚠ UNVERIFIED whether hiding reads better than leaving it (§8 U4) — and §4.4 no longer depends on the answer.

### 4.2 The drop resolution (RULED — DR47-5, DR47-6 — C47-2)

**C47-2.** The **ORDER half is built once at arm; the GEOMETRY half is re-read per move** (rects change under `#dsh-screen` scroll, window resize and reflow), which is what G47-4's *"the last reading is stale"* refers to.

1. **ORDER — from the artifact, once.** Walk `prevOid` to the head and `nextOid` to the tail. No DOM.
2. **GEOMETRY — from the DOM, per move, parent-scoped, and RESOLVED-MEMBERS-ONLY.** Search `subjectEl.parentElement`'s children for each chain oid. A member must resolve to **at most one element, and to a DIRECT CHILD** of that node. Then:
   - **a member resolving to ZERO nodes is DROPPED from the table, not a refusal;**
   - **`chain-member-not-locatable` refuses the whole gesture** on AMBIGUITY only — when the **subject itself** does not resolve, when a member resolves to **more than one** node in that parent, or when a member resolves to a **deeper descendant**;
   - ⚠ **and when FEWER THAN TWO members resolve, the refusal is a DIFFERENT key — `no-sibling-in-this-copy` — because nothing failed to be found (r4).** A run of one is a well-defined *nothing here to trade places with* state, and it is **INSTANCE-SCOPED**: the same chain in the copy next door has two. Routing it through `chain-member-not-locatable` would tell the user the siblings could not be located when the sibling simply is not rendered here — the wrong relationship, which is wording rule 1's own failure.

   ⚠ **THE DROP-ON-ABSENCE RULE IS A r3 RULING, AND IT IS AVAILABLE ONLY BECAUSE OF DR47-4(f).** Round 3 measured that r2's require-every-member rule refuses on a population the plan never named: **the artifact links mutually-exclusive `{cond && <el/>}` siblings into ONE chain** — §3.2's parenthetical, load-bearing at last. Measured over 235 chains: **6 refused in every observed state (2.6 %), 9 refused only in SOME observations (3.8 %), 1 never renders at all (0.4 %), 219 never refused (93.2 %).** The clearest **at source** is `sandbox/resize-repeat-list`, whose `smndaa`/`smndbb`/`smndcc` are three `{queueState === 'x' && <p/>}` blocks inside the 5-member chain `[smlist, smndaa, smndbb, smndcc, smlnkk]` — each an `opUnitKind: 'conditional-container'`, exactly one rendering per state. ⚠ **It is NOT a draggable subject and the sentence must not read as though it were (r4): that chain's parent computes `block`, so it refuses at E2 before any of this is reached.** The same source shape appears in `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`. **The draggable instance of this class is `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` (flex-parented in all five copies), and it is the one the gates use.**
   ⚠ **THE 9 "SOMETIMES" CHAINS ARE THE HALF THAT FORCED A RULING RATHER THAN A SENTENCE: under r2's rule the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed** — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, the **first** missing `rpb6hb` and the other five complete, giving 55 passing scopes and 11 refusing. **A per-instance verdict on a per-chain contract, and no refusal wording survives a user who just did the same drag successfully one column over.** **Options: (i) accept the per-instance verdict and word around it; (ii) refuse the chain everywhere it can ever be incomplete — not decidable client-side, since it requires knowing every state; (iii) DROP unrendered members from the table and refuse only on ambiguity or on fewer than two survivors. RULED (iii).** It costs nothing, because **the anchor receipt never computes an index** — the client names a rendered sibling and a side, and the server resolves it against the live source chain, which still contains the unrendered member. The only consequence is that a user cannot drop *between* two positions separated solely by unrendered members, which is invisible to them.
   ⚠ **AND r3's CLOSING SENTENCE FOR THIS RULING WAS FALSE ON A SHIPPED SUBJECT — MEASURED IN DEFAULT STATE, AND THE CORRECTION IS r4's ONE BLOCKING EDIT.** r3 wrote *"under (iii) all 15 chains admit in every instance, and the per-instance inconsistency does not exist."* **It does not, for a 2-member chain whose one sibling is conditional.** `src/app/lab/tests/shared-oid/page.tsx`'s chain `d4b6s3,d8m1w7` resolves **2 / 2 / 2 / 2 / 1 across five instances, all five parents flex** — the separator `src/app/lab/tests/shared-oid/page.tsx#{i < arr.length - 1 && <span data-oid="d8m1w7"` is conditional on not being last, so the fifth `<li>` renders one member and falls below (iii)'s own floor **while every arming precondition holds**: term 4 passes (`d4b6s3` renders in all five), E1 passes (`canMoveUp: false, canMoveDown: true`, verified in the map), E2 passes. **The user drags the last step label, is refused, drags the identical label one column left, and it works** — verbatim the sentence this paragraph uses to reject option (i). Controls: removing the separator from instance 0 gives `1,2,2,2,1`; planting one into the last gives `1,2,2,2,2`, so the detector both produces a 1 from a change and erases the observed 1.
   ⚠ **THE ROOT CAUSE IS THIS PHASE'S RECURRING SHAPE AND IS WORTH NAMING: the ruling was derived from the right measurement and validated against the population it was derived FROM** — chains where *some* member goes missing — **never against chains where ENOUGH go missing to fall below its own floor. For a 2-member chain with one conditional sibling those are the same event.**
   **RULED (r4): (iii) STANDS — it is correct on its merits and it genuinely dissolves the refusal wherever two survivors remain. What changes is that the sub-floor case gets its OWN key** (the bullet above), whose sentence names the *copy* rather than the parent, so it survives the user who just succeeded one column over — and predicts it. **Its gate leg is G47-11d and its subject is SHIPPED, not synthetic.**
   ⚠ **THE `.map()` ATTRIBUTION r1 AND r2 GAVE THE "SEVERAL MATCHES" ARM IS WITHDRAWN — MEASURED WRONG, AND WRONG BECAUSE OF A SCOPE THE PLAN ITSELF SPECIFIED.** `.map()` bodies produce **52 many-node readings across 20 chains at PARTITION scope, and 0 at the PARENT scope §4.2(2) uses**, because each repeat renders under its own parent: `smcell`/`smname`/`smtagg` resolve once per `<li>`, all direct children, under a `flex flex-row` parent. **0 of 636 member readings hit the several-matches arm.**
   ⚠ **THE DIRECT-CHILD CLAUSE HAS ZERO SUBJECTS TOO** — 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — **with a planted control (`C-B` wrapped a member in a fresh `<div>` and the analyzer reported it immediately)**. ⚠ **AND r2's ATTRIBUTION OF IT TO `wflbl3` IS FACTUALLY WRONG AND IS DELETED: `wflbl3` is a DIRECT CHILD of its own `Field` wrapper** (`src/app/lab/challenge/swallowed-oid/page.tsx#    <div className="flex flex-col gap-0.5 bg-white px-3 py-2 border border-neutral-300 rounded-md">`), so it passes both clauses. The one prop-swallowing component in the repo produces the **opposite** failure: `Field`'s *exterior* oids (`wcall1…wcall4`) reach no node and are caught by the zero-match arm — and under ruling (iii) that is a DROP, not a refusal, and in any case **`wcall1…wcall4` cannot be pressed at all** (term 4 requires the press to resolve to a `[data-oid]` element; they have zero DOM nodes in every state, the only such chain in the corpus, and their parent `wgrid1` is `grid`, so E2 would refuse first).
   **Both clauses are KEPT and both are cheap: each prevents a real failure the browser can produce, and the control proves a detector can see it. What they lose is the claim to a shipped subject — their gate subjects are SYNTHETIC and owed by S47-0**, on the `unequal-indent` rider's model.
3. **FLOW, AXIS, REVERSAL — one `getComputedStyle(parentEl)` plus one per resolved member.** Admit iff: `cs.display` is `flex` or `inline-flex` (⚠ **the predicate, not `directionSource === "unresolved"`**, which §3.4 shows a `md:flex-row` parent below `md` never reaches; ⚠ `display: contents` is therefore refused — **ruled, not missed**, since a `contents` parent lays out nothing itself); `cs.direction === "ltr"`; `cs.writingMode === "horizontal-tb"`; and every resolved member's computed `order` equal. Then **axis** = `cs.flexDirection.startsWith("row") ? "row" : "col"`, **reversed** = `cs.flexDirection.endsWith("-reverse")`.
   ⚠ **The three exclusions are correct about the browser (§3.4) and have ZERO SUBJECTS in this corpus** (round 3, each with a planted control returning the planted value): `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930**. **They stay, their subjects are synthetic and owed by S47-0.**
4. **HIT-TEST — the total algorithm.** Over the rects `R` of all **resolved** members including the subject's own: `S = argmin` of the **squared point-to-rect distance** (0 inside a rect); **inside more than one rect** → the member **earliest in source-chain order**; **exact ties at equal distance** (a midpoint, a wrap-line gap) → the same rule, **one tie-break in the design, not two**; **`side`** by projecting onto `S`'s main-axis extent against its midpoint, `< mid ⇒ leading`, `>= mid ⇒ trailing`.
   ⚠ **THE COORDINATES COME FROM THE EVENT AND THE RECTS, NEVER FROM `e.target` — AND THE WRONG IMPLEMENTATION IS THE OBVIOUS ONE (round 3).** Under pointer capture, `e.target` is `#dsh-stage` for **every** event from the first move onward, while `document.elementFromPoint` keeps resolving the real element and returns `null` off-frame. **A hit-test reading `e.target` mid-drag gets the stage and nothing else.** This algorithm reads neither and is unaffected — stated because the failure is silent.
   ⚠ **Tie-break subjects are small but NOT zero (round 3, and the corrected wrap count):** **wrap has 2 subjects**, both in `lab/tests/align-wrap` and both genuinely two-line — ⚠ *the lane's first detector counted distinct cross-axis offsets and reported 37 wrapped parents; an `items-center` row with unequal-height children produces that without wrapping, and the corrected count of wrapped parents is 3* — and **overlap has 1**, `shop/order-detail`'s `4jpxin`, a 2 px step-connector over a step marker, the only one of three overlaps whose parent is flex. ⚠ **Both counts are viewport-dependent and were measured at one viewport.**
5. **VISUAL → SOURCE.** `sourceSide = reversed ? flip(side) : side`. The result is `(anchorOid = S, side = sourceSide)` — **which is the wire receipt itself**, so no conversion step exists. ⚠ **The `reversed` branch has ZERO SUBJECTS: three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1), but none of their children carries a `data-oid`, so none can be a chain member.** Clause kept, subject synthetic and owed by S47-0.
6. **NO-OP DETECTION — OVER SOURCE POSITION, RULED (r4).** A destination equal to the subject's current **source** position issues no request and, per §4.1(g), arms no latch. ⚠ **r3's sentence named no order-space, and once members can be dropped the two spaces differ**: with source `[A, B_unrendered, C, D]` rendering as `[A, C, D]`, dragging `A` to leading-of-`C` makes the source `[B, A, C, D]` **and the render does not change.** **Source is the right space** — it is what the write acts on, what the receipt addresses and what the undo entry restores; a render-space check would refuse a reordering the user actually expressed.
   ⚠ **The residual is STATED rather than prevented: a source-effective, render-inert drag issues a real request, consumes an undo slot and arms the latch.** The user sees nothing move and one Cmd+Z is owed. ⚠ **A FLEX-PARENTED SUBJECT DOES CONSTRUCT IT TODAY, AND r4's CLAIM THAT NONE COULD IS FALSE (r5, measured live at 1440×900).** On `/shop/member-detail`'s **benefits tab**, the chain `omy3i9,0cyt4v,z76fvu,d29ipo` under `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` renders **two copies, n = 4 and n = 3** — the short one missing `z76fvu`, an **INTERIOR** member, because that node is guarded by `src/app/shop/member-detail/page.tsx#                        {b.value > 0 && (` and `INITIAL_BENEFITS`' `b002` carries `value: 0`. `0cyt4v` reads `canMoveUp: true, canMoveDown: true` with an empty `reasons` map (verified in the map this lane built), E2 is flex/row and E3 passes at 3 ≥ 2. **Drag `0cyt4v` to leading-of-`d29ipo`: source index 1 → 2, the source-space no-op check does not fire, and the render does not change.** Controls in the same session: `pk9pwr`, `scroot`, `srroot`, `smroot` → `block/row`; `grpeul` → `table/row`; `smroww`, `xufjus` → `flex/row`; **and r4's own cited counter-subject `ww57qb` reproduces as `block/row` — the reading was never in dispute, the SWEEP was.** ⚠ **HOW IT WAS MISSED IS THE FINDING'S REAL CONTENT: the r4 lane went into tab space to read `ww57qb` on the memo tab and did not check the benefits tab one click away. That is pre-mortem 4's shape, recurring INSIDE the edit that documents pre-mortem 4.** **What actually contains the residual is narrower and is named as such: the benefits tab is a plain `useState` an in-page click cannot drive on the design view (§5's M10 constraint), so the copy that constructs it is not reachable on :3001 by clicking.** ⚠ **AND THAT MAKES §9.6's KI RULING LOAD-BEARING RATHER THAN A NOTE: the only thing containing this residual is a defect this plan itself calls *"not phase-47's to fix"* — one anyone may fix at any time, silently re-opening it.** A containment a future bugfix removes is not a containment; it is a dependency, and it is recorded here as one.
   ⚠ **AND ONE EDGE THE RULE DOES NOT COVER, NAMED RATHER THAN LEFT TO DISCOVERY: when the unrendered member is FIRST, the user cannot express *"make this the first child"* at all**, because the anchor receipt names a rendered sibling and there is none leading of the first rendered one. The gesture is not wrong there; it is simply mute, and the panel's ↑ still reaches that position.
7. **THE MULTI-INSTANCE CONSEQUENCE.** A drag on a `.map()`-body element edits the TEMPLATE, so every rendered instance reorders at once — **G47-16 is the row**, and §4.1(h) keeps the instance hint visible for it.

### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)

**C47-3.** `target: 'structure'`, verb `move-up`/`move-down` by the sign of the source-order displacement, unchanged `expect` for the ORIGIN, plus **`expectDestination: { anchorOid, side }`**, **REQUIRED on the two move verbs and FORBIDDEN on the other four**, with a total switch beside the shipped `parseExpectForOp`. **Both producers can construct it**, so §2's "does NOT touch" list needs no exception.

⚠ **THE UNION SPLIT IS BY BASELINE ON THE SERVER AND BY PAYLOAD ON THE CLIENT.** `packages/descvi/src/sidecar/server.ts#export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;` carries **all five** ops, so splitting the moves off the server's baselined arm leaves **`{delete, duplicate, insert-after}`**; the client's `packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export type PayloadFreeStructureOp = Exclude<StructureOp, 'insert-after' | 'insert-child'>;` leaves **`{delete, duplicate}`**.

Server, inside `computeStructuralEdit`'s move arm, under the write lock:
1. resolve the op-unit and re-derive the live origin baseline; mismatch ⇒ `stale-baseline` (409);
2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
4. **rearrange in ONE SPLICE (M1).** Read every member's span from **one** `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. ⚠ **This is not the k-swap loop r2 specified: that shape does not run, and the repo had already written the lesson down in this very file** — `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` **S47-2 therefore owes a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** ⚠ *r2's clause "`expect` consulted on the first step only" dies with the steps: there is one step.*
5. a typed refusal aborts `prepare`, so **nothing is written**, and the 422 carries that reason. ⚠ **The k-swap shape failed with `span-sentinel-failed`, an INTERNAL error this clause does not catch — recorded because it is why the shape had to change rather than be guarded**;
6. one journal push, subject unchanged; `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string | null {` needs no new arm;
7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.

⚠ **`parentOid: null` CHAINS ARE ADMITTED, AND SAYING SO IS A RULING (M9).** `wflbl3`/`wfval7` carry it — they are declared in a helper outside the default export, so the extractor records no oid-bearing parent — and they are **pressable, admissible, flex-parented** subjects (their DOM parent is `flex flex-col`). **`parentOid` is not consulted by this design at all**: order comes from `prev`/`next`, geometry from `subjectEl.parentElement`. The server's own chain re-derivation is likewise positional. **Nothing special is owed; the case is recorded so an implementer does not add a `parentOid !== null` guard that would refuse a working subject.**

**ONE Cmd+Z AFTER A 4-POSITION DRAG TAKES THE ELEMENT BACK FOUR POSITIONS** — one request, one entry, one undo, byte-exact from the entry's whole-file `before` bytes.

⚠ **The anchor receipt is slightly more permissive than a gap receipt, and that is a property.** A gap receipt refuses when either neighbour changed; an anchor receipt names **the element the user aimed at**, so a concurrent edit elsewhere in the chain **re-targets rather than refuses**. The origin `expect` still refuses any change to the subject's own position, and the receipt is still a COORDINATE rather than a count — **G47-10's argument is unchanged.**

**Why this is not a new write class — the enumeration is the argument.** No new `StructuralOp` member, no new wire verb, no new journal arm, no new `reselectTargetFor` arm, no new `REASON_TEXT` key. ⚠ *(r0's appeal to `structural-edit.ts`'s header sentence was withdrawn in round 1: it names one class contrasted with literal replacement and carries no taxonomy.)*

### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)

**C47-4.** Three new nodes in `#dsh-ring-layer`, all **readouts by role**: no `data-dsh-handle`, no `data-v3-glyph-control`, `pointerEvents = "none"` set **inline** (a class-only rule reads back `auto` in jsdom and the gate could not go RED).

- **`#dsh-reorder-indicator`** — the blue insertion line, in the destination gap, spanning the cross-axis extent of the **resolved** members, perpendicular to the main axis.
- **`#dsh-reorder-readout`** — **the DROP POSITION `n / N`**, per the owner's ruling. ⚠ **`N` is the count of RESOLVED members and `n` the subject's 1-based position among them — deliberately the count the user can see, not the source chain length**, which §4.2(2)'s drop-on-absence ruling makes differ whenever a conditional sibling is not rendering. Showing a total the user cannot count would be the readout's own version of KI-17.
  ⚠ **AND THE CONSEQUENCE THAT RULING CARRIES MUST BE STATED, BECAUSE r3 RULED IT AND DID NOT (r4): `n / N` IS INSTANCE-LOCAL.** Measured on the chain this plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`, six step columns, per-instance **`2/3/3/3/3/3` — in DOCUMENT order, and the SHORT one is the FIRST** (⚠ *r4 wrote `3/3/3/3/3/2`, which reads positional and is wrong in order; the connector `src/app/shop/order-detail/page.tsx#                  <div data-oid="rpb6hb"` sits under an `{i > 0 && (` guard, so column 0 is the one that lacks it, and a lane building the U9 material from the sixth column would conclude the effect does not exist*), all flex — **every column admits** (ruling (iii) works there), and the readout then shows `n / 3` in five columns and **`n / 2` in the **first**, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16). **The per-instance inconsistency was not dissolved; it was relocated out of the refusal and into the readout by the consequence ruled in the same paragraph.** Stated plainly: **`n / N` describes neither the source order the edit acts on** — in column 0, `5s41w1` reads `2 / 2` while being source index **3 of 3** on the same 1-based reading §4.4 defines `n` by — **nor the scope of the edit**, which is every instance. The affordance that carries the scope is `#dsh-ring-instance-hint`, which §4.1(h) keeps visible for exactly this reason.
  ⚠ **The KI-17 argument for showing what the user can count still holds, so the ruling stands — but the readout's SEMANTICS are ground the owner personally ruled, so they are routed rather than settled here: §8 U9.**
- **`#dsh-reorder-refusal`** — §4.5's sentence. ⚠ **On a refusing arm the DROP-POSITION readout is ABSENT (M9), not blanked**: there is no position to report, and a `0 / 0` would be a number about nothing.

⚠ **THE READOUT AND THE REFUSAL ARE TWO NODES, NOT ONE RE-STYLED NODE.** They are mutually exclusive in time, and re-styling one node per paint means re-running the `border` shorthand, which resets all four sides and wipes the accent — the trap `use-spacing-drag.ts`'s own comment warns about.

⚠ **THE READOUT IS CLIPPED AT THE FRAME EDGE, AND THAT IS RULED HERE RATHER THAN LEFT TO U1 (M9).** `#dsh-ring-layer` carries `overflow-hidden` (§3.8). **The readout is therefore CLAMPED to the layer's rect rather than following the pointer past it** — it stops at the edge and stays legible, which is what phase-42's own refusal marker does when it flips above rather than clamping off-screen. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too, and this is the answer.

**Z: all three take `zIndex = 44`**, matching the shipped drag readout (§3.8), with the popup above at 45. ⚠ *r2 briefly moved them to 41 on two false premises — that 41 is "the readout family's own" z (it is the STACK family's) and that §4.1(h)'s hiding replaces the need for a z privilege (that is U4, settled after the story that ships the indicator).* **Ordering among the three at equal z is by DOM order**, the repo's own precedent — and nearly moot, since the readout and the refusal never coexist.

**THE `styleReadout` EXTRACTION, WITH ALL FOUR COSTS PAID.** It takes **`tone`, `zIndex` AND `accentPx`** as parameters — ⚠ `accentPx` is a parameter and not an import, because `READOUT_ACCENT_PX` is module-private in **both** files and importing from either would create a cycle; **neither declaration moves**, because the shipped regex gate requires both and requires the spacing copy to survive. **`use-resize-handles.ts`'s THREE call sites** migrate in the same commit. Placement is pointer-relative and clamped, never `layoutReadouts`'.

⚠ Colour, weight, inset and the gap convention are NOT settleable here (§8 U1/U2); G47-6 asserts only a property.

### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)

**C47-5.** A total `Record<StructuralRefusalReason, BilingualMessage>` rendered through `packages/descvi/src/react/overlay/shared/refusal-messages.ts#export function bilingualLine(message: BilingualMessage): string {`, **plus an `undefined` arm** (required by the producer's type; measured at zero occurrences today — §3.1), **plus the client-only set: SIX KEYS OVER THREE CONDITIONS** — E1, E2 and E3, exactly as §4.1(a) enumerates them. ⚠ *(The count has been spelled four different ways across r2 and r3 — "three conditions" over a five-row table, then "four conditions, five keys" derivable under no consistent reading. It is stated ONCE, here, and §4.1(a), the table below and §12 are the three sites that must agree with it. r4's new key makes it six.)*

**Engine-keyed rows** (counts are **refusal** counts over `move-up`/`move-down` across `src/app` — §3.1):

| key | ko | en |
|---|---|---|
| `no-adjacent-sibling` (541) | 이 방향에 **형제 요소가 없습니다.** | **There is no sibling in that direction.** |
| `unsupported-sibling` (189 = 165 arm-time + 24 fold-step) | 옆에 있는 요소가 **편집할 수 있는 단위가 아닙니다** — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit** — something invisible, such as a comment, may sit between them. |
| `unsupported-parent` (52) | **부모가 순서 편집을 지원하는 형태가 아닙니다.** | **The parent is not a shape that supports reordering.** |
| `target-bears-data-screen` (48) | **화면 경계는 순서를 바꿀 수 있는 자리가 아닙니다.** | **A screen boundary is not a position that can be reordered.** |
| `unsupported-container` (18) | **감싸고 있는 조건부 묶음이 지원되는 형태가 아닙니다.** | **The conditional wrapper around it is not a supported shape.** |
| `non-canonical-separator` (6) | **형제 요소 사이 간격이 편집 가능한 형태가 아닙니다.** | **The spacing between the siblings is not in an editable form.** |
| `unequal-indent` (0 — R47-3) | 지나가야 하는 형제 요소와 **들여쓰기가 달라** 이동할 수 없습니다. | The move is blocked because **a sibling it must pass has a different indent**. |
| every remaining engine reason, and `undefined` | **이 위치에서는 순서를 바꿀 수 없습니다.** | **Reordering is not available at this position.** |

⚠ **`unsupported-sibling`'s WORDING MUST BE TRUE AT BOTH MOMENTS, AND r2 FIXED ONLY ONE (M9).** R1 scoped it to *"a step of the fold"* and worded it *"a sibling it must pass"*; r2 corrected the scope to arm-time. **Measured, it is both: 165 arm-time and 24 fold-step** — and **the 24 genuinely ARE the "a sibling it must pass" case.** The row above names the **relationship** (the neighbour is not an editable unit) rather than a traversal, which is true at both, and its second clause names what the user cannot see — §3.1's driven JSX-comment cause is the evidence.

⚠ **The generic arm names the POSITION, not the element.** R1's read *"이 요소는 … / This element cannot be reordered here"* — the element as subject, differing from rule 1's own counterexample by one word, so G47-11 leg (ii) fired on the plan's own text. The three largest causes (52 + 48 + 18 = 118 refusals) now have relationship-naming sentences of their own.

**The client-only set — three conditions, six keys:**

| key | condition | ko | en |
|---|---|---|---|
| `no-reorderable-sibling` | E1, the **22** | 같은 부모 안에 **순서를 바꿀 형제 요소가 없습니다.** | There is **no sibling to reorder with** inside this parent. |
| `sibling-not-editable` | E1, the **108** | 옆에 있는 요소가 **편집할 수 있는 단위가 아니라** 순서를 바꿀 수 없습니다 — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit**, so the order cannot be changed — something invisible, such as a comment, may sit between them. |
| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |

⚠ Two of these name the panel as the working alternative deliberately: the flow-axis refusal is a GESTURE policy, not a write constraint, so telling the user the buttons still work is the true and actionable sentence.

⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**

**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.

**Where each is shown.** E1, E2 and E3 are known at arm time (E3 at the first geometry read): the gesture arms into a refusing state, paints `#dsh-reorder-refusal`, draws no indicator, shows no drop-position readout, and issues nothing. Step-refusals arrive as the 422's typed reason after release.

⚠ **The indicator can therefore be shown for a destination the server refuses — and R47-3 explains why that is safe rather than merely asserting it (M8).** `unequal-indent` is the only move-only precondition a chain-derived destination can trip, **and the mechanism is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."*** Because the chain is built **only across links `adjacentOpUnit` already admitted**, every other move-only condition was already satisfied when the link was made. A lane tried to break this with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. **And `unequal-indent` is measured at zero, so the cost lands entirely on G47-9's synthetic fixture.**

### 4.6 `undo-focus-ownership` — ONE fix and ONE placement improvement (RULED — DR47-9 — C47-6)

⚠ **NAMING NOTE, RECORDED BECAUSE PER-COMMIT BRIEFS CITE CONTRACT IDS VERBATIM (M9): C47-6a and C47-6b SWAPPED MEANINGS BETWEEN r1 AND r2.** In r1, `a` was the `focusStageIfOrphaned` call and `b` the ownership widening; from r2 onward `a` is the ownership widening (the fix) and `b` the focus placement. **A brief drafted against r1 would build the other thing.** The r3 meanings are below and are final.

**C47-6a — THE FIX, and it closes BOTH dead windows on its own.** `document.body` counts as owned in the Cmd+Z keydown effect. The backlog row names `document.body` as the mechanism for both windows. ⚠ **The `null` half is DROPPED**: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` bails on `null` two guards above ownership and **above** the text-entry guard, so implementing it would mean moving an early return past that guard — the exact shape G47-12 exists to police, inside the fix. **`stageRef.current?.isConnected` is NOT re-checked**; it is proven one line above.

**C47-6b — THE PLACEMENT IMPROVEMENT, and it is NOT what restores Cmd+Z.** It calls `focusStageIfOrphaned` after a panel value commit so the canvas keyboard surface is live again. ⚠ **It must land on the flush AFTER the `key={value}` remount**, because in the commit callback the ticket element is still connected and focused, `orphaned` is false, and the call does nothing.

⚠ **THE CONTROL AND THE REACH, both stated precisely (M9).** The physics — *"the remount lands on a LATER flush than this callback"* — is measured in `focusStageIfOwned`'s three-row table, **which measured the canvas-click ticket-restore path, not the panel value-commit flush**. The physics generalises; **calling that table "the control" for this claim over-claims by one call path, so it is named as the EVIDENCE and S47-5 owes the control on its own path.** And the reach is one control of three: `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever there — **which is correct, not a gap**, because focus staying in a text field is where Cmd+Z should reach the field's own undo. **C47-6b is reachable only on the chip add-input and the `key={value}` numeric value fields, and G47-12 row (a) names the chip add-input as its subject.**

### 4.7 The ontology rows, and what no gate watches (RULED — C47-7)

**C47-7.** `.omc/specs/interaction-ontology.md` §3.F-1 has **six** rows; all six get a disposition, because no gate watches them:

| §3.F-1 row | disposition |
|---|---|
| element in flex parent, within-parent | **SHIPPED at phase-47**, with an anchor into the composer — **and the row states the modelled subset** (LTR, horizontal writing mode, equal `order`), because an unqualified SHIPPED is the false half of the browser falsification written into the register |
| element in flex parent, cross-parent | unchanged `deferred-v2 (hard)` |
| element in non-flex parent | **the gate this phase clarifies** — flips to a REFUSAL row naming `parent-has-no-flow-axis`; *"undefined blue-line; clarify at gate"* is discharged |
| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
| selection box (drag the selection) | **SHIPS**; its own cell already says *"== dragging the node"*, and §4.1(c) makes subject ≡ selection at arm time |
| stage background (empty) | unchanged — §2 exclusion 2, G47-2 keeps it so |

⚠ **AND THE SWEEP DISCIPLINE THIS SECTION DEPENDS ON GETS ITS LESSON RECORDED HERE, BECAUSE IT IS NOW FIVE ROUNDS OLD (r5): A SWEEP LIST HAS TURNED OUT TO BE A PROPER SUBSET IN FIVE OF THE SEVEN ROUNDS THIS PLAN HAS HAD — the two clean rounds were the exception, not the turn.** **The portable rule: the BY-CAUSE GREP is the instrument and the enumerated list never is.** A list is a record of what one reader thought of; `git grep -n '<the key or claim being changed>'` over `.omc/plans .omc/specs docs` is a record of what is there. **When a ruling changes a KEY's meaning, sweep the key, not the sections.**

⚠ **`node scripts/check-v3-registers.mjs` does NOT gate these rows** (its census is over `**deferred-v3` markers and the eleven v3 slugs; these are `deferred-v2`). `check-citation-anchors.mjs` protects only the new anchors; a review lane is the rest.

⚠ **BOTH PREAMBLE SENTENCES ARE REWRITTEN, AND r2's CLAIM THAT THE SECOND WAS "STILL LITERALLY TRUE" IS WITHDRAWN — IT IS FALSE AT HEAD, INDEPENDENTLY OF THIS PHASE (M7).** Sentence 1 (*"every drag variant resolves to select-on-press-then-nothing-on-move"*) has been false since phase-42. Sentence 2 asserts *"There are NO `dragstart`/`mousemove`/`dragover`/`drop` listeners (grep-confirmed)"* — but `packages/descvi/src/react/overlay/canvas/use-canvas-hover-ring.ts#    stage.addEventListener("mousemove", onMouseMove);` ships today. ⚠ **Keeping a false sentence and calling it verified is the process failure this plan's own status block records, committed by the revision that wrote the record.** **The amendment describes the shipped listener set rather than asserting an absence whose terms have drifted.** ⚠ It also carries **two banned line pins that are now dead** — `selection-shield.ts:75-78` lands on a docblock tail and `OverlayShell.tsx:292-293` on `[],\n  );` — **converted to anchors in the same amendment**, since `AGENTS.md`'s rule is binding and `check-citation-anchors.mjs` cannot see either form.

---

## 5. Stories, in ship order

**S47-0 — the fixtures, the routing record, and the two counts this phase owes.**

⚠ **WHICH HALVES ALREADY SHIP — AND r3 WROTE THIS INVENTORY FROM THE AUTHORED PROXY IN EXACTLY THE PLACES §4.2(3) RULES THE PROXY MUST NOT BE TRUSTED (r4).** That is pre-mortem 3's own class arriving in the fixture list: **D47-2's whole story is that the authored token is corroboration and the live read is authoritative**, and then the inventory was written from the token. Corrected against the live reader:
- **"three flex-row chains of 7" is TWO.** The two `shop/member-list` chains (`ohpkna…lqaxc2`, `xaro3n…1hzfxp`) stand. ⚠ **`shop/order-detail`'s `kh1mfx…thbzev` does NOT** — its parent `src/app/shop/order-detail/page.tsx#      <div data-oid="grpeul" className="flex-wrap gap-x-3 gap-y-1 text-gray-500 text-sm table">` computes `display: table`, so it refuses at E2 and **can never be a drag subject.** *(Control: `4jpxin` on the same page reads `flex row` through the same reader, so the reader can see flex.)*

**Genuinely absent and owed:**
- a **flex-col chain of ≥5 whose members all render together** — ⚠ **and r3's stated reason for excluding the corpus's flex-col 5-chains was WRONG (r4): `sandbox/resize-flex-col`, `sandbox/resize-flex-row` and `sandbox/resize-repeat-list` all compute `block` at the chain's parent, so they fail at E2 — not because of their conditional members.** *(Control: the same reader returns `flex row` for `smcell`'s parent on `resize-repeat-list`.)* The conditional-member observation is true and is not the disqualifier;
- a **`flex-row-reverse` chain with oid-bearing children** — the three reverse containers in `lab/tests/align-enablement` have none (§4.2(5));
- a **variant (`md:flex-*`) chain with oid-bearing children** (G47-5c);
- **an `rtl` chain, a `vertical-rl` chain and an unequal-`order` chain** (G47-5d) — **all three declared SYNTHETIC: measured at zero subjects (§4.2(3))**;
- **an ambiguity subject for `chain-member-not-locatable`** — **SYNTHETIC: both of r2's "shipped subjects" were measured not to fire, and the several-matches and direct-child arms have zero subjects at parent scope (§4.2(2))**;
- **a flex parent whose DOM element-child count differs from its chain length**, for G47-19;
- **an ordinary reorderable subject reachable in `e2e/spacing-gesture.spec.ts`'s own fixture**, for G47-1's fourth press;
- **an `unequal-indent` pair — SYNTHETIC and unconditional** (measured at zero, §3.1).

⚠ **AND ONE SUBJECT THIS STORY DOES NOT OWE, SAID SO NOBODY AUTHORS IT TWICE: `no-sibling-in-this-copy` (G47-11d) is the ONE client-only refusal whose subject already SHIPS** — `lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, five flex-parented instances resolving 2/2/2/2/1 in default state.

**Two counts owed and not gettable from source**, both DOM reads: **(i)** the direct-child violation rate at parent scope — measured **0 of 601** by round 3, so this is now a *confirmation* rather than an unknown, re-run at the fixture set; **(ii)** nothing else: **D47-2's live prevalence is settled (§3.1).**

**And one DOC deliverable, placed FIRST so it cannot be lost:** route DR47-8 reading (a) back to **B-Q4's row in `docs/post-loop-backlog.md`** with the 2026-08-27 owner ruling recorded and **no phase number invented**.

The regenerated `.descvi/screens.json` diff **is** the deliverable. **Verification: `pnpm gates`.**

**S47-1 ∥ — the headless reorder model.** The chain walk; the drop table's two lifetimes and its resolved-members-only rule; the total hit-test; the scoped layout admissibility and its refusal branches; the reversal flip; no-op detection; the candidate/eligible split with term 5's two-reader predicate; the one-per-press rule; the terminal totality; the refusal map's engine-total shape plus its `undefined` arm and six client-only keys. **Verification: unit, jsdom-free.**

**S47-2 ∥ — the wire and the server composer.** The move-arm split; `expectDestination: {anchorOid, side}` REQUIRED-on-move / FORBIDDEN-elsewhere with its total parser and its self-anchor 400; the exported `resolveMoveDestination`; **the span-rearrangement primitive beside `swapSpans` and the ONE-SPLICE composer**; the direction-disagreement 400; the atomic abort; the applied-`k` echo; **an instrumented `parse` counter in the sidecar's test harness** so G47-20 can observe what §3.3 measured. **Verification: unit + the sidecar suite, plus the cost re-derivation against R47-4's threshold with the same controls (byte-equality against the naive fold, no-move, wrong-destination).**

**S47-3 — the gesture wiring and the guard.** `canvas/use-reorder-drag.ts`; the two shield edits; `setPointerCapture` on the stage; the terminal set **and the reorder guard's own teardown reset**; the request-gated latch; furniture suppression by `visibility` **with the instance hint's explicit re-declaration**; DR47-11's second guard, the `terminateActiveCanvasGesture()` wrapper and the migration of all 7 boundary sites — ⚠ **the brief must NAME THE WRAPPER'S MODULE, because `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#    if (rel === definitionFile) continue;` excludes the definition file, so a wrapper living in `resize-gesture-guard.ts` makes G47-14's scan return ZERO rather than "exactly one" (M9)**; the `POINTER_DRAG_THRESHOLD_PX` header correction; the `armTrailingClickSuppression` docstring correction; the §3.F preamble amendment including its two dead line pins. ⚠ The brief must require the implementer to state what the new predicate must NOT match. **Verification: jsdom for the wiring; a live `descvi:dev` smoke is REQUIRED.**

**S47-4 — the indicator, the readout and the refusal surface.** The three nodes at z 44, the readout clamped to the ring layer's rect and absent on a refusing arm; the `styleReadout` extraction with `tone`/`zIndex`/`accentPx` parameterised, **three** callers migrated, both `READOUT_ACCENT_PX` declarations left in place; the engine-total bilingual refusal map with its six client-only keys. **Verification: jsdom for structure and non-operability; Playwright for position; the owner for look.**

**S47-5 — `undo-focus-ownership`.** C47-6a and C47-6b, each with its own rows, and **C47-6b's own control on the panel value-commit path** (§4.6). **Verification: jsdom + `e2e/undo-cmdz.spec.ts`.**

**S47-6 — live coverage, the six ontology rows, the landing audit and the tracker section.** `e2e/reorder-drag.spec.ts` with its `spec-classes.json` declaration argued (§12); the §3.F-1 dispositions with their anchors; **the F46-D `readScene` grep as a named deliverable**; the whole-set audit **as this phase lands**; the tracker row.

⚠ **AND ONE CONSTRAINT S47-6 MUST READ BEFORE IT WRITES A SPEC (M10). On the design view, an in-page control cannot be activated by a click.** `shop/member-detail`'s three tab buttons drive a plain React `useState`; on :3001 three consecutive clicks produced **no state change** (oid counts 84/84/84) while the byte-identical script on :3000 produced 84/69/35. **The canvas selection shield claims the press.** A cross-host control ran first: 20/20 screens identical at default state. **This is not phase-47's defect and not phase-47's to fix, but it constrains how any Playwright spec drives in-page state on the design view** — a spec that needs a non-default page state must drive it on :3000, or reach the state without a click. ⚠ **Whether it deserves a `docs/known-issues.md` entry is a LEAD RULING, not this plan's** (§9.6).

---

## 6. Gates — each with a stated, CONSTRUCTIBLE RED-when and a NAMED subject

⚠ **Where a subject is SYNTHETIC it says so and S47-0 owes it.** That is not a weakness of the gate: the `unequal-indent` rider has carried it since r1, and round 3 showed that a gate claiming a shipped subject it does not have is worse — it reads as covered and cannot fire.

| id | What it pins | RED-when | subject |
|---|---|---|---|
| **G47-1** | The arm table over FOUR presses: `e2e/spacing-gesture.spec.ts#§3.9's THREE-ARM TABLE — a handle press is preventDefault-ed (ROW D)` already presses a strip, an `se` corner and the popup input; **a fourth press on an ordinary reorderable element must read `true` and still record travel.** | **Build DR47-1(a)**: hoist the reorder call above `suppressShieldPointer(e)` and early-return → the ordinary row flips to `false`. ⚠ **AND THAT HOIST ALSO KILLS TRAVEL RECORDING**, so *"every reorder behaviour stays green"* is false — the `defaultPrevented` bit is the discriminating leg and the travel leg fires too. ⚠ r0's mutation was **not constructible** (the call sits after `beginTravelRecording`). **Layer: e2e** — jsdom has no `PointerEvent` and no pointer capture. | **S47-0 (fourth-press fixture)** |
| **G47-2** | The stage background is unclaimed. | Drop candidate term 4 → both a stage-background drag and a `#dsh-screen`-but-not-`[data-oid]` drag arm. | shipped |
| **G47-3** | The threshold is the shipped symbol, consumed by the reorder classifier. | Edit `POINTER_DRAG_THRESHOLD_PX` to 40. ⚠ **Broadly RED** — it also moves two render floors, the travel guard and two other classifiers — so the reorder assertion is the **discriminating** leg. | shipped |
| **G47-4** | Capture on a STAGE host holds; the per-move geometry re-read follows the pointer off-frame. | Skip `setPointerCapture` → off-frame moves stop arriving and the last geometry read is stale. **The paired control §4.1(e) already measured: `pointerup = 0` without capture.** | shipped (measured) |
| **G47-5** | Reversal and wrap. | (i) Delete the `reversed` flip → the reverse row inverts. (ii) Replace the hit-test with a main-axis ordinal → the wrap row picks a first-line sibling. | reverse **SYNTHETIC** (§4.2(5)); wrap **shipped** (`lab/tests/align-wrap`, 2 subjects) |
| **G47-5b** | The hit-test is total: wrap-line gap; exact midpoint; equal distance; two overlapping rects. | (i) `>=` → `>` at the midpoint → the midpoint row flips side. (ii) source-chain tie-break → DOM order → the overlapping row picks the other sibling. (iii) point-to-rect → centre-distance → the wrap-line-gap row picks a sibling on the wrong line. | wrap **shipped** (2); overlap **shipped** (`shop/order-detail`'s `4jpxin`, 1); midpoint/equal-distance synthetic |
| **G47-5c** | The flow predicate is LIVE: a `md:flex-row` parent **below** `md` refuses, **above** `md` admits. | Replace `cs.display` with `directionSource === "unresolved"` → the below-`md` row admits and takes an axis from a `display: block` element. **The defect r0 shipped.** | **S47-0 (variant fixture)** |
| **G47-5d** | The modelled subset — **three independent legs**: an `rtl` flex row refuses; a `vertical-rl` flex row refuses; a chain with unequal child `order` refuses. All paint `layout-not-modelled`. | (i) Drop the `ltr` clause → the `rtl` subject admits and the drop lands mirrored. (ii) Drop the `writingMode` clause → the axis read is 90° wrong. (iii) Drop the `order`-equality clause → the source moves and **nothing on screen moves** — the failure with no visible symptom, which is why it needs its own leg. **Positive control: a plain LTR flex chain admits and reorders.** | **all three SYNTHETIC** — measured 0/930, 0/930, `order === "0"` on 930/930 (§4.2(3)) |
| **G47-6** | The indicator's rect lies strictly between the two siblings it names, overlaps neither, is perpendicular to the main axis. | Swap the destination gap for the subject's own → the rect overlaps the subject. Swap the axis → the orientation leg fires alone. | shipped |
| **G47-7** | Non-operability and the C46-0 partition for all three new nodes. | Set `pointerEvents` through a CLASS → the jsdom read returns `auto`. | shipped |
| **G47-7b** | The extraction changed nothing that ships: the three existing readouts' computed colour, border and `borderLeftWidth` byte-identical before and after; **both** `READOUT_ACCENT_PX` declarations survive. | (i) Drop `tone` and let a new node inherit the default → it ships **red**. (ii) Move either declaration into the extracted module → `spacing-readout-accent.test.ts` row (3) goes RED, which is that gate working. | shipped |
| **G47-8** | **ONE Cmd+Z takes a k-position drag all the way back.** 3 positions in a 5-member chain; page bytes byte-identical after one undo. | Issue k sequential requests instead of one → 2 of 3 steps remain and the journal shows k entries. **RED before green.** | **S47-0 (flex-col ≥5); flex-row ≥5 already ships** |
| **G47-9** | Atomicity: a drag crossing an `unequal-indent` pair writes nothing and returns that reason. | Move the rearrangement outside the pure arm → a partial write with a 422 returned. | **SYNTHETIC, unconditional** (measured 0) |
| **G47-10** | The destination receipt is verifiable: a stale `anchorOid` 409s rather than landing somewhere plausible. | Replace `{anchorOid, side}` with `steps: number` → the stale-chain row lands wrong and returns 200. | shipped |
| **G47-10b** | REQUIRED-or-FORBIDDEN: the field on a `delete`/`duplicate`/`insert-after` request is a **400**; its absence on a `move-up` is a **400**; **`anchorOid === the subject's oid` is a 400.** | Make the field optional → the first two rows stop being 400. Accept a self-anchor → the third returns 200 and writes nothing while reporting success. | shipped |
| **G47-11** | The refusal words: ko and en, no display value, no element as subject — **over the whole map including the generic arm.** | (i) ko only → the bilingual leg. (ii) Restore r1's generic arm (*"이 요소는 …"*) → the relationship leg fires **on the plan's own former text**. | shipped |
| **G47-11b** | E1's three-way split and the map's totality — four legs: a **22**-class subject paints `no-reorderable-sibling`; a **108**-class subject paints `sibling-not-editable`; a **62**-class subject paints the engine's own reason; an unmapped reason or `undefined` paints the position-fallback and never a raw code. | (i) **Fold the 108 into `no-reorderable-sibling`** → leg 2 fires with a sentence false of its subject. ⚠ *r1's version was green on the defect and on the correct behaviour alike.* (ii) Fold the 62 in → leg 3. (iii) Delete the fallback → leg 4 renders the kebab-case identifier. | shipped (all three classes) |
| **G47-11c** ⚠ **SUBJECT REPLACED (M5)** | `chain-member-not-locatable` fires on **ambiguity**: a member resolving to two nodes within one parent, and a member resolving to a deeper descendant. | Relax the join to "first match wins" → the two-node subject proceeds against an arbitrary box. Drop the direct-child clause → the descendant subject hands the hit-test a box that is not a flex item of the parent whose axis was read. | ⚠ **SYNTHETIC, and now cleanly so.** r2 named `wcall1…wcall4` and `wflbl3`/`wfval7`; **round 3 measured that neither fires** — the first cannot be pressed at all, the second resolves once as a direct child at parent scope, and both stated mutations change nothing on it; **round 4 independently reproduced 0 several-matches and 0 deeper-descendant readings at parent scope with a planted control that fires.** ⚠ **The fewer-than-two arm has LEFT this gate for G47-11d, where its subject is SHIPPED** — r3 filed it here and called the whole cell synthetic, which under-claimed the evidence. |
| **G47-11d** ⚠ **NEW (r4), AND ITS SUBJECT IS SHIPPED** | The sub-floor arm is INSTANCE-SCOPED and carries its own words. Two legs on one chain: pressing `d4b6s3` in **any of instances 0–3** admits and reorders; pressing it in **instance 4** paints `no-sibling-in-this-copy` — **not** `chain-member-not-locatable`, and **not** `no-reorderable-sibling`. | (i) Route the fewer-than-two case to `chain-member-not-locatable` → instance 4 tells the user the siblings could not be located when the sibling simply is not rendered there — the wrong relationship, wording rule 1. (ii) Route it to `no-reorderable-sibling` → the sentence claims no sibling exists in the parent, which is **false at source** (`d8m1w7` is a chain member with `prevOid: d4b6s3`). (iii) Restore r3's rule and refuse the whole chain when any member is missing → instances 0–3 stop admitting, which is the per-instance inconsistency (iii) exists to dissolve. | ⚠ **SHIPPED** — `src/app/lab/tests/shared-oid/page.tsx`'s `d4b6s3,d8m1w7`, default state, five flex-parented instances resolving **2/2/2/2/1**. Controls (round 4): remove the separator from instance 0 → `1,2,2,2,1`; plant one into the last → `1,2,2,2,2`. |
| **G47-12** | Two rows for two edits: **(a) after a panel value commit on the CHIP ADD-INPUT, `#dsh-stage` IS FOCUSED** (⚠ not "Cmd+Z undoes" — that passes on C47-6a alone); (b) `activeElement === document.body` + connected stage → Cmd+Z undoes; focus in a panel `<input>` → it does not. | (a) Site the call in the commit callback instead of the post-remount flush → `orphaned` is false and focus does not move. (b-i) Revert the ownership term → the body row fires. (b-ii) **Hoist the ownership check WITH its new term** above the text-entry guard → the input row fires. | shipped; ⚠ **row (a)'s subject is the CHIP ADD-INPUT specifically — the other two panel controls keep focus and `orphaned` is false forever there** |
| **G47-13** | The e2e declaration, in **both** directions the shipped gate asserts. | **(i)** add the spec with no class → `scripts/e2e-gate-cx1.mjs` is RED. **(ii)** declare it `neutral` while it needs the sidecar → the suppressed run fails it; declare it `ambient` with every row passing sidecar-free → the ambient side stops meaning anything. ⚠ **The gate is GREEN at HEAD** (round 2 ran it: 15 ambient / 2 solo / 7 neutral), so a wrong pick in this phase is what would turn it red. | shipped |
| **G47-14** | Every boundary consults BOTH gestures: `terminateActiveResizeGesture` has exactly ONE caller outside its own module, via `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#export function countCalls(source: string, name: string): number {`; and a live reorder drag is terminated by a panel className commit. | (i) Leave one of the 7 sites calling the resize guard directly → the caller-scan leg names the file. (ii) Do not register the reorder terminal → the drag survives the boundary. ⚠ **The scan EXCLUDES the definition file, so the wrapper must not live in `resize-gesture-guard.ts` or the leg returns zero and inverts (M9).** | shipped |
| **G47-15** | An armed drag that resolved to a NO-OP still selects. | Arm the latch on every armed drag → the click is swallowed and no selection happens. | shipped |
| **G47-16** | A drag on a `.map()`-body element reorders **all N rendered instances** from ONE request, and `#dsh-ring-instance-hint` stays visible. | (i) Assert only the first instance → the row cannot see a failed template propagation. **(ii) Delete the hint's explicit `visibility: visible` override** → the hint inherits the handle layer's hide and disappears. ⚠ **r2's mutation ("add the hint to the hidden set") was green on the defect and on the correct behaviour alike, because the hint is a CHILD of the layer already being hidden (M4).** | shipped (`smcell`/`smname`/`smtagg`, four instances) |
| **G47-17** | One arm per press over the `mousedown`/`pointerdown` pair. | Arm per event → two candidates, and the `mousedown`-derived one cannot express `setPointerCapture(e.pointerId)`. | shipped |
| **G47-18** | The drag subject — four rows: no selection → drag B moves and selects B; A selected → drag B moves B, selection ends on B; **A dirty → does NOT arm, behaves as an ordinary click**; subject retained across 200 / 409 / 422. | (i) Drop term 5 → the dirty row arms and the pending-edit seam is bypassed. (ii) Skip §4.1(c)'s synchronous switch → rows 1–2 move B while the panel and the handoff still read A. | shipped |
| **G47-18b** | **KI-46, executable.** Begin a className commit; before it resolves, attempt a reorder arm → it does not arm, and the in-flight write lands intact. | **Use `hasPendingEdits()` alone** → the arm succeeds inside the window, the synchronous selection switch moves `identityRef`, the commit's R1 guard drops the write, and **a committed token disappears silently.** | shipped |
| **G47-19** ⚠ **REBUILT (M6)** | The `n / N` readout reads both numbers from the **resolved chain members at parent scope**, never from a DOM sibling count and never document-wide. | (i) Read `N` from `parentEl.children.length` → fires on a flex parent with an element child that is not a chain member. (ii) Read `N` from a **document-wide** `querySelectorAll` over the chain's oids → fires on the `.map()` subject, **12 vs 3**. ⚠ **r2's version was not constructible: it read a ROW count and called it a chain length.** `smroww` is a **singleton** (`canMoveUp: false, canMoveDown: false`) and can never be a drag subject; at parent scope both of r2's named populations **agree** with the artifact (the `.map()` subject is 3 chain members in an `<li>` with exactly 3 element children; the `swallowed-oid` chain is 2 and 2). **The "opposite directions" argument is withdrawn.** | leg (ii) **shipped**; leg (i) **S47-0** |
| **G47-20** ⚠ **COUNTS CORRECTED (M3)** | The composer parses **twice** per request, whatever `k` is. | Restore the naive per-step fold → the parse count for k = 6 goes **2 → 12**. ⚠ **r2's "1 → 6" was wrong in both numbers: `swapSpans` ends on `reparseOrThrow`, so one `moveAdjacent` is TWO parses** — the timings confirm it arithmetically (`5.616 ≈ 2.628 + 0.233 + 2.911`) — **and a correct one-splice floor is 2, not 1, because a structural edit that skipped the defensive reparse would write unvalidated bytes.** The counts the gate discriminates are **2 for any correct request** and **2k for the naive fold**; **S47-2 ships the instrumented `parse` that observes them** (§5). | shipped |

**Standing obligation:** every gate is shown RED under its named mutation before it is believed green, and the RED is recorded in the tracker with the mutation beside it.

---

## 7. Risks, each paired with a MECHANISM

| id | Risk | Mechanism |
|---|---|---|
| **R47-1** | The new predicate on the ordinary arm matches more than it means to — the ONE failure class the record contains. | (i) **G47-5c, G47-5d, G47-2** are breadth assertions. (ii) The S47-3 brief requires the implementer to state **what the predicate must NOT match and which target class each existing arm claims**. (iii) G47-1's fourth press, with a constructible mutation. ⚠ The obligation attaches to the ordinary-arm call; the wrapper swap is mechanical and policed by G47-14. |
| **R47-2** | The client's chain is one edit stale. | The anchor receipt makes it a **409 with no write**; G47-10 substitutes the unverifiable alternative to prove it. |
| **R47-3** | The indicator promises a drop the server refuses. | ⚠ **The MECHANISM, not just the conclusion (M8):** the chain is built **only across links `adjacentOpUnit` already admitted**, and that function's docblock rules *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."* So **indent is the only move-only precondition a chain-derived destination can trip** — a lane tried `unsupported-sibling` and `non-canonical-separator` mid-chain and could not break it — **and `unequal-indent` is measured at zero.** The cost lands entirely on G47-9's synthetic fixture. |
| **R47-4** ⚠ **THRESHOLD RE-DERIVED (M2)** | The in-lock rearrangement stalls the sidecar. | k ≤ chainLength − 1 ≤ 6. ⚠ **r2's *"under 19 ms"* was unreachable by a CORRECT implementation of the design it was written to accept**: a correct k-swap fold's best case is **21.49 ms**, so the criterion would have fired on a correct build and returned the k = 1 clamp for a reason unrelated to the design's merit. *(It was also self-inconsistent: "closer to the floor than to the ceiling" is `< 18.92`, not `< 19`.)* **Under the one-splice shape (§4.3(4)) the floor an implementation can occupy is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ 7.5 ms.** **Pre-committed acceptance, written before the measurement so it can go RED: the k = 6 rearrangement must complete in under 12 ms on `src/app/shop/order-detail/page.tsx`'s 7-member chain `kh1mfx…thbzev` (**40,979 bytes**), or the design is re-opened.** ⚠ **THAT CHAIN IS A COMPOSER BENCHMARK, NOT A DRAGGABLE SUBJECT (r4)** — its parent computes `display: table` and refuses at E2 (§5), so the lane building the Playwright row must not assume it can be dragged. The criterion is a server-side measurement over source bytes and is unaffected. ⚠ **The threshold is met: round 4 built the one-splice composer and measured 6.803 ms — 1.76× headroom — with the naive fold (33.0 ms) and a correct k-swap (≈21 ms) both RED against it, and byte-exactness confirmed in both directions including an interior up-move (index 3 → 1), a direction no earlier round had tested.** ⚠ **The subject is named because these numbers are page-size dependent — the same three primitives read 0.662 / 1.490 / 9.041 ms on `shop/member-list` (9,656 B).** Controls: byte-equality against the naive fold, no-move, wrong-destination. G47-20 pins the parse count. |
| **R47-5** | The trailing-click latch has two producers. | Co-occurrence needs two simultaneous pointers (disjoint targets); bounded by the shipped unconditional drop-on-press. The docstring's precondition is corrected in S47-3. |
| **R47-6** | Widening Cmd+Z ownership to `document.body` intercepts a keystroke meant for something else. | The text-entry guard runs first and is untouched; `body` is unowned rather than outside the overlay. G47-12(b-ii) asserts the order, meaningful only because the `null` half was dropped. |
| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
| **R47-8** | One drag, N rows move, and the user is surprised. | §4.1(h) keeps `#dsh-ring-instance-hint` visible **through an explicit `visibility: visible` re-declaration**, because the hint is a child of the layer being hidden; G47-16(ii) is aimed at deleting that override. ⚠ **Without the override this risk had NO working mechanism (M4).** |
| **R47-9** | A boundary forgets the second guard call, or the teardown. | One wrapper, 7 sites migrated in S47-3's own commit, G47-14's caller-scan leg **with the wrapper's module named**; and the reorder guard's own teardown reset (§4.1(f)). |
| **R47-10** | The §3.F-1 amendments and the preamble go stale and no gate notices. | Six rows with dispositions, amended in the commit that makes them true; the two dead line pins converted; `check-citation-anchors.mjs` protects the new anchors; the S47-6 whole-set audit is the rest. **Stated as an uncovered surface rather than believed covered — and r2's own "still literally true" claim about the preamble is why (M7).** |
| **R47-11** ⚠ **RE-PRICED (round 3)** | The modelled subset is narrower than the corpus and users meet the refusal. | ⚠ **MEASURED AT ZERO in this corpus** — `rtl` 0/930, non-`horizontal-tb` 0/930, `order !== "0"` 0/930 (§4.2(3)) — so nothing is lost today, and the refusal names the panel as the working alternative. **What is UNMEASURED is whether that stays true as the corpus grows**, and the gate subjects are synthetic precisely so the clauses keep working when it does not. |

---

## 8. Where the owner's eyes are needed

**What the phase settles WITHOUT the owner:** every gate in §6. **Playwright driving a real Chromium IS the running app for that purpose** — "browser-only" means *not reachable in jsdom*, never *needs a human*. What needs a human is taste.

**The boundary is AFTER S47-4 and BEFORE S47-6.**

| U-item | The question | Why no test answers it |
|---|---|---|
| **U1** | The indicator's position convention — centred in the gap, or flush against the preceding sibling's trailing edge? Full chain cross-extent, or the subject's? ⚠ *Clipping is no longer part of this question — §4.4 rules the readout clamped.* | Both are correct against G47-6. |
| **U2** | The indicator's weight and colour. ⚠ Adjacent but out of scope: `selection-ring-treatment` is the ring's *shape* question. |
| **U3** | **The arming threshold for THIS gesture.** 4 px is owner-ratified **for resize**, with 2-of-20 tremor misclassifications accepted; a reorder drag begins on the element itself. **The concrete harm of a sub-intent arm — it would have eaten the selection click — is closed by §4.1(g), but the arm still costs an indicator flash and a needless selection switch.** | A felt classification on a different gesture. |
| **U4** | Furniture during the drag: hide six nodes, keep the instance hint? ⚠ §4.4 no longer depends on this answer. |
| **U5** | **The silent refusal at N > 1.** A drag on a member of a multi-member selection does nothing. Should it say so? | A refusal surface for an excluded gesture is a scope question. |
| ~~U6~~ | ⚠ **DELIBERATELY EMPTY. U6 was DR47-8 and the owner answered it on 2026-08-27.** The number is not reused and the hole is recorded so a later lane does not "restore" it. | |
| **U7** | The refusal readout's timing — paint on arming, or only after further travel that looks like intent? | An immediate paint on every accidental 4 px drag is noise; a late paint may read as no feedback. |
| **U8** | **The dirty-press silence.** Term 5 makes the headline gesture do nothing whenever the controller is unsettled or dirty, on a canvas where **578 of 770 elements are reorderable** (§3.1) — while DR47-7 rejects silence precisely because it teaches the user the feature is broken. Should it say something, and how often does it happen? | Either a scope call or a measurement of the dirty-press rate; the phase can ship the self-healing behaviour (the ordinary click commits the draft, so the next press works) but cannot decide whether that is enough. |
| **U9** ⚠ **NEW (r4)** | **What `n / N` MEANS.** §4.4 rules the numbers instance-local so the user can count them, and §4.2(2)'s drop-on-absence ruling then makes the denominator **change between visually identical rows**: on `shop/order-detail`'s six step columns the readout shows `n / 3` in five and `n / 2` in the sixth, for a single template edit that changes all six. So `n / N` describes neither the source order the edit acts on nor the scope of the edit. ⚠ **AND THE FRAMING MATTERS, BECAUSE r4's WAS WRONG (r5): the owner DELEGATED the form.** The ruling record reads *"the drop position (`3 / 7` **or whatever form the plan settles**)"* — so this is not *"ground the owner personally ruled and the plan must not settle"*; it is **the plan settling the form it was handed, and reporting a consequence of that form which was not visible when the form was delegated.** **Asking the owner to re-decide something they handed over is the one way this reads badly**; asking them whether a consequence they could not have seen is acceptable is the reason the U-list exists. Options if the owner wants one: keep instance-local (what the user can count); show the source position (what the write does); or drop the denominator. | A denominator that changes between identical-looking rows is a number the user cannot reconcile, and no test can say whether that is worse than a total they cannot count. |

**Still UNVERIFIED, and it is now a short list:** every claim about how the gesture FEELS; other browser engines; a real cross-application pointer drag-out; the viewport-dependence of the wrap and overlap counts; and any chain hidden behind an in-page control a sweep did not reach — **a bound whose SCOPE is stated in the status block rather than left implicit, because three sweeps drove three different state scopes.**

---

## 9. Open questions routed OUT of this lane

**9.1 — DR47-8 is CLOSED**; what remains is the DESTINATION of reading (a), which the owner did not cancel (*"it'd be useful to have"*). **S47-0 routes it back to B-Q4's row with the ruling recorded and no phase number invented.** ⚠ One half of the owner's reasoning is deliberately **not** repeated as fact: they offered *"what went into phase-46 was (b) too"* as their own reading from context; phase-46 touched the readout FAMILY and shipped no size readout, which is consistent but is not the same claim. **The ruling stands on the owner having made it.**

**9.2 — KI-47: NOT TAKEN, lead-ruled; the destination stays open.** Phase-46's S46-5 records that correcting every routing site was the owner's **stated condition** for excluding the family KI-47 was found to belong to; adding it back by lead inference reverses an owner condition.

**9.3 — `expectDestination` and "no new write class": CLOSED** on the enumeration in §4.3, with r0's header-sentence appeal withdrawn. The real objection was **optionality**, and the anchor receipt answers it by design.

**9.4 — `undo-focus-ownership`.** C47-6a is the fix, C47-6b the placement improvement; the owner's sketch is honoured in mechanism and declined only in host. **Needs: owner confirmation at the U-item pass. Blocking: nothing.**

**9.5 — F46-D: LEFT STANDING and unrouted, on a MECHANISM.** `e2e/resize-handles.spec.ts#async function readScene(page: Page, oid: string = SUBJECT_OID): Promise<Scene> {`'s predicate falls back when `#dsh-handle-layer` is **absent**; §4.1(h) hides by `visibility`, never by unmount, so phase-47 does not make that fallback reachable. **S47-6 owes the grep as a named deliverable**, and a lead may still take F46-D opportunistically.

**9.6 — The design-view click constraint (M10): does it deserve a `docs/known-issues.md` entry?** On :3001 an in-page control cannot be activated by a click because the selection shield claims the press; measured with a cross-host control (§5, S47-6). **It is not phase-47's defect and not phase-47's to fix**, but it constrains every future Playwright spec that needs a non-default page state on the design view. **The lead rules whether it becomes a KI; this plan records it where S47-6 will read it either way.**

---

## 10. ADR

**Decision.** Ship drag-to-reorder as a gesture that (i) is recognised inside the shield's existing ordinary press arm, adding no arm to a table that partitions by target ownership; (ii) splits CANDIDATE from ELIGIBLE so an ineligible subject arms into a refusing state, and declines to arm unless the controller is settled-and-clean; (iii) makes the drag subject the selection at arm time; (iv) resolves its drop by sibling IDENTITY against the published chain, with a total hit-test, an order-once/geometry-per-move table, a parent-scoped direct-child join that **drops unrendered members rather than refusing**, and layout admissibility **scoped to the subset actually modelled**; (v) writes it as ONE request carrying an **anchor receipt**, rearranged by a **ONE-SPLICE composer** inside `computeStructuralEdit`, yielding one journal entry and one Cmd+Z; (vi) surfaces a blue indicator, a **drop-position** readout clamped to the ring layer, and a refusal readout, as three non-operable nodes at z 44; (vii) refuses with a map total over the engine's vocabulary, its `undefined` arm and six client-only keys over three conditions, in ko+en, naming relationships rather than elements or display values — including one whose sentence names the rendered COPY, because E3 is instance-scoped; (viii) registers a second active-drag guard behind one wrapper at all 7 boundaries, with its own teardown; and (ix) fixes `undo-focus-ownership` by counting `document.body` as owned, with a separately-sited focus-placement improvement.

**Drivers.** D47-1 (§3.1's chain census — five independent derivations). D47-2 (**the no-flow-axis refusal is the majority case, 61.3 % measured live**, and the ontology contract owed it regardless). D47-3 (four shipped, gated mechanisms on one press).

**Alternatives considered.** A fourth shield arm — rejected on what the table partitions by. A second stage listener — spec-legal, rejected on one press having two owners. N sequential POSTs — rejected on undo count, round-trips and atomicity. A `steps: number` — rejected because a count is unverifiable; G47-10 makes it executable. A `move-to` verb — rejected as five ripples. **A `{prevOid, nextOid}` GAP receipt (r1's own choice) — withdrawn because its second producer cannot construct it.** **A k = 1 CLAMP** — the strongest argument against this design's centre of gravity, proposed independently by two round-1 lanes; **rejected because a clamped gesture measures a crippled one at the owner's live pass**, and its cost half is gone since the one-splice composer. **A k-SWAP fold over one parse (r2's own choice) — falsified: two lanes built it and both watched it throw `span-sentinel-failed`, because `swapSpans` shifts every later offset. The repo had already written that lesson into `cutSpans`'s docblock in the same file, and the plan reached past it.** **Requiring every chain member to resolve (r2's rule) — withdrawn: it produced a per-instance verdict on a per-chain contract for 9 chains, and no refusal wording survives a user who just did the same drag one column over.** ⚠ **Routing the sub-floor case through `chain-member-not-locatable` (r3's rule) — withdrawn at r4: nothing failed to be LOCATED there, and on `d4b6s3,d8m1w7` it reproduced the very inconsistency the ruling above exists to dissolve. A run of one is a distinct state and gets a distinct key.** A geometric ordinal drop — rejected as silently wrong on reverse and wrapping parents. A live DOM reorder preview — rejected because `#dsh-screen`'s children belong to React. `directionToken` for reversal — rejected as base-layer only. **Modelling full logical flow — rejected on scope after a headless-browser falsification; the subset is scoped and refused-outside instead.** A panel-hosted Korean-only refusal — rejected on surface and on the bilingual rule. Registering with the shipped resize guard — rejected because registration replaces and its `state()` carries resize semantics. Moving default focus to `#dsh-screen` — rejected on host.

**Consequences.**
- The shield takes **two** edits: one ordinary-arm call carrying the predicate-breadth obligation, and one mechanical wrapper swap.
- `POINTER_DRAG_THRESHOLD_PX` gains a fifth importer and a fourth drag classifier; its stale header is corrected.
- The trailing-click one-shot gains a second producer and a widened docstring contract.
- **A second active-drag guard exists**, with a wrapper at all 7 boundaries and its own teardown.
- The wire gains one REQUIRED-or-FORBIDDEN field; **`StructureSection` gains nothing.**
- **`structural-edit.ts` gains a span-rearrangement primitive beside `swapSpans`**, because a k-step move is not k swaps of one pair.
- `styleReadout` moves to a shared module with `tone`, `zIndex` and `accentPx` parameterised and **three** callers migrated; **both** `READOUT_ACCENT_PX` declarations stay where the shipped regex gate reads them.
- The ring layer gains three readouts at **z 44**; the drop-position readout is **clamped** at the frame edge because the layer clips.
- **`#dsh-ring-instance-hint` gains an explicit `visibility: visible`**, without which R47-8 had no working mechanism.
- **The gesture refuses on four layout shapes it does not model and on chain ambiguity — all with zero subjects in this corpus**, so their gates carry authored subjects rather than a false claim to shipped ones.
- ⚠ **And it refuses, with its own key and its own words, when fewer than two chain members render in the pressed copy — the ONE client-only refusal with a SHIPPED subject** (`lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, 2/2/2/2/1). **E3 is therefore the only instance-scoped eligibility question**, and G47-11d is what keeps its wording honest for a user who just succeeded one copy over.
- ⚠ **No-op detection is over SOURCE position**, so a source-effective, render-inert drag issues a real request and consumes an undo slot — stated as a consequence, unconstructible on any flex-parented subject today.
- Six ontology rows get dispositions, the component-instance row ships **qualified**, the preamble's two sentences are rewritten and its two dead line pins converted; no register gate watches any of it.
- The resize W×H readout leaves the phase **without being cancelled**.

**Follow-ups.** The drag GHOST (DR47-3b). Cross-parent drag. Marquee / absolute insert-on-drop — the stage-background slot is left unclaimed on purpose. **B-Q4 now carries two live halves: auto-scroll, and the W×H readout routed back by the 2026-08-27 ruling.** KI-47 and F46-D (§9.2, §9.5). Modelling `rtl` / vertical writing modes / `order` (R47-11). The design-view click constraint (§9.6). ⚠ **Retiring `use-spacing-drag.ts`'s duplicate `styleReadout` is NOT a follow-up** — the shipped regex gate requires that copy's `READOUT_ACCENT_PX` declaration to exist.

---

## 11. Pre-mortem — four ways this phase ships broken

1. **The new predicate is too BROAD and everything is green.** The reorder call matched a target class nobody intended, and no behavioural row could see it because the gesture appeared to work everywhere it was tried. **This is the class the record contains:** `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, `#dsh-stage`'s `tabIndex={-1}` made it match from anywhere, and ROW D became unreachable while every behaviour stayed green. **Countermeasures: G47-2, G47-5c, G47-5d, G47-1's fourth press, and the S47-3 brief's must-NOT-match statement.**
2. **One Cmd+Z is asserted and passes for the wrong reason.** The gate drags one position because **173 of 235 chains can only produce k = 1**, and a k-per-request implementation passes it. **Countermeasures: G47-8 specifies a 5-member chain and a 3-position drag; S47-0 owes a flex-col chain of ≥5 whose members all render together, because the corpus's existing flex-col 5-chains are three-quarters conditional; and G47-20 pins the parse count at 2 so the composer cannot silently degrade.**
3. ⚠ **A GATE IS BUILT THAT CANNOT FAIL — and this plan has now shipped FIVE instances in its own text, SPLIT BY CLASS, because they are not one failure and one countermeasure does not cover them.** **SUBJECT CLASS (2): the subject cannot produce the failure.** r2's G47-11c named two shipped subjects that measurement showed cannot fire, and r2's G47-19 read a row count and called it a chain length. **MUTATION CLASS (3): the subject is fine and the mutation is not.** r0's G47-1 named a mutation the contract could not express; r1's G47-11b leg (i) was green on the defect and on the correct behaviour alike; ⚠ **and r3's G47-16 leg (ii) was the same failure again, described in the identical words in the very revision that wrote this paragraph — the hint is a CHILD of the layer the mutation adds it to, so "add the hint to the hidden set" changes nothing (§4.1(h)). r3 counted four and was short by its own freshest one.** Every one was found by someone re-deriving the subject or the mutation rather than the rule. ⚠ **COUNTERMEASURES, AND THE ASYMMETRY IS NAMED RATHER THAN PAPERED OVER: §6's subject column and the SYNTHETIC declarations are MECHANISMS, and they cover the SUBJECT class only.** For the mutation class the plan offers the standing obligation that *every gate is shown RED under its named mutation before it is believed green* — **which is a RESOLUTION, not a mechanism.** Three of the five instances are in the class the plan has no mechanism for, and two of those three were caught by a reviewer rather than by the process. That is the honest state.
4. ⚠ **A RULING IS CORRECT AND ITS DIVIDEND IS FALSE, BECAUSE IT WAS VALIDATED AGAINST THE POPULATION IT WAS DERIVED FROM.** §4.2(2)'s drop-on-absence ruling was derived from chains where *some* member goes missing, and its closing sentence claimed *"all 15 chains admit in every instance."* **It was never checked against a chain where enough members go missing to fall below its own floor — and for a 2-member chain with one conditional sibling those are the same event.** `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` resolves 2/2/2/2/1 across five flex-parented instances, so the fifth reproduced, on a shipped default-state subject, the exact user experience the ruling exists to prevent. The ruling survived; **only its dividend sentence was wrong, which is the hardest shape to catch, because everything around it is right.** **Countermeasures: G47-11d, whose subject is that chain and whose three mutations each restore one of the wrong answers; and the standing habit that produced the catch — re-deriving a claim's population rather than its rule.** ⚠ **This is the phase's signature failure, and it has now happened at four levels** — a false brief claim (§0), a correction that repeated the error inside itself (§3.1's oid reasons), an ontology sentence asserted as verified without re-running its grep (§4.7), and now a ruling's dividend. **The plan carries all four rather than only the ones still visible in the text.**

---

## 12. Test plan, by layer

- **Unit (headless):** the chain walk and its termination; the drop table's two lifetimes and its drop-on-absence rule; the total hit-test over synthetic rects (wrap-line gaps, exact midpoints, equal distances, overlapping rects); the scoped-admissibility conjunction, each clause falsified singly; the reversal flip; no-op detection; the candidate conjunction's five terms; the eligible split's three questions (E1/E2/E3) and their SEVEN failure routes — E1's three, E2's two, E3's two; the terminal totality **and the teardown reset**; the destination and direction computation; **the refusal map's `Record` over the engine union, its `undefined` arm, and its six client-only keys**.
- **jsdom:** the three new nodes' structure, marks, inline `pointer-events` and clamping; the `styleReadout` extraction's before/after equality and both `READOUT_ACCENT_PX` declarations; **the instance hint's `visibility: visible` override under a hidden handle layer**; the bilingual rendering and its legs; the one-per-press pair row; the Cmd+Z rows and guard order; the drag-subject rows; the KI-46 in-flight-window row.
- **Sidecar / integration:** the anchor receipt's 409 arms and its self-anchor 400; the REQUIRED/FORBIDDEN 400s; the direction-disagreement 400; **the one-splice composer's byte-exact equality against the naive fold with the no-move and wrong-destination controls, its parse count (2), and its in-lock time against R47-4's pre-committed 12 ms on the named subject**; atomic abort; one journal push; the applied-`k` echo.
- **Playwright — `e2e/reorder-drag.spec.ts`, declared `ambient`, plus the fourth press added to `e2e/spacing-gesture.spec.ts`.** ⚠ **The classification is argued (G47-13 leg ii):** the spec drives structural edits through the sidecar and asserts the resulting bytes on disk, so it **fails without a sidecar** — the `$doc`'s stated criterion. It resembles `e2e/structural-editing.spec.ts` (ambient, destructive, on-disk assertions), not `e2e/resize-handles.spec.ts` (neutral, a pure DOM-geometry checker). Rows: a full drag with on-disk bytes asserted; capture across the frame edge; the no-op-still-selects row; one Cmd+Z reverting a 3-position drag; the stage-background rows; wrap and overlap on their shipped subjects; the live-variant predicate; the three modelled-subset refusals with their LTR positive control; the `.map()` multi-instance row **and the instance-hint visibility leg**; the ambiguity refusals on S47-0's authored subjects; **the sub-floor row on `d4b6s3,d8m1w7` — admit in instances 0–3, `no-sibling-in-this-copy` in instance 4 (G47-11d), the one client-only refusal with a shipped subject**; the boundary-termination row. ⚠ **Destructive** — every mutating row owes the same `finally` snapshot-and-re-derive net `structural-editing.spec.ts` carries. ⚠ **And no row may depend on driving an in-page control by clicking on :3001 (§5, S47-6).**
- **Observability:** the structural log line carries the **applied** `k`, read from the result.
- **Owner, live:** §8's U1–U5, U7, U8 **and U9**, at the boundary after S47-4. ⚠ *r4 minted U9 and left it out of this list; §12 is the layer-by-layer contract a story brief is written from, so a U-item that exists only in §8 is a deliverable with no carrier.* **U6 is deliberately empty.**
<!-- Generated: 2026-06-10 | Updated: 2026-07-12 -->

# Descvi

**Descvi** = description + visual/view. An LLM-native design/planning tool.

This file holds the **rules** that bind every agent working on this repo, whatever the vendor. Keep it short: if something is a lookup ("where does X live", "how is Y wired"), it belongs in a reference doc, not here.

| Read this when you need | Doc |
|---|---|
| The rules — invariants, gates, commit and workflow conventions | this file |
| To author a screen (folder=id=route, `page.tsx`/`spec.ts`, edges, state axes, `::` sub-screens) | `docs/prompt/PORTING.md` — the authoring contract |
| Where a mechanism lives / how it is wired | `docs/architecture.md` |
| What is being worked on, what is left, what is broken | `docs/post-loop-backlog.md` (+ per-initiative trackers and `docs/known-issues.md`, indexed in `docs/README.md`) |
| Detail on one package | `packages/*/AGENTS.md` |

**The plan is the source of truth.** Read the relevant doc before any architectural or scope decision; if reality forces a deviation, update the plan in the same change.

## Stack

- **Vite 5** + **React 19** + **TailwindCSS v4** + **shadcn (base-ui/react)**. Two Vite entries over the same `src/app/**/page.tsx`: `npm run dev` = plain prototype view (:3000, overlay-free); `npm run descvi:dev` = design-view (:3001, overlay + the `descvi-sidecar` write-back editor on :7331). No Next/webpack/RSC.
- **pnpm workspace** monorepo: the dogfood app `descvi-dogfood` at the root + `packages/{core, descvi, eval-harness}`.
- **TypeScript strict** + **Vitest** + **ESLint** everywhere. AST extraction via **swc**, state via **zustand**.
- Korean i18n: viewer UI strings must round-trip Korean input correctly (no jamo separation, no encoding loss).

## Architectural invariants (do not violate without a plan update)

1. **LLM-writeable by construction.** Source of truth = `packages/core/src/schema/screen-graph.schema.json` + the example manifests. zod/TS are sync-checked implementation details (zod ↔ JSON-schema must stay in sync).
2. **One dev surface: the Vite single stack.** descvi dictates ONE stack (it is a prototype tool, not something deployed). Extraction runs through the Vite plugin's `configureServer` loop in dev and the `descvi-extract` bin at build. No SaaS. No VS Code extension.
3. **Page-state is first-class.** The ScreenGraph + intent + the state matrix (status × component visibility, 2-axis) are the spine.
4. **The `::` sub-screen grammar is shipped and settled.** Authoring contract in `docs/prompt/PORTING.md`, implementation map in `docs/architecture.md` — don't re-derive either.
5. **Start small, leave seams.** MCP server, design-system collab, Korean xlsx adapter, graph view, LLM-assist buttons — all explicitly later.

## Verification gates

- **A gate must be able to go RED. Make it fail before you believe it green.** A gate that cannot fail is scaffolding, and it is the most expensive kind of green there is.
- **Deleting a test needs one of exactly two reasons, named in the commit: the code it covered is gone, or the assertion could not go RED.** Anything else is coverage loss wearing a cleanup label. The second reason is the rule above, inverted — phase-23 deleted `live-runner-cleanup.test.ts` on it: the test drove the runner with `--lane restart`, so the sidecar it asserted was stopped had never been started and the port was free because nothing had bound it.
- **The gate set is CI's `verify` job in `.github/workflows/ci.yml` — not a list written here.** Run `pnpm gates`, which parses that job and runs its `run:` steps in order, rather than trusting a hand-copied enumeration: a prose list is not the gate set, and this repo has already shipped one that drifted (a session ran every gate this section used to name, reported green, and CI failed). `e2e` and `e2e-contract-gates` are out of `pnpm gates`' scope on purpose — see the script's own header — run `pnpm test:e2e` for those.
- **A gate nobody watches has already stopped being one.** `main`'s CI failed on every push for two weeks before anyone noticed. Before trusting CI as a gate, look at whether it is green — `gh run list --branch main`.
- **Cite code by ANCHOR, never by line number — `node scripts/check-citation-anchors.mjs` (phase-26).** Write `` `path/to/file.ts#<exact source text>` `` and the gate proves that text occurs **exactly once** in that file; a rename or a delete turns it RED instead of leaving a pointer that quietly means something else. `file.ts:NNN` into `plugin.ts` is banned outright, in every spelling the audit found people reach for — `#LNNN`, `LNNN`, `line NNN`, `NNN행`, and the bare back-reference `` (`:NNN`) `` whose file is named only by the preceding sentence. (Placeholders, not real numbers: an example of a banned form has no business carrying one, and `AGENTS.md` is outside the gate's scan roots so nothing here would catch it.) **This is not a style preference: 19 of 20 pins into one file were wrong within eight commits, and the four in the KI-28 record were byte-exact when written.** A number that is genuinely load-bearing is pinned to an immutable object instead (`git show <sha>:path`), which the gate treats as a record rather than a pin. Two things worth knowing before you fight it: a `.md` target is a section link and is never uniqueness-checked, and an anchor cannot contain a backtick. `--selftest` (41 cases) is what proves the gate itself can go RED.
- **Artifact byte-identity.** Re-run the extractor and confirm `git diff --exit-code .descvi/screens.json` is clean — unless the change is *meant* to alter the artifact, in which case that diff is the deliverable and gets reviewed as such. An unexplained artifact diff is a defect, not noise.
- **UI changes need a real `descvi:dev` smoke** (or Playwright). Unit tests routinely mask defects that only a running server exposes.
- **Schema changes**: ajv-validate every `examples/*.json` + `fixtures/*.json`.

## Branching & commits

- `main` is the integration branch.
- Feature work happens on `feat/phase-{N}-{short-slug}` branches, one branch per plan phase. Deep-dive-derived initiatives get a phase number too — assign the next free N rather than shipping a number-less slug.
- **Conventional Commits** (`feat(core): ...`, `fix(descvi): ...`, `docs(plan): ...`). Atomic: one logical change per commit, and phase artifacts (schema, fixtures, plugins) commit together with their tests.
- Include the trailing `Co-Authored-By: Claude <active-model> <noreply@anthropic.com>` line.
- **Never** skip hooks (`--no-verify`) without explicit user approval. **Never** force-push `main`.
- Doc updates (`docs/*.md`, plans, specs) get their own commits.

## Workflow & scope

- **Per phase: implement → independent verification pass → atomic commit.** External review lanes (codex/gemini) are advisory; a binding lane that RAN the code outranks an advisory lane that reasoned about it.
- **A multi-phase feature needs a whole-set audit, and the audit runs as each phase LANDS, not once at the end.** Per-phase review cannot see a cross-phase contract mismatch by construction — one phase promises X, the next consumes it as Y, and every per-phase review passes. Phase-23 audited once at the end and found a documented command dead since phase 4 of 5, a gate one CLI flag turned off silently, and a gate assertion that could not go RED. **Every one of those was findable the moment the phase after it landed.** Cost of auditing per landing is one lane; cost of auditing at the end is re-opening a phase you called done.
- **Cite what you re-read, not what you remember.** Every `file:line` in a brief, plan or review gets re-opened at the moment you write it. Phase-23's most expensive error was a Playwright citation carried from an earlier lane's report into a brief and from there into four files — the line existed, on a code path that never fires. Confirming a line is there is not confirming it is the one that runs.
- **Transitional cutover pattern.** For grammar/shape migrations: ship the readers first behind dual-read helpers, migrate the artifact LAST, then drop the transitional path. No half-migrated commit, no broken-runtime window.
- **`src/app/**` is the dogfood app — OUT of the deliverable scope.** The deliverable is `packages/**`. Changes under `src/app/` exist to verify an example end-to-end.

## Cost-gated work (needs an explicit human go-ahead)

Do not let these run automatically: the paper eval (~$2–5), the full eval harness (~$50 dual-model grading + cross-grade), and marketing artifacts (videos, embeds, storyboards — human production). Stop and report when you reach one.

## Language & formatting

- **Code comments and commit messages are English.**
- User-facing app strings: bilingual ko + en where applicable.# Worker brief

You are a WORKER. You own the task in your brief and nothing else. The lead owns the conversation with the user, all git, and the decision of who verifies what.

## Ownership

1. **Do not spawn anything that writes or that judges your work.** A read-only lookup is fine when it saves you from pulling a lot of context yourself. Everything else is out: no writer, no reviewer, no second CLI, no fan-out. The lead holds the map of which lane owns which file, and anything you spawn is invisible on it.

2. **Never own git.** No `commit`, `add`, `stash`, `branch`, `push`, `merge`, `rebase`, or `reset`. Leave every change uncommitted for the lead.

   Undoing your own side effects is required, not a violation — leaving the tree dirty is the failure. Restore by copying back a snapshot you took **after the work began**, and never with `git checkout`: that reverts to before the work under review, and the loss is silent, because HEAD's own version passes typecheck, lint and the suite.

3. **Check your own work as hard as you can, and never be the lane that approves it.** Catching your own broken probe before it becomes a finding is worth more than the finding. Routing verification is the lead's.

## When something is unclear

4. **When the brief and reality disagree, settle what you can and tell the lead the rest.** What you can settle FROM SOURCE, settle: fix it, cite the source, and say **loudly** in your report that you reversed the brief — reversing it silently is the failure. What turns on intent, scope or priority you cannot settle. The bar for telling the lead is low: two readings that produce different code, a decision the brief does not cover, a scope materially bigger or smaller than described, a gate that cannot run. The answer reaches you at your next tool call, so you need not stop — keep to work that does not depend on it.

5. **Talk to a peer only if your brief names one.** You may see other agents listed, but the lead owns coordination and a lane you were not told about is not yours to recruit. You also cannot see lanes that started after you, so that list is never the whole picture.

## Doing the work

- Deliver exactly what the brief asks, including the gates it names. Do not skip them and do not silently add scope.
- **Paste the actual results** of what you ran. Never claim "all pass" from a partial run, and report no number you cannot re-derive — give the command beside it, or an immutable anchor.
- **A zero result is evidence only once you have shown the instrument can produce a non-zero one.** Plant the signature you are hunting and confirm the search finds it. An instrument that cannot tell its own silence from its subject's has measured neither, and it reads as the answer you expected.
- **Anchor every edit by content, never by line number.** A script that mutates files must assert it applied exactly once and print the evidence, and you confirm the result by reading the line back — never by a green suite.
- **If you disprove something the brief or the plan asserts, propagate the correction through your own output before reporting it.** Grep the whole FILE, not your diff: a claim your change falsifies does not care whether you edited the line it sits on.
- **The lead sees your final message, not what you print.** A deliverable that is a judgement must be your final message or a file — printed text reaches nobody. If your brief tells you to send to another agent and you have no `SendMessage` tool, load it with `ToolSearch("select:SendMessage")`.
hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,160p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '161,320p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '321,480p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '481,620p' .omc/plans/ralplan-phase-47-drag-reorder.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
# RALPLAN — phase-47 (E3 v3.5): drag-to-reorder, the drag readout, and `undo-focus-ownership`

> **Status: REVISION 3 (final).** Written against `.omc/state/phase47-revision-r3.md` — a primed closure audit, a fresh unprimed reviewer, and a **live probe lane that drove a real browser** — on top of r2's owner ruling (`.omc/state/phase47-owner-ruling-drag-readout.md`).
>
> **THE STANDING EVIDENCE RULE (r2 §E): every population claim and every timing number names the probe that produced it and its control, and each number lives in exactly ONE section.** Static probes: `.omc/state/scratch-r2/*.mjs`, re-run by this lane in r2 against an edit-map built by `buildEditMap` over every `src/app/**/page.tsx` with a sibling `spec.ts`. Live probes: round 3's lane.
>
> ### What has been DRIVEN, and on what
>
> **Browser: Chromium 148.0.7778.96, headless and headed, agreeing exactly. Hosts: `descvi:dev` :3001 with the sidecar on :7331, and the plain view :3000. Both ports free before, both stopped after; tree clean; `.descvi/screens.json` byte-identical.** Every live number below carries a planted positive control.
>
> - **Capture on `#dsh-stage` holds off-frame** (§4.1(e)) — with the paired no-capture control that makes it evidence.
> - **The live parent-layout census** (§3.1) — **91 flex / 144 non-flex of 235, 61.3 % non-flex**, cross-tabulated against the authored proxy with **zero misclassifications in either direction**.
> - **Zero-population findings for four clauses this plan keeps anyway** (§4.2(2), §4.2(3), §4.2(5)) and small non-zero counts for two tie-breaks (§4.2(4)).
> - **The one-splice composer, measured byte-exact against the naive fold with controls in both directions** (§3.3).
> - The census reproduces a **fifth** time.
>
> ⚠ **A CONTROL CAUGHT THE LIVE LANE'S OWN INSTRUMENT, AND THAT IS RECORDED RATHER THAN SMOOTHED.** Its first wrap detector counted distinct cross-axis offsets and reported **37** wrapped parents; an `items-center` row with unequal-height children produces that reading without wrapping. **The corrected count is 3**, and §4.2(4) carries the corrected number.
>
> ### What remains UNMEASURED, precisely
>
> - **Other browser engines.** Firefox and WebKit are not in this repo's Playwright cache and the repo's own e2e is Chromium-only.
> - **A real cross-application pointer drag-out.** CDP input always targets the page, so §4.1(e) measures *the browser honouring off-viewport coordinates*, **not** the OS handing the pointer to another application.
> - **Viewport-dependence of the wrap and overlap counts** (§4.2(4)) — measured at one viewport.
> - **Any chain hidden behind an in-page control a sweep did not reach.** ⚠ **THE BOUND IS SCOPE-QUALIFIED, AND r3 STATED IT WITHOUT ITS SCOPE (r5). Three sweeps ran under three different scopes and the figures are NOT interchangeable:** **round 3** swept multiple observed states over 235 chains and found **exactly 1 never reachable in any state it observed** — that is the origin of the *"1 of 235"* figure, and it is a bound **over the states that sweep drove**, not over all states; **round 4's delta lane** enumerated **215** of 235 (naive screen-id derivation, no `::` sub-screens) and swept **DEFAULT STATE ONLY**, so its zero-counts are lower bounds on coverage and it said so; **round 5's pre-codex sweep** found **112 of 235 chains render zero instances in default state.** **No figure here is wrong; what was missing is which states each was driven under, and this lane does not guess.** The honest reading: *at least* one chain is unreachable in every state anyone drove, roughly half render nothing at default, and **no sweep has enumerated the state space.** ⚠ **This matters because four SYNTHETIC gate-subject declarations rest on zero-counts, and a zero measured under an unstated scope is the seam §4.2(6)'s own falsification crawled out of** — the r4 lane read one tab of a two-tab screen and wrote a universal. **S47-0's subject audit therefore states the scope of every count it reports, per §E.**
> - **Every claim about how the gesture FEELS.** §8 routes those.
>
> ⚠ **THE PROCESS NOTE, KEPT BECAUSE IT HAS COST THIS PHASE FOUR TIMES — AND THE COUNT IS KEPT EQUAL TO THE LIST, BECAUSE P47-5's OWN STANDARD IS THAT A COUNT OMITTING ITS FRESHEST INSTANCE IS THE FAILURE IT DESCRIBES.** `AGENTS.md`: *"Cite what you re-read, not what you remember."* R0 inherited a false claim about the shield's docblock without re-opening it (§0); **r1 repeated the error inside the correction for it** (the oid-reconciliation reasons); **r2 asserted an ontology sentence was *"still literally true"* without re-running its grep — it is false at HEAD** (§4.7); **and r4 wrote that no flex-parented subject could construct the render-inert drag, having read one tab of a two-tab screen** (§4.2(6)). ⚠ **THE FOURTH IS THE MOST INSTRUCTIVE, BECAUSE IT HAPPENED INSIDE THE EDIT THAT DOCUMENTS THE FAILURE MODE (pre-mortem 4).** ⚠ **AND THE BASE RATE IS THE MOST PORTABLE THING THIS PLANNING ROUND PRODUCED, SO IT IS RECORDED HERE RATHER THAN LEFT IN A REVIEW NOTE: EVERY UNREVIEWED ADDITION MADE IN THIS ROUND HAS CARRIED A DEFECT — FOUR FOR FOUR — AND EVERY ONE WAS CAUGHT BY BUILDING OR DRIVING IT, NEVER BY READING IT.** The operative consequence for whoever implements this plan: **a paragraph nobody has executed is not evidence, however carefully it was reasoned** — which is `AGENTS.md`'s own *"a fact checked against an ARTIFACT is not verified until it is checked against the RUNNING APP"*, one level up, applied to prose. This revision re-opened every source claim it repeats and drove none of them; **it is therefore subject to the same rate.**

---

## 0. The corrected arm-table record, and what it changes

The record in `use-canvas-selection-shield.ts`, re-verified at source: **ONE** occasion on which the arm table itself was wrong — `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, so `#dsh-stage`'s own `tabIndex={-1}` made every handle, strip and apron take ROW P and retired phase-42's entire ROW D as unreachable code. **That failure is PREDICATE BREADTH, not order of arms.** The two other recorded items are wrong claims *about* the table.

**Downstream:** P47-4's ground; D47-3's count and class; **R47-1's MECHANISM** (a mechanism aimed at arm order would not have caught the failure that happened); pre-mortem 1; and **G47-1's rebuild**.

**Phase-47 adds no arm, and the reason is what the table is a partition OF.** It classifies by **target ownership** — ROW D means *this target owns its own pointer*, ROW P *its own caret*. Reorderability is a **gesture state on an ordinary target**, decided after the press by travel, and a sub-threshold press must retain **ordinary click semantics in full**. A partition by target cannot express a distinction that only exists after the target has been claimed. C45-5 is the precedent for TOPOLOGY only.

⚠ **The phase's edit to that file is TWO edits: (i) one call on the ordinary arm, and (ii) one call-site swap at `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      terminateActiveResizeGesture();` plus its import. The predicate-breadth obligation attaches to (i) alone**; (ii) is mechanical and is policed by G47-14.

---

## 1. RALPLAN-DR summary

### Principles (5)

- **P47-1 — THE ARTIFACT OWNS ORDER AND MEMBERSHIP; THE DOM OWNS GEOMETRY AND LIVE LAYOUT.** `StructureSection.tsx`'s prohibition is about re-deriving the **engine's op-unit eligibility**, a source-shape verdict the artifact publishes; this phase never re-derives it (`packages/descvi/src/react/overlay/engine/source-resolver.ts#export interface StructureEditInfo {`, produced by `packages/descvi/src/extractor/structural-edit.ts#function adjacentOpUnit(` — the same function the server re-derives the write baseline from). What IS computed client-side is whether the parent lays its children out along an axis right now: a RENDER fact the artifact does not publish and the sidecar has no DOM to answer, so **there is no second implementation for it to diverge from**.
- **P47-2 — ONE GESTURE, ONE REQUEST, ONE JOURNAL ENTRY, ONE Cmd+Z.** `packages/descvi/src/sidecar/commit-write.ts#export type JournalSubject =`: *"an undo unit is an ENTRY, so N entries would be N undos however the write was folded."*
- **P47-3 — A REFUSAL NAMES THE RELATIONSHIP THAT REFUSED, IS TOTAL OVER THE PRODUCER'S VOCABULARY, AND IS BILINGUAL.** ⚠ This plan broke each half at least once in its own text (r1's generic arm named the element; r1's `no-reorderable-sibling` was false for 108 of 130 subjects). §4.5 is where all three are closed.
- **P47-4 — THE ARM TABLE PARTITIONS BY TARGET OWNERSHIP; REORDERABILITY IS NOT A TARGET-OWNERSHIP CLASS.** The risk is undiminished and it is **predicate breadth**.
- **P47-5 — A GATE THAT HAS NOT BEEN SHOWN RED HAS NOT BEEN BUILT; A GATE WHOSE MUTATION THE CONTRACT CANNOT EXPRESS IS NOT A GATE; AND A GATE WITH NO SATISFIABLE SUBJECT IS NOT A GATE EITHER.** All three have now occurred in this plan's own text, **FIVE times, and the enumeration is kept complete because a count that omits its own freshest instance is the failure it describes**: **mutation class** — r0's G47-1 (a mutation the contract could not express), r1's G47-11b leg (i) (green on the defect and on the correct behaviour alike), **and r3's G47-16 leg (ii), which is this plan's most recent one and was described in the identical words** (§4.1(h), M4); **subject class** — r2's G47-11c and r2's G47-19, both naming shipped subjects that measurement showed cannot fire. ⚠ **The remedy for the third is the `unequal-indent` rider this plan already carries: keep the clause, declare the subject SYNTHETIC, and make authoring it an unconditional S47-0 obligation.**

### Decision drivers (top 3)

- **D47-1 — THE SUBJECT POPULATION IS SMALL AND SHALLOW, WHICH PRICES OUT EVERY PER-STEP DESIGN.** The figures live once, in §3.1.
- **D47-2 — THE NO-FLOW-AXIS REFUSAL IS THE MAJORITY CASE. ⚠ NOW VERIFIED LIVE, AND THE UNVERIFIED LABEL r2 ATTACHED IS RETIRED.** §3.1 carries the number and its control. The ontology contract already owed the refusal regardless of prevalence (`.omc/specs/interaction-ontology.md` §3.F-1 rules the non-flex case *"Reorder ambiguous (no flow axis)"* with gate *"undefined blue-line; clarify at gate"*) — **prevalence decides how much surface it deserves, and the answer is: a first-class one.** The `canInsertChild` history is the precedent: a plan justification of *"a rare refusal arrives as a 422"* was false by measurement, the refusal being the majority case.
- **D47-3 — FOUR SHIPPED, GATED MECHANISMS MEET ON THE ORDINARY CANVAS PRESS.** (i) the arm table and its one recorded predicate-breadth failure; (ii) phase-45's travel guard (`packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#        maxTravelRef.current >= POINTER_DRAG_THRESHOLD_PX`); (iii) phase-42's one-shot trailing-click latch; (iv) the shared active-drag guard, consulted at **7 production sites across 4 files**.

### Real decisions, with options

| # | Decision | Options considered | Chosen | Why the losers lost |
|---|---|---|---|---|
| **DR47-1** | Where the reorder press is recognised | **(a)** a FOURTH arm-table row; **(b)** a second capture listener on `#dsh-stage`; **(c)** a `document`-capture listener; **(d)** ONE call inside the shield's existing ordinary arm, beside `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (e instanceof MouseEvent) beginTravelRecording(e);` | **(d)** | **(a)** loses on what the table partitions by (§0). **(b)** works in the spec — `packages/descvi/src/react/overlay/canvas/selection-shield.ts#export function suppressShieldPointer(event: ShieldEvent): void {` calls `stopPropagation`, never `stopImmediatePropagation` — but gives one press two owners on one node, ordered by effect registration. **(c)** is (b) with a wider blast radius. |
| **DR47-2** | How the trailing click is suppressed | **(a)** widen phase-45's travel consumption; **(b)** arm phase-42's shipped one-shot at a terminal that **issued a request**; **(c)** a second one-shot cell | **(b)** | **(a)** moves a shipped, gated condition phase-45 spent four revisions making evaluable at its pinned point. **(c)** adds a second drop site to the unconditional `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      void takeTrailingClickSuppression();`. **(b)'s cost is two producers for one boolean**; co-occurrence needs two simultaneous pointers (disjoint targets). ⚠ Its docstring contract widens — `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#/** Called by the terminal path when a gesture ended with the primary button still down. */` is untrue of a reorder terminal; keep the name, correct the docstring. |
| **DR47-3** | What the drag shows | **(a)** live DOM reorder preview; **(b)** a drag GHOST plus the indicator; **(c)** the indicator ALONE | **(c)**; (b) a follow-up | **(a)** is refused structurally: `#dsh-screen`'s children are React's. **(b)** is a second render surface with its own theme, clipping and stacking questions. ⚠ **AND THE CLIPPING COST IS NOT ONLY THE GHOST'S (M9):** `packages/descvi/src/react/overlay/OverlayShell.tsx#              className="z-40 absolute inset-0 overflow-hidden pointer-events-none"` clips the ring layer at the frame edge, so **a pointer-following readout is clipped too** — ruled at §4.4 rather than left for U1 to discover. |
| **DR47-4** | The wire shape of an n-position move | **(a)** N sequential POSTs; **(b)** `steps: number`; **(c)** a new verb `move-to`; **(d)** a `{prevOid, nextOid}` GAP receipt; **(e)** clamp to k = 1; **(f)** an **ANCHOR receipt `{anchorOid, side}`** | **(f)** | **(d) is unbuildable by its second producer**: `StructureSection` holds ONE LINK, not a chain, so moving B up in `[A,B,C,D]` needs `prev(A)`, which lives in A's entry — every shipped ↑/↓ click would 400. **(f)** is constructible from the panel's own two fields (`prevOid`+`leading` / `nextOid`+`trailing`) and is **exactly what the hit-test produces**. **(a)** fails on undo count, round-trips (`packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export async function applyStructureEdit(` re-fetches on every outcome) and atomicity. **(b)** fails the D7 principle: a count is unverifiable against a stale chain, a coordinate 409s. **(c)** costs a new `StructuralOp` member rippling into `STRUCTURAL_OPS`, the flag ladder, `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string \| null {`'s `never` tail and `REASON_TEXT`. **(e)** — the round-1 steelman from two lanes — **rejected: the phase's most expensive instrument is the owner's live pass and a clamped gesture measures a crippled one**; its cost half is gone anyway (§3.3). ⚠ **(f) EARNED A SECOND DIVIDEND NOBODY PLANNED, AND IT DECIDES §4.2(2):** because the client names a rendered sibling instead of computing an index, **a chain member that does not render costs nothing** — which is what dissolves the conditional-sibling refusal the live lane found. |
| **DR47-5** | How the drop position is computed | **(a)** a geometric ordinal; **(b)** by IDENTITY — hit-test which sibling's box the pointer is nearest and which HALF | **(b)** | **(a)** is silently wrong on reverse order and on wrapping parents. **(b)** makes both fall out. |
| **DR47-6** | How the gesture learns flow, axis and reversal | **(a)** extend `ParentContext`; **(b)** read `getComputedStyle` in the reorder module; **(c)** refuse under reverse parents; **(d)** `packages/descvi/src/react/overlay/panel/parent-context.ts#  directionToken: string \| null;` with a computed fallback; **(e)** model full logical flow | **(b)**, with **admissibility SCOPED to the subset actually modelled** | (a)/(d) closed in round 1: `directionToken` is assigned only inside the `orderedBases` loop, so it is silent on exactly the variant/computed population M3 proved broken, and `flexDirection` comes off the same `CSSStyleDeclaration` the mandatory `display` read creates. **(c)** refuses a well-defined gesture for convenience. **(e)** loses on scope: codex drove headless Chromium and measured that `direction: rtl` reverses visual order with `flexDirection` still `row`, `writing-mode: vertical-rl` makes that `row` advance on y, and unequal child `order` makes a source reorder produce no visual movement — with a positive control in the same run. **Ruling: admit only the modelled subset and refuse otherwise**, three independent RED-whens. ⚠ **Round 3 measured all three exclusions at ZERO subjects in this corpus (§4.2(3)) — which changes their GATE SUBJECTS, not their correctness.** |
| **DR47-7** | Where the refusal is surfaced | **(a)** the panel's Korean-only `REASON_TEXT`; **(b)** a CANVAS readout, bilingual, non-operable; **(c)** silence | **(b)** for an ARMED gesture; **(c)** only below the threshold | **(a)** is the wrong surface and the wrong channel (`title` is a user-facing app string; `AGENTS.md` requires ko+en; phase-46 S46-4 reversed a Korean-only proposal on that ground). **(c) alone** teaches the user the feature is broken — at 61.3 % non-flex (§3.1) that is the majority experience. ⚠ The panel's ↑/↓ buttons are not weakened: the flow-axis refusal is a GESTURE policy, not a write constraint. |
| **DR47-8** | What the drag readout is | **(a)** a W×H readout on the RESIZE drag; **(b)** a DROP-POSITION readout on the REORDER drag | **(b)**, **owner-ruled 2026-08-27** | **The phase does (b) because the owner ruled (b)**, not because the v3 CLOSE sentence was correctly parsed — **the owner does not remember making that ruling**, so it is a weaker authority than r0/r1 treated it as and the fresh input is the strong one. The v3 CLOSE record is **not edited**. **(a) is not cancelled**: it is routed back to B-Q4's row with the ruling recorded, no phase number invented (§9.1). |
| **DR47-9** | `undo-focus-ownership` | **(a)** default focus to `#dsh-screen`; **(b)** widen the OWNERSHIP guard so `document.body` counts as owned; **(c)** restore focus by hand at the remount site; **(e)** call the shipped `packages/descvi/src/react/overlay/engine/use-preview-session.ts#export function focusStageIfOrphaned(stage: HTMLElement \| null): void {` from the panel value-commit path | **(b) is the fix; (e) rides as a placement improvement, correctly sited** | The backlog row names `document.body` as the mechanism for **both** dead windows, so **(b) alone restores Cmd+Z in both**. **(e) as r1 sited it cannot fire**: `focusStageIfOwned`'s measured table records that *"the remount lands on a LATER flush than this callback"*, so at the commit callback `orphaned` is false. **(a)** loses on host: `#dsh-stage` already carries `tabIndex={-1}`; `#dsh-screen` would need one, putting a new `[tabindex]` node inside the stage. **(c)** is (e) hand-rolled. ⚠ The evidence lives at `packages/descvi/src/react/overlay/OverlayShell.tsx#const focusStageIfOwned = useCallback(`, where a text-entry guard **was built and rejected** with two rows measured STICKY. |
| **DR47-10** | The drag subject vs `selectedTarget` | **(i)** arm only when pressed oid == selected oid; **(ii)** resolve pending edits at threshold, asynchronously; **(iii)** pass an explicit subject through the handoff; **(iv)** arm on any eligible element, switch selection **synchronously** at threshold, decline to arm unless the controller is settled-and-clean | **(iv)** | `packages/descvi/src/react/overlay/engine/use-preview-session.ts#      const oidOfTarget = selectedTarget.oid ?? selectedTarget.specId;` makes `selectedTarget` the sole subject of the post-save handoff, and the latch makes the release click return before selection resolution. **(i)** costs two gestures per reorder (this shield selects on CLICK). **(ii)** loses on a phase-42 defect that was found and **FIXED** — the hazard CLASS survives: an async commit mid-gesture can invalidate an armed gesture through an HMR reseed. **(iii)** leaves the dirty-draft bypass. ⚠ The predicate is the shipped two-reader one, `packages/descvi/src/react/overlay/panel/use-classname-commit.ts#    const settledAndClean = hasPendingEdits?.() !== true && isSettled?.() !== false;` — **`hasPendingEdits()` alone is the predicate KI-46 was filed against.** |
| **DR47-11** | The shared active-drag guard | **(a)** register with the shipped `resizeGestureGuard`; **(b)** a second guard behind ONE wrapper at all 7 boundaries; **(c)** a keyed terminal registry; **(d)** do not register | **(b)** | **(d)** is disqualified by the shield's own comment: *"reachable exactly when pointer CAPTURE FAILS … the shield would resolve a selection mid-gesture and produce a second POST for one drag."* **(a) is fatal twice**: `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#  registerTerminal(run: () => void): () => void;` documents *"registering replaces"* and registration happens at machine creation, so a reorder machine would permanently replace the resize terminal; and the guard publishes `packages/descvi/src/react/overlay/canvas/resize-gesture-guard.ts#export type GestureState = "idle" \| "armed-pending" \| "armed" \| "dragging" \| "terminal";` plus `armedBaseline()` to the reseed choke with *resize* semantics. **(c)** relocates the second problem. **(b)'s cost is answered by a mechanism** — one wrapper, 7 sites migrated in S47-3's commit, G47-14. |

---

## 2. What this phase ships, inherits, does not touch, and is EXCLUDED from

**The scope line, quoted from `docs/e3/tracker.md` §"v3 CLOSE (2026-08-24)" — byte-identical, and NOT edited:**

> **Drag-to-reorder → IN, as phase-47 of a v3.5 follow-up pair.** The gesture rides v2's existing `move-up`/`move-down` verbs (no new write class) with the blue insertion indicator, and carries the cheap B-Q4 mitigation (a W×H readout during drag) since this gesture is where dragging blind bites.

⚠ **This quote's authority is weaker than r0 and r1 treated it as: the owner does not remember making the ruling.** The readout half is now governed by the fresh input of 2026-08-27 (DR47-8). The rest — riding the existing verbs, no new write class, the blue insertion indicator — is unchallenged and is what this phase builds, as is the v3.5 line's *"undo-focus-ownership belongs with 47"*.

**Also lands here, ruled in §4:** the gesture's arming, subject rule, one-per-press rule and terminal (§4.1); the drop resolution, its total hit-test and its scoped layout admissibility (§4.2); the anchor-receipted single-request move over a **one-splice composer** (§4.3); the indicator and the drop-position readout (§4.4); the refusal set (§4.5); `undo-focus-ownership` (§4.6); the ontology amendments (§4.7).

**Inherits without change:** `packages/descvi/src/extractor/structural-edit.ts#export const STRUCTURAL_OPS: readonly StructuralOp[] = ['delete', 'move-up', 'move-down', 'duplicate', 'insert-after'];`; the five-verb flag ladder; `packages/descvi/src/extractor/structural-edit.ts#function baselineFor(ctx: ModuleContext, loc: OpUnitLocation): StructuralBaseline {` and the D7 receipt semantics; the shield's three-arm table **unchanged in every arm**; phase-45's travel guard **unchanged**; `deriveParentContext`'s field set; the spacing family; KI-10's inheritance.

⚠ **`POINTER_DRAG_THRESHOLD_PX`'s stale header is corrected as a free rider**: it says *"ONE SYMBOL, THREE CONSUMERS"*; four modules import it today, so reorder is the **fifth importer and the fourth drag classifier**.

**Does NOT touch:** any serializer; `ParentContext`'s shape; the panel's `StructureSection` affordance record — **no exceptions**, because the anchor receipt needs only the two fields the panel already holds; the handle-geometry admission rules (phase-48); `.descvi/screens.json`'s content **except** for S47-0's fixture authoring.

**EXCLUDED, each with its reason and its destination:**
1. **B-Q5** → **phase-48**, owner ruling 2026-08-25.
2. **Marquee / rubber-band** → **deferred-v4**. §4.1's arming requires the press to resolve to a `[data-oid]` element inside `#dsh-screen`, so the stage background stays unclaimed. **G47-2 keeps that true.**
3. **Cross-parent drag** → `deferred-v2 (hard)`. §4.2's chain is scoped to ONE `parentOid` by construction.
4. **Alt / Cmd / Ctrl + drag** → unchanged. A modifier-held press **does not arm reorder; existing click behaviour is unchanged.** A modifier acquired mid-gesture is ruled at §4.1(f).
5. **Multi-select drag (N > 1)** → OUT; §4.1(b) carries the argument, which is about the click arm's ORDER.
6. **`selection-ring-treatment`, `spacing-affordance-mark`, KI-54** → not picked up.
7. **KI-47** → **NOT TAKEN, lead-ruled** (§9.2): it needs a fresh owner input, not a lead inference.
8. **The resize W×H readout** → routed back to B-Q4's row, **excluded but NOT cancelled** (§9.1).
9. ⚠ **Modelling `rtl` / vertical writing modes / unequal `order`** → out by DR47-6(e); the gesture refuses on them and names the panel as the working alternative. **Zero subjects in this corpus (§4.2(3))**, so nothing is lost today.

---

## 3. Repo facts

### 3.1 The census, the singleton split, and the parent-layout split — the ONE home for all of these numbers

**Static probes** (`.omc/state/scratch-r2/{census,singletons,split,tally}.mjs`, re-run by this lane in r2; reproduced independently five times across rounds 1–3):

| Quantity | Value |
|---|---|
| oid entries / entries with `canMoveUp \|\| canMoveDown` | 770 / **578** |
| chain components / orphans | **427** / 0 |
| admissible multi-member chains (≥2) / members in them | **235 / 578** |
| chains of ≥3 / ≥4 / longest | **62 / 21 / 7** |
| component-length histogram | 1×192, 2×173, 3×41, 4×7, 5×6, 6×5, 7×3 |

**Internal control:** *members in multi-member chains* equals *entries with `canMoveUp || canMoveDown`* exactly (578 = 578), by two independent paths.

**The 192 singletons split three ways by refusal PAIR** (rows sum to 192): **22** `no-adjacent-sibling` both ways — genuinely no neighbour; **108** where a neighbour exists and is not an editable op-unit (57 + 39 + 12); **62** structurally ineligible (26 `unsupported-parent`, 24 `target-bears-data-screen`, 9 `unsupported-container`, 3 `non-canonical-separator`). **The cause of the 108 was DRIVEN:** in `src/app/lab/tests/style-edit/page.tsx`, `v002k2`/`5pznp9`/`sms60s`/`hakgqo` are four *visibly adjacent* children of a `flex flex-col` parent each reporting `unsupported-sibling` with `prev=null next=null`; **strip the intervening `{/* … */}` JSX comments and re-run `buildEditMap` and `v002k2` reads `prev=5n09bh next=5pznp9`, fully eligible.** A JSX comment severs the chain, because `adjacentOpUnit` requires one canonical separator and a comment is not one — **and the user cannot see it.**

⚠ **All 192 carry a typed reason for BOTH move ops, so §4.5's `undefined` arm is measured at ZERO occurrences today.** It exists because the producer's TYPE admits it (`reasons?: Partial<Record<StructuralOp, StructuralRefusalReason>>`, omitted when empty) and because the shipped panel carries the equivalent at `packages/descvi/src/react/overlay/panel/StructureSection.tsx#function fallbackReason(op: StructureOp, structure: StructureEditInfo): string {`.

**The refusal tally over `move-up`/`move-down` across `src/app` — 854 REFUSALS (not entries):** `no-adjacent-sibling` 541 · `unsupported-sibling` 189 · `unsupported-parent` 52 · `target-bears-data-screen` 48 · `unsupported-container` 18 · `non-canonical-separator` 6 · **`unequal-indent` 0** (positive-controlled: re-indenting a real line makes it 4). ⚠ **`unsupported-sibling`'s 189 splits by MOMENT (M9): 165 arm-time (on singletons) and 24 fold-step (on multi-member chain members)** — so §4.5's wording must be true at **both** moments, not merely re-scoped from one wrong moment to another.

**THE PARENT-LAYOUT CENSUS — LIVE, and it is the authoritative reading.** Round 3's lane measured computed layout on the running app over all 235 multi-member chains: **91 flex / 144 non-flex — the no-flow-axis refusal is the majority case at 61.3 %.** Cross-tabulated against the authored-class proxy: **zero misclassifications in either direction**; all movement is the proxy's 19 unknowns resolving **8 flex / 11 block**. ⚠ **Both of the proxy's stated edges held as edges**: 83 was a lower bound on flex (→ 91) and 133 + 19 an upper bound on non-flex (→ 144). **The proxy is kept beside the live number as the corroborating reading** — 133 non-flex / 83 flex / 19 unknown, of the 133: 54 `no-class`, 79 real non-flex className **of which 15 are `grid`**, which is the figure §4.5's wording rule 2 rests on. ⚠ *(The `no-class` classification survives here empirically because `src/app/globals.css` contains zero `display:` declarations and zero occurrences of `flex` — an empirical fact about this tree, not a general rule.)*

⚠ **The oid reconciliation, re-opened at source in r2 because r1 carried both of its reasons without re-reading them and both were false:** `798` static `data-oid=` − `24` (`src/app/page.tsx`, the one page with no sibling `spec.ts`) − `3` (`insert-scratch`'s three occurrences are `data-oid="…"` **ellipses in a file-header docblock**, not duplicate oids) − `1` (`wcall1`, one real element plus one docblock mention) = **770**. **The corpus has exactly one duplicated oid string and it is a comment.**

### 3.2 The engine's published chain, and what terminates it (READ)

The chain links only across **exactly one canonical separator** to a `JSXElement` **or an admissible `{cond && <el/>}` container** bearing a well-formed oid, per `(parent, screen partition)`. ⚠ **That parenthetical is load-bearing and §4.2(2) is where it lands: the artifact links siblings the DOM can never show together.**

⚠ **`adjacentOpUnit` and `locateOpUnit` are NOT exported.** S47-2 does not export them; it adds one exported entry point beside them — `resolveMoveDestination(ctx, screenId, oid, anchorOid, side)` — so the chain walk stays in the module that owns `adjacentOpUnit`.

⚠ **`.map()` BODIES ARE ORDINARY SUBJECTS.** The container is not an op-unit, but elements inside it are: `src/app/sandbox/resize-repeat-list/page.tsx#      <ul data-oid="smlist" className="flex flex-col gap-2">` holds a chain, and `smcell`/`smname`/`smtagg` form a three-member chain under `smroww`, rendered four times. ⚠ **`smroww` itself is a SINGLETON (`canMoveUp: false, canMoveDown: false`, no parent, no neighbours) and can never be a drag subject** — which is what falsified r2's G47-19 (§4.4).

### 3.3 One request, one journal entry; and the composer that actually runs (READ + RUN)

`packages/descvi/src/sidecar/server.ts#        { files: [absSpec, absPage], subject: structureSubjectFor(intent.op, screenId, oidValue), journal: { mode: 'push' } },` — one `push` per request. `packages/descvi/src/sidecar/server.ts#export function computeStructuralEdit(` runs inside `commitWrite`'s `prepare`; its move arm returns `{ nextPage, nextSpec: null }` — a move touches `pageSource` only, and the fold belongs inside that arm. `JournalEntry` stores whole-file `before` bytes for **both** declared files, which is why one Cmd+Z restores byte-for-byte rather than replaying k inverse moves.

⚠ **THE k-SWAP FOLD r2 SPECIFIED DOES NOT RUN, AND TWO LANES WATCHED IT THROW.** `spelled composer k=1: equals naive → true; k=2, k=3, k=6 → THREW span-sentinel-failed` (on `shop/member-list`, `reparse-failed` at k=2). **`resolveJsxChildOp` derives spans from `ctx.mod`, whose offsets address the buffer `moduleContext` parsed; `swapSpans` swaps spans of unequal length, so every later offset shifts and step 2 hands stale spans to a buffer they no longer describe. The parse is not per-step overhead to be hoisted — it is what makes each step's spans valid.** ⚠ **And the failure is `span-sentinel-failed`, an INTERNAL error, so §4.3(5)'s *"any step's typed refusal aborts `prepare`"* does not catch it.**

⚠ **THIS REPO HAD ALREADY WRITTEN THE LESSON DOWN, IN THE SAME FILE, AND THE PLAN REACHED PAST IT.** `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` — `cutSpans`'s own docblock, which exists because *"Removes N disjoint spans from `source` in ONE pass and ONE re-parse."* **The correct shape is ONE-SPLICE, not a k-swap loop.**

**Measured, with controls in both directions** (round-3 lane, subject `src/app/shop/order-detail/page.tsx`, the 7-member chain `kh1mfx…thbzev`, page **40,979 bytes** — ⚠ *r3 wrote "39.8 KB", which is that file's JS string length and not its byte size; two units in one sentence, inside the acceptance criterion for a byte-oriented composer*):

| reading | value |
|---|---|
| one-splice k = 6 equals the naive 6-step fold, byte for byte | **true** |
| CONTROL — no move (0→0) is byte-identical to source | **true** |
| CONTROL — wrong destination (0→5) differs from the naive k = 6 | **true** |
| naive k = 6 fold, median | **34.436 ms** |
| one-parse one-splice k = 6 (no verify reparse), median | **4.538 ms** |
| `moduleContext` / `resolveJsxChildOp` warm / `swapSpans` incl. its own reparse | **2.628 / 0.233 / 2.911 ms** |

⚠ **ROUND 4 BUILT THE ONE-SPLICE COMPOSER AND CONFIRMED IT.** Byte-exact against the naive fold **in both directions, including an interior up-move (index 3 → 1) that no earlier round had tested**; **2 parses against the naive fold's 12, measured with an instrumented `parseSync` rather than derived arithmetically**; **6.803 ms** against R47-4's pre-committed 12 ms.

⚠ **`swapSpans` ends on `reparseOrThrow`, so ONE `moveAdjacent` is TWO parses** (`packages/descvi/src/extractor/structural-edit.ts#export function swapSpans(`), and the timings confirm it arithmetically: `5.616 ≈ 2.628 + 0.233 + 2.911`. **A correct k-swap fold's best case is therefore 21.49 ms.** ⚠ **These numbers are page-size dependent — on `shop/member-list` (9,656 B) the same three read 0.662 / 1.490 / 9.041 ms** — which is why R47-4 names its subject.

### 3.4 Neither the authored reader nor a naive live read is sufficient (READ + RUN)

`packages/descvi/src/react/overlay/panel/parent-context.ts#  if (variantControlsDirection) {` is tested **before** `baseIsFlex` and `computedIsFlex`, so a parent carrying `md:flex-row` below the `md` breakpoint reports `directionSource: "variant"` and never reaches `"unresolved"` while its computed `display` is `block`. `packages/descvi/src/react/overlay/engine/tailwind-class-model.ts#export type ParentDirection = "row" | "col" | "unset" | "unsupported";` has four members and `"unsupported"` is reachable without `"unresolved"`. §4.2(3)'s live read makes both moot.

⚠ **And the live read alone is not sufficient either — driven in headless Chromium:** `flexDirection` reads `row` while `direction: rtl` reverses visual order; `writing-mode: vertical-rl` makes that `row` advance on y; unequal child `order` makes a DOM reorder produce no visual movement. Positive control in the same run: plain LTR flex, moving C to the first DOM position moved it x=48 → x=8.

### 3.5 The shield's ordinary arm and click arm, in order (READ)

Press: zero `maxTravelRef`; drop the trailing-click latch; return if ROW P; `preventDefault()` and return if ROW D; else `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      suppressShieldPointer(e);`; then `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (e instanceof MouseEvent) beginTravelRecording(e);`. Bound for **`mousedown` AND `pointerdown`** at capture on `#dsh-stage`.

Click, in order: `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      const trailing = takeTrailingClickSuppression();` → `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (trailing || isResizeHandleEvent(e)) {` (suppress and return) → **only then** the travel check. **The latch branch precedes the travel check.**

### 3.6 The Cmd+Z guard order, and the two focus mechanisms (READ)

In order: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` → text-entry return → `if (!stage?.isConnected) return;` → `packages/descvi/src/react/overlay/OverlayShell.tsx#const owned = stage.contains(active)` with its host disjunct. **A `null` `activeElement` bails at the FIRST guard**, above the text-entry guard.

`focusStageIfOrphaned` (predicate `active === null || active === document.body || active.isConnected === false`) is called from exactly one site, `packages/descvi/src/react/overlay/engine/use-preview-session.ts#      focusStageIfOrphaned(stageRef.current);`. Its sibling `focusStageIfOwned` carries a measured three-row table: *"the remount lands on a LATER flush than this callback. At restore time the ticket element is connected and focused on EVERY path."* **That table also records that the three panel controls differ**: the chip add-input is keyed and remounts; `EditableDescription` and `#dsh-name-input` re-seed in place and **keep focus**. A text-entry guard **was built on that path and rejected**, two rows measured STICKY.

### 3.7 The drag subject is not `selectedTarget`, and the panel holds one link (READ)

`packages/descvi/src/react/overlay/engine/use-preview-session.ts#      const oidOfTarget = selectedTarget.oid ?? selectedTarget.specId;` is the sole subject of the post-save handoff. `StructureSection` receives only the selected oid's `StructureEditInfo` — one link, not a chain. The dirty predicate is `packages/descvi/src/react/overlay/panel/use-classname-commit.ts#    const settledAndClean = hasPendingEdits?.() !== true && isSettled?.() !== false;`, the shipped repair for **KI-46**.

### 3.8 The readout family, and where its nodes actually live (READ)

`packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function styleReadout(node: HTMLElement, isDark: boolean): void {` is module-private with **THREE** call sites in its own file, and: its base tone is the **REFUSAL's palette** with two callers each overriding three colour lines **in a specific order** because the `border` shorthand resets all four sides; it hard-codes `zIndex = "41"` — ⚠ **but the family's DRAG member is 44**: the independent copy in `use-spacing-drag.ts` sets 44 with `packages/descvi/src/react/overlay/canvas/use-spacing-drag.ts#      popup.style.zIndex = "45";` above it; `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#const READOUT_ACCENT_PX = 3;` is module-private in **both** files and read as TEXT by a shipped gate (`packages/descvi/src/react/overlay/__tests__/spacing-readout-accent.test.ts#      const m = /const READOUT_ACCENT_PX = (\d+);/.exec(source);`) that requires **both** declarations and requires the spacing copy to survive; and `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function layoutReadouts(` places the family as a selection-anchored STACK a pointer-following readout cannot join.

⚠ **AND ALL THREE READOUTS ARE CHILDREN OF `#dsh-handle-layer`, NOT OF THE RING LAYER (M4).** `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#      const hint = ensureReadout(host, INSTANCE_HINT_ID);` — and `host` is `handleLayerRef.current`. **`visibility` inherits, so hiding the handle layer hides the instance hint**, which is exactly the node §4.1(h) says it keeps visible.

⚠ **`#dsh-ring-layer` carries `overflow-hidden`** (`packages/descvi/src/react/overlay/OverlayShell.tsx#              className="z-40 absolute inset-0 overflow-hidden pointer-events-none"`), so anything in it is clipped at the frame edge.

---

## 4. The design

### 4.1 Arming, ownership, subject and terminal (RULED — DR47-1, DR47-2, DR47-10, DR47-11 — C47-1)

**C47-1.** A headless `canvas/reorder-drag-machine.ts` and a wiring hook `canvas/use-reorder-drag.ts`; **two edits to `use-canvas-selection-shield.ts`** (§0). The arm table is unchanged in every arm.

**(a) CANDIDATE vs ELIGIBLE.** A press becomes a **CANDIDATE** iff: (1) it took the ordinary arm; (2) **no modifier at the press**; (3) the selection holds at most one member, read from the pinned mirror `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#  const selectionRef = useRef<readonly SelectionMember[]>(EMPTY_SELECTION);`; (4) it resolves through the shield's own container-scoped resolution to a `[data-oid]` element inside `#dsh-screen`; (5) **the controller is SETTLED AND CLEAN** — the shipped two-reader predicate (§3.7). ⚠ Term 5 does not *guarantee* cleanliness; **it declines to arm in the window where the controller's confirmed string is stale**, which is where §4.1(c)'s synchronous selection switch would move `identityRef` under an in-flight commit and make its R1 guard **drop the write — a committed token disappearing silently.**

A candidate that crosses `packages/descvi/src/react/overlay/canvas/pointer-thresholds.ts#export const POINTER_DRAG_THRESHOLD_PX = 4;` becomes **ARMED**, and arming evaluates **ELIGIBILITY**; an ineligible arm **arms into a REFUSING state**.
- **E1 — a reorderable neighbour exists.** Failure splits three ways per §3.1: **22** → `no-reorderable-sibling`; **108** → `sibling-not-editable`; **62** → the engine's own reason through §4.5's total map.
- **E2 — the parent is a live flow container in the modelled subset** (§4.2(3)).
- **E3 — the drop table can be built** (§4.2(2)). **Failure splits two ways: AMBIGUITY → `chain-member-not-locatable`; FEWER THAN TWO RESOLVED MEMBERS IN THIS COPY → `no-sibling-in-this-copy` (r4).** ⚠ **E3 is the only one of the three that is INSTANCE-SCOPED** — E1 is a property of the source chain and E2 of the parent, while E3 is a property of *which rendered copy the user pressed*, and that is why its second arm's sentence names the copy.

⚠ **WHY NO SETTLEMENT BARRIER, stated because the sibling gesture has one.** `resize-gesture-guard.ts`'s `armed-pending` state exists because a resize gesture **captures a className baseline it will compose on**. A reorder gesture composes nothing from the className; its baseline is the structural one, re-derived server-side under the write lock. The barrier's purpose does not apply, and the interaction that remains — the arm-time selection switch against an in-flight commit — is what term 5 **declines** rather than awaits.

⚠ **What the new predicate must NOT match** (the S47-3 brief must have the implementer state it back): any target under `[data-dsh-handle]`; the stage background or any `#dsh-stage` descendant outside `#dsh-screen`; any node under `#dsh-ring-layer`; a press carrying any modifier.

**(b) THE MULTI-SELECT EXCLUSION — SUSTAINED ON THE CLICK ARM'S ORDER.** A press-time modifier read is legitimate for *arming*, a gesture-start question. The case phase-45's ruling exists for — Shift acquired between press and release — is covered twice and neither cover is that read: if the gesture issued a request the latch is armed and the click arm suppresses **before** the travel check; if it issued none, the travel check swallows it on `shiftKey && travel ≥ threshold`. At N > 1 the gesture never becomes a candidate.

**(c) THE SUBJECT.** At arming — synchronously — the machine switches the selection to the drag subject through the shipped `applySelection` path, so **subject ≡ `selectedTarget` by construction** and the post-save handoff is correct **without being changed**.

**(d) ONE ARM PER PRESS, AND THE `pointerId` PRECONDITION.** Idempotent over the `mousedown`/`pointerdown` pair on `pointerId`, in `beginTravelRecording`'s shape. A **precondition, not defence in depth**: `setPointerCapture(e.pointerId)` is not expressible from a `mousedown`.

**(e) CAPTURE ON `#dsh-stage` — MEASURED HERE, NOT INHERITED.** ⚠ **r0–r2 declined to claim phase-42's handle-host measurement for a stage host; round 3 measured the stage host directly.** Chromium 148.0.7778.96, headless and headed agreeing: dragging 500 px past all four edges and the corner, `pointermove` keeps arriving, `pointerup` arrives at the off-frame coordinate with `pointerId 1`, `target === #dsh-stage`, capture still held, and **`pointercancel` 0 in 15 drags**. **The paired control is what makes it evidence: same host, same listeners, capture removed → `outsideViewport = 0` and `pointerup = 0`.** ⚠ **Two limitations carried verbatim: CDP input always targets the page, so this measures the browser honouring off-viewport coordinates and NOT the OS handing the pointer to another application; and only Chromium was measured** — Firefox and WebKit are not in this repo's Playwright cache and its e2e is Chromium-only.

**(f) THE TERMINAL** is one idempotent transition over: `pointerup`, `pointercancel`, `Escape` at `document` capture, **the shared active-drag guard's consultation** (DR47-11 — what delivers "selection change"), screen change, edit-mode off, and **unmount**; its final act returns the machine to `idle`. ⚠ **UNMOUNT IS A SEPARATE OBLIGATION FROM THE 7 BOUNDARY CALLS (M9):** the reorder guard needs its own `reset…()` counterpart to `resetResizeGestureGuard()`, which drops the registration and clears the latch after an unmount mid-gesture — and that module's docblock states why `terminate()` cannot be it (*"a teardown that left one behind would hand the next mount"* a live gesture nobody is performing). **S47-3 ships it.** ⚠ A modifier acquired **mid-gesture does not abort**: aborting would make the outcome depend on a key state whose effect is invisible until release, and the meanings it would defer to are deferred-v2/v4 and unimplemented.

**(g) THE LATCH IS ARMED ONLY ON A TERMINAL THAT ISSUED A REQUEST.** Arming on every armed drag composes with §4.2(6)'s no-op detection into a live regression: a 5 px out-and-back on a reorderable element would suppress a selection that happens today, across the majority of the canvas. **G47-15 is the row; §8 U3 carries the harm.**

**(h) FURNITURE DURING THE DRAG — `visibility`, never unmount, WITH ONE EXPLICIT RE-DECLARATION.** Hidden for the duration and restored at the terminal: `#dsh-hover-ring`, `#dsh-selection-ring`, `#dsh-selection-ring-pool`, `#dsh-selection-badge`, `#dsh-handle-layer`, `#dsh-spacing-layer`.
⚠ **`#dsh-ring-instance-hint` IS A CHILD OF `#dsh-handle-layer` AND `visibility` INHERITS (§3.8), SO r2's RULE HID THE VERY NODE IT SAID IT KEPT (M4).** R47-8's only mechanism was inoperative and G47-16 leg (ii) was green on the defect and on the correct behaviour alike. **The fix is an explicit `visibility: visible` re-declaration on the hint, named here in C47-1**, and G47-16(ii) is re-aimed at deleting that override. The two other readouts in that layer — `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint` — are **left to inherit the hide**, which is what we want.
⚠ **The hiding is `visibility: hidden`, never removal**, because `e2e/resize-handles.spec.ts#    const handleLayerEl = document.getElementById("dsh-handle-layer") ?? layerEl;` falls back precisely when that node is **absent**; an unmount would make phase-47 the first runtime mechanism that makes a never-fired fallback reachable. **§9.5's F46-D disposition rests on this mechanism.**
⚠ UNVERIFIED whether hiding reads better than leaving it (§8 U4) — and §4.4 no longer depends on the answer.

### 4.2 The drop resolution (RULED — DR47-5, DR47-6 — C47-2)

**C47-2.** The **ORDER half is built once at arm; the GEOMETRY half is re-read per move** (rects change under `#dsh-screen` scroll, window resize and reflow), which is what G47-4's *"the last reading is stale"* refers to.

1. **ORDER — from the artifact, once.** Walk `prevOid` to the head and `nextOid` to the tail. No DOM.
2. **GEOMETRY — from the DOM, per move, parent-scoped, and RESOLVED-MEMBERS-ONLY.** Search `subjectEl.parentElement`'s children for each chain oid. A member must resolve to **at most one element, and to a DIRECT CHILD** of that node. Then:
   - **a member resolving to ZERO nodes is DROPPED from the table, not a refusal;**
   - **`chain-member-not-locatable` refuses the whole gesture** on AMBIGUITY only — when the **subject itself** does not resolve, when a member resolves to **more than one** node in that parent, or when a member resolves to a **deeper descendant**;
   - ⚠ **and when FEWER THAN TWO members resolve, the refusal is a DIFFERENT key — `no-sibling-in-this-copy` — because nothing failed to be found (r4).** A run of one is a well-defined *nothing here to trade places with* state, and it is **INSTANCE-SCOPED**: the same chain in the copy next door has two. Routing it through `chain-member-not-locatable` would tell the user the siblings could not be located when the sibling simply is not rendered here — the wrong relationship, which is wording rule 1's own failure.

   ⚠ **THE DROP-ON-ABSENCE RULE IS A r3 RULING, AND IT IS AVAILABLE ONLY BECAUSE OF DR47-4(f).** Round 3 measured that r2's require-every-member rule refuses on a population the plan never named: **the artifact links mutually-exclusive `{cond && <el/>}` siblings into ONE chain** — §3.2's parenthetical, load-bearing at last. Measured over 235 chains: **6 refused in every observed state (2.6 %), 9 refused only in SOME observations (3.8 %), 1 never renders at all (0.4 %), 219 never refused (93.2 %).** The clearest **at source** is `sandbox/resize-repeat-list`, whose `smndaa`/`smndbb`/`smndcc` are three `{queueState === 'x' && <p/>}` blocks inside the 5-member chain `[smlist, smndaa, smndbb, smndcc, smlnkk]` — each an `opUnitKind: 'conditional-container'`, exactly one rendering per state. ⚠ **It is NOT a draggable subject and the sentence must not read as though it were (r4): that chain's parent computes `block`, so it refuses at E2 before any of this is reached.** The same source shape appears in `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`. **The draggable instance of this class is `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` (flex-parented in all five copies), and it is the one the gates use.**
   ⚠ **THE 9 "SOMETIMES" CHAINS ARE THE HALF THAT FORCED A RULING RATHER THAN A SENTENCE: under r2's rule the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed** — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, the **first** missing `rpb6hb` and the other five complete, giving 55 passing scopes and 11 refusing. **A per-instance verdict on a per-chain contract, and no refusal wording survives a user who just did the same drag successfully one column over.** **Options: (i) accept the per-instance verdict and word around it; (ii) refuse the chain everywhere it can ever be incomplete — not decidable client-side, since it requires knowing every state; (iii) DROP unrendered members from the table and refuse only on ambiguity or on fewer than two survivors. RULED (iii).** It costs nothing, because **the anchor receipt never computes an index** — the client names a rendered sibling and a side, and the server resolves it against the live source chain, which still contains the unrendered member. The only consequence is that a user cannot drop *between* two positions separated solely by unrendered members, which is invisible to them.
   ⚠ **AND r3's CLOSING SENTENCE FOR THIS RULING WAS FALSE ON A SHIPPED SUBJECT — MEASURED IN DEFAULT STATE, AND THE CORRECTION IS r4's ONE BLOCKING EDIT.** r3 wrote *"under (iii) all 15 chains admit in every instance, and the per-instance inconsistency does not exist."* **It does not, for a 2-member chain whose one sibling is conditional.** `src/app/lab/tests/shared-oid/page.tsx`'s chain `d4b6s3,d8m1w7` resolves **2 / 2 / 2 / 2 / 1 across five instances, all five parents flex** — the separator `src/app/lab/tests/shared-oid/page.tsx#{i < arr.length - 1 && <span data-oid="d8m1w7"` is conditional on not being last, so the fifth `<li>` renders one member and falls below (iii)'s own floor **while every arming precondition holds**: term 4 passes (`d4b6s3` renders in all five), E1 passes (`canMoveUp: false, canMoveDown: true`, verified in the map), E2 passes. **The user drags the last step label, is refused, drags the identical label one column left, and it works** — verbatim the sentence this paragraph uses to reject option (i). Controls: removing the separator from instance 0 gives `1,2,2,2,1`; planting one into the last gives `1,2,2,2,2`, so the detector both produces a 1 from a change and erases the observed 1.
   ⚠ **THE ROOT CAUSE IS THIS PHASE'S RECURRING SHAPE AND IS WORTH NAMING: the ruling was derived from the right measurement and validated against the population it was derived FROM** — chains where *some* member goes missing — **never against chains where ENOUGH go missing to fall below its own floor. For a 2-member chain with one conditional sibling those are the same event.**
   **RULED (r4): (iii) STANDS — it is correct on its merits and it genuinely dissolves the refusal wherever two survivors remain. What changes is that the sub-floor case gets its OWN key** (the bullet above), whose sentence names the *copy* rather than the parent, so it survives the user who just succeeded one column over — and predicts it. **Its gate leg is G47-11d and its subject is SHIPPED, not synthetic.**
   ⚠ **THE `.map()` ATTRIBUTION r1 AND r2 GAVE THE "SEVERAL MATCHES" ARM IS WITHDRAWN — MEASURED WRONG, AND WRONG BECAUSE OF A SCOPE THE PLAN ITSELF SPECIFIED.** `.map()` bodies produce **52 many-node readings across 20 chains at PARTITION scope, and 0 at the PARENT scope §4.2(2) uses**, because each repeat renders under its own parent: `smcell`/`smname`/`smtagg` resolve once per `<li>`, all direct children, under a `flex flex-row` parent. **0 of 636 member readings hit the several-matches arm.**
   ⚠ **THE DIRECT-CHILD CLAUSE HAS ZERO SUBJECTS TOO** — 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — **with a planted control (`C-B` wrapped a member in a fresh `<div>` and the analyzer reported it immediately)**. ⚠ **AND r2's ATTRIBUTION OF IT TO `wflbl3` IS FACTUALLY WRONG AND IS DELETED: `wflbl3` is a DIRECT CHILD of its own `Field` wrapper** (`src/app/lab/challenge/swallowed-oid/page.tsx#    <div className="flex flex-col gap-0.5 bg-white px-3 py-2 border border-neutral-300 rounded-md">`), so it passes both clauses. The one prop-swallowing component in the repo produces the **opposite** failure: `Field`'s *exterior* oids (`wcall1…wcall4`) reach no node and are caught by the zero-match arm — and under ruling (iii) that is a DROP, not a refusal, and in any case **`wcall1…wcall4` cannot be pressed at all** (term 4 requires the press to resolve to a `[data-oid]` element; they have zero DOM nodes in every state, the only such chain in the corpus, and their parent `wgrid1` is `grid`, so E2 would refuse first).
   **Both clauses are KEPT and both are cheap: each prevents a real failure the browser can produce, and the control proves a detector can see it. What they lose is the claim to a shipped subject — their gate subjects are SYNTHETIC and owed by S47-0**, on the `unequal-indent` rider's model.
3. **FLOW, AXIS, REVERSAL — one `getComputedStyle(parentEl)` plus one per resolved member.** Admit iff: `cs.display` is `flex` or `inline-flex` (⚠ **the predicate, not `directionSource === "unresolved"`**, which §3.4 shows a `md:flex-row` parent below `md` never reaches; ⚠ `display: contents` is therefore refused — **ruled, not missed**, since a `contents` parent lays out nothing itself); `cs.direction === "ltr"`; `cs.writingMode === "horizontal-tb"`; and every resolved member's computed `order` equal. Then **axis** = `cs.flexDirection.startsWith("row") ? "row" : "col"`, **reversed** = `cs.flexDirection.endsWith("-reverse")`.
   ⚠ **The three exclusions are correct about the browser (§3.4) and have ZERO SUBJECTS in this corpus** (round 3, each with a planted control returning the planted value): `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930**. **They stay, their subjects are synthetic and owed by S47-0.**
4. **HIT-TEST — the total algorithm.** Over the rects `R` of all **resolved** members including the subject's own: `S = argmin` of the **squared point-to-rect distance** (0 inside a rect); **inside more than one rect** → the member **earliest in source-chain order**; **exact ties at equal distance** (a midpoint, a wrap-line gap) → the same rule, **one tie-break in the design, not two**; **`side`** by projecting onto `S`'s main-axis extent against its midpoint, `< mid ⇒ leading`, `>= mid ⇒ trailing`.
   ⚠ **THE COORDINATES COME FROM THE EVENT AND THE RECTS, NEVER FROM `e.target` — AND THE WRONG IMPLEMENTATION IS THE OBVIOUS ONE (round 3).** Under pointer capture, `e.target` is `#dsh-stage` for **every** event from the first move onward, while `document.elementFromPoint` keeps resolving the real element and returns `null` off-frame. **A hit-test reading `e.target` mid-drag gets the stage and nothing else.** This algorithm reads neither and is unaffected — stated because the failure is silent.
   ⚠ **Tie-break subjects are small but NOT zero (round 3, and the corrected wrap count):** **wrap has 2 subjects**, both in `lab/tests/align-wrap` and both genuinely two-line — ⚠ *the lane's first detector counted distinct cross-axis offsets and reported 37 wrapped parents; an `items-center` row with unequal-height children produces that without wrapping, and the corrected count of wrapped parents is 3* — and **overlap has 1**, `shop/order-detail`'s `4jpxin`, a 2 px step-connector over a step marker, the only one of three overlaps whose parent is flex. ⚠ **Both counts are viewport-dependent and were measured at one viewport.**
5. **VISUAL → SOURCE.** `sourceSide = reversed ? flip(side) : side`. The result is `(anchorOid = S, side = sourceSide)` — **which is the wire receipt itself**, so no conversion step exists. ⚠ **The `reversed` branch has ZERO SUBJECTS: three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1), but none of their children carries a `data-oid`, so none can be a chain member.** Clause kept, subject synthetic and owed by S47-0.
6. **NO-OP DETECTION — OVER SOURCE POSITION, RULED (r4).** A destination equal to the subject's current **source** position issues no request and, per §4.1(g), arms no latch. ⚠ **r3's sentence named no order-space, and once members can be dropped the two spaces differ**: with source `[A, B_unrendered, C, D]` rendering as `[A, C, D]`, dragging `A` to leading-of-`C` makes the source `[B, A, C, D]` **and the render does not change.** **Source is the right space** — it is what the write acts on, what the receipt addresses and what the undo entry restores; a render-space check would refuse a reordering the user actually expressed.
   ⚠ **The residual is STATED rather than prevented: a source-effective, render-inert drag issues a real request, consumes an undo slot and arms the latch.** The user sees nothing move and one Cmd+Z is owed. ⚠ **A FLEX-PARENTED SUBJECT DOES CONSTRUCT IT TODAY, AND r4's CLAIM THAT NONE COULD IS FALSE (r5, measured live at 1440×900).** On `/shop/member-detail`'s **benefits tab**, the chain `omy3i9,0cyt4v,z76fvu,d29ipo` under `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` renders **two copies, n = 4 and n = 3** — the short one missing `z76fvu`, an **INTERIOR** member, because that node is guarded by `src/app/shop/member-detail/page.tsx#                        {b.value > 0 && (` and `INITIAL_BENEFITS`' `b002` carries `value: 0`. `0cyt4v` reads `canMoveUp: true, canMoveDown: true` with an empty `reasons` map (verified in the map this lane built), E2 is flex/row and E3 passes at 3 ≥ 2. **Drag `0cyt4v` to leading-of-`d29ipo`: source index 1 → 2, the source-space no-op check does not fire, and the render does not change.** Controls in the same session: `pk9pwr`, `scroot`, `srroot`, `smroot` → `block/row`; `grpeul` → `table/row`; `smroww`, `xufjus` → `flex/row`; **and r4's own cited counter-subject `ww57qb` reproduces as `block/row` — the reading was never in dispute, the SWEEP was.** ⚠ **HOW IT WAS MISSED IS THE FINDING'S REAL CONTENT: the r4 lane went into tab space to read `ww57qb` on the memo tab and did not check the benefits tab one click away. That is pre-mortem 4's shape, recurring INSIDE the edit that documents pre-mortem 4.** **What actually contains the residual is narrower and is named as such: the benefits tab is a plain `useState` an in-page click cannot drive on the design view (§5's M10 constraint), so the copy that constructs it is not reachable on :3001 by clicking.** ⚠ **AND THAT MAKES §9.6's KI RULING LOAD-BEARING RATHER THAN A NOTE: the only thing containing this residual is a defect this plan itself calls *"not phase-47's to fix"* — one anyone may fix at any time, silently re-opening it.** A containment a future bugfix removes is not a containment; it is a dependency, and it is recorded here as one.
   ⚠ **AND ONE EDGE THE RULE DOES NOT COVER, NAMED RATHER THAN LEFT TO DISCOVERY: when the unrendered member is FIRST, the user cannot express *"make this the first child"* at all**, because the anchor receipt names a rendered sibling and there is none leading of the first rendered one. The gesture is not wrong there; it is simply mute, and the panel's ↑ still reaches that position.
7. **THE MULTI-INSTANCE CONSEQUENCE.** A drag on a `.map()`-body element edits the TEMPLATE, so every rendered instance reorders at once — **G47-16 is the row**, and §4.1(h) keeps the instance hint visible for it.

### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)

**C47-3.** `target: 'structure'`, verb `move-up`/`move-down` by the sign of the source-order displacement, unchanged `expect` for the ORIGIN, plus **`expectDestination: { anchorOid, side }`**, **REQUIRED on the two move verbs and FORBIDDEN on the other four**, with a total switch beside the shipped `parseExpectForOp`. **Both producers can construct it**, so §2's "does NOT touch" list needs no exception.

⚠ **THE UNION SPLIT IS BY BASELINE ON THE SERVER AND BY PAYLOAD ON THE CLIENT.** `packages/descvi/src/sidecar/server.ts#export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;` carries **all five** ops, so splitting the moves off the server's baselined arm leaves **`{delete, duplicate, insert-after}`**; the client's `packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export type PayloadFreeStructureOp = Exclude<StructureOp, 'insert-after' | 'insert-child'>;` leaves **`{delete, duplicate}`**.

Server, inside `computeStructuralEdit`'s move arm, under the write lock:
1. resolve the op-unit and re-derive the live origin baseline; mismatch ⇒ `stale-baseline` (409);
2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
4. **rearrange in ONE SPLICE (M1).** Read every member's span from **one** `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. ⚠ **This is not the k-swap loop r2 specified: that shape does not run, and the repo had already written the lesson down in this very file** — `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` **S47-2 therefore owes a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** ⚠ *r2's clause "`expect` consulted on the first step only" dies with the steps: there is one step.*
5. a typed refusal aborts `prepare`, so **nothing is written**, and the 422 carries that reason. ⚠ **The k-swap shape failed with `span-sentinel-failed`, an INTERNAL error this clause does not catch — recorded because it is why the shape had to change rather than be guarded**;
6. one journal push, subject unchanged; `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string | null {` needs no new arm;
7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.

⚠ **`parentOid: null` CHAINS ARE ADMITTED, AND SAYING SO IS A RULING (M9).** `wflbl3`/`wfval7` carry it — they are declared in a helper outside the default export, so the extractor records no oid-bearing parent — and they are **pressable, admissible, flex-parented** subjects (their DOM parent is `flex flex-col`). **`parentOid` is not consulted by this design at all**: order comes from `prev`/`next`, geometry from `subjectEl.parentElement`. The server's own chain re-derivation is likewise positional. **Nothing special is owed; the case is recorded so an implementer does not add a `parentOid !== null` guard that would refuse a working subject.**

**ONE Cmd+Z AFTER A 4-POSITION DRAG TAKES THE ELEMENT BACK FOUR POSITIONS** — one request, one entry, one undo, byte-exact from the entry's whole-file `before` bytes.

⚠ **The anchor receipt is slightly more permissive than a gap receipt, and that is a property.** A gap receipt refuses when either neighbour changed; an anchor receipt names **the element the user aimed at**, so a concurrent edit elsewhere in the chain **re-targets rather than refuses**. The origin `expect` still refuses any change to the subject's own position, and the receipt is still a COORDINATE rather than a count — **G47-10's argument is unchanged.**

**Why this is not a new write class — the enumeration is the argument.** No new `StructuralOp` member, no new wire verb, no new journal arm, no new `reselectTargetFor` arm, no new `REASON_TEXT` key. ⚠ *(r0's appeal to `structural-edit.ts`'s header sentence was withdrawn in round 1: it names one class contrasted with literal replacement and carries no taxonomy.)*

### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)

**C47-4.** Three new nodes in `#dsh-ring-layer`, all **readouts by role**: no `data-dsh-handle`, no `data-v3-glyph-control`, `pointerEvents = "none"` set **inline** (a class-only rule reads back `auto` in jsdom and the gate could not go RED).

- **`#dsh-reorder-indicator`** — the blue insertion line, in the destination gap, spanning the cross-axis extent of the **resolved** members, perpendicular to the main axis.
- **`#dsh-reorder-readout`** — **the DROP POSITION `n / N`**, per the owner's ruling. ⚠ **`N` is the count of RESOLVED members and `n` the subject's 1-based position among them — deliberately the count the user can see, not the source chain length**, which §4.2(2)'s drop-on-absence ruling makes differ whenever a conditional sibling is not rendering. Showing a total the user cannot count would be the readout's own version of KI-17.
  ⚠ **AND THE CONSEQUENCE THAT RULING CARRIES MUST BE STATED, BECAUSE r3 RULED IT AND DID NOT (r4): `n / N` IS INSTANCE-LOCAL.** Measured on the chain this plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`, six step columns, per-instance **`2/3/3/3/3/3` — in DOCUMENT order, and the SHORT one is the FIRST** (⚠ *r4 wrote `3/3/3/3/3/2`, which reads positional and is wrong in order; the connector `src/app/shop/order-detail/page.tsx#                  <div data-oid="rpb6hb"` sits under an `{i > 0 && (` guard, so column 0 is the one that lacks it, and a lane building the U9 material from the sixth column would conclude the effect does not exist*), all flex — **every column admits** (ruling (iii) works there), and the readout then shows `n / 3` in five columns and **`n / 2` in the **first**, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16). **The per-instance inconsistency was not dissolved; it was relocated out of the refusal and into the readout by the consequence ruled in the same paragraph.** Stated plainly: **`n / N` describes neither the source order the edit acts on** — in column 0, `5s41w1` reads `2 / 2` while being source index **3 of 3** on the same 1-based reading §4.4 defines `n` by — **nor the scope of the edit**, which is every instance. The affordance that carries the scope is `#dsh-ring-instance-hint`, which §4.1(h) keeps visible for exactly this reason.
  ⚠ **The KI-17 argument for showing what the user can count still holds, so the ruling stands — but the readout's SEMANTICS are ground the owner personally ruled, so they are routed rather than settled here: §8 U9.**
- **`#dsh-reorder-refusal`** — §4.5's sentence. ⚠ **On a refusing arm the DROP-POSITION readout is ABSENT (M9), not blanked**: there is no position to report, and a `0 / 0` would be a number about nothing.

⚠ **THE READOUT AND THE REFUSAL ARE TWO NODES, NOT ONE RE-STYLED NODE.** They are mutually exclusive in time, and re-styling one node per paint means re-running the `border` shorthand, which resets all four sides and wipes the accent — the trap `use-spacing-drag.ts`'s own comment warns about.

⚠ **THE READOUT IS CLIPPED AT THE FRAME EDGE, AND THAT IS RULED HERE RATHER THAN LEFT TO U1 (M9).** `#dsh-ring-layer` carries `overflow-hidden` (§3.8). **The readout is therefore CLAMPED to the layer's rect rather than following the pointer past it** — it stops at the edge and stays legible, which is what phase-42's own refusal marker does when it flips above rather than clamping off-screen. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too, and this is the answer.

**Z: all three take `zIndex = 44`**, matching the shipped drag readout (§3.8), with the popup above at 45. ⚠ *r2 briefly moved them to 41 on two false premises — that 41 is "the readout family's own" z (it is the STACK family's) and that §4.1(h)'s hiding replaces the need for a z privilege (that is U4, settled after the story that ships the indicator).* **Ordering among the three at equal z is by DOM order**, the repo's own precedent — and nearly moot, since the readout and the refusal never coexist.

**THE `styleReadout` EXTRACTION, WITH ALL FOUR COSTS PAID.** It takes **`tone`, `zIndex` AND `accentPx`** as parameters — ⚠ `accentPx` is a parameter and not an import, because `READOUT_ACCENT_PX` is module-private in **both** files and importing from either would create a cycle; **neither declaration moves**, because the shipped regex gate requires both and requires the spacing copy to survive. **`use-resize-handles.ts`'s THREE call sites** migrate in the same commit. Placement is pointer-relative and clamped, never `layoutReadouts`'.

⚠ Colour, weight, inset and the gap convention are NOT settleable here (§8 U1/U2); G47-6 asserts only a property.

### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)

**C47-5.** A total `Record<StructuralRefusalReason, BilingualMessage>` rendered through `packages/descvi/src/react/overlay/shared/refusal-messages.ts#export function bilingualLine(message: BilingualMessage): string {`, **plus an `undefined` arm** (required by the producer's type; measured at zero occurrences today — §3.1), **plus the client-only set: SIX KEYS OVER THREE CONDITIONS** — E1, E2 and E3, exactly as §4.1(a) enumerates them. ⚠ *(The count has been spelled four different ways across r2 and r3 — "three conditions" over a five-row table, then "four conditions, five keys" derivable under no consistent reading. It is stated ONCE, here, and §4.1(a), the table below and §12 are the three sites that must agree with it. r4's new key makes it six.)*

**Engine-keyed rows** (counts are **refusal** counts over `move-up`/`move-down` across `src/app` — §3.1):

| key | ko | en |
|---|---|---|
| `no-adjacent-sibling` (541) | 이 방향에 **형제 요소가 없습니다.** | **There is no sibling in that direction.** |
| `unsupported-sibling` (189 = 165 arm-time + 24 fold-step) | 옆에 있는 요소가 **편집할 수 있는 단위가 아닙니다** — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit** — something invisible, such as a comment, may sit between them. |
| `unsupported-parent` (52) | **부모가 순서 편집을 지원하는 형태가 아닙니다.** | **The parent is not a shape that supports reordering.** |
| `target-bears-data-screen` (48) | **화면 경계는 순서를 바꿀 수 있는 자리가 아닙니다.** | **A screen boundary is not a position that can be reordered.** |
| `unsupported-container` (18) | **감싸고 있는 조건부 묶음이 지원되는 형태가 아닙니다.** | **The conditional wrapper around it is not a supported shape.** |
| `non-canonical-separator` (6) | **형제 요소 사이 간격이 편집 가능한 형태가 아닙니다.** | **The spacing between the siblings is not in an editable form.** |
| `unequal-indent` (0 — R47-3) | 지나가야 하는 형제 요소와 **들여쓰기가 달라** 이동할 수 없습니다. | The move is blocked because **a sibling it must pass has a different indent**. |
| every remaining engine reason, and `undefined` | **이 위치에서는 순서를 바꿀 수 없습니다.** | **Reordering is not available at this position.** |

⚠ **`unsupported-sibling`'s WORDING MUST BE TRUE AT BOTH MOMENTS, AND r2 FIXED ONLY ONE (M9).** R1 scoped it to *"a step of the fold"* and worded it *"a sibling it must pass"*; r2 corrected the scope to arm-time. **Measured, it is both: 165 arm-time and 24 fold-step** — and **the 24 genuinely ARE the "a sibling it must pass" case.** The row above names the **relationship** (the neighbour is not an editable unit) rather than a traversal, which is true at both, and its second clause names what the user cannot see — §3.1's driven JSX-comment cause is the evidence.

⚠ **The generic arm names the POSITION, not the element.** R1's read *"이 요소는 … / This element cannot be reordered here"* — the element as subject, differing from rule 1's own counterexample by one word, so G47-11 leg (ii) fired on the plan's own text. The three largest causes (52 + 48 + 18 = 118 refusals) now have relationship-naming sentences of their own.

**The client-only set — three conditions, six keys:**

| key | condition | ko | en |
|---|---|---|---|
| `no-reorderable-sibling` | E1, the **22** | 같은 부모 안에 **순서를 바꿀 형제 요소가 없습니다.** | There is **no sibling to reorder with** inside this parent. |
| `sibling-not-editable` | E1, the **108** | 옆에 있는 요소가 **편집할 수 있는 단위가 아니라** 순서를 바꿀 수 없습니다 — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit**, so the order cannot be changed — something invisible, such as a comment, may sit between them. |
| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |

⚠ Two of these name the panel as the working alternative deliberately: the flow-axis refusal is a GESTURE policy, not a write constraint, so telling the user the buttons still work is the true and actionable sentence.

⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**

**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.

**Where each is shown.** E1, E2 and E3 are known at arm time (E3 at the first geometry read): the gesture arms into a refusing state, paints `#dsh-reorder-refusal`, draws no indicator, shows no drop-position readout, and issues nothing. Step-refusals arrive as the 422's typed reason after release.

⚠ **The indicator can therefore be shown for a destination the server refuses — and R47-3 explains why that is safe rather than merely asserting it (M8).** `unequal-indent` is the only move-only precondition a chain-derived destination can trip, **and the mechanism is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."*** Because the chain is built **only across links `adjacentOpUnit` already admitted**, every other move-only condition was already satisfied when the link was made. A lane tried to break this with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. **And `unequal-indent` is measured at zero, so the cost lands entirely on G47-9's synthetic fixture.**

### 4.6 `undo-focus-ownership` — ONE fix and ONE placement improvement (RULED — DR47-9 — C47-6)

⚠ **NAMING NOTE, RECORDED BECAUSE PER-COMMIT BRIEFS CITE CONTRACT IDS VERBATIM (M9): C47-6a and C47-6b SWAPPED MEANINGS BETWEEN r1 AND r2.** In r1, `a` was the `focusStageIfOrphaned` call and `b` the ownership widening; from r2 onward `a` is the ownership widening (the fix) and `b` the focus placement. **A brief drafted against r1 would build the other thing.** The r3 meanings are below and are final.

**C47-6a — THE FIX, and it closes BOTH dead windows on its own.** `document.body` counts as owned in the Cmd+Z keydown effect. The backlog row names `document.body` as the mechanism for both windows. ⚠ **The `null` half is DROPPED**: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` bails on `null` two guards above ownership and **above** the text-entry guard, so implementing it would mean moving an early return past that guard — the exact shape G47-12 exists to police, inside the fix. **`stageRef.current?.isConnected` is NOT re-checked**; it is proven one line above.

**C47-6b — THE PLACEMENT IMPROVEMENT, and it is NOT what restores Cmd+Z.** It calls `focusStageIfOrphaned` after a panel value commit so the canvas keyboard surface is live again. ⚠ **It must land on the flush AFTER the `key={value}` remount**, because in the commit callback the ticket element is still connected and focused, `orphaned` is false, and the call does nothing.

⚠ **THE CONTROL AND THE REACH, both stated precisely (M9).** The physics — *"the remount lands on a LATER flush than this callback"* — is measured in `focusStageIfOwned`'s three-row table, **which measured the canvas-click ticket-restore path, not the panel value-commit flush**. The physics generalises; **calling that table "the control" for this claim over-claims by one call path, so it is named as the EVIDENCE and S47-5 owes the control on its own path.** And the reach is one control of three: `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever there — **which is correct, not a gap**, because focus staying in a text field is where Cmd+Z should reach the field's own undo. **C47-6b is reachable only on the chip add-input and the `key={value}` numeric value fields, and G47-12 row (a) names the chip add-input as its subject.**

### 4.7 The ontology rows, and what no gate watches (RULED — C47-7)

**C47-7.** `.omc/specs/interaction-ontology.md` §3.F-1 has **six** rows; all six get a disposition, because no gate watches them:

| §3.F-1 row | disposition |
|---|---|
| element in flex parent, within-parent | **SHIPPED at phase-47**, with an anchor into the composer — **and the row states the modelled subset** (LTR, horizontal writing mode, equal `order`), because an unqualified SHIPPED is the false half of the browser falsification written into the register |
| element in flex parent, cross-parent | unchanged `deferred-v2 (hard)` |
| element in non-flex parent | **the gate this phase clarifies** — flips to a REFUSAL row naming `parent-has-no-flow-axis`; *"undefined blue-line; clarify at gate"* is discharged |
| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
| selection box (drag the selection) | **SHIPS**; its own cell already says *"== dragging the node"*, and §4.1(c) makes subject ≡ selection at arm time |
| stage background (empty) | unchanged — §2 exclusion 2, G47-2 keeps it so |

⚠ **AND THE SWEEP DISCIPLINE THIS SECTION DEPENDS ON GETS ITS LESSON RECORDED HERE, BECAUSE IT IS NOW FIVE ROUNDS OLD (r5): A SWEEP LIST HAS TURNED OUT TO BE A PROPER SUBSET IN FIVE OF THE SEVEN ROUNDS THIS PLAN HAS HAD — the two clean rounds were the exception, not the turn.** **The portable rule: the BY-CAUSE GREP is the instrument and the enumerated list never is.** A list is a record of what one reader thought of; `git grep -n '<the key or claim being changed>'` over `.omc/plans .omc/specs docs` is a record of what is there. **When a ruling changes a KEY's meaning, sweep the key, not the sections.**

⚠ **`node scripts/check-v3-registers.mjs` does NOT gate these rows** (its census is over `**deferred-v3` markers and the eleven v3 slugs; these are `deferred-v2`). `check-citation-anchors.mjs` protects only the new anchors; a review lane is the rest.

⚠ **BOTH PREAMBLE SENTENCES ARE REWRITTEN, AND r2's CLAIM THAT THE SECOND WAS "STILL LITERALLY TRUE" IS WITHDRAWN — IT IS FALSE AT HEAD, INDEPENDENTLY OF THIS PHASE (M7).** Sentence 1 (*"every drag variant resolves to select-on-press-then-nothing-on-move"*) has been false since phase-42. Sentence 2 asserts *"There are NO `dragstart`/`mousemove`/`dragover`/`drop` listeners (grep-confirmed)"* — but `packages/descvi/src/react/overlay/canvas/use-canvas-hover-ring.ts#    stage.addEventListener("mousemove", onMouseMove);` ships today. ⚠ **Keeping a false sentence and calling it verified is the process failure this plan's own status block records, committed by the revision that wrote the record.** **The amendment describes the shipped listener set rather than asserting an absence whose terms have drifted.** ⚠ It also carries **two banned line pins that are now dead** — `selection-shield.ts:75-78` lands on a docblock tail and `OverlayShell.tsx:292-293` on `[],\n  );` — **converted to anchors in the same amendment**, since `AGENTS.md`'s rule is binding and `check-citation-anchors.mjs` cannot see either form.

---

## 5. Stories, in ship order

**S47-0 — the fixtures, the routing record, and the two counts this phase owes.**

⚠ **WHICH HALVES ALREADY SHIP — AND r3 WROTE THIS INVENTORY FROM THE AUTHORED PROXY IN EXACTLY THE PLACES §4.2(3) RULES THE PROXY MUST NOT BE TRUSTED (r4).** That is pre-mortem 3's own class arriving in the fixture list: **D47-2's whole story is that the authored token is corroboration and the live read is authoritative**, and then the inventory was written from the token. Corrected against the live reader:
- **"three flex-row chains of 7" is TWO.** The two `shop/member-list` chains (`ohpkna…lqaxc2`, `xaro3n…1hzfxp`) stand. ⚠ **`shop/order-detail`'s `kh1mfx…thbzev` does NOT** — its parent `src/app/shop/order-detail/page.tsx#      <div data-oid="grpeul" className="flex-wrap gap-x-3 gap-y-1 text-gray-500 text-sm table">` computes `display: table`, so it refuses at E2 and **can never be a drag subject.** *(Control: `4jpxin` on the same page reads `flex row` through the same reader, so the reader can see flex.)*

**Genuinely absent and owed:**
- a **flex-col chain of ≥5 whose members all render together** — ⚠ **and r3's stated reason for excluding the corpus's flex-col 5-chains was WRONG (r4): `sandbox/resize-flex-col`, `sandbox/resize-flex-row` and `sandbox/resize-repeat-list` all compute `block` at the chain's parent, so they fail at E2 — not because of their conditional members.** *(Control: the same reader returns `flex row` for `smcell`'s parent on `resize-repeat-list`.)* The conditional-member observation is true and is not the disqualifier;
- a **`flex-row-reverse` chain with oid-bearing children** — the three reverse containers in `lab/tests/align-enablement` have none (§4.2(5));
- a **variant (`md:flex-*`) chain with oid-bearing children** (G47-5c);
- **an `rtl` chain, a `vertical-rl` chain and an unequal-`order` chain** (G47-5d) — **all three declared SYNTHETIC: measured at zero subjects (§4.2(3))**;
- **an ambiguity subject for `chain-member-not-locatable`** — **SYNTHETIC: both of r2's "shipped subjects" were measured not to fire, and the several-matches and direct-child arms have zero subjects at parent scope (§4.2(2))**;
- **a flex parent whose DOM element-child count differs from its chain length**, for G47-19;
- **an ordinary reorderable subject reachable in `e2e/spacing-gesture.spec.ts`'s own fixture**, for G47-1's fourth press;
- **an `unequal-indent` pair — SYNTHETIC and unconditional** (measured at zero, §3.1).

⚠ **AND ONE SUBJECT THIS STORY DOES NOT OWE, SAID SO NOBODY AUTHORS IT TWICE: `no-sibling-in-this-copy` (G47-11d) is the ONE client-only refusal whose subject already SHIPS** — `lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, five flex-parented instances resolving 2/2/2/2/1 in default state.

**Two counts owed and not gettable from source**, both DOM reads: **(i)** the direct-child violation rate at parent scope — measured **0 of 601** by round 3, so this is now a *confirmation* rather than an unknown, re-run at the fixture set; **(ii)** nothing else: **D47-2's live prevalence is settled (§3.1).**

**And one DOC deliverable, placed FIRST so it cannot be lost:** route DR47-8 reading (a) back to **B-Q4's row in `docs/post-loop-backlog.md`** with the 2026-08-27 owner ruling recorded and **no phase number invented**.

The regenerated `.descvi/screens.json` diff **is** the deliverable. **Verification: `pnpm gates`.**

**S47-1 ∥ — the headless reorder model.** The chain walk; the drop table's two lifetimes and its resolved-members-only rule; the total hit-test; the scoped layout admissibility and its refusal branches; the reversal flip; no-op detection; the candidate/eligible split with term 5's two-reader predicate; the one-per-press rule; the terminal totality; the refusal map's engine-total shape plus its `undefined` arm and six client-only keys. **Verification: unit, jsdom-free.**

**S47-2 ∥ — the wire and the server composer.** The move-arm split; `expectDestination: {anchorOid, side}` REQUIRED-on-move / FORBIDDEN-elsewhere with its total parser and its self-anchor 400; the exported `resolveMoveDestination`; **the span-rearrangement primitive beside `swapSpans` and the ONE-SPLICE composer**; the direction-disagreement 400; the atomic abort; the applied-`k` echo; **an instrumented `parse` counter in the sidecar's test harness** so G47-20 can observe what §3.3 measured. **Verification: unit + the sidecar suite, plus the cost re-derivation against R47-4's threshold with the same controls (byte-equality against the naive fold, no-move, wrong-destination).**

**S47-3 — the gesture wiring and the guard.** `canvas/use-reorder-drag.ts`; the two shield edits; `setPointerCapture` on the stage; the terminal set **and the reorder guard's own teardown reset**; the request-gated latch; furniture suppression by `visibility` **with the instance hint's explicit re-declaration**; DR47-11's second guard, the `terminateActiveCanvasGesture()` wrapper and the migration of all 7 boundary sites — ⚠ **the brief must NAME THE WRAPPER'S MODULE, because `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#    if (rel === definitionFile) continue;` excludes the definition file, so a wrapper living in `resize-gesture-guard.ts` makes G47-14's scan return ZERO rather than "exactly one" (M9)**; the `POINTER_DRAG_THRESHOLD_PX` header correction; the `armTrailingClickSuppression` docstring correction; the §3.F preamble amendment including its two dead line pins. ⚠ The brief must require the implementer to state what the new predicate must NOT match. **Verification: jsdom for the wiring; a live `descvi:dev` smoke is REQUIRED.**

**S47-4 — the indicator, the readout and the refusal surface.** The three nodes at z 44, the readout clamped to the ring layer's rect and absent on a refusing arm; the `styleReadout` extraction with `tone`/`zIndex`/`accentPx` parameterised, **three** callers migrated, both `READOUT_ACCENT_PX` declarations left in place; the engine-total bilingual refusal map with its six client-only keys. **Verification: jsdom for structure and non-operability; Playwright for position; the owner for look.**

**S47-5 — `undo-focus-ownership`.** C47-6a and C47-6b, each with its own rows, and **C47-6b's own control on the panel value-commit path** (§4.6). **Verification: jsdom + `e2e/undo-cmdz.spec.ts`.**

**S47-6 — live coverage, the six ontology rows, the landing audit and the tracker section.** `e2e/reorder-drag.spec.ts` with its `spec-classes.json` declaration argued (§12); the §3.F-1 dispositions with their anchors; **the F46-D `readScene` grep as a named deliverable**; the whole-set audit **as this phase lands**; the tracker row.

⚠ **AND ONE CONSTRAINT S47-6 MUST READ BEFORE IT WRITES A SPEC (M10). On the design view, an in-page control cannot be activated by a click.** `shop/member-detail`'s three tab buttons drive a plain React `useState`; on :3001 three consecutive clicks produced **no state change** (oid counts 84/84/84) while the byte-identical script on :3000 produced 84/69/35. **The canvas selection shield claims the press.** A cross-host control ran first: 20/20 screens identical at default state. **This is not phase-47's defect and not phase-47's to fix, but it constrains how any Playwright spec drives in-page state on the design view** — a spec that needs a non-default page state must drive it on :3000, or reach the state without a click. ⚠ **Whether it deserves a `docs/known-issues.md` entry is a LEAD RULING, not this plan's** (§9.6).

---

## 6. Gates — each with a stated, CONSTRUCTIBLE RED-when and a NAMED subject

⚠ **Where a subject is SYNTHETIC it says so and S47-0 owes it.** That is not a weakness of the gate: the `unequal-indent` rider has carried it since r1, and round 3 showed that a gate claiming a shipped subject it does not have is worse — it reads as covered and cannot fire.

| id | What it pins | RED-when | subject |
|---|---|---|---|
| **G47-1** | The arm table over FOUR presses: `e2e/spacing-gesture.spec.ts#§3.9's THREE-ARM TABLE — a handle press is preventDefault-ed (ROW D)` already presses a strip, an `se` corner and the popup input; **a fourth press on an ordinary reorderable element must read `true` and still record travel.** | **Build DR47-1(a)**: hoist the reorder call above `suppressShieldPointer(e)` and early-return → the ordinary row flips to `false`. ⚠ **AND THAT HOIST ALSO KILLS TRAVEL RECORDING**, so *"every reorder behaviour stays green"* is false — the `defaultPrevented` bit is the discriminating leg and the travel leg fires too. ⚠ r0's mutation was **not constructible** (the call sits after `beginTravelRecording`). **Layer: e2e** — jsdom has no `PointerEvent` and no pointer capture. | **S47-0 (fourth-press fixture)** |
| **G47-2** | The stage background is unclaimed. | Drop candidate term 4 → both a stage-background drag and a `#dsh-screen`-but-not-`[data-oid]` drag arm. | shipped |
| **G47-3** | The threshold is the shipped symbol, consumed by the reorder classifier. | Edit `POINTER_DRAG_THRESHOLD_PX` to 40. ⚠ **Broadly RED** — it also moves two render floors, the travel guard and two other classifiers — so the reorder assertion is the **discriminating** leg. | shipped |
| **G47-4** | Capture on a STAGE host holds; the per-move geometry re-read follows the pointer off-frame. | Skip `setPointerCapture` → off-frame moves stop arriving and the last geometry read is stale. **The paired control §4.1(e) already measured: `pointerup = 0` without capture.** | shipped (measured) |
| **G47-5** | Reversal and wrap. | (i) Delete the `reversed` flip → the reverse row inverts. (ii) Replace the hit-test with a main-axis ordinal → the wrap row picks a first-line sibling. | reverse **SYNTHETIC** (§4.2(5)); wrap **shipped** (`lab/tests/align-wrap`, 2 subjects) |
| **G47-5b** | The hit-test is total: wrap-line gap; exact midpoint; equal distance; two overlapping rects. | (i) `>=` → `>` at the midpoint → the midpoint row flips side. (ii) source-chain tie-break → DOM order → the overlapping row picks the other sibling. (iii) point-to-rect → centre-distance → the wrap-line-gap row picks a sibling on the wrong line. | wrap **shipped** (2); overlap **shipped** (`shop/order-detail`'s `4jpxin`, 1); midpoint/equal-distance synthetic |
| **G47-5c** | The flow predicate is LIVE: a `md:flex-row` parent **below** `md` refuses, **above** `md` admits. | Replace `cs.display` with `directionSource === "unresolved"` → the below-`md` row admits and takes an axis from a `display: block` element. **The defect r0 shipped.** | **S47-0 (variant fixture)** |
| **G47-5d** | The modelled subset — **three independent legs**: an `rtl` flex row refuses; a `vertical-rl` flex row refuses; a chain with unequal child `order` refuses. All paint `layout-not-modelled`. | (i) Drop the `ltr` clause → the `rtl` subject admits and the drop lands mirrored. (ii) Drop the `writingMode` clause → the axis read is 90° wrong. (iii) Drop the `order`-equality clause → the source moves and **nothing on screen moves** — the failure with no visible symptom, which is why it needs its own leg. **Positive control: a plain LTR flex chain admits and reorders.** | **all three SYNTHETIC** — measured 0/930, 0/930, `order === "0"` on 930/930 (§4.2(3)) |
| **G47-6** | The indicator's rect lies strictly between the two siblings it names, overlaps neither, is perpendicular to the main axis. | Swap the destination gap for the subject's own → the rect overlaps the subject. Swap the axis → the orientation leg fires alone. | shipped |
| **G47-7** | Non-operability and the C46-0 partition for all three new nodes. | Set `pointerEvents` through a CLASS → the jsdom read returns `auto`. | shipped |
| **G47-7b** | The extraction changed nothing that ships: the three existing readouts' computed colour, border and `borderLeftWidth` byte-identical before and after; **both** `READOUT_ACCENT_PX` declarations survive. | (i) Drop `tone` and let a new node inherit the default → it ships **red**. (ii) Move either declaration into the extracted module → `spacing-readout-accent.test.ts` row (3) goes RED, which is that gate working. | shipped |
| **G47-8** | **ONE Cmd+Z takes a k-position drag all the way back.** 3 positions in a 5-member chain; page bytes byte-identical after one undo. | Issue k sequential requests instead of one → 2 of 3 steps remain and the journal shows k entries. **RED before green.** | **S47-0 (flex-col ≥5); flex-row ≥5 already ships** |
| **G47-9** | Atomicity: a drag crossing an `unequal-indent` pair writes nothing and returns that reason. | Move the rearrangement outside the pure arm → a partial write with a 422 returned. | **SYNTHETIC, unconditional** (measured 0) |
| **G47-10** | The destination receipt is verifiable: a stale `anchorOid` 409s rather than landing somewhere plausible. | Replace `{anchorOid, side}` with `steps: number` → the stale-chain row lands wrong and returns 200. | shipped |
| **G47-10b** | REQUIRED-or-FORBIDDEN: the field on a `delete`/`duplicate`/`insert-after` request is a **400**; its absence on a `move-up` is a **400**; **`anchorOid === the subject's oid` is a 400.** | Make the field optional → the first two rows stop being 400. Accept a self-anchor → the third returns 200 and writes nothing while reporting success. | shipped |
| **G47-11** | The refusal words: ko and en, no display value, no element as subject — **over the whole map including the generic arm.** | (i) ko only → the bilingual leg. (ii) Restore r1's generic arm (*"이 요소는 …"*) → the relationship leg fires **on the plan's own former text**. | shipped |
| **G47-11b** | E1's three-way split and the map's totality — four legs: a **22**-class subject paints `no-reorderable-sibling`; a **108**-class subject paints `sibling-not-editable`; a **62**-class subject paints the engine's own reason; an unmapped reason or `undefined` paints the position-fallback and never a raw code. | (i) **Fold the 108 into `no-reorderable-sibling`** → leg 2 fires with a sentence false of its subject. ⚠ *r1's version was green on the defect and on the correct behaviour alike.* (ii) Fold the 62 in → leg 3. (iii) Delete the fallback → leg 4 renders the kebab-case identifier. | shipped (all three classes) |
| **G47-11c** ⚠ **SUBJECT REPLACED (M5)** | `chain-member-not-locatable` fires on **ambiguity**: a member resolving to two nodes within one parent, and a member resolving to a deeper descendant. | Relax the join to "first match wins" → the two-node subject proceeds against an arbitrary box. Drop the direct-child clause → the descendant subject hands the hit-test a box that is not a flex item of the parent whose axis was read. | ⚠ **SYNTHETIC, and now cleanly so.** r2 named `wcall1…wcall4` and `wflbl3`/`wfval7`; **round 3 measured that neither fires** — the first cannot be pressed at all, the second resolves once as a direct child at parent scope, and both stated mutations change nothing on it; **round 4 independently reproduced 0 several-matches and 0 deeper-descendant readings at parent scope with a planted control that fires.** ⚠ **The fewer-than-two arm has LEFT this gate for G47-11d, where its subject is SHIPPED** — r3 filed it here and called the whole cell synthetic, which under-claimed the evidence. |
| **G47-11d** ⚠ **NEW (r4), AND ITS SUBJECT IS SHIPPED** | The sub-floor arm is INSTANCE-SCOPED and carries its own words. Two legs on one chain: pressing `d4b6s3` in **any of instances 0–3** admits and reorders; pressing it in **instance 4** paints `no-sibling-in-this-copy` — **not** `chain-member-not-locatable`, and **not** `no-reorderable-sibling`. | (i) Route the fewer-than-two case to `chain-member-not-locatable` → instance 4 tells the user the siblings could not be located when the sibling simply is not rendered there — the wrong relationship, wording rule 1. (ii) Route it to `no-reorderable-sibling` → the sentence claims no sibling exists in the parent, which is **false at source** (`d8m1w7` is a chain member with `prevOid: d4b6s3`). (iii) Restore r3's rule and refuse the whole chain when any member is missing → instances 0–3 stop admitting, which is the per-instance inconsistency (iii) exists to dissolve. | ⚠ **SHIPPED** — `src/app/lab/tests/shared-oid/page.tsx`'s `d4b6s3,d8m1w7`, default state, five flex-parented instances resolving **2/2/2/2/1**. Controls (round 4): remove the separator from instance 0 → `1,2,2,2,1`; plant one into the last → `1,2,2,2,2`. |
| **G47-12** | Two rows for two edits: **(a) after a panel value commit on the CHIP ADD-INPUT, `#dsh-stage` IS FOCUSED** (⚠ not "Cmd+Z undoes" — that passes on C47-6a alone); (b) `activeElement === document.body` + connected stage → Cmd+Z undoes; focus in a panel `<input>` → it does not. | (a) Site the call in the commit callback instead of the post-remount flush → `orphaned` is false and focus does not move. (b-i) Revert the ownership term → the body row fires. (b-ii) **Hoist the ownership check WITH its new term** above the text-entry guard → the input row fires. | shipped; ⚠ **row (a)'s subject is the CHIP ADD-INPUT specifically — the other two panel controls keep focus and `orphaned` is false forever there** |
| **G47-13** | The e2e declaration, in **both** directions the shipped gate asserts. | **(i)** add the spec with no class → `scripts/e2e-gate-cx1.mjs` is RED. **(ii)** declare it `neutral` while it needs the sidecar → the suppressed run fails it; declare it `ambient` with every row passing sidecar-free → the ambient side stops meaning anything. ⚠ **The gate is GREEN at HEAD** (round 2 ran it: 15 ambient / 2 solo / 7 neutral), so a wrong pick in this phase is what would turn it red. | shipped |
| **G47-14** | Every boundary consults BOTH gestures: `terminateActiveResizeGesture` has exactly ONE caller outside its own module, via `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#export function countCalls(source: string, name: string): number {`; and a live reorder drag is terminated by a panel className commit. | (i) Leave one of the 7 sites calling the resize guard directly → the caller-scan leg names the file. (ii) Do not register the reorder terminal → the drag survives the boundary. ⚠ **The scan EXCLUDES the definition file, so the wrapper must not live in `resize-gesture-guard.ts` or the leg returns zero and inverts (M9).** | shipped |
| **G47-15** | An armed drag that resolved to a NO-OP still selects. | Arm the latch on every armed drag → the click is swallowed and no selection happens. | shipped |
| **G47-16** | A drag on a `.map()`-body element reorders **all N rendered instances** from ONE request, and `#dsh-ring-instance-hint` stays visible. | (i) Assert only the first instance → the row cannot see a failed template propagation. **(ii) Delete the hint's explicit `visibility: visible` override** → the hint inherits the handle layer's hide and disappears. ⚠ **r2's mutation ("add the hint to the hidden set") was green on the defect and on the correct behaviour alike, because the hint is a CHILD of the layer already being hidden (M4).** | shipped (`smcell`/`smname`/`smtagg`, four instances) |
| **G47-17** | One arm per press over the `mousedown`/`pointerdown` pair. | Arm per event → two candidates, and the `mousedown`-derived one cannot express `setPointerCapture(e.pointerId)`. | shipped |
| **G47-18** | The drag subject — four rows: no selection → drag B moves and selects B; A selected → drag B moves B, selection ends on B; **A dirty → does NOT arm, behaves as an ordinary click**; subject retained across 200 / 409 / 422. | (i) Drop term 5 → the dirty row arms and the pending-edit seam is bypassed. (ii) Skip §4.1(c)'s synchronous switch → rows 1–2 move B while the panel and the handoff still read A. | shipped |
| **G47-18b** | **KI-46, executable.** Begin a className commit; before it resolves, attempt a reorder arm → it does not arm, and the in-flight write lands intact. | **Use `hasPendingEdits()` alone** → the arm succeeds inside the window, the synchronous selection switch moves `identityRef`, the commit's R1 guard drops the write, and **a committed token disappears silently.** | shipped |
| **G47-19** ⚠ **REBUILT (M6)** | The `n / N` readout reads both numbers from the **resolved chain members at parent scope**, never from a DOM sibling count and never document-wide. | (i) Read `N` from `parentEl.children.length` → fires on a flex parent with an element child that is not a chain member. (ii) Read `N` from a **document-wide** `querySelectorAll` over the chain's oids → fires on the `.map()` subject, **12 vs 3**. ⚠ **r2's version was not constructible: it read a ROW count and called it a chain length.** `smroww` is a **singleton** (`canMoveUp: false, canMoveDown: false`) and can never be a drag subject; at parent scope both of r2's named populations **agree** with the artifact (the `.map()` subject is 3 chain members in an `<li>` with exactly 3 element children; the `swallowed-oid` chain is 2 and 2). **The "opposite directions" argument is withdrawn.** | leg (ii) **shipped**; leg (i) **S47-0** |
| **G47-20** ⚠ **COUNTS CORRECTED (M3)** | The composer parses **twice** per request, whatever `k` is. | Restore the naive per-step fold → the parse count for k = 6 goes **2 → 12**. ⚠ **r2's "1 → 6" was wrong in both numbers: `swapSpans` ends on `reparseOrThrow`, so one `moveAdjacent` is TWO parses** — the timings confirm it arithmetically (`5.616 ≈ 2.628 + 0.233 + 2.911`) — **and a correct one-splice floor is 2, not 1, because a structural edit that skipped the defensive reparse would write unvalidated bytes.** The counts the gate discriminates are **2 for any correct request** and **2k for the naive fold**; **S47-2 ships the instrumented `parse` that observes them** (§5). | shipped |

**Standing obligation:** every gate is shown RED under its named mutation before it is believed green, and the RED is recorded in the tracker with the mutation beside it.

---

## 7. Risks, each paired with a MECHANISM

| id | Risk | Mechanism |
|---|---|---|
| **R47-1** | The new predicate on the ordinary arm matches more than it means to — the ONE failure class the record contains. | (i) **G47-5c, G47-5d, G47-2** are breadth assertions. (ii) The S47-3 brief requires the implementer to state **what the predicate must NOT match and which target class each existing arm claims**. (iii) G47-1's fourth press, with a constructible mutation. ⚠ The obligation attaches to the ordinary-arm call; the wrapper swap is mechanical and policed by G47-14. |
| **R47-2** | The client's chain is one edit stale. | The anchor receipt makes it a **409 with no write**; G47-10 substitutes the unverifiable alternative to prove it. |
| **R47-3** | The indicator promises a drop the server refuses. | ⚠ **The MECHANISM, not just the conclusion (M8):** the chain is built **only across links `adjacentOpUnit` already admitted**, and that function's docblock rules *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."* So **indent is the only move-only precondition a chain-derived destination can trip** — a lane tried `unsupported-sibling` and `non-canonical-separator` mid-chain and could not break it — **and `unequal-indent` is measured at zero.** The cost lands entirely on G47-9's synthetic fixture. |
| **R47-4** ⚠ **THRESHOLD RE-DERIVED (M2)** | The in-lock rearrangement stalls the sidecar. | k ≤ chainLength − 1 ≤ 6. ⚠ **r2's *"under 19 ms"* was unreachable by a CORRECT implementation of the design it was written to accept**: a correct k-swap fold's best case is **21.49 ms**, so the criterion would have fired on a correct build and returned the k = 1 clamp for a reason unrelated to the design's merit. *(It was also self-inconsistent: "closer to the floor than to the ceiling" is `< 18.92`, not `< 19`.)* **Under the one-splice shape (§4.3(4)) the floor an implementation can occupy is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ 7.5 ms.** **Pre-committed acceptance, written before the measurement so it can go RED: the k = 6 rearrangement must complete in under 12 ms on `src/app/shop/order-detail/page.tsx`'s 7-member chain `kh1mfx…thbzev` (**40,979 bytes**), or the design is re-opened.** ⚠ **THAT CHAIN IS A COMPOSER BENCHMARK, NOT A DRAGGABLE SUBJECT (r4)** — its parent computes `display: table` and refuses at E2 (§5), so the lane building the Playwright row must not assume it can be dragged. The criterion is a server-side measurement over source bytes and is unaffected. ⚠ **The threshold is met: round 4 built the one-splice composer and measured 6.803 ms — 1.76× headroom — with the naive fold (33.0 ms) and a correct k-swap (≈21 ms) both RED against it, and byte-exactness confirmed in both directions including an interior up-move (index 3 → 1), a direction no earlier round had tested.** ⚠ **The subject is named because these numbers are page-size dependent — the same three primitives read 0.662 / 1.490 / 9.041 ms on `shop/member-list` (9,656 B).** Controls: byte-equality against the naive fold, no-move, wrong-destination. G47-20 pins the parse count. |
| **R47-5** | The trailing-click latch has two producers. | Co-occurrence needs two simultaneous pointers (disjoint targets); bounded by the shipped unconditional drop-on-press. The docstring's precondition is corrected in S47-3. |
| **R47-6** | Widening Cmd+Z ownership to `document.body` intercepts a keystroke meant for something else. | The text-entry guard runs first and is untouched; `body` is unowned rather than outside the overlay. G47-12(b-ii) asserts the order, meaningful only because the `null` half was dropped. |
| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
| **R47-8** | One drag, N rows move, and the user is surprised. | §4.1(h) keeps `#dsh-ring-instance-hint` visible **through an explicit `visibility: visible` re-declaration**, because the hint is a child of the layer being hidden; G47-16(ii) is aimed at deleting that override. ⚠ **Without the override this risk had NO working mechanism (M4).** |
| **R47-9** | A boundary forgets the second guard call, or the teardown. | One wrapper, 7 sites migrated in S47-3's own commit, G47-14's caller-scan leg **with the wrapper's module named**; and the reorder guard's own teardown reset (§4.1(f)). |
| **R47-10** | The §3.F-1 amendments and the preamble go stale and no gate notices. | Six rows with dispositions, amended in the commit that makes them true; the two dead line pins converted; `check-citation-anchors.mjs` protects the new anchors; the S47-6 whole-set audit is the rest. **Stated as an uncovered surface rather than believed covered — and r2's own "still literally true" claim about the preamble is why (M7).** |
| **R47-11** ⚠ **RE-PRICED (round 3)** | The modelled subset is narrower than the corpus and users meet the refusal. | ⚠ **MEASURED AT ZERO in this corpus** — `rtl` 0/930, non-`horizontal-tb` 0/930, `order !== "0"` 0/930 (§4.2(3)) — so nothing is lost today, and the refusal names the panel as the working alternative. **What is UNMEASURED is whether that stays true as the corpus grows**, and the gate subjects are synthetic precisely so the clauses keep working when it does not. |

---

## 8. Where the owner's eyes are needed

**What the phase settles WITHOUT the owner:** every gate in §6. **Playwright driving a real Chromium IS the running app for that purpose** — "browser-only" means *not reachable in jsdom*, never *needs a human*. What needs a human is taste.

**The boundary is AFTER S47-4 and BEFORE S47-6.**

| U-item | The question | Why no test answers it |
|---|---|---|
| **U1** | The indicator's position convention — centred in the gap, or flush against the preceding sibling's trailing edge? Full chain cross-extent, or the subject's? ⚠ *Clipping is no longer part of this question — §4.4 rules the readout clamped.* | Both are correct against G47-6. |
| **U2** | The indicator's weight and colour. ⚠ Adjacent but out of scope: `selection-ring-treatment` is the ring's *shape* question. |
| **U3** | **The arming threshold for THIS gesture.** 4 px is owner-ratified **for resize**, with 2-of-20 tremor misclassifications accepted; a reorder drag begins on the element itself. **The concrete harm of a sub-intent arm — it would have eaten the selection click — is closed by §4.1(g), but the arm still costs an indicator flash and a needless selection switch.** | A felt classification on a different gesture. |
| **U4** | Furniture during the drag: hide six nodes, keep the instance hint? ⚠ §4.4 no longer depends on this answer. |
| **U5** | **The silent refusal at N > 1.** A drag on a member of a multi-member selection does nothing. Should it say so? | A refusal surface for an excluded gesture is a scope question. |
| ~~U6~~ | ⚠ **DELIBERATELY EMPTY. U6 was DR47-8 and the owner answered it on 2026-08-27.** The number is not reused and the hole is recorded so a later lane does not "restore" it. | |
| **U7** | The refusal readout's timing — paint on arming, or only after further travel that looks like intent? | An immediate paint on every accidental 4 px drag is noise; a late paint may read as no feedback. |
| **U8** | **The dirty-press silence.** Term 5 makes the headline gesture do nothing whenever the controller is unsettled or dirty, on a canvas where **578 of 770 elements are reorderable** (§3.1) — while DR47-7 rejects silence precisely because it teaches the user the feature is broken. Should it say something, and how often does it happen? | Either a scope call or a measurement of the dirty-press rate; the phase can ship the self-healing behaviour (the ordinary click commits the draft, so the next press works) but cannot decide whether that is enough. |
| **U9** ⚠ **NEW (r4)** | **What `n / N` MEANS.** §4.4 rules the numbers instance-local so the user can count them, and §4.2(2)'s drop-on-absence ruling then makes the denominator **change between visually identical rows**: on `shop/order-detail`'s six step columns the readout shows `n / 3` in five and `n / 2` in the sixth, for a single template edit that changes all six. So `n / N` describes neither the source order the edit acts on nor the scope of the edit. ⚠ **AND THE FRAMING MATTERS, BECAUSE r4's WAS WRONG (r5): the owner DELEGATED the form.** The ruling record reads *"the drop position (`3 / 7` **or whatever form the plan settles**)"* — so this is not *"ground the owner personally ruled and the plan must not settle"*; it is **the plan settling the form it was handed, and reporting a consequence of that form which was not visible when the form was delegated.** **Asking the owner to re-decide something they handed over is the one way this reads badly**; asking them whether a consequence they could not have seen is acceptable is the reason the U-list exists. Options if the owner wants one: keep instance-local (what the user can count); show the source position (what the write does); or drop the denominator. | A denominator that changes between identical-looking rows is a number the user cannot reconcile, and no test can say whether that is worse than a total they cannot count. |

**Still UNVERIFIED, and it is now a short list:** every claim about how the gesture FEELS; other browser engines; a real cross-application pointer drag-out; the viewport-dependence of the wrap and overlap counts; and any chain hidden behind an in-page control a sweep did not reach — **a bound whose SCOPE is stated in the status block rather than left implicit, because three sweeps drove three different state scopes.**

---

## 9. Open questions routed OUT of this lane

**9.1 — DR47-8 is CLOSED**; what remains is the DESTINATION of reading (a), which the owner did not cancel (*"it'd be useful to have"*). **S47-0 routes it back to B-Q4's row with the ruling recorded and no phase number invented.** ⚠ One half of the owner's reasoning is deliberately **not** repeated as fact: they offered *"what went into phase-46 was (b) too"* as their own reading from context; phase-46 touched the readout FAMILY and shipped no size readout, which is consistent but is not the same claim. **The ruling stands on the owner having made it.**

**9.2 — KI-47: NOT TAKEN, lead-ruled; the destination stays open.** Phase-46's S46-5 records that correcting every routing site was the owner's **stated condition** for excluding the family KI-47 was found to belong to; adding it back by lead inference reverses an owner condition.

**9.3 — `expectDestination` and "no new write class": CLOSED** on the enumeration in §4.3, with r0's header-sentence appeal withdrawn. The real objection was **optionality**, and the anchor receipt answers it by design.

**9.4 — `undo-focus-ownership`.** C47-6a is the fix, C47-6b the placement improvement; the owner's sketch is honoured in mechanism and declined only in host. **Needs: owner confirmation at the U-item pass. Blocking: nothing.**

**9.5 — F46-D: LEFT STANDING and unrouted, on a MECHANISM.** `e2e/resize-handles.spec.ts#async function readScene(page: Page, oid: string = SUBJECT_OID): Promise<Scene> {`'s predicate falls back when `#dsh-handle-layer` is **absent**; §4.1(h) hides by `visibility`, never by unmount, so phase-47 does not make that fallback reachable. **S47-6 owes the grep as a named deliverable**, and a lead may still take F46-D opportunistically.

**9.6 — The design-view click constraint (M10): does it deserve a `docs/known-issues.md` entry?** On :3001 an in-page control cannot be activated by a click because the selection shield claims the press; measured with a cross-host control (§5, S47-6). **It is not phase-47's defect and not phase-47's to fix**, but it constrains every future Playwright spec that needs a non-default page state on the design view. **The lead rules whether it becomes a KI; this plan records it where S47-6 will read it either way.**

---

## 10. ADR

**Decision.** Ship drag-to-reorder as a gesture that (i) is recognised inside the shield's existing ordinary press arm, adding no arm to a table that partitions by target ownership; (ii) splits CANDIDATE from ELIGIBLE so an ineligible subject arms into a refusing state, and declines to arm unless the controller is settled-and-clean; (iii) makes the drag subject the selection at arm time; (iv) resolves its drop by sibling IDENTITY against the published chain, with a total hit-test, an order-once/geometry-per-move table, a parent-scoped direct-child join that **drops unrendered members rather than refusing**, and layout admissibility **scoped to the subset actually modelled**; (v) writes it as ONE request carrying an **anchor receipt**, rearranged by a **ONE-SPLICE composer** inside `computeStructuralEdit`, yielding one journal entry and one Cmd+Z; (vi) surfaces a blue indicator, a **drop-position** readout clamped to the ring layer, and a refusal readout, as three non-operable nodes at z 44; (vii) refuses with a map total over the engine's vocabulary, its `undefined` arm and six client-only keys over three conditions, in ko+en, naming relationships rather than elements or display values — including one whose sentence names the rendered COPY, because E3 is instance-scoped; (viii) registers a second active-drag guard behind one wrapper at all 7 boundaries, with its own teardown; and (ix) fixes `undo-focus-ownership` by counting `document.body` as owned, with a separately-sited focus-placement improvement.

**Drivers.** D47-1 (§3.1's chain census — five independent derivations). D47-2 (**the no-flow-axis refusal is the majority case, 61.3 % measured live**, and the ontology contract owed it regardless). D47-3 (four shipped, gated mechanisms on one press).

**Alternatives considered.** A fourth shield arm — rejected on what the table partitions by. A second stage listener — spec-legal, rejected on one press having two owners. N sequential POSTs — rejected on undo count, round-trips and atomicity. A `steps: number` — rejected because a count is unverifiable; G47-10 makes it executable. A `move-to` verb — rejected as five ripples. **A `{prevOid, nextOid}` GAP receipt (r1's own choice) — withdrawn because its second producer cannot construct it.** **A k = 1 CLAMP** — the strongest argument against this design's centre of gravity, proposed independently by two round-1 lanes; **rejected because a clamped gesture measures a crippled one at the owner's live pass**, and its cost half is gone since the one-splice composer. **A k-SWAP fold over one parse (r2's own choice) — falsified: two lanes built it and both watched it throw `span-sentinel-failed`, because `swapSpans` shifts every later offset. The repo had already written that lesson into `cutSpans`'s docblock in the same file, and the plan reached past it.** **Requiring every chain member to resolve (r2's rule) — withdrawn: it produced a per-instance verdict on a per-chain contract for 9 chains, and no refusal wording survives a user who just did the same drag one column over.** ⚠ **Routing the sub-floor case through `chain-member-not-locatable` (r3's rule) — withdrawn at r4: nothing failed to be LOCATED there, and on `d4b6s3,d8m1w7` it reproduced the very inconsistency the ruling above exists to dissolve. A run of one is a distinct state and gets a distinct key.** A geometric ordinal drop — rejected as silently wrong on reverse and wrapping parents. A live DOM reorder preview — rejected because `#dsh-screen`'s children belong to React. `directionToken` for reversal — rejected as base-layer only. **Modelling full logical flow — rejected on scope after a headless-browser falsification; the subset is scoped and refused-outside instead.** A panel-hosted Korean-only refusal — rejected on surface and on the bilingual rule. Registering with the shipped resize guard — rejected because registration replaces and its `state()` carries resize semantics. Moving default focus to `#dsh-screen` — rejected on host.

**Consequences.**
- The shield takes **two** edits: one ordinary-arm call carrying the predicate-breadth obligation, and one mechanical wrapper swap.
- `POINTER_DRAG_THRESHOLD_PX` gains a fifth importer and a fourth drag classifier; its stale header is corrected.
- The trailing-click one-shot gains a second producer and a widened docstring contract.
- **A second active-drag guard exists**, with a wrapper at all 7 boundaries and its own teardown.
- The wire gains one REQUIRED-or-FORBIDDEN field; **`StructureSection` gains nothing.**
- **`structural-edit.ts` gains a span-rearrangement primitive beside `swapSpans`**, because a k-step move is not k swaps of one pair.
- `styleReadout` moves to a shared module with `tone`, `zIndex` and `accentPx` parameterised and **three** callers migrated; **both** `READOUT_ACCENT_PX` declarations stay where the shipped regex gate reads them.
- The ring layer gains three readouts at **z 44**; the drop-position readout is **clamped** at the frame edge because the layer clips.
- **`#dsh-ring-instance-hint` gains an explicit `visibility: visible`**, without which R47-8 had no working mechanism.
- **The gesture refuses on four layout shapes it does not model and on chain ambiguity — all with zero subjects in this corpus**, so their gates carry authored subjects rather than a false claim to shipped ones.
- ⚠ **And it refuses, with its own key and its own words, when fewer than two chain members render in the pressed copy — the ONE client-only refusal with a SHIPPED subject** (`lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, 2/2/2/2/1). **E3 is therefore the only instance-scoped eligibility question**, and G47-11d is what keeps its wording honest for a user who just succeeded one copy over.
- ⚠ **No-op detection is over SOURCE position**, so a source-effective, render-inert drag issues a real request and consumes an undo slot — stated as a consequence, unconstructible on any flex-parented subject today.
- Six ontology rows get dispositions, the component-instance row ships **qualified**, the preamble's two sentences are rewritten and its two dead line pins converted; no register gate watches any of it.
- The resize W×H readout leaves the phase **without being cancelled**.

**Follow-ups.** The drag GHOST (DR47-3b). Cross-parent drag. Marquee / absolute insert-on-drop — the stage-background slot is left unclaimed on purpose. **B-Q4 now carries two live halves: auto-scroll, and the W×H readout routed back by the 2026-08-27 ruling.** KI-47 and F46-D (§9.2, §9.5). Modelling `rtl` / vertical writing modes / `order` (R47-11). The design-view click constraint (§9.6). ⚠ **Retiring `use-spacing-drag.ts`'s duplicate `styleReadout` is NOT a follow-up** — the shipped regex gate requires that copy's `READOUT_ACCENT_PX` declaration to exist.

---

## 11. Pre-mortem — four ways this phase ships broken

1. **The new predicate is too BROAD and everything is green.** The reorder call matched a target class nobody intended, and no behavioural row could see it because the gesture appeared to work everywhere it was tried. **This is the class the record contains:** `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, `#dsh-stage`'s `tabIndex={-1}` made it match from anywhere, and ROW D became unreachable while every behaviour stayed green. **Countermeasures: G47-2, G47-5c, G47-5d, G47-1's fourth press, and the S47-3 brief's must-NOT-match statement.**
2. **One Cmd+Z is asserted and passes for the wrong reason.** The gate drags one position because **173 of 235 chains can only produce k = 1**, and a k-per-request implementation passes it. **Countermeasures: G47-8 specifies a 5-member chain and a 3-position drag; S47-0 owes a flex-col chain of ≥5 whose members all render together, because the corpus's existing flex-col 5-chains are three-quarters conditional; and G47-20 pins the parse count at 2 so the composer cannot silently degrade.**
3. ⚠ **A GATE IS BUILT THAT CANNOT FAIL — and this plan has now shipped FIVE instances in its own text, SPLIT BY CLASS, because they are not one failure and one countermeasure does not cover them.** **SUBJECT CLASS (2): the subject cannot produce the failure.** r2's G47-11c named two shipped subjects that measurement showed cannot fire, and r2's G47-19 read a row count and called it a chain length. **MUTATION CLASS (3): the subject is fine and the mutation is not.** r0's G47-1 named a mutation the contract could not express; r1's G47-11b leg (i) was green on the defect and on the correct behaviour alike; ⚠ **and r3's G47-16 leg (ii) was the same failure again, described in the identical words in the very revision that wrote this paragraph — the hint is a CHILD of the layer the mutation adds it to, so "add the hint to the hidden set" changes nothing (§4.1(h)). r3 counted four and was short by its own freshest one.** Every one was found by someone re-deriving the subject or the mutation rather than the rule. ⚠ **COUNTERMEASURES, AND THE ASYMMETRY IS NAMED RATHER THAN PAPERED OVER: §6's subject column and the SYNTHETIC declarations are MECHANISMS, and they cover the SUBJECT class only.** For the mutation class the plan offers the standing obligation that *every gate is shown RED under its named mutation before it is believed green* — **which is a RESOLUTION, not a mechanism.** Three of the five instances are in the class the plan has no mechanism for, and two of those three were caught by a reviewer rather than by the process. That is the honest state.
4. ⚠ **A RULING IS CORRECT AND ITS DIVIDEND IS FALSE, BECAUSE IT WAS VALIDATED AGAINST THE POPULATION IT WAS DERIVED FROM.** §4.2(2)'s drop-on-absence ruling was derived from chains where *some* member goes missing, and its closing sentence claimed *"all 15 chains admit in every instance."* **It was never checked against a chain where enough members go missing to fall below its own floor — and for a 2-member chain with one conditional sibling those are the same event.** `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` resolves 2/2/2/2/1 across five flex-parented instances, so the fifth reproduced, on a shipped default-state subject, the exact user experience the ruling exists to prevent. The ruling survived; **only its dividend sentence was wrong, which is the hardest shape to catch, because everything around it is right.** **Countermeasures: G47-11d, whose subject is that chain and whose three mutations each restore one of the wrong answers; and the standing habit that produced the catch — re-deriving a claim's population rather than its rule.** ⚠ **This is the phase's signature failure, and it has now happened at four levels** — a false brief claim (§0), a correction that repeated the error inside itself (§3.1's oid reasons), an ontology sentence asserted as verified without re-running its grep (§4.7), and now a ruling's dividend. **The plan carries all four rather than only the ones still visible in the text.**

---

## 12. Test plan, by layer

- **Unit (headless):** the chain walk and its termination; the drop table's two lifetimes and its drop-on-absence rule; the total hit-test over synthetic rects (wrap-line gaps, exact midpoints, equal distances, overlapping rects); the scoped-admissibility conjunction, each clause falsified singly; the reversal flip; no-op detection; the candidate conjunction's five terms; the eligible split's three questions (E1/E2/E3) and their SEVEN failure routes — E1's three, E2's two, E3's two; the terminal totality **and the teardown reset**; the destination and direction computation; **the refusal map's `Record` over the engine union, its `undefined` arm, and its six client-only keys**.
- **jsdom:** the three new nodes' structure, marks, inline `pointer-events` and clamping; the `styleReadout` extraction's before/after equality and both `READOUT_ACCENT_PX` declarations; **the instance hint's `visibility: visible` override under a hidden handle layer**; the bilingual rendering and its legs; the one-per-press pair row; the Cmd+Z rows and guard order; the drag-subject rows; the KI-46 in-flight-window row.
- **Sidecar / integration:** the anchor receipt's 409 arms and its self-anchor 400; the REQUIRED/FORBIDDEN 400s; the direction-disagreement 400; **the one-splice composer's byte-exact equality against the naive fold with the no-move and wrong-destination controls, its parse count (2), and its in-lock time against R47-4's pre-committed 12 ms on the named subject**; atomic abort; one journal push; the applied-`k` echo.
- **Playwright — `e2e/reorder-drag.spec.ts`, declared `ambient`, plus the fourth press added to `e2e/spacing-gesture.spec.ts`.** ⚠ **The classification is argued (G47-13 leg ii):** the spec drives structural edits through the sidecar and asserts the resulting bytes on disk, so it **fails without a sidecar** — the `$doc`'s stated criterion. It resembles `e2e/structural-editing.spec.ts` (ambient, destructive, on-disk assertions), not `e2e/resize-handles.spec.ts` (neutral, a pure DOM-geometry checker). Rows: a full drag with on-disk bytes asserted; capture across the frame edge; the no-op-still-selects row; one Cmd+Z reverting a 3-position drag; the stage-background rows; wrap and overlap on their shipped subjects; the live-variant predicate; the three modelled-subset refusals with their LTR positive control; the `.map()` multi-instance row **and the instance-hint visibility leg**; the ambiguity refusals on S47-0's authored subjects; **the sub-floor row on `d4b6s3,d8m1w7` — admit in instances 0–3, `no-sibling-in-this-copy` in instance 4 (G47-11d), the one client-only refusal with a shipped subject**; the boundary-termination row. ⚠ **Destructive** — every mutating row owes the same `finally` snapshot-and-re-derive net `structural-editing.spec.ts` carries. ⚠ **And no row may depend on driving an in-page control by clicking on :3001 (§5, S47-6).**
- **Observability:** the structural log line carries the **applied** `k`, read from the result.
- **Owner, live:** §8's U1–U5, U7, U8 **and U9**, at the boundary after S47-4. ⚠ *r4 minted U9 and left it out of this list; §12 is the layer-by-layer contract a story brief is written from, so a U-item that exists only in §8 is a deliverable with no carrier.* **U6 is deliberately empty.**

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "rg -n '"'^## |''^### |''^#### '"' .omc/plans/ralplan-phase-47-drag-reorder.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
31:## 0. The corrected arm-table record, and what it changes
43:## 1. RALPLAN-DR summary
45:### Principles (5)
53:### Decision drivers (top 3)
59:### Real decisions, with options
77:## 2. What this phase ships, inherits, does not touch, and is EXCLUDED from
106:## 3. Repo facts
108:### 3.1 The census, the singleton split, and the parent-layout split — the ONE home for all of these numbers
132:### 3.2 The engine's published chain, and what terminates it (READ)
140:### 3.3 One request, one journal entry; and the composer that actually runs (READ + RUN)
163:### 3.4 Neither the authored reader nor a naive live read is sufficient (READ + RUN)
169:### 3.5 The shield's ordinary arm and click arm, in order (READ)
175:### 3.6 The Cmd+Z guard order, and the two focus mechanisms (READ)
181:### 3.7 The drag subject is not `selectedTarget`, and the panel holds one link (READ)
185:### 3.8 The readout family, and where its nodes actually live (READ)
195:## 4. The design
197:### 4.1 Arming, ownership, subject and terminal (RULED — DR47-1, DR47-2, DR47-10, DR47-11 — C47-1)
229:### 4.2 The drop resolution (RULED — DR47-5, DR47-6 — C47-2)
258:### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)
281:### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)
301:### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)
343:### 4.6 `undo-focus-ownership` — ONE fix and ONE placement improvement (RULED — DR47-9 — C47-6)
353:### 4.7 The ontology rows, and what no gate watches (RULED — C47-7)
374:## 5. Stories, in ship order
415:## 6. Gates — each with a stated, CONSTRUCTIBLE RED-when and a NAMED subject
455:## 7. Risks, each paired with a MECHANISM
473:## 8. Where the owner's eyes are needed
495:## 9. Open questions routed OUT of this lane
511:## 10. ADR
539:## 11. Pre-mortem — four ways this phase ships broken
548:## 12. Test plan, by layer

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '77,195p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '196,374p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '375,472p' .omc/plans/ralplan-phase-47-drag-reorder.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
## 2. What this phase ships, inherits, does not touch, and is EXCLUDED from

**The scope line, quoted from `docs/e3/tracker.md` §"v3 CLOSE (2026-08-24)" — byte-identical, and NOT edited:**

> **Drag-to-reorder → IN, as phase-47 of a v3.5 follow-up pair.** The gesture rides v2's existing `move-up`/`move-down` verbs (no new write class) with the blue insertion indicator, and carries the cheap B-Q4 mitigation (a W×H readout during drag) since this gesture is where dragging blind bites.

⚠ **This quote's authority is weaker than r0 and r1 treated it as: the owner does not remember making the ruling.** The readout half is now governed by the fresh input of 2026-08-27 (DR47-8). The rest — riding the existing verbs, no new write class, the blue insertion indicator — is unchallenged and is what this phase builds, as is the v3.5 line's *"undo-focus-ownership belongs with 47"*.

**Also lands here, ruled in §4:** the gesture's arming, subject rule, one-per-press rule and terminal (§4.1); the drop resolution, its total hit-test and its scoped layout admissibility (§4.2); the anchor-receipted single-request move over a **one-splice composer** (§4.3); the indicator and the drop-position readout (§4.4); the refusal set (§4.5); `undo-focus-ownership` (§4.6); the ontology amendments (§4.7).

**Inherits without change:** `packages/descvi/src/extractor/structural-edit.ts#export const STRUCTURAL_OPS: readonly StructuralOp[] = ['delete', 'move-up', 'move-down', 'duplicate', 'insert-after'];`; the five-verb flag ladder; `packages/descvi/src/extractor/structural-edit.ts#function baselineFor(ctx: ModuleContext, loc: OpUnitLocation): StructuralBaseline {` and the D7 receipt semantics; the shield's three-arm table **unchanged in every arm**; phase-45's travel guard **unchanged**; `deriveParentContext`'s field set; the spacing family; KI-10's inheritance.

⚠ **`POINTER_DRAG_THRESHOLD_PX`'s stale header is corrected as a free rider**: it says *"ONE SYMBOL, THREE CONSUMERS"*; four modules import it today, so reorder is the **fifth importer and the fourth drag classifier**.

**Does NOT touch:** any serializer; `ParentContext`'s shape; the panel's `StructureSection` affordance record — **no exceptions**, because the anchor receipt needs only the two fields the panel already holds; the handle-geometry admission rules (phase-48); `.descvi/screens.json`'s content **except** for S47-0's fixture authoring.

**EXCLUDED, each with its reason and its destination:**
1. **B-Q5** → **phase-48**, owner ruling 2026-08-25.
2. **Marquee / rubber-band** → **deferred-v4**. §4.1's arming requires the press to resolve to a `[data-oid]` element inside `#dsh-screen`, so the stage background stays unclaimed. **G47-2 keeps that true.**
3. **Cross-parent drag** → `deferred-v2 (hard)`. §4.2's chain is scoped to ONE `parentOid` by construction.
4. **Alt / Cmd / Ctrl + drag** → unchanged. A modifier-held press **does not arm reorder; existing click behaviour is unchanged.** A modifier acquired mid-gesture is ruled at §4.1(f).
5. **Multi-select drag (N > 1)** → OUT; §4.1(b) carries the argument, which is about the click arm's ORDER.
6. **`selection-ring-treatment`, `spacing-affordance-mark`, KI-54** → not picked up.
7. **KI-47** → **NOT TAKEN, lead-ruled** (§9.2): it needs a fresh owner input, not a lead inference.
8. **The resize W×H readout** → routed back to B-Q4's row, **excluded but NOT cancelled** (§9.1).
9. ⚠ **Modelling `rtl` / vertical writing modes / unequal `order`** → out by DR47-6(e); the gesture refuses on them and names the panel as the working alternative. **Zero subjects in this corpus (§4.2(3))**, so nothing is lost today.

---

## 3. Repo facts

### 3.1 The census, the singleton split, and the parent-layout split — the ONE home for all of these numbers

**Static probes** (`.omc/state/scratch-r2/{census,singletons,split,tally}.mjs`, re-run by this lane in r2; reproduced independently five times across rounds 1–3):

| Quantity | Value |
|---|---|
| oid entries / entries with `canMoveUp \|\| canMoveDown` | 770 / **578** |
| chain components / orphans | **427** / 0 |
| admissible multi-member chains (≥2) / members in them | **235 / 578** |
| chains of ≥3 / ≥4 / longest | **62 / 21 / 7** |
| component-length histogram | 1×192, 2×173, 3×41, 4×7, 5×6, 6×5, 7×3 |

**Internal control:** *members in multi-member chains* equals *entries with `canMoveUp || canMoveDown`* exactly (578 = 578), by two independent paths.

**The 192 singletons split three ways by refusal PAIR** (rows sum to 192): **22** `no-adjacent-sibling` both ways — genuinely no neighbour; **108** where a neighbour exists and is not an editable op-unit (57 + 39 + 12); **62** structurally ineligible (26 `unsupported-parent`, 24 `target-bears-data-screen`, 9 `unsupported-container`, 3 `non-canonical-separator`). **The cause of the 108 was DRIVEN:** in `src/app/lab/tests/style-edit/page.tsx`, `v002k2`/`5pznp9`/`sms60s`/`hakgqo` are four *visibly adjacent* children of a `flex flex-col` parent each reporting `unsupported-sibling` with `prev=null next=null`; **strip the intervening `{/* … */}` JSX comments and re-run `buildEditMap` and `v002k2` reads `prev=5n09bh next=5pznp9`, fully eligible.** A JSX comment severs the chain, because `adjacentOpUnit` requires one canonical separator and a comment is not one — **and the user cannot see it.**

⚠ **All 192 carry a typed reason for BOTH move ops, so §4.5's `undefined` arm is measured at ZERO occurrences today.** It exists because the producer's TYPE admits it (`reasons?: Partial<Record<StructuralOp, StructuralRefusalReason>>`, omitted when empty) and because the shipped panel carries the equivalent at `packages/descvi/src/react/overlay/panel/StructureSection.tsx#function fallbackReason(op: StructureOp, structure: StructureEditInfo): string {`.

**The refusal tally over `move-up`/`move-down` across `src/app` — 854 REFUSALS (not entries):** `no-adjacent-sibling` 541 · `unsupported-sibling` 189 · `unsupported-parent` 52 · `target-bears-data-screen` 48 · `unsupported-container` 18 · `non-canonical-separator` 6 · **`unequal-indent` 0** (positive-controlled: re-indenting a real line makes it 4). ⚠ **`unsupported-sibling`'s 189 splits by MOMENT (M9): 165 arm-time (on singletons) and 24 fold-step (on multi-member chain members)** — so §4.5's wording must be true at **both** moments, not merely re-scoped from one wrong moment to another.

**THE PARENT-LAYOUT CENSUS — LIVE, and it is the authoritative reading.** Round 3's lane measured computed layout on the running app over all 235 multi-member chains: **91 flex / 144 non-flex — the no-flow-axis refusal is the majority case at 61.3 %.** Cross-tabulated against the authored-class proxy: **zero misclassifications in either direction**; all movement is the proxy's 19 unknowns resolving **8 flex / 11 block**. ⚠ **Both of the proxy's stated edges held as edges**: 83 was a lower bound on flex (→ 91) and 133 + 19 an upper bound on non-flex (→ 144). **The proxy is kept beside the live number as the corroborating reading** — 133 non-flex / 83 flex / 19 unknown, of the 133: 54 `no-class`, 79 real non-flex className **of which 15 are `grid`**, which is the figure §4.5's wording rule 2 rests on. ⚠ *(The `no-class` classification survives here empirically because `src/app/globals.css` contains zero `display:` declarations and zero occurrences of `flex` — an empirical fact about this tree, not a general rule.)*

⚠ **The oid reconciliation, re-opened at source in r2 because r1 carried both of its reasons without re-reading them and both were false:** `798` static `data-oid=` − `24` (`src/app/page.tsx`, the one page with no sibling `spec.ts`) − `3` (`insert-scratch`'s three occurrences are `data-oid="…"` **ellipses in a file-header docblock**, not duplicate oids) − `1` (`wcall1`, one real element plus one docblock mention) = **770**. **The corpus has exactly one duplicated oid string and it is a comment.**

### 3.2 The engine's published chain, and what terminates it (READ)

The chain links only across **exactly one canonical separator** to a `JSXElement` **or an admissible `{cond && <el/>}` container** bearing a well-formed oid, per `(parent, screen partition)`. ⚠ **That parenthetical is load-bearing and §4.2(2) is where it lands: the artifact links siblings the DOM can never show together.**

⚠ **`adjacentOpUnit` and `locateOpUnit` are NOT exported.** S47-2 does not export them; it adds one exported entry point beside them — `resolveMoveDestination(ctx, screenId, oid, anchorOid, side)` — so the chain walk stays in the module that owns `adjacentOpUnit`.

⚠ **`.map()` BODIES ARE ORDINARY SUBJECTS.** The container is not an op-unit, but elements inside it are: `src/app/sandbox/resize-repeat-list/page.tsx#      <ul data-oid="smlist" className="flex flex-col gap-2">` holds a chain, and `smcell`/`smname`/`smtagg` form a three-member chain under `smroww`, rendered four times. ⚠ **`smroww` itself is a SINGLETON (`canMoveUp: false, canMoveDown: false`, no parent, no neighbours) and can never be a drag subject** — which is what falsified r2's G47-19 (§4.4).

### 3.3 One request, one journal entry; and the composer that actually runs (READ + RUN)

`packages/descvi/src/sidecar/server.ts#        { files: [absSpec, absPage], subject: structureSubjectFor(intent.op, screenId, oidValue), journal: { mode: 'push' } },` — one `push` per request. `packages/descvi/src/sidecar/server.ts#export function computeStructuralEdit(` runs inside `commitWrite`'s `prepare`; its move arm returns `{ nextPage, nextSpec: null }` — a move touches `pageSource` only, and the fold belongs inside that arm. `JournalEntry` stores whole-file `before` bytes for **both** declared files, which is why one Cmd+Z restores byte-for-byte rather than replaying k inverse moves.

⚠ **THE k-SWAP FOLD r2 SPECIFIED DOES NOT RUN, AND TWO LANES WATCHED IT THROW.** `spelled composer k=1: equals naive → true; k=2, k=3, k=6 → THREW span-sentinel-failed` (on `shop/member-list`, `reparse-failed` at k=2). **`resolveJsxChildOp` derives spans from `ctx.mod`, whose offsets address the buffer `moduleContext` parsed; `swapSpans` swaps spans of unequal length, so every later offset shifts and step 2 hands stale spans to a buffer they no longer describe. The parse is not per-step overhead to be hoisted — it is what makes each step's spans valid.** ⚠ **And the failure is `span-sentinel-failed`, an INTERNAL error, so §4.3(5)'s *"any step's typed refusal aborts `prepare`"* does not catch it.**

⚠ **THIS REPO HAD ALREADY WRITTEN THE LESSON DOWN, IN THE SAME FILE, AND THE PLAN REACHED PAST IT.** `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` — `cutSpans`'s own docblock, which exists because *"Removes N disjoint spans from `source` in ONE pass and ONE re-parse."* **The correct shape is ONE-SPLICE, not a k-swap loop.**

**Measured, with controls in both directions** (round-3 lane, subject `src/app/shop/order-detail/page.tsx`, the 7-member chain `kh1mfx…thbzev`, page **40,979 bytes** — ⚠ *r3 wrote "39.8 KB", which is that file's JS string length and not its byte size; two units in one sentence, inside the acceptance criterion for a byte-oriented composer*):

| reading | value |
|---|---|
| one-splice k = 6 equals the naive 6-step fold, byte for byte | **true** |
| CONTROL — no move (0→0) is byte-identical to source | **true** |
| CONTROL — wrong destination (0→5) differs from the naive k = 6 | **true** |
| naive k = 6 fold, median | **34.436 ms** |
| one-parse one-splice k = 6 (no verify reparse), median | **4.538 ms** |
| `moduleContext` / `resolveJsxChildOp` warm / `swapSpans` incl. its own reparse | **2.628 / 0.233 / 2.911 ms** |

⚠ **ROUND 4 BUILT THE ONE-SPLICE COMPOSER AND CONFIRMED IT.** Byte-exact against the naive fold **in both directions, including an interior up-move (index 3 → 1) that no earlier round had tested**; **2 parses against the naive fold's 12, measured with an instrumented `parseSync` rather than derived arithmetically**; **6.803 ms** against R47-4's pre-committed 12 ms.

⚠ **`swapSpans` ends on `reparseOrThrow`, so ONE `moveAdjacent` is TWO parses** (`packages/descvi/src/extractor/structural-edit.ts#export function swapSpans(`), and the timings confirm it arithmetically: `5.616 ≈ 2.628 + 0.233 + 2.911`. **A correct k-swap fold's best case is therefore 21.49 ms.** ⚠ **These numbers are page-size dependent — on `shop/member-list` (9,656 B) the same three read 0.662 / 1.490 / 9.041 ms** — which is why R47-4 names its subject.

### 3.4 Neither the authored reader nor a naive live read is sufficient (READ + RUN)

`packages/descvi/src/react/overlay/panel/parent-context.ts#  if (variantControlsDirection) {` is tested **before** `baseIsFlex` and `computedIsFlex`, so a parent carrying `md:flex-row` below the `md` breakpoint reports `directionSource: "variant"` and never reaches `"unresolved"` while its computed `display` is `block`. `packages/descvi/src/react/overlay/engine/tailwind-class-model.ts#export type ParentDirection = "row" | "col" | "unset" | "unsupported";` has four members and `"unsupported"` is reachable without `"unresolved"`. §4.2(3)'s live read makes both moot.

⚠ **And the live read alone is not sufficient either — driven in headless Chromium:** `flexDirection` reads `row` while `direction: rtl` reverses visual order; `writing-mode: vertical-rl` makes that `row` advance on y; unequal child `order` makes a DOM reorder produce no visual movement. Positive control in the same run: plain LTR flex, moving C to the first DOM position moved it x=48 → x=8.

### 3.5 The shield's ordinary arm and click arm, in order (READ)

Press: zero `maxTravelRef`; drop the trailing-click latch; return if ROW P; `preventDefault()` and return if ROW D; else `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      suppressShieldPointer(e);`; then `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (e instanceof MouseEvent) beginTravelRecording(e);`. Bound for **`mousedown` AND `pointerdown`** at capture on `#dsh-stage`.

Click, in order: `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      const trailing = takeTrailingClickSuppression();` → `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#      if (trailing || isResizeHandleEvent(e)) {` (suppress and return) → **only then** the travel check. **The latch branch precedes the travel check.**

### 3.6 The Cmd+Z guard order, and the two focus mechanisms (READ)

In order: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` → text-entry return → `if (!stage?.isConnected) return;` → `packages/descvi/src/react/overlay/OverlayShell.tsx#const owned = stage.contains(active)` with its host disjunct. **A `null` `activeElement` bails at the FIRST guard**, above the text-entry guard.

`focusStageIfOrphaned` (predicate `active === null || active === document.body || active.isConnected === false`) is called from exactly one site, `packages/descvi/src/react/overlay/engine/use-preview-session.ts#      focusStageIfOrphaned(stageRef.current);`. Its sibling `focusStageIfOwned` carries a measured three-row table: *"the remount lands on a LATER flush than this callback. At restore time the ticket element is connected and focused on EVERY path."* **That table also records that the three panel controls differ**: the chip add-input is keyed and remounts; `EditableDescription` and `#dsh-name-input` re-seed in place and **keep focus**. A text-entry guard **was built on that path and rejected**, two rows measured STICKY.

### 3.7 The drag subject is not `selectedTarget`, and the panel holds one link (READ)

`packages/descvi/src/react/overlay/engine/use-preview-session.ts#      const oidOfTarget = selectedTarget.oid ?? selectedTarget.specId;` is the sole subject of the post-save handoff. `StructureSection` receives only the selected oid's `StructureEditInfo` — one link, not a chain. The dirty predicate is `packages/descvi/src/react/overlay/panel/use-classname-commit.ts#    const settledAndClean = hasPendingEdits?.() !== true && isSettled?.() !== false;`, the shipped repair for **KI-46**.

### 3.8 The readout family, and where its nodes actually live (READ)

`packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function styleReadout(node: HTMLElement, isDark: boolean): void {` is module-private with **THREE** call sites in its own file, and: its base tone is the **REFUSAL's palette** with two callers each overriding three colour lines **in a specific order** because the `border` shorthand resets all four sides; it hard-codes `zIndex = "41"` — ⚠ **but the family's DRAG member is 44**: the independent copy in `use-spacing-drag.ts` sets 44 with `packages/descvi/src/react/overlay/canvas/use-spacing-drag.ts#      popup.style.zIndex = "45";` above it; `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#const READOUT_ACCENT_PX = 3;` is module-private in **both** files and read as TEXT by a shipped gate (`packages/descvi/src/react/overlay/__tests__/spacing-readout-accent.test.ts#      const m = /const READOUT_ACCENT_PX = (\d+);/.exec(source);`) that requires **both** declarations and requires the spacing copy to survive; and `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#function layoutReadouts(` places the family as a selection-anchored STACK a pointer-following readout cannot join.

⚠ **AND ALL THREE READOUTS ARE CHILDREN OF `#dsh-handle-layer`, NOT OF THE RING LAYER (M4).** `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#      const hint = ensureReadout(host, INSTANCE_HINT_ID);` — and `host` is `handleLayerRef.current`. **`visibility` inherits, so hiding the handle layer hides the instance hint**, which is exactly the node §4.1(h) says it keeps visible.

⚠ **`#dsh-ring-layer` carries `overflow-hidden`** (`packages/descvi/src/react/overlay/OverlayShell.tsx#              className="z-40 absolute inset-0 overflow-hidden pointer-events-none"`), so anything in it is clipped at the frame edge.

---

## 4. The design

### 4.1 Arming, ownership, subject and terminal (RULED — DR47-1, DR47-2, DR47-10, DR47-11 — C47-1)

**C47-1.** A headless `canvas/reorder-drag-machine.ts` and a wiring hook `canvas/use-reorder-drag.ts`; **two edits to `use-canvas-selection-shield.ts`** (§0). The arm table is unchanged in every arm.

**(a) CANDIDATE vs ELIGIBLE.** A press becomes a **CANDIDATE** iff: (1) it took the ordinary arm; (2) **no modifier at the press**; (3) the selection holds at most one member, read from the pinned mirror `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#  const selectionRef = useRef<readonly SelectionMember[]>(EMPTY_SELECTION);`; (4) it resolves through the shield's own container-scoped resolution to a `[data-oid]` element inside `#dsh-screen`; (5) **the controller is SETTLED AND CLEAN** — the shipped two-reader predicate (§3.7). ⚠ Term 5 does not *guarantee* cleanliness; **it declines to arm in the window where the controller's confirmed string is stale**, which is where §4.1(c)'s synchronous selection switch would move `identityRef` under an in-flight commit and make its R1 guard **drop the write — a committed token disappearing silently.**

A candidate that crosses `packages/descvi/src/react/overlay/canvas/pointer-thresholds.ts#export const POINTER_DRAG_THRESHOLD_PX = 4;` becomes **ARMED**, and arming evaluates **ELIGIBILITY**; an ineligible arm **arms into a REFUSING state**.
- **E1 — a reorderable neighbour exists.** Failure splits three ways per §3.1: **22** → `no-reorderable-sibling`; **108** → `sibling-not-editable`; **62** → the engine's own reason through §4.5's total map.
- **E2 — the parent is a live flow container in the modelled subset** (§4.2(3)).
- **E3 — the drop table can be built** (§4.2(2)). **Failure splits two ways: AMBIGUITY → `chain-member-not-locatable`; FEWER THAN TWO RESOLVED MEMBERS IN THIS COPY → `no-sibling-in-this-copy` (r4).** ⚠ **E3 is the only one of the three that is INSTANCE-SCOPED** — E1 is a property of the source chain and E2 of the parent, while E3 is a property of *which rendered copy the user pressed*, and that is why its second arm's sentence names the copy.

⚠ **WHY NO SETTLEMENT BARRIER, stated because the sibling gesture has one.** `resize-gesture-guard.ts`'s `armed-pending` state exists because a resize gesture **captures a className baseline it will compose on**. A reorder gesture composes nothing from the className; its baseline is the structural one, re-derived server-side under the write lock. The barrier's purpose does not apply, and the interaction that remains — the arm-time selection switch against an in-flight commit — is what term 5 **declines** rather than awaits.

⚠ **What the new predicate must NOT match** (the S47-3 brief must have the implementer state it back): any target under `[data-dsh-handle]`; the stage background or any `#dsh-stage` descendant outside `#dsh-screen`; any node under `#dsh-ring-layer`; a press carrying any modifier.

**(b) THE MULTI-SELECT EXCLUSION — SUSTAINED ON THE CLICK ARM'S ORDER.** A press-time modifier read is legitimate for *arming*, a gesture-start question. The case phase-45's ruling exists for — Shift acquired between press and release — is covered twice and neither cover is that read: if the gesture issued a request the latch is armed and the click arm suppresses **before** the travel check; if it issued none, the travel check swallows it on `shiftKey && travel ≥ threshold`. At N > 1 the gesture never becomes a candidate.

**(c) THE SUBJECT.** At arming — synchronously — the machine switches the selection to the drag subject through the shipped `applySelection` path, so **subject ≡ `selectedTarget` by construction** and the post-save handoff is correct **without being changed**.

**(d) ONE ARM PER PRESS, AND THE `pointerId` PRECONDITION.** Idempotent over the `mousedown`/`pointerdown` pair on `pointerId`, in `beginTravelRecording`'s shape. A **precondition, not defence in depth**: `setPointerCapture(e.pointerId)` is not expressible from a `mousedown`.

**(e) CAPTURE ON `#dsh-stage` — MEASURED HERE, NOT INHERITED.** ⚠ **r0–r2 declined to claim phase-42's handle-host measurement for a stage host; round 3 measured the stage host directly.** Chromium 148.0.7778.96, headless and headed agreeing: dragging 500 px past all four edges and the corner, `pointermove` keeps arriving, `pointerup` arrives at the off-frame coordinate with `pointerId 1`, `target === #dsh-stage`, capture still held, and **`pointercancel` 0 in 15 drags**. **The paired control is what makes it evidence: same host, same listeners, capture removed → `outsideViewport = 0` and `pointerup = 0`.** ⚠ **Two limitations carried verbatim: CDP input always targets the page, so this measures the browser honouring off-viewport coordinates and NOT the OS handing the pointer to another application; and only Chromium was measured** — Firefox and WebKit are not in this repo's Playwright cache and its e2e is Chromium-only.

**(f) THE TERMINAL** is one idempotent transition over: `pointerup`, `pointercancel`, `Escape` at `document` capture, **the shared active-drag guard's consultation** (DR47-11 — what delivers "selection change"), screen change, edit-mode off, and **unmount**; its final act returns the machine to `idle`. ⚠ **UNMOUNT IS A SEPARATE OBLIGATION FROM THE 7 BOUNDARY CALLS (M9):** the reorder guard needs its own `reset…()` counterpart to `resetResizeGestureGuard()`, which drops the registration and clears the latch after an unmount mid-gesture — and that module's docblock states why `terminate()` cannot be it (*"a teardown that left one behind would hand the next mount"* a live gesture nobody is performing). **S47-3 ships it.** ⚠ A modifier acquired **mid-gesture does not abort**: aborting would make the outcome depend on a key state whose effect is invisible until release, and the meanings it would defer to are deferred-v2/v4 and unimplemented.

**(g) THE LATCH IS ARMED ONLY ON A TERMINAL THAT ISSUED A REQUEST.** Arming on every armed drag composes with §4.2(6)'s no-op detection into a live regression: a 5 px out-and-back on a reorderable element would suppress a selection that happens today, across the majority of the canvas. **G47-15 is the row; §8 U3 carries the harm.**

**(h) FURNITURE DURING THE DRAG — `visibility`, never unmount, WITH ONE EXPLICIT RE-DECLARATION.** Hidden for the duration and restored at the terminal: `#dsh-hover-ring`, `#dsh-selection-ring`, `#dsh-selection-ring-pool`, `#dsh-selection-badge`, `#dsh-handle-layer`, `#dsh-spacing-layer`.
⚠ **`#dsh-ring-instance-hint` IS A CHILD OF `#dsh-handle-layer` AND `visibility` INHERITS (§3.8), SO r2's RULE HID THE VERY NODE IT SAID IT KEPT (M4).** R47-8's only mechanism was inoperative and G47-16 leg (ii) was green on the defect and on the correct behaviour alike. **The fix is an explicit `visibility: visible` re-declaration on the hint, named here in C47-1**, and G47-16(ii) is re-aimed at deleting that override. The two other readouts in that layer — `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint` — are **left to inherit the hide**, which is what we want.
⚠ **The hiding is `visibility: hidden`, never removal**, because `e2e/resize-handles.spec.ts#    const handleLayerEl = document.getElementById("dsh-handle-layer") ?? layerEl;` falls back precisely when that node is **absent**; an unmount would make phase-47 the first runtime mechanism that makes a never-fired fallback reachable. **§9.5's F46-D disposition rests on this mechanism.**
⚠ UNVERIFIED whether hiding reads better than leaving it (§8 U4) — and §4.4 no longer depends on the answer.

### 4.2 The drop resolution (RULED — DR47-5, DR47-6 — C47-2)

**C47-2.** The **ORDER half is built once at arm; the GEOMETRY half is re-read per move** (rects change under `#dsh-screen` scroll, window resize and reflow), which is what G47-4's *"the last reading is stale"* refers to.

1. **ORDER — from the artifact, once.** Walk `prevOid` to the head and `nextOid` to the tail. No DOM.
2. **GEOMETRY — from the DOM, per move, parent-scoped, and RESOLVED-MEMBERS-ONLY.** Search `subjectEl.parentElement`'s children for each chain oid. A member must resolve to **at most one element, and to a DIRECT CHILD** of that node. Then:
   - **a member resolving to ZERO nodes is DROPPED from the table, not a refusal;**
   - **`chain-member-not-locatable` refuses the whole gesture** on AMBIGUITY only — when the **subject itself** does not resolve, when a member resolves to **more than one** node in that parent, or when a member resolves to a **deeper descendant**;
   - ⚠ **and when FEWER THAN TWO members resolve, the refusal is a DIFFERENT key — `no-sibling-in-this-copy` — because nothing failed to be found (r4).** A run of one is a well-defined *nothing here to trade places with* state, and it is **INSTANCE-SCOPED**: the same chain in the copy next door has two. Routing it through `chain-member-not-locatable` would tell the user the siblings could not be located when the sibling simply is not rendered here — the wrong relationship, which is wording rule 1's own failure.

   ⚠ **THE DROP-ON-ABSENCE RULE IS A r3 RULING, AND IT IS AVAILABLE ONLY BECAUSE OF DR47-4(f).** Round 3 measured that r2's require-every-member rule refuses on a population the plan never named: **the artifact links mutually-exclusive `{cond && <el/>}` siblings into ONE chain** — §3.2's parenthetical, load-bearing at last. Measured over 235 chains: **6 refused in every observed state (2.6 %), 9 refused only in SOME observations (3.8 %), 1 never renders at all (0.4 %), 219 never refused (93.2 %).** The clearest **at source** is `sandbox/resize-repeat-list`, whose `smndaa`/`smndbb`/`smndcc` are three `{queueState === 'x' && <p/>}` blocks inside the 5-member chain `[smlist, smndaa, smndbb, smndcc, smlnkk]` — each an `opUnitKind: 'conditional-container'`, exactly one rendering per state. ⚠ **It is NOT a draggable subject and the sentence must not read as though it were (r4): that chain's parent computes `block`, so it refuses at E2 before any of this is reached.** The same source shape appears in `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`. **The draggable instance of this class is `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` (flex-parented in all five copies), and it is the one the gates use.**
   ⚠ **THE 9 "SOMETIMES" CHAINS ARE THE HALF THAT FORCED A RULING RATHER THAN A SENTENCE: under r2's rule the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed** — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, the **first** missing `rpb6hb` and the other five complete, giving 55 passing scopes and 11 refusing. **A per-instance verdict on a per-chain contract, and no refusal wording survives a user who just did the same drag successfully one column over.** **Options: (i) accept the per-instance verdict and word around it; (ii) refuse the chain everywhere it can ever be incomplete — not decidable client-side, since it requires knowing every state; (iii) DROP unrendered members from the table and refuse only on ambiguity or on fewer than two survivors. RULED (iii).** It costs nothing, because **the anchor receipt never computes an index** — the client names a rendered sibling and a side, and the server resolves it against the live source chain, which still contains the unrendered member. The only consequence is that a user cannot drop *between* two positions separated solely by unrendered members, which is invisible to them.
   ⚠ **AND r3's CLOSING SENTENCE FOR THIS RULING WAS FALSE ON A SHIPPED SUBJECT — MEASURED IN DEFAULT STATE, AND THE CORRECTION IS r4's ONE BLOCKING EDIT.** r3 wrote *"under (iii) all 15 chains admit in every instance, and the per-instance inconsistency does not exist."* **It does not, for a 2-member chain whose one sibling is conditional.** `src/app/lab/tests/shared-oid/page.tsx`'s chain `d4b6s3,d8m1w7` resolves **2 / 2 / 2 / 2 / 1 across five instances, all five parents flex** — the separator `src/app/lab/tests/shared-oid/page.tsx#{i < arr.length - 1 && <span data-oid="d8m1w7"` is conditional on not being last, so the fifth `<li>` renders one member and falls below (iii)'s own floor **while every arming precondition holds**: term 4 passes (`d4b6s3` renders in all five), E1 passes (`canMoveUp: false, canMoveDown: true`, verified in the map), E2 passes. **The user drags the last step label, is refused, drags the identical label one column left, and it works** — verbatim the sentence this paragraph uses to reject option (i). Controls: removing the separator from instance 0 gives `1,2,2,2,1`; planting one into the last gives `1,2,2,2,2`, so the detector both produces a 1 from a change and erases the observed 1.
   ⚠ **THE ROOT CAUSE IS THIS PHASE'S RECURRING SHAPE AND IS WORTH NAMING: the ruling was derived from the right measurement and validated against the population it was derived FROM** — chains where *some* member goes missing — **never against chains where ENOUGH go missing to fall below its own floor. For a 2-member chain with one conditional sibling those are the same event.**
   **RULED (r4): (iii) STANDS — it is correct on its merits and it genuinely dissolves the refusal wherever two survivors remain. What changes is that the sub-floor case gets its OWN key** (the bullet above), whose sentence names the *copy* rather than the parent, so it survives the user who just succeeded one column over — and predicts it. **Its gate leg is G47-11d and its subject is SHIPPED, not synthetic.**
   ⚠ **THE `.map()` ATTRIBUTION r1 AND r2 GAVE THE "SEVERAL MATCHES" ARM IS WITHDRAWN — MEASURED WRONG, AND WRONG BECAUSE OF A SCOPE THE PLAN ITSELF SPECIFIED.** `.map()` bodies produce **52 many-node readings across 20 chains at PARTITION scope, and 0 at the PARENT scope §4.2(2) uses**, because each repeat renders under its own parent: `smcell`/`smname`/`smtagg` resolve once per `<li>`, all direct children, under a `flex flex-row` parent. **0 of 636 member readings hit the several-matches arm.**
   ⚠ **THE DIRECT-CHILD CLAUSE HAS ZERO SUBJECTS TOO** — 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — **with a planted control (`C-B` wrapped a member in a fresh `<div>` and the analyzer reported it immediately)**. ⚠ **AND r2's ATTRIBUTION OF IT TO `wflbl3` IS FACTUALLY WRONG AND IS DELETED: `wflbl3` is a DIRECT CHILD of its own `Field` wrapper** (`src/app/lab/challenge/swallowed-oid/page.tsx#    <div className="flex flex-col gap-0.5 bg-white px-3 py-2 border border-neutral-300 rounded-md">`), so it passes both clauses. The one prop-swallowing component in the repo produces the **opposite** failure: `Field`'s *exterior* oids (`wcall1…wcall4`) reach no node and are caught by the zero-match arm — and under ruling (iii) that is a DROP, not a refusal, and in any case **`wcall1…wcall4` cannot be pressed at all** (term 4 requires the press to resolve to a `[data-oid]` element; they have zero DOM nodes in every state, the only such chain in the corpus, and their parent `wgrid1` is `grid`, so E2 would refuse first).
   **Both clauses are KEPT and both are cheap: each prevents a real failure the browser can produce, and the control proves a detector can see it. What they lose is the claim to a shipped subject — their gate subjects are SYNTHETIC and owed by S47-0**, on the `unequal-indent` rider's model.
3. **FLOW, AXIS, REVERSAL — one `getComputedStyle(parentEl)` plus one per resolved member.** Admit iff: `cs.display` is `flex` or `inline-flex` (⚠ **the predicate, not `directionSource === "unresolved"`**, which §3.4 shows a `md:flex-row` parent below `md` never reaches; ⚠ `display: contents` is therefore refused — **ruled, not missed**, since a `contents` parent lays out nothing itself); `cs.direction === "ltr"`; `cs.writingMode === "horizontal-tb"`; and every resolved member's computed `order` equal. Then **axis** = `cs.flexDirection.startsWith("row") ? "row" : "col"`, **reversed** = `cs.flexDirection.endsWith("-reverse")`.
   ⚠ **The three exclusions are correct about the browser (§3.4) and have ZERO SUBJECTS in this corpus** (round 3, each with a planted control returning the planted value): `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930**. **They stay, their subjects are synthetic and owed by S47-0.**
4. **HIT-TEST — the total algorithm.** Over the rects `R` of all **resolved** members including the subject's own: `S = argmin` of the **squared point-to-rect distance** (0 inside a rect); **inside more than one rect** → the member **earliest in source-chain order**; **exact ties at equal distance** (a midpoint, a wrap-line gap) → the same rule, **one tie-break in the design, not two**; **`side`** by projecting onto `S`'s main-axis extent against its midpoint, `< mid ⇒ leading`, `>= mid ⇒ trailing`.
   ⚠ **THE COORDINATES COME FROM THE EVENT AND THE RECTS, NEVER FROM `e.target` — AND THE WRONG IMPLEMENTATION IS THE OBVIOUS ONE (round 3).** Under pointer capture, `e.target` is `#dsh-stage` for **every** event from the first move onward, while `document.elementFromPoint` keeps resolving the real element and returns `null` off-frame. **A hit-test reading `e.target` mid-drag gets the stage and nothing else.** This algorithm reads neither and is unaffected — stated because the failure is silent.
   ⚠ **Tie-break subjects are small but NOT zero (round 3, and the corrected wrap count):** **wrap has 2 subjects**, both in `lab/tests/align-wrap` and both genuinely two-line — ⚠ *the lane's first detector counted distinct cross-axis offsets and reported 37 wrapped parents; an `items-center` row with unequal-height children produces that without wrapping, and the corrected count of wrapped parents is 3* — and **overlap has 1**, `shop/order-detail`'s `4jpxin`, a 2 px step-connector over a step marker, the only one of three overlaps whose parent is flex. ⚠ **Both counts are viewport-dependent and were measured at one viewport.**
5. **VISUAL → SOURCE.** `sourceSide = reversed ? flip(side) : side`. The result is `(anchorOid = S, side = sourceSide)` — **which is the wire receipt itself**, so no conversion step exists. ⚠ **The `reversed` branch has ZERO SUBJECTS: three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1), but none of their children carries a `data-oid`, so none can be a chain member.** Clause kept, subject synthetic and owed by S47-0.
6. **NO-OP DETECTION — OVER SOURCE POSITION, RULED (r4).** A destination equal to the subject's current **source** position issues no request and, per §4.1(g), arms no latch. ⚠ **r3's sentence named no order-space, and once members can be dropped the two spaces differ**: with source `[A, B_unrendered, C, D]` rendering as `[A, C, D]`, dragging `A` to leading-of-`C` makes the source `[B, A, C, D]` **and the render does not change.** **Source is the right space** — it is what the write acts on, what the receipt addresses and what the undo entry restores; a render-space check would refuse a reordering the user actually expressed.
   ⚠ **The residual is STATED rather than prevented: a source-effective, render-inert drag issues a real request, consumes an undo slot and arms the latch.** The user sees nothing move and one Cmd+Z is owed. ⚠ **A FLEX-PARENTED SUBJECT DOES CONSTRUCT IT TODAY, AND r4's CLAIM THAT NONE COULD IS FALSE (r5, measured live at 1440×900).** On `/shop/member-detail`'s **benefits tab**, the chain `omy3i9,0cyt4v,z76fvu,d29ipo` under `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` renders **two copies, n = 4 and n = 3** — the short one missing `z76fvu`, an **INTERIOR** member, because that node is guarded by `src/app/shop/member-detail/page.tsx#                        {b.value > 0 && (` and `INITIAL_BENEFITS`' `b002` carries `value: 0`. `0cyt4v` reads `canMoveUp: true, canMoveDown: true` with an empty `reasons` map (verified in the map this lane built), E2 is flex/row and E3 passes at 3 ≥ 2. **Drag `0cyt4v` to leading-of-`d29ipo`: source index 1 → 2, the source-space no-op check does not fire, and the render does not change.** Controls in the same session: `pk9pwr`, `scroot`, `srroot`, `smroot` → `block/row`; `grpeul` → `table/row`; `smroww`, `xufjus` → `flex/row`; **and r4's own cited counter-subject `ww57qb` reproduces as `block/row` — the reading was never in dispute, the SWEEP was.** ⚠ **HOW IT WAS MISSED IS THE FINDING'S REAL CONTENT: the r4 lane went into tab space to read `ww57qb` on the memo tab and did not check the benefits tab one click away. That is pre-mortem 4's shape, recurring INSIDE the edit that documents pre-mortem 4.** **What actually contains the residual is narrower and is named as such: the benefits tab is a plain `useState` an in-page click cannot drive on the design view (§5's M10 constraint), so the copy that constructs it is not reachable on :3001 by clicking.** ⚠ **AND THAT MAKES §9.6's KI RULING LOAD-BEARING RATHER THAN A NOTE: the only thing containing this residual is a defect this plan itself calls *"not phase-47's to fix"* — one anyone may fix at any time, silently re-opening it.** A containment a future bugfix removes is not a containment; it is a dependency, and it is recorded here as one.
   ⚠ **AND ONE EDGE THE RULE DOES NOT COVER, NAMED RATHER THAN LEFT TO DISCOVERY: when the unrendered member is FIRST, the user cannot express *"make this the first child"* at all**, because the anchor receipt names a rendered sibling and there is none leading of the first rendered one. The gesture is not wrong there; it is simply mute, and the panel's ↑ still reaches that position.
7. **THE MULTI-INSTANCE CONSEQUENCE.** A drag on a `.map()`-body element edits the TEMPLATE, so every rendered instance reorders at once — **G47-16 is the row**, and §4.1(h) keeps the instance hint visible for it.

### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)

**C47-3.** `target: 'structure'`, verb `move-up`/`move-down` by the sign of the source-order displacement, unchanged `expect` for the ORIGIN, plus **`expectDestination: { anchorOid, side }`**, **REQUIRED on the two move verbs and FORBIDDEN on the other four**, with a total switch beside the shipped `parseExpectForOp`. **Both producers can construct it**, so §2's "does NOT touch" list needs no exception.

⚠ **THE UNION SPLIT IS BY BASELINE ON THE SERVER AND BY PAYLOAD ON THE CLIENT.** `packages/descvi/src/sidecar/server.ts#export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;` carries **all five** ops, so splitting the moves off the server's baselined arm leaves **`{delete, duplicate, insert-after}`**; the client's `packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export type PayloadFreeStructureOp = Exclude<StructureOp, 'insert-after' | 'insert-child'>;` leaves **`{delete, duplicate}`**.

Server, inside `computeStructuralEdit`'s move arm, under the write lock:
1. resolve the op-unit and re-derive the live origin baseline; mismatch ⇒ `stale-baseline` (409);
2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
4. **rearrange in ONE SPLICE (M1).** Read every member's span from **one** `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. ⚠ **This is not the k-swap loop r2 specified: that shape does not run, and the repo had already written the lesson down in this very file** — `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` **S47-2 therefore owes a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** ⚠ *r2's clause "`expect` consulted on the first step only" dies with the steps: there is one step.*
5. a typed refusal aborts `prepare`, so **nothing is written**, and the 422 carries that reason. ⚠ **The k-swap shape failed with `span-sentinel-failed`, an INTERNAL error this clause does not catch — recorded because it is why the shape had to change rather than be guarded**;
6. one journal push, subject unchanged; `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string | null {` needs no new arm;
7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.

⚠ **`parentOid: null` CHAINS ARE ADMITTED, AND SAYING SO IS A RULING (M9).** `wflbl3`/`wfval7` carry it — they are declared in a helper outside the default export, so the extractor records no oid-bearing parent — and they are **pressable, admissible, flex-parented** subjects (their DOM parent is `flex flex-col`). **`parentOid` is not consulted by this design at all**: order comes from `prev`/`next`, geometry from `subjectEl.parentElement`. The server's own chain re-derivation is likewise positional. **Nothing special is owed; the case is recorded so an implementer does not add a `parentOid !== null` guard that would refuse a working subject.**

**ONE Cmd+Z AFTER A 4-POSITION DRAG TAKES THE ELEMENT BACK FOUR POSITIONS** — one request, one entry, one undo, byte-exact from the entry's whole-file `before` bytes.

⚠ **The anchor receipt is slightly more permissive than a gap receipt, and that is a property.** A gap receipt refuses when either neighbour changed; an anchor receipt names **the element the user aimed at**, so a concurrent edit elsewhere in the chain **re-targets rather than refuses**. The origin `expect` still refuses any change to the subject's own position, and the receipt is still a COORDINATE rather than a count — **G47-10's argument is unchanged.**

**Why this is not a new write class — the enumeration is the argument.** No new `StructuralOp` member, no new wire verb, no new journal arm, no new `reselectTargetFor` arm, no new `REASON_TEXT` key. ⚠ *(r0's appeal to `structural-edit.ts`'s header sentence was withdrawn in round 1: it names one class contrasted with literal replacement and carries no taxonomy.)*

### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)

**C47-4.** Three new nodes in `#dsh-ring-layer`, all **readouts by role**: no `data-dsh-handle`, no `data-v3-glyph-control`, `pointerEvents = "none"` set **inline** (a class-only rule reads back `auto` in jsdom and the gate could not go RED).

- **`#dsh-reorder-indicator`** — the blue insertion line, in the destination gap, spanning the cross-axis extent of the **resolved** members, perpendicular to the main axis.
- **`#dsh-reorder-readout`** — **the DROP POSITION `n / N`**, per the owner's ruling. ⚠ **`N` is the count of RESOLVED members and `n` the subject's 1-based position among them — deliberately the count the user can see, not the source chain length**, which §4.2(2)'s drop-on-absence ruling makes differ whenever a conditional sibling is not rendering. Showing a total the user cannot count would be the readout's own version of KI-17.
  ⚠ **AND THE CONSEQUENCE THAT RULING CARRIES MUST BE STATED, BECAUSE r3 RULED IT AND DID NOT (r4): `n / N` IS INSTANCE-LOCAL.** Measured on the chain this plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`, six step columns, per-instance **`2/3/3/3/3/3` — in DOCUMENT order, and the SHORT one is the FIRST** (⚠ *r4 wrote `3/3/3/3/3/2`, which reads positional and is wrong in order; the connector `src/app/shop/order-detail/page.tsx#                  <div data-oid="rpb6hb"` sits under an `{i > 0 && (` guard, so column 0 is the one that lacks it, and a lane building the U9 material from the sixth column would conclude the effect does not exist*), all flex — **every column admits** (ruling (iii) works there), and the readout then shows `n / 3` in five columns and **`n / 2` in the **first**, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16). **The per-instance inconsistency was not dissolved; it was relocated out of the refusal and into the readout by the consequence ruled in the same paragraph.** Stated plainly: **`n / N` describes neither the source order the edit acts on** — in column 0, `5s41w1` reads `2 / 2` while being source index **3 of 3** on the same 1-based reading §4.4 defines `n` by — **nor the scope of the edit**, which is every instance. The affordance that carries the scope is `#dsh-ring-instance-hint`, which §4.1(h) keeps visible for exactly this reason.
  ⚠ **The KI-17 argument for showing what the user can count still holds, so the ruling stands — but the readout's SEMANTICS are ground the owner personally ruled, so they are routed rather than settled here: §8 U9.**
- **`#dsh-reorder-refusal`** — §4.5's sentence. ⚠ **On a refusing arm the DROP-POSITION readout is ABSENT (M9), not blanked**: there is no position to report, and a `0 / 0` would be a number about nothing.

⚠ **THE READOUT AND THE REFUSAL ARE TWO NODES, NOT ONE RE-STYLED NODE.** They are mutually exclusive in time, and re-styling one node per paint means re-running the `border` shorthand, which resets all four sides and wipes the accent — the trap `use-spacing-drag.ts`'s own comment warns about.

⚠ **THE READOUT IS CLIPPED AT THE FRAME EDGE, AND THAT IS RULED HERE RATHER THAN LEFT TO U1 (M9).** `#dsh-ring-layer` carries `overflow-hidden` (§3.8). **The readout is therefore CLAMPED to the layer's rect rather than following the pointer past it** — it stops at the edge and stays legible, which is what phase-42's own refusal marker does when it flips above rather than clamping off-screen. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too, and this is the answer.

**Z: all three take `zIndex = 44`**, matching the shipped drag readout (§3.8), with the popup above at 45. ⚠ *r2 briefly moved them to 41 on two false premises — that 41 is "the readout family's own" z (it is the STACK family's) and that §4.1(h)'s hiding replaces the need for a z privilege (that is U4, settled after the story that ships the indicator).* **Ordering among the three at equal z is by DOM order**, the repo's own precedent — and nearly moot, since the readout and the refusal never coexist.

**THE `styleReadout` EXTRACTION, WITH ALL FOUR COSTS PAID.** It takes **`tone`, `zIndex` AND `accentPx`** as parameters — ⚠ `accentPx` is a parameter and not an import, because `READOUT_ACCENT_PX` is module-private in **both** files and importing from either would create a cycle; **neither declaration moves**, because the shipped regex gate requires both and requires the spacing copy to survive. **`use-resize-handles.ts`'s THREE call sites** migrate in the same commit. Placement is pointer-relative and clamped, never `layoutReadouts`'.

⚠ Colour, weight, inset and the gap convention are NOT settleable here (§8 U1/U2); G47-6 asserts only a property.

### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)

**C47-5.** A total `Record<StructuralRefusalReason, BilingualMessage>` rendered through `packages/descvi/src/react/overlay/shared/refusal-messages.ts#export function bilingualLine(message: BilingualMessage): string {`, **plus an `undefined` arm** (required by the producer's type; measured at zero occurrences today — §3.1), **plus the client-only set: SIX KEYS OVER THREE CONDITIONS** — E1, E2 and E3, exactly as §4.1(a) enumerates them. ⚠ *(The count has been spelled four different ways across r2 and r3 — "three conditions" over a five-row table, then "four conditions, five keys" derivable under no consistent reading. It is stated ONCE, here, and §4.1(a), the table below and §12 are the three sites that must agree with it. r4's new key makes it six.)*

**Engine-keyed rows** (counts are **refusal** counts over `move-up`/`move-down` across `src/app` — §3.1):

| key | ko | en |
|---|---|---|
| `no-adjacent-sibling` (541) | 이 방향에 **형제 요소가 없습니다.** | **There is no sibling in that direction.** |
| `unsupported-sibling` (189 = 165 arm-time + 24 fold-step) | 옆에 있는 요소가 **편집할 수 있는 단위가 아닙니다** — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit** — something invisible, such as a comment, may sit between them. |
| `unsupported-parent` (52) | **부모가 순서 편집을 지원하는 형태가 아닙니다.** | **The parent is not a shape that supports reordering.** |
| `target-bears-data-screen` (48) | **화면 경계는 순서를 바꿀 수 있는 자리가 아닙니다.** | **A screen boundary is not a position that can be reordered.** |
| `unsupported-container` (18) | **감싸고 있는 조건부 묶음이 지원되는 형태가 아닙니다.** | **The conditional wrapper around it is not a supported shape.** |
| `non-canonical-separator` (6) | **형제 요소 사이 간격이 편집 가능한 형태가 아닙니다.** | **The spacing between the siblings is not in an editable form.** |
| `unequal-indent` (0 — R47-3) | 지나가야 하는 형제 요소와 **들여쓰기가 달라** 이동할 수 없습니다. | The move is blocked because **a sibling it must pass has a different indent**. |
| every remaining engine reason, and `undefined` | **이 위치에서는 순서를 바꿀 수 없습니다.** | **Reordering is not available at this position.** |

⚠ **`unsupported-sibling`'s WORDING MUST BE TRUE AT BOTH MOMENTS, AND r2 FIXED ONLY ONE (M9).** R1 scoped it to *"a step of the fold"* and worded it *"a sibling it must pass"*; r2 corrected the scope to arm-time. **Measured, it is both: 165 arm-time and 24 fold-step** — and **the 24 genuinely ARE the "a sibling it must pass" case.** The row above names the **relationship** (the neighbour is not an editable unit) rather than a traversal, which is true at both, and its second clause names what the user cannot see — §3.1's driven JSX-comment cause is the evidence.

⚠ **The generic arm names the POSITION, not the element.** R1's read *"이 요소는 … / This element cannot be reordered here"* — the element as subject, differing from rule 1's own counterexample by one word, so G47-11 leg (ii) fired on the plan's own text. The three largest causes (52 + 48 + 18 = 118 refusals) now have relationship-naming sentences of their own.

**The client-only set — three conditions, six keys:**

| key | condition | ko | en |
|---|---|---|---|
| `no-reorderable-sibling` | E1, the **22** | 같은 부모 안에 **순서를 바꿀 형제 요소가 없습니다.** | There is **no sibling to reorder with** inside this parent. |
| `sibling-not-editable` | E1, the **108** | 옆에 있는 요소가 **편집할 수 있는 단위가 아니라** 순서를 바꿀 수 없습니다 — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit**, so the order cannot be changed — something invisible, such as a comment, may sit between them. |
| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |

⚠ Two of these name the panel as the working alternative deliberately: the flow-axis refusal is a GESTURE policy, not a write constraint, so telling the user the buttons still work is the true and actionable sentence.

⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**

**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.

**Where each is shown.** E1, E2 and E3 are known at arm time (E3 at the first geometry read): the gesture arms into a refusing state, paints `#dsh-reorder-refusal`, draws no indicator, shows no drop-position readout, and issues nothing. Step-refusals arrive as the 422's typed reason after release.

⚠ **The indicator can therefore be shown for a destination the server refuses — and R47-3 explains why that is safe rather than merely asserting it (M8).** `unequal-indent` is the only move-only precondition a chain-derived destination can trip, **and the mechanism is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."*** Because the chain is built **only across links `adjacentOpUnit` already admitted**, every other move-only condition was already satisfied when the link was made. A lane tried to break this with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. **And `unequal-indent` is measured at zero, so the cost lands entirely on G47-9's synthetic fixture.**

### 4.6 `undo-focus-ownership` — ONE fix and ONE placement improvement (RULED — DR47-9 — C47-6)

⚠ **NAMING NOTE, RECORDED BECAUSE PER-COMMIT BRIEFS CITE CONTRACT IDS VERBATIM (M9): C47-6a and C47-6b SWAPPED MEANINGS BETWEEN r1 AND r2.** In r1, `a` was the `focusStageIfOrphaned` call and `b` the ownership widening; from r2 onward `a` is the ownership widening (the fix) and `b` the focus placement. **A brief drafted against r1 would build the other thing.** The r3 meanings are below and are final.

**C47-6a — THE FIX, and it closes BOTH dead windows on its own.** `document.body` counts as owned in the Cmd+Z keydown effect. The backlog row names `document.body` as the mechanism for both windows. ⚠ **The `null` half is DROPPED**: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` bails on `null` two guards above ownership and **above** the text-entry guard, so implementing it would mean moving an early return past that guard — the exact shape G47-12 exists to police, inside the fix. **`stageRef.current?.isConnected` is NOT re-checked**; it is proven one line above.

**C47-6b — THE PLACEMENT IMPROVEMENT, and it is NOT what restores Cmd+Z.** It calls `focusStageIfOrphaned` after a panel value commit so the canvas keyboard surface is live again. ⚠ **It must land on the flush AFTER the `key={value}` remount**, because in the commit callback the ticket element is still connected and focused, `orphaned` is false, and the call does nothing.

⚠ **THE CONTROL AND THE REACH, both stated precisely (M9).** The physics — *"the remount lands on a LATER flush than this callback"* — is measured in `focusStageIfOwned`'s three-row table, **which measured the canvas-click ticket-restore path, not the panel value-commit flush**. The physics generalises; **calling that table "the control" for this claim over-claims by one call path, so it is named as the EVIDENCE and S47-5 owes the control on its own path.** And the reach is one control of three: `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever there — **which is correct, not a gap**, because focus staying in a text field is where Cmd+Z should reach the field's own undo. **C47-6b is reachable only on the chip add-input and the `key={value}` numeric value fields, and G47-12 row (a) names the chip add-input as its subject.**

### 4.7 The ontology rows, and what no gate watches (RULED — C47-7)

**C47-7.** `.omc/specs/interaction-ontology.md` §3.F-1 has **six** rows; all six get a disposition, because no gate watches them:

| §3.F-1 row | disposition |
|---|---|
| element in flex parent, within-parent | **SHIPPED at phase-47**, with an anchor into the composer — **and the row states the modelled subset** (LTR, horizontal writing mode, equal `order`), because an unqualified SHIPPED is the false half of the browser falsification written into the register |
| element in flex parent, cross-parent | unchanged `deferred-v2 (hard)` |
| element in non-flex parent | **the gate this phase clarifies** — flips to a REFUSAL row naming `parent-has-no-flow-axis`; *"undefined blue-line; clarify at gate"* is discharged |
| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
| selection box (drag the selection) | **SHIPS**; its own cell already says *"== dragging the node"*, and §4.1(c) makes subject ≡ selection at arm time |
| stage background (empty) | unchanged — §2 exclusion 2, G47-2 keeps it so |

⚠ **AND THE SWEEP DISCIPLINE THIS SECTION DEPENDS ON GETS ITS LESSON RECORDED HERE, BECAUSE IT IS NOW FIVE ROUNDS OLD (r5): A SWEEP LIST HAS TURNED OUT TO BE A PROPER SUBSET IN FIVE OF THE SEVEN ROUNDS THIS PLAN HAS HAD — the two clean rounds were the exception, not the turn.** **The portable rule: the BY-CAUSE GREP is the instrument and the enumerated list never is.** A list is a record of what one reader thought of; `git grep -n '<the key or claim being changed>'` over `.omc/plans .omc/specs docs` is a record of what is there. **When a ruling changes a KEY's meaning, sweep the key, not the sections.**

⚠ **`node scripts/check-v3-registers.mjs` does NOT gate these rows** (its census is over `**deferred-v3` markers and the eleven v3 slugs; these are `deferred-v2`). `check-citation-anchors.mjs` protects only the new anchors; a review lane is the rest.

⚠ **BOTH PREAMBLE SENTENCES ARE REWRITTEN, AND r2's CLAIM THAT THE SECOND WAS "STILL LITERALLY TRUE" IS WITHDRAWN — IT IS FALSE AT HEAD, INDEPENDENTLY OF THIS PHASE (M7).** Sentence 1 (*"every drag variant resolves to select-on-press-then-nothing-on-move"*) has been false since phase-42. Sentence 2 asserts *"There are NO `dragstart`/`mousemove`/`dragover`/`drop` listeners (grep-confirmed)"* — but `packages/descvi/src/react/overlay/canvas/use-canvas-hover-ring.ts#    stage.addEventListener("mousemove", onMouseMove);` ships today. ⚠ **Keeping a false sentence and calling it verified is the process failure this plan's own status block records, committed by the revision that wrote the record.** **The amendment describes the shipped listener set rather than asserting an absence whose terms have drifted.** ⚠ It also carries **two banned line pins that are now dead** — `selection-shield.ts:75-78` lands on a docblock tail and `OverlayShell.tsx:292-293` on `[],\n  );` — **converted to anchors in the same amendment**, since `AGENTS.md`'s rule is binding and `check-citation-anchors.mjs` cannot see either form.

---

## 5. Stories, in ship order

**S47-0 — the fixtures, the routing record, and the two counts this phase owes.**

⚠ **WHICH HALVES ALREADY SHIP — AND r3 WROTE THIS INVENTORY FROM THE AUTHORED PROXY IN EXACTLY THE PLACES §4.2(3) RULES THE PROXY MUST NOT BE TRUSTED (r4).** That is pre-mortem 3's own class arriving in the fixture list: **D47-2's whole story is that the authored token is corroboration and the live read is authoritative**, and then the inventory was written from the token. Corrected against the live reader:
- **"three flex-row chains of 7" is TWO.** The two `shop/member-list` chains (`ohpkna…lqaxc2`, `xaro3n…1hzfxp`) stand. ⚠ **`shop/order-detail`'s `kh1mfx…thbzev` does NOT** — its parent `src/app/shop/order-detail/page.tsx#      <div data-oid="grpeul" className="flex-wrap gap-x-3 gap-y-1 text-gray-500 text-sm table">` computes `display: table`, so it refuses at E2 and **can never be a drag subject.** *(Control: `4jpxin` on the same page reads `flex row` through the same reader, so the reader can see flex.)*

**Genuinely absent and owed:**
- a **flex-col chain of ≥5 whose members all render together** — ⚠ **and r3's stated reason for excluding the corpus's flex-col 5-chains was WRONG (r4): `sandbox/resize-flex-col`, `sandbox/resize-flex-row` and `sandbox/resize-repeat-list` all compute `block` at the chain's parent, so they fail at E2 — not because of their conditional members.** *(Control: the same reader returns `flex row` for `smcell`'s parent on `resize-repeat-list`.)* The conditional-member observation is true and is not the disqualifier;
- a **`flex-row-reverse` chain with oid-bearing children** — the three reverse containers in `lab/tests/align-enablement` have none (§4.2(5));
- a **variant (`md:flex-*`) chain with oid-bearing children** (G47-5c);
- **an `rtl` chain, a `vertical-rl` chain and an unequal-`order` chain** (G47-5d) — **all three declared SYNTHETIC: measured at zero subjects (§4.2(3))**;
- **an ambiguity subject for `chain-member-not-locatable`** — **SYNTHETIC: both of r2's "shipped subjects" were measured not to fire, and the several-matches and direct-child arms have zero subjects at parent scope (§4.2(2))**;
- **a flex parent whose DOM element-child count differs from its chain length**, for G47-19;
- **an ordinary reorderable subject reachable in `e2e/spacing-gesture.spec.ts`'s own fixture**, for G47-1's fourth press;
- **an `unequal-indent` pair — SYNTHETIC and unconditional** (measured at zero, §3.1).

⚠ **AND ONE SUBJECT THIS STORY DOES NOT OWE, SAID SO NOBODY AUTHORS IT TWICE: `no-sibling-in-this-copy` (G47-11d) is the ONE client-only refusal whose subject already SHIPS** — `lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, five flex-parented instances resolving 2/2/2/2/1 in default state.

**Two counts owed and not gettable from source**, both DOM reads: **(i)** the direct-child violation rate at parent scope — measured **0 of 601** by round 3, so this is now a *confirmation* rather than an unknown, re-run at the fixture set; **(ii)** nothing else: **D47-2's live prevalence is settled (§3.1).**

**And one DOC deliverable, placed FIRST so it cannot be lost:** route DR47-8 reading (a) back to **B-Q4's row in `docs/post-loop-backlog.md`** with the 2026-08-27 owner ruling recorded and **no phase number invented**.

The regenerated `.descvi/screens.json` diff **is** the deliverable. **Verification: `pnpm gates`.**

**S47-1 ∥ — the headless reorder model.** The chain walk; the drop table's two lifetimes and its resolved-members-only rule; the total hit-test; the scoped layout admissibility and its refusal branches; the reversal flip; no-op detection; the candidate/eligible split with term 5's two-reader predicate; the one-per-press rule; the terminal totality; the refusal map's engine-total shape plus its `undefined` arm and six client-only keys. **Verification: unit, jsdom-free.**

**S47-2 ∥ — the wire and the server composer.** The move-arm split; `expectDestination: {anchorOid, side}` REQUIRED-on-move / FORBIDDEN-elsewhere with its total parser and its self-anchor 400; the exported `resolveMoveDestination`; **the span-rearrangement primitive beside `swapSpans` and the ONE-SPLICE composer**; the direction-disagreement 400; the atomic abort; the applied-`k` echo; **an instrumented `parse` counter in the sidecar's test harness** so G47-20 can observe what §3.3 measured. **Verification: unit + the sidecar suite, plus the cost re-derivation against R47-4's threshold with the same controls (byte-equality against the naive fold, no-move, wrong-destination).**

**S47-3 — the gesture wiring and the guard.** `canvas/use-reorder-drag.ts`; the two shield edits; `setPointerCapture` on the stage; the terminal set **and the reorder guard's own teardown reset**; the request-gated latch; furniture suppression by `visibility` **with the instance hint's explicit re-declaration**; DR47-11's second guard, the `terminateActiveCanvasGesture()` wrapper and the migration of all 7 boundary sites — ⚠ **the brief must NAME THE WRAPPER'S MODULE, because `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#    if (rel === definitionFile) continue;` excludes the definition file, so a wrapper living in `resize-gesture-guard.ts` makes G47-14's scan return ZERO rather than "exactly one" (M9)**; the `POINTER_DRAG_THRESHOLD_PX` header correction; the `armTrailingClickSuppression` docstring correction; the §3.F preamble amendment including its two dead line pins. ⚠ The brief must require the implementer to state what the new predicate must NOT match. **Verification: jsdom for the wiring; a live `descvi:dev` smoke is REQUIRED.**

**S47-4 — the indicator, the readout and the refusal surface.** The three nodes at z 44, the readout clamped to the ring layer's rect and absent on a refusing arm; the `styleReadout` extraction with `tone`/`zIndex`/`accentPx` parameterised, **three** callers migrated, both `READOUT_ACCENT_PX` declarations left in place; the engine-total bilingual refusal map with its six client-only keys. **Verification: jsdom for structure and non-operability; Playwright for position; the owner for look.**

**S47-5 — `undo-focus-ownership`.** C47-6a and C47-6b, each with its own rows, and **C47-6b's own control on the panel value-commit path** (§4.6). **Verification: jsdom + `e2e/undo-cmdz.spec.ts`.**

**S47-6 — live coverage, the six ontology rows, the landing audit and the tracker section.** `e2e/reorder-drag.spec.ts` with its `spec-classes.json` declaration argued (§12); the §3.F-1 dispositions with their anchors; **the F46-D `readScene` grep as a named deliverable**; the whole-set audit **as this phase lands**; the tracker row.

⚠ **AND ONE CONSTRAINT S47-6 MUST READ BEFORE IT WRITES A SPEC (M10). On the design view, an in-page control cannot be activated by a click.** `shop/member-detail`'s three tab buttons drive a plain React `useState`; on :3001 three consecutive clicks produced **no state change** (oid counts 84/84/84) while the byte-identical script on :3000 produced 84/69/35. **The canvas selection shield claims the press.** A cross-host control ran first: 20/20 screens identical at default state. **This is not phase-47's defect and not phase-47's to fix, but it constrains how any Playwright spec drives in-page state on the design view** — a spec that needs a non-default page state must drive it on :3000, or reach the state without a click. ⚠ **Whether it deserves a `docs/known-issues.md` entry is a LEAD RULING, not this plan's** (§9.6).

---

## 6. Gates — each with a stated, CONSTRUCTIBLE RED-when and a NAMED subject

⚠ **Where a subject is SYNTHETIC it says so and S47-0 owes it.** That is not a weakness of the gate: the `unequal-indent` rider has carried it since r1, and round 3 showed that a gate claiming a shipped subject it does not have is worse — it reads as covered and cannot fire.

| id | What it pins | RED-when | subject |
|---|---|---|---|
| **G47-1** | The arm table over FOUR presses: `e2e/spacing-gesture.spec.ts#§3.9's THREE-ARM TABLE — a handle press is preventDefault-ed (ROW D)` already presses a strip, an `se` corner and the popup input; **a fourth press on an ordinary reorderable element must read `true` and still record travel.** | **Build DR47-1(a)**: hoist the reorder call above `suppressShieldPointer(e)` and early-return → the ordinary row flips to `false`. ⚠ **AND THAT HOIST ALSO KILLS TRAVEL RECORDING**, so *"every reorder behaviour stays green"* is false — the `defaultPrevented` bit is the discriminating leg and the travel leg fires too. ⚠ r0's mutation was **not constructible** (the call sits after `beginTravelRecording`). **Layer: e2e** — jsdom has no `PointerEvent` and no pointer capture. | **S47-0 (fourth-press fixture)** |
| **G47-2** | The stage background is unclaimed. | Drop candidate term 4 → both a stage-background drag and a `#dsh-screen`-but-not-`[data-oid]` drag arm. | shipped |
| **G47-3** | The threshold is the shipped symbol, consumed by the reorder classifier. | Edit `POINTER_DRAG_THRESHOLD_PX` to 40. ⚠ **Broadly RED** — it also moves two render floors, the travel guard and two other classifiers — so the reorder assertion is the **discriminating** leg. | shipped |
| **G47-4** | Capture on a STAGE host holds; the per-move geometry re-read follows the pointer off-frame. | Skip `setPointerCapture` → off-frame moves stop arriving and the last geometry read is stale. **The paired control §4.1(e) already measured: `pointerup = 0` without capture.** | shipped (measured) |
| **G47-5** | Reversal and wrap. | (i) Delete the `reversed` flip → the reverse row inverts. (ii) Replace the hit-test with a main-axis ordinal → the wrap row picks a first-line sibling. | reverse **SYNTHETIC** (§4.2(5)); wrap **shipped** (`lab/tests/align-wrap`, 2 subjects) |
| **G47-5b** | The hit-test is total: wrap-line gap; exact midpoint; equal distance; two overlapping rects. | (i) `>=` → `>` at the midpoint → the midpoint row flips side. (ii) source-chain tie-break → DOM order → the overlapping row picks the other sibling. (iii) point-to-rect → centre-distance → the wrap-line-gap row picks a sibling on the wrong line. | wrap **shipped** (2); overlap **shipped** (`shop/order-detail`'s `4jpxin`, 1); midpoint/equal-distance synthetic |
| **G47-5c** | The flow predicate is LIVE: a `md:flex-row` parent **below** `md` refuses, **above** `md` admits. | Replace `cs.display` with `directionSource === "unresolved"` → the below-`md` row admits and takes an axis from a `display: block` element. **The defect r0 shipped.** | **S47-0 (variant fixture)** |
| **G47-5d** | The modelled subset — **three independent legs**: an `rtl` flex row refuses; a `vertical-rl` flex row refuses; a chain with unequal child `order` refuses. All paint `layout-not-modelled`. | (i) Drop the `ltr` clause → the `rtl` subject admits and the drop lands mirrored. (ii) Drop the `writingMode` clause → the axis read is 90° wrong. (iii) Drop the `order`-equality clause → the source moves and **nothing on screen moves** — the failure with no visible symptom, which is why it needs its own leg. **Positive control: a plain LTR flex chain admits and reorders.** | **all three SYNTHETIC** — measured 0/930, 0/930, `order === "0"` on 930/930 (§4.2(3)) |
| **G47-6** | The indicator's rect lies strictly between the two siblings it names, overlaps neither, is perpendicular to the main axis. | Swap the destination gap for the subject's own → the rect overlaps the subject. Swap the axis → the orientation leg fires alone. | shipped |
| **G47-7** | Non-operability and the C46-0 partition for all three new nodes. | Set `pointerEvents` through a CLASS → the jsdom read returns `auto`. | shipped |
| **G47-7b** | The extraction changed nothing that ships: the three existing readouts' computed colour, border and `borderLeftWidth` byte-identical before and after; **both** `READOUT_ACCENT_PX` declarations survive. | (i) Drop `tone` and let a new node inherit the default → it ships **red**. (ii) Move either declaration into the extracted module → `spacing-readout-accent.test.ts` row (3) goes RED, which is that gate working. | shipped |
| **G47-8** | **ONE Cmd+Z takes a k-position drag all the way back.** 3 positions in a 5-member chain; page bytes byte-identical after one undo. | Issue k sequential requests instead of one → 2 of 3 steps remain and the journal shows k entries. **RED before green.** | **S47-0 (flex-col ≥5); flex-row ≥5 already ships** |
| **G47-9** | Atomicity: a drag crossing an `unequal-indent` pair writes nothing and returns that reason. | Move the rearrangement outside the pure arm → a partial write with a 422 returned. | **SYNTHETIC, unconditional** (measured 0) |
| **G47-10** | The destination receipt is verifiable: a stale `anchorOid` 409s rather than landing somewhere plausible. | Replace `{anchorOid, side}` with `steps: number` → the stale-chain row lands wrong and returns 200. | shipped |
| **G47-10b** | REQUIRED-or-FORBIDDEN: the field on a `delete`/`duplicate`/`insert-after` request is a **400**; its absence on a `move-up` is a **400**; **`anchorOid === the subject's oid` is a 400.** | Make the field optional → the first two rows stop being 400. Accept a self-anchor → the third returns 200 and writes nothing while reporting success. | shipped |
| **G47-11** | The refusal words: ko and en, no display value, no element as subject — **over the whole map including the generic arm.** | (i) ko only → the bilingual leg. (ii) Restore r1's generic arm (*"이 요소는 …"*) → the relationship leg fires **on the plan's own former text**. | shipped |
| **G47-11b** | E1's three-way split and the map's totality — four legs: a **22**-class subject paints `no-reorderable-sibling`; a **108**-class subject paints `sibling-not-editable`; a **62**-class subject paints the engine's own reason; an unmapped reason or `undefined` paints the position-fallback and never a raw code. | (i) **Fold the 108 into `no-reorderable-sibling`** → leg 2 fires with a sentence false of its subject. ⚠ *r1's version was green on the defect and on the correct behaviour alike.* (ii) Fold the 62 in → leg 3. (iii) Delete the fallback → leg 4 renders the kebab-case identifier. | shipped (all three classes) |
| **G47-11c** ⚠ **SUBJECT REPLACED (M5)** | `chain-member-not-locatable` fires on **ambiguity**: a member resolving to two nodes within one parent, and a member resolving to a deeper descendant. | Relax the join to "first match wins" → the two-node subject proceeds against an arbitrary box. Drop the direct-child clause → the descendant subject hands the hit-test a box that is not a flex item of the parent whose axis was read. | ⚠ **SYNTHETIC, and now cleanly so.** r2 named `wcall1…wcall4` and `wflbl3`/`wfval7`; **round 3 measured that neither fires** — the first cannot be pressed at all, the second resolves once as a direct child at parent scope, and both stated mutations change nothing on it; **round 4 independently reproduced 0 several-matches and 0 deeper-descendant readings at parent scope with a planted control that fires.** ⚠ **The fewer-than-two arm has LEFT this gate for G47-11d, where its subject is SHIPPED** — r3 filed it here and called the whole cell synthetic, which under-claimed the evidence. |
| **G47-11d** ⚠ **NEW (r4), AND ITS SUBJECT IS SHIPPED** | The sub-floor arm is INSTANCE-SCOPED and carries its own words. Two legs on one chain: pressing `d4b6s3` in **any of instances 0–3** admits and reorders; pressing it in **instance 4** paints `no-sibling-in-this-copy` — **not** `chain-member-not-locatable`, and **not** `no-reorderable-sibling`. | (i) Route the fewer-than-two case to `chain-member-not-locatable` → instance 4 tells the user the siblings could not be located when the sibling simply is not rendered there — the wrong relationship, wording rule 1. (ii) Route it to `no-reorderable-sibling` → the sentence claims no sibling exists in the parent, which is **false at source** (`d8m1w7` is a chain member with `prevOid: d4b6s3`). (iii) Restore r3's rule and refuse the whole chain when any member is missing → instances 0–3 stop admitting, which is the per-instance inconsistency (iii) exists to dissolve. | ⚠ **SHIPPED** — `src/app/lab/tests/shared-oid/page.tsx`'s `d4b6s3,d8m1w7`, default state, five flex-parented instances resolving **2/2/2/2/1**. Controls (round 4): remove the separator from instance 0 → `1,2,2,2,1`; plant one into the last → `1,2,2,2,2`. |
| **G47-12** | Two rows for two edits: **(a) after a panel value commit on the CHIP ADD-INPUT, `#dsh-stage` IS FOCUSED** (⚠ not "Cmd+Z undoes" — that passes on C47-6a alone); (b) `activeElement === document.body` + connected stage → Cmd+Z undoes; focus in a panel `<input>` → it does not. | (a) Site the call in the commit callback instead of the post-remount flush → `orphaned` is false and focus does not move. (b-i) Revert the ownership term → the body row fires. (b-ii) **Hoist the ownership check WITH its new term** above the text-entry guard → the input row fires. | shipped; ⚠ **row (a)'s subject is the CHIP ADD-INPUT specifically — the other two panel controls keep focus and `orphaned` is false forever there** |
| **G47-13** | The e2e declaration, in **both** directions the shipped gate asserts. | **(i)** add the spec with no class → `scripts/e2e-gate-cx1.mjs` is RED. **(ii)** declare it `neutral` while it needs the sidecar → the suppressed run fails it; declare it `ambient` with every row passing sidecar-free → the ambient side stops meaning anything. ⚠ **The gate is GREEN at HEAD** (round 2 ran it: 15 ambient / 2 solo / 7 neutral), so a wrong pick in this phase is what would turn it red. | shipped |
| **G47-14** | Every boundary consults BOTH gestures: `terminateActiveResizeGesture` has exactly ONE caller outside its own module, via `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#export function countCalls(source: string, name: string): number {`; and a live reorder drag is terminated by a panel className commit. | (i) Leave one of the 7 sites calling the resize guard directly → the caller-scan leg names the file. (ii) Do not register the reorder terminal → the drag survives the boundary. ⚠ **The scan EXCLUDES the definition file, so the wrapper must not live in `resize-gesture-guard.ts` or the leg returns zero and inverts (M9).** | shipped |
| **G47-15** | An armed drag that resolved to a NO-OP still selects. | Arm the latch on every armed drag → the click is swallowed and no selection happens. | shipped |
| **G47-16** | A drag on a `.map()`-body element reorders **all N rendered instances** from ONE request, and `#dsh-ring-instance-hint` stays visible. | (i) Assert only the first instance → the row cannot see a failed template propagation. **(ii) Delete the hint's explicit `visibility: visible` override** → the hint inherits the handle layer's hide and disappears. ⚠ **r2's mutation ("add the hint to the hidden set") was green on the defect and on the correct behaviour alike, because the hint is a CHILD of the layer already being hidden (M4).** | shipped (`smcell`/`smname`/`smtagg`, four instances) |
| **G47-17** | One arm per press over the `mousedown`/`pointerdown` pair. | Arm per event → two candidates, and the `mousedown`-derived one cannot express `setPointerCapture(e.pointerId)`. | shipped |
| **G47-18** | The drag subject — four rows: no selection → drag B moves and selects B; A selected → drag B moves B, selection ends on B; **A dirty → does NOT arm, behaves as an ordinary click**; subject retained across 200 / 409 / 422. | (i) Drop term 5 → the dirty row arms and the pending-edit seam is bypassed. (ii) Skip §4.1(c)'s synchronous switch → rows 1–2 move B while the panel and the handoff still read A. | shipped |
| **G47-18b** | **KI-46, executable.** Begin a className commit; before it resolves, attempt a reorder arm → it does not arm, and the in-flight write lands intact. | **Use `hasPendingEdits()` alone** → the arm succeeds inside the window, the synchronous selection switch moves `identityRef`, the commit's R1 guard drops the write, and **a committed token disappears silently.** | shipped |
| **G47-19** ⚠ **REBUILT (M6)** | The `n / N` readout reads both numbers from the **resolved chain members at parent scope**, never from a DOM sibling count and never document-wide. | (i) Read `N` from `parentEl.children.length` → fires on a flex parent with an element child that is not a chain member. (ii) Read `N` from a **document-wide** `querySelectorAll` over the chain's oids → fires on the `.map()` subject, **12 vs 3**. ⚠ **r2's version was not constructible: it read a ROW count and called it a chain length.** `smroww` is a **singleton** (`canMoveUp: false, canMoveDown: false`) and can never be a drag subject; at parent scope both of r2's named populations **agree** with the artifact (the `.map()` subject is 3 chain members in an `<li>` with exactly 3 element children; the `swallowed-oid` chain is 2 and 2). **The "opposite directions" argument is withdrawn.** | leg (ii) **shipped**; leg (i) **S47-0** |
| **G47-20** ⚠ **COUNTS CORRECTED (M3)** | The composer parses **twice** per request, whatever `k` is. | Restore the naive per-step fold → the parse count for k = 6 goes **2 → 12**. ⚠ **r2's "1 → 6" was wrong in both numbers: `swapSpans` ends on `reparseOrThrow`, so one `moveAdjacent` is TWO parses** — the timings confirm it arithmetically (`5.616 ≈ 2.628 + 0.233 + 2.911`) — **and a correct one-splice floor is 2, not 1, because a structural edit that skipped the defensive reparse would write unvalidated bytes.** The counts the gate discriminates are **2 for any correct request** and **2k for the naive fold**; **S47-2 ships the instrumented `parse` that observes them** (§5). | shipped |

**Standing obligation:** every gate is shown RED under its named mutation before it is believed green, and the RED is recorded in the tracker with the mutation beside it.

---

## 7. Risks, each paired with a MECHANISM

| id | Risk | Mechanism |
|---|---|---|
| **R47-1** | The new predicate on the ordinary arm matches more than it means to — the ONE failure class the record contains. | (i) **G47-5c, G47-5d, G47-2** are breadth assertions. (ii) The S47-3 brief requires the implementer to state **what the predicate must NOT match and which target class each existing arm claims**. (iii) G47-1's fourth press, with a constructible mutation. ⚠ The obligation attaches to the ordinary-arm call; the wrapper swap is mechanical and policed by G47-14. |
| **R47-2** | The client's chain is one edit stale. | The anchor receipt makes it a **409 with no write**; G47-10 substitutes the unverifiable alternative to prove it. |
| **R47-3** | The indicator promises a drop the server refuses. | ⚠ **The MECHANISM, not just the conclusion (M8):** the chain is built **only across links `adjacentOpUnit` already admitted**, and that function's docblock rules *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."* So **indent is the only move-only precondition a chain-derived destination can trip** — a lane tried `unsupported-sibling` and `non-canonical-separator` mid-chain and could not break it — **and `unequal-indent` is measured at zero.** The cost lands entirely on G47-9's synthetic fixture. |
| **R47-4** ⚠ **THRESHOLD RE-DERIVED (M2)** | The in-lock rearrangement stalls the sidecar. | k ≤ chainLength − 1 ≤ 6. ⚠ **r2's *"under 19 ms"* was unreachable by a CORRECT implementation of the design it was written to accept**: a correct k-swap fold's best case is **21.49 ms**, so the criterion would have fired on a correct build and returned the k = 1 clamp for a reason unrelated to the design's merit. *(It was also self-inconsistent: "closer to the floor than to the ceiling" is `< 18.92`, not `< 19`.)* **Under the one-splice shape (§4.3(4)) the floor an implementation can occupy is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ 7.5 ms.** **Pre-committed acceptance, written before the measurement so it can go RED: the k = 6 rearrangement must complete in under 12 ms on `src/app/shop/order-detail/page.tsx`'s 7-member chain `kh1mfx…thbzev` (**40,979 bytes**), or the design is re-opened.** ⚠ **THAT CHAIN IS A COMPOSER BENCHMARK, NOT A DRAGGABLE SUBJECT (r4)** — its parent computes `display: table` and refuses at E2 (§5), so the lane building the Playwright row must not assume it can be dragged. The criterion is a server-side measurement over source bytes and is unaffected. ⚠ **The threshold is met: round 4 built the one-splice composer and measured 6.803 ms — 1.76× headroom — with the naive fold (33.0 ms) and a correct k-swap (≈21 ms) both RED against it, and byte-exactness confirmed in both directions including an interior up-move (index 3 → 1), a direction no earlier round had tested.** ⚠ **The subject is named because these numbers are page-size dependent — the same three primitives read 0.662 / 1.490 / 9.041 ms on `shop/member-list` (9,656 B).** Controls: byte-equality against the naive fold, no-move, wrong-destination. G47-20 pins the parse count. |
| **R47-5** | The trailing-click latch has two producers. | Co-occurrence needs two simultaneous pointers (disjoint targets); bounded by the shipped unconditional drop-on-press. The docstring's precondition is corrected in S47-3. |
| **R47-6** | Widening Cmd+Z ownership to `document.body` intercepts a keystroke meant for something else. | The text-entry guard runs first and is untouched; `body` is unowned rather than outside the overlay. G47-12(b-ii) asserts the order, meaningful only because the `null` half was dropped. |
| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
| **R47-8** | One drag, N rows move, and the user is surprised. | §4.1(h) keeps `#dsh-ring-instance-hint` visible **through an explicit `visibility: visible` re-declaration**, because the hint is a child of the layer being hidden; G47-16(ii) is aimed at deleting that override. ⚠ **Without the override this risk had NO working mechanism (M4).** |
| **R47-9** | A boundary forgets the second guard call, or the teardown. | One wrapper, 7 sites migrated in S47-3's own commit, G47-14's caller-scan leg **with the wrapper's module named**; and the reorder guard's own teardown reset (§4.1(f)). |
| **R47-10** | The §3.F-1 amendments and the preamble go stale and no gate notices. | Six rows with dispositions, amended in the commit that makes them true; the two dead line pins converted; `check-citation-anchors.mjs` protects the new anchors; the S47-6 whole-set audit is the rest. **Stated as an uncovered surface rather than believed covered — and r2's own "still literally true" claim about the preamble is why (M7).** |
| **R47-11** ⚠ **RE-PRICED (round 3)** | The modelled subset is narrower than the corpus and users meet the refusal. | ⚠ **MEASURED AT ZERO in this corpus** — `rtl` 0/930, non-`horizontal-tb` 0/930, `order !== "0"` 0/930 (§4.2(3)) — so nothing is lost today, and the refusal names the panel as the working alternative. **What is UNMEASURED is whether that stays true as the corpus grows**, and the gate subjects are synthetic precisely so the clauses keep working when it does not. |

---


hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '195,228p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '229,280p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '281,342p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '343,414p' .omc/plans/ralplan-phase-47-drag-reorder.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
## 4. The design

### 4.1 Arming, ownership, subject and terminal (RULED — DR47-1, DR47-2, DR47-10, DR47-11 — C47-1)

**C47-1.** A headless `canvas/reorder-drag-machine.ts` and a wiring hook `canvas/use-reorder-drag.ts`; **two edits to `use-canvas-selection-shield.ts`** (§0). The arm table is unchanged in every arm.

**(a) CANDIDATE vs ELIGIBLE.** A press becomes a **CANDIDATE** iff: (1) it took the ordinary arm; (2) **no modifier at the press**; (3) the selection holds at most one member, read from the pinned mirror `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts#  const selectionRef = useRef<readonly SelectionMember[]>(EMPTY_SELECTION);`; (4) it resolves through the shield's own container-scoped resolution to a `[data-oid]` element inside `#dsh-screen`; (5) **the controller is SETTLED AND CLEAN** — the shipped two-reader predicate (§3.7). ⚠ Term 5 does not *guarantee* cleanliness; **it declines to arm in the window where the controller's confirmed string is stale**, which is where §4.1(c)'s synchronous selection switch would move `identityRef` under an in-flight commit and make its R1 guard **drop the write — a committed token disappearing silently.**

A candidate that crosses `packages/descvi/src/react/overlay/canvas/pointer-thresholds.ts#export const POINTER_DRAG_THRESHOLD_PX = 4;` becomes **ARMED**, and arming evaluates **ELIGIBILITY**; an ineligible arm **arms into a REFUSING state**.
- **E1 — a reorderable neighbour exists.** Failure splits three ways per §3.1: **22** → `no-reorderable-sibling`; **108** → `sibling-not-editable`; **62** → the engine's own reason through §4.5's total map.
- **E2 — the parent is a live flow container in the modelled subset** (§4.2(3)).
- **E3 — the drop table can be built** (§4.2(2)). **Failure splits two ways: AMBIGUITY → `chain-member-not-locatable`; FEWER THAN TWO RESOLVED MEMBERS IN THIS COPY → `no-sibling-in-this-copy` (r4).** ⚠ **E3 is the only one of the three that is INSTANCE-SCOPED** — E1 is a property of the source chain and E2 of the parent, while E3 is a property of *which rendered copy the user pressed*, and that is why its second arm's sentence names the copy.

⚠ **WHY NO SETTLEMENT BARRIER, stated because the sibling gesture has one.** `resize-gesture-guard.ts`'s `armed-pending` state exists because a resize gesture **captures a className baseline it will compose on**. A reorder gesture composes nothing from the className; its baseline is the structural one, re-derived server-side under the write lock. The barrier's purpose does not apply, and the interaction that remains — the arm-time selection switch against an in-flight commit — is what term 5 **declines** rather than awaits.

⚠ **What the new predicate must NOT match** (the S47-3 brief must have the implementer state it back): any target under `[data-dsh-handle]`; the stage background or any `#dsh-stage` descendant outside `#dsh-screen`; any node under `#dsh-ring-layer`; a press carrying any modifier.

**(b) THE MULTI-SELECT EXCLUSION — SUSTAINED ON THE CLICK ARM'S ORDER.** A press-time modifier read is legitimate for *arming*, a gesture-start question. The case phase-45's ruling exists for — Shift acquired between press and release — is covered twice and neither cover is that read: if the gesture issued a request the latch is armed and the click arm suppresses **before** the travel check; if it issued none, the travel check swallows it on `shiftKey && travel ≥ threshold`. At N > 1 the gesture never becomes a candidate.

**(c) THE SUBJECT.** At arming — synchronously — the machine switches the selection to the drag subject through the shipped `applySelection` path, so **subject ≡ `selectedTarget` by construction** and the post-save handoff is correct **without being changed**.

**(d) ONE ARM PER PRESS, AND THE `pointerId` PRECONDITION.** Idempotent over the `mousedown`/`pointerdown` pair on `pointerId`, in `beginTravelRecording`'s shape. A **precondition, not defence in depth**: `setPointerCapture(e.pointerId)` is not expressible from a `mousedown`.

**(e) CAPTURE ON `#dsh-stage` — MEASURED HERE, NOT INHERITED.** ⚠ **r0–r2 declined to claim phase-42's handle-host measurement for a stage host; round 3 measured the stage host directly.** Chromium 148.0.7778.96, headless and headed agreeing: dragging 500 px past all four edges and the corner, `pointermove` keeps arriving, `pointerup` arrives at the off-frame coordinate with `pointerId 1`, `target === #dsh-stage`, capture still held, and **`pointercancel` 0 in 15 drags**. **The paired control is what makes it evidence: same host, same listeners, capture removed → `outsideViewport = 0` and `pointerup = 0`.** ⚠ **Two limitations carried verbatim: CDP input always targets the page, so this measures the browser honouring off-viewport coordinates and NOT the OS handing the pointer to another application; and only Chromium was measured** — Firefox and WebKit are not in this repo's Playwright cache and its e2e is Chromium-only.

**(f) THE TERMINAL** is one idempotent transition over: `pointerup`, `pointercancel`, `Escape` at `document` capture, **the shared active-drag guard's consultation** (DR47-11 — what delivers "selection change"), screen change, edit-mode off, and **unmount**; its final act returns the machine to `idle`. ⚠ **UNMOUNT IS A SEPARATE OBLIGATION FROM THE 7 BOUNDARY CALLS (M9):** the reorder guard needs its own `reset…()` counterpart to `resetResizeGestureGuard()`, which drops the registration and clears the latch after an unmount mid-gesture — and that module's docblock states why `terminate()` cannot be it (*"a teardown that left one behind would hand the next mount"* a live gesture nobody is performing). **S47-3 ships it.** ⚠ A modifier acquired **mid-gesture does not abort**: aborting would make the outcome depend on a key state whose effect is invisible until release, and the meanings it would defer to are deferred-v2/v4 and unimplemented.

**(g) THE LATCH IS ARMED ONLY ON A TERMINAL THAT ISSUED A REQUEST.** Arming on every armed drag composes with §4.2(6)'s no-op detection into a live regression: a 5 px out-and-back on a reorderable element would suppress a selection that happens today, across the majority of the canvas. **G47-15 is the row; §8 U3 carries the harm.**

**(h) FURNITURE DURING THE DRAG — `visibility`, never unmount, WITH ONE EXPLICIT RE-DECLARATION.** Hidden for the duration and restored at the terminal: `#dsh-hover-ring`, `#dsh-selection-ring`, `#dsh-selection-ring-pool`, `#dsh-selection-badge`, `#dsh-handle-layer`, `#dsh-spacing-layer`.
⚠ **`#dsh-ring-instance-hint` IS A CHILD OF `#dsh-handle-layer` AND `visibility` INHERITS (§3.8), SO r2's RULE HID THE VERY NODE IT SAID IT KEPT (M4).** R47-8's only mechanism was inoperative and G47-16 leg (ii) was green on the defect and on the correct behaviour alike. **The fix is an explicit `visibility: visible` re-declaration on the hint, named here in C47-1**, and G47-16(ii) is re-aimed at deleting that override. The two other readouts in that layer — `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint` — are **left to inherit the hide**, which is what we want.
⚠ **The hiding is `visibility: hidden`, never removal**, because `e2e/resize-handles.spec.ts#    const handleLayerEl = document.getElementById("dsh-handle-layer") ?? layerEl;` falls back precisely when that node is **absent**; an unmount would make phase-47 the first runtime mechanism that makes a never-fired fallback reachable. **§9.5's F46-D disposition rests on this mechanism.**
⚠ UNVERIFIED whether hiding reads better than leaving it (§8 U4) — and §4.4 no longer depends on the answer.

### 4.2 The drop resolution (RULED — DR47-5, DR47-6 — C47-2)

**C47-2.** The **ORDER half is built once at arm; the GEOMETRY half is re-read per move** (rects change under `#dsh-screen` scroll, window resize and reflow), which is what G47-4's *"the last reading is stale"* refers to.

1. **ORDER — from the artifact, once.** Walk `prevOid` to the head and `nextOid` to the tail. No DOM.
2. **GEOMETRY — from the DOM, per move, parent-scoped, and RESOLVED-MEMBERS-ONLY.** Search `subjectEl.parentElement`'s children for each chain oid. A member must resolve to **at most one element, and to a DIRECT CHILD** of that node. Then:
   - **a member resolving to ZERO nodes is DROPPED from the table, not a refusal;**
   - **`chain-member-not-locatable` refuses the whole gesture** on AMBIGUITY only — when the **subject itself** does not resolve, when a member resolves to **more than one** node in that parent, or when a member resolves to a **deeper descendant**;
   - ⚠ **and when FEWER THAN TWO members resolve, the refusal is a DIFFERENT key — `no-sibling-in-this-copy` — because nothing failed to be found (r4).** A run of one is a well-defined *nothing here to trade places with* state, and it is **INSTANCE-SCOPED**: the same chain in the copy next door has two. Routing it through `chain-member-not-locatable` would tell the user the siblings could not be located when the sibling simply is not rendered here — the wrong relationship, which is wording rule 1's own failure.

   ⚠ **THE DROP-ON-ABSENCE RULE IS A r3 RULING, AND IT IS AVAILABLE ONLY BECAUSE OF DR47-4(f).** Round 3 measured that r2's require-every-member rule refuses on a population the plan never named: **the artifact links mutually-exclusive `{cond && <el/>}` siblings into ONE chain** — §3.2's parenthetical, load-bearing at last. Measured over 235 chains: **6 refused in every observed state (2.6 %), 9 refused only in SOME observations (3.8 %), 1 never renders at all (0.4 %), 219 never refused (93.2 %).** The clearest **at source** is `sandbox/resize-repeat-list`, whose `smndaa`/`smndbb`/`smndcc` are three `{queueState === 'x' && <p/>}` blocks inside the 5-member chain `[smlist, smndaa, smndbb, smndcc, smlnkk]` — each an `opUnitKind: 'conditional-container'`, exactly one rendering per state. ⚠ **It is NOT a draggable subject and the sentence must not read as though it were (r4): that chain's parent computes `block`, so it refuses at E2 before any of this is reached.** The same source shape appears in `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`. **The draggable instance of this class is `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` (flex-parented in all five copies), and it is the one the gates use.**
   ⚠ **THE 9 "SOMETIMES" CHAINS ARE THE HALF THAT FORCED A RULING RATHER THAN A SENTENCE: under r2's rule the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed** — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, the **first** missing `rpb6hb` and the other five complete, giving 55 passing scopes and 11 refusing. **A per-instance verdict on a per-chain contract, and no refusal wording survives a user who just did the same drag successfully one column over.** **Options: (i) accept the per-instance verdict and word around it; (ii) refuse the chain everywhere it can ever be incomplete — not decidable client-side, since it requires knowing every state; (iii) DROP unrendered members from the table and refuse only on ambiguity or on fewer than two survivors. RULED (iii).** It costs nothing, because **the anchor receipt never computes an index** — the client names a rendered sibling and a side, and the server resolves it against the live source chain, which still contains the unrendered member. The only consequence is that a user cannot drop *between* two positions separated solely by unrendered members, which is invisible to them.
   ⚠ **AND r3's CLOSING SENTENCE FOR THIS RULING WAS FALSE ON A SHIPPED SUBJECT — MEASURED IN DEFAULT STATE, AND THE CORRECTION IS r4's ONE BLOCKING EDIT.** r3 wrote *"under (iii) all 15 chains admit in every instance, and the per-instance inconsistency does not exist."* **It does not, for a 2-member chain whose one sibling is conditional.** `src/app/lab/tests/shared-oid/page.tsx`'s chain `d4b6s3,d8m1w7` resolves **2 / 2 / 2 / 2 / 1 across five instances, all five parents flex** — the separator `src/app/lab/tests/shared-oid/page.tsx#{i < arr.length - 1 && <span data-oid="d8m1w7"` is conditional on not being last, so the fifth `<li>` renders one member and falls below (iii)'s own floor **while every arming precondition holds**: term 4 passes (`d4b6s3` renders in all five), E1 passes (`canMoveUp: false, canMoveDown: true`, verified in the map), E2 passes. **The user drags the last step label, is refused, drags the identical label one column left, and it works** — verbatim the sentence this paragraph uses to reject option (i). Controls: removing the separator from instance 0 gives `1,2,2,2,1`; planting one into the last gives `1,2,2,2,2`, so the detector both produces a 1 from a change and erases the observed 1.
   ⚠ **THE ROOT CAUSE IS THIS PHASE'S RECURRING SHAPE AND IS WORTH NAMING: the ruling was derived from the right measurement and validated against the population it was derived FROM** — chains where *some* member goes missing — **never against chains where ENOUGH go missing to fall below its own floor. For a 2-member chain with one conditional sibling those are the same event.**
   **RULED (r4): (iii) STANDS — it is correct on its merits and it genuinely dissolves the refusal wherever two survivors remain. What changes is that the sub-floor case gets its OWN key** (the bullet above), whose sentence names the *copy* rather than the parent, so it survives the user who just succeeded one column over — and predicts it. **Its gate leg is G47-11d and its subject is SHIPPED, not synthetic.**
   ⚠ **THE `.map()` ATTRIBUTION r1 AND r2 GAVE THE "SEVERAL MATCHES" ARM IS WITHDRAWN — MEASURED WRONG, AND WRONG BECAUSE OF A SCOPE THE PLAN ITSELF SPECIFIED.** `.map()` bodies produce **52 many-node readings across 20 chains at PARTITION scope, and 0 at the PARENT scope §4.2(2) uses**, because each repeat renders under its own parent: `smcell`/`smname`/`smtagg` resolve once per `<li>`, all direct children, under a `flex flex-row` parent. **0 of 636 member readings hit the several-matches arm.**
   ⚠ **THE DIRECT-CHILD CLAUSE HAS ZERO SUBJECTS TOO** — 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — **with a planted control (`C-B` wrapped a member in a fresh `<div>` and the analyzer reported it immediately)**. ⚠ **AND r2's ATTRIBUTION OF IT TO `wflbl3` IS FACTUALLY WRONG AND IS DELETED: `wflbl3` is a DIRECT CHILD of its own `Field` wrapper** (`src/app/lab/challenge/swallowed-oid/page.tsx#    <div className="flex flex-col gap-0.5 bg-white px-3 py-2 border border-neutral-300 rounded-md">`), so it passes both clauses. The one prop-swallowing component in the repo produces the **opposite** failure: `Field`'s *exterior* oids (`wcall1…wcall4`) reach no node and are caught by the zero-match arm — and under ruling (iii) that is a DROP, not a refusal, and in any case **`wcall1…wcall4` cannot be pressed at all** (term 4 requires the press to resolve to a `[data-oid]` element; they have zero DOM nodes in every state, the only such chain in the corpus, and their parent `wgrid1` is `grid`, so E2 would refuse first).
   **Both clauses are KEPT and both are cheap: each prevents a real failure the browser can produce, and the control proves a detector can see it. What they lose is the claim to a shipped subject — their gate subjects are SYNTHETIC and owed by S47-0**, on the `unequal-indent` rider's model.
3. **FLOW, AXIS, REVERSAL — one `getComputedStyle(parentEl)` plus one per resolved member.** Admit iff: `cs.display` is `flex` or `inline-flex` (⚠ **the predicate, not `directionSource === "unresolved"`**, which §3.4 shows a `md:flex-row` parent below `md` never reaches; ⚠ `display: contents` is therefore refused — **ruled, not missed**, since a `contents` parent lays out nothing itself); `cs.direction === "ltr"`; `cs.writingMode === "horizontal-tb"`; and every resolved member's computed `order` equal. Then **axis** = `cs.flexDirection.startsWith("row") ? "row" : "col"`, **reversed** = `cs.flexDirection.endsWith("-reverse")`.
   ⚠ **The three exclusions are correct about the browser (§3.4) and have ZERO SUBJECTS in this corpus** (round 3, each with a planted control returning the planted value): `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930**. **They stay, their subjects are synthetic and owed by S47-0.**
4. **HIT-TEST — the total algorithm.** Over the rects `R` of all **resolved** members including the subject's own: `S = argmin` of the **squared point-to-rect distance** (0 inside a rect); **inside more than one rect** → the member **earliest in source-chain order**; **exact ties at equal distance** (a midpoint, a wrap-line gap) → the same rule, **one tie-break in the design, not two**; **`side`** by projecting onto `S`'s main-axis extent against its midpoint, `< mid ⇒ leading`, `>= mid ⇒ trailing`.
   ⚠ **THE COORDINATES COME FROM THE EVENT AND THE RECTS, NEVER FROM `e.target` — AND THE WRONG IMPLEMENTATION IS THE OBVIOUS ONE (round 3).** Under pointer capture, `e.target` is `#dsh-stage` for **every** event from the first move onward, while `document.elementFromPoint` keeps resolving the real element and returns `null` off-frame. **A hit-test reading `e.target` mid-drag gets the stage and nothing else.** This algorithm reads neither and is unaffected — stated because the failure is silent.
   ⚠ **Tie-break subjects are small but NOT zero (round 3, and the corrected wrap count):** **wrap has 2 subjects**, both in `lab/tests/align-wrap` and both genuinely two-line — ⚠ *the lane's first detector counted distinct cross-axis offsets and reported 37 wrapped parents; an `items-center` row with unequal-height children produces that without wrapping, and the corrected count of wrapped parents is 3* — and **overlap has 1**, `shop/order-detail`'s `4jpxin`, a 2 px step-connector over a step marker, the only one of three overlaps whose parent is flex. ⚠ **Both counts are viewport-dependent and were measured at one viewport.**
5. **VISUAL → SOURCE.** `sourceSide = reversed ? flip(side) : side`. The result is `(anchorOid = S, side = sourceSide)` — **which is the wire receipt itself**, so no conversion step exists. ⚠ **The `reversed` branch has ZERO SUBJECTS: three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1), but none of their children carries a `data-oid`, so none can be a chain member.** Clause kept, subject synthetic and owed by S47-0.
6. **NO-OP DETECTION — OVER SOURCE POSITION, RULED (r4).** A destination equal to the subject's current **source** position issues no request and, per §4.1(g), arms no latch. ⚠ **r3's sentence named no order-space, and once members can be dropped the two spaces differ**: with source `[A, B_unrendered, C, D]` rendering as `[A, C, D]`, dragging `A` to leading-of-`C` makes the source `[B, A, C, D]` **and the render does not change.** **Source is the right space** — it is what the write acts on, what the receipt addresses and what the undo entry restores; a render-space check would refuse a reordering the user actually expressed.
   ⚠ **The residual is STATED rather than prevented: a source-effective, render-inert drag issues a real request, consumes an undo slot and arms the latch.** The user sees nothing move and one Cmd+Z is owed. ⚠ **A FLEX-PARENTED SUBJECT DOES CONSTRUCT IT TODAY, AND r4's CLAIM THAT NONE COULD IS FALSE (r5, measured live at 1440×900).** On `/shop/member-detail`'s **benefits tab**, the chain `omy3i9,0cyt4v,z76fvu,d29ipo` under `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` renders **two copies, n = 4 and n = 3** — the short one missing `z76fvu`, an **INTERIOR** member, because that node is guarded by `src/app/shop/member-detail/page.tsx#                        {b.value > 0 && (` and `INITIAL_BENEFITS`' `b002` carries `value: 0`. `0cyt4v` reads `canMoveUp: true, canMoveDown: true` with an empty `reasons` map (verified in the map this lane built), E2 is flex/row and E3 passes at 3 ≥ 2. **Drag `0cyt4v` to leading-of-`d29ipo`: source index 1 → 2, the source-space no-op check does not fire, and the render does not change.** Controls in the same session: `pk9pwr`, `scroot`, `srroot`, `smroot` → `block/row`; `grpeul` → `table/row`; `smroww`, `xufjus` → `flex/row`; **and r4's own cited counter-subject `ww57qb` reproduces as `block/row` — the reading was never in dispute, the SWEEP was.** ⚠ **HOW IT WAS MISSED IS THE FINDING'S REAL CONTENT: the r4 lane went into tab space to read `ww57qb` on the memo tab and did not check the benefits tab one click away. That is pre-mortem 4's shape, recurring INSIDE the edit that documents pre-mortem 4.** **What actually contains the residual is narrower and is named as such: the benefits tab is a plain `useState` an in-page click cannot drive on the design view (§5's M10 constraint), so the copy that constructs it is not reachable on :3001 by clicking.** ⚠ **AND THAT MAKES §9.6's KI RULING LOAD-BEARING RATHER THAN A NOTE: the only thing containing this residual is a defect this plan itself calls *"not phase-47's to fix"* — one anyone may fix at any time, silently re-opening it.** A containment a future bugfix removes is not a containment; it is a dependency, and it is recorded here as one.
   ⚠ **AND ONE EDGE THE RULE DOES NOT COVER, NAMED RATHER THAN LEFT TO DISCOVERY: when the unrendered member is FIRST, the user cannot express *"make this the first child"* at all**, because the anchor receipt names a rendered sibling and there is none leading of the first rendered one. The gesture is not wrong there; it is simply mute, and the panel's ↑ still reaches that position.
7. **THE MULTI-INSTANCE CONSEQUENCE.** A drag on a `.map()`-body element edits the TEMPLATE, so every rendered instance reorders at once — **G47-16 is the row**, and §4.1(h) keeps the instance hint visible for it.

### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)

**C47-3.** `target: 'structure'`, verb `move-up`/`move-down` by the sign of the source-order displacement, unchanged `expect` for the ORIGIN, plus **`expectDestination: { anchorOid, side }`**, **REQUIRED on the two move verbs and FORBIDDEN on the other four**, with a total switch beside the shipped `parseExpectForOp`. **Both producers can construct it**, so §2's "does NOT touch" list needs no exception.

⚠ **THE UNION SPLIT IS BY BASELINE ON THE SERVER AND BY PAYLOAD ON THE CLIENT.** `packages/descvi/src/sidecar/server.ts#export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;` carries **all five** ops, so splitting the moves off the server's baselined arm leaves **`{delete, duplicate, insert-after}`**; the client's `packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export type PayloadFreeStructureOp = Exclude<StructureOp, 'insert-after' | 'insert-child'>;` leaves **`{delete, duplicate}`**.

Server, inside `computeStructuralEdit`'s move arm, under the write lock:
1. resolve the op-unit and re-derive the live origin baseline; mismatch ⇒ `stale-baseline` (409);
2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
4. **rearrange in ONE SPLICE (M1).** Read every member's span from **one** `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. ⚠ **This is not the k-swap loop r2 specified: that shape does not run, and the repo had already written the lesson down in this very file** — `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` **S47-2 therefore owes a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** ⚠ *r2's clause "`expect` consulted on the first step only" dies with the steps: there is one step.*
5. a typed refusal aborts `prepare`, so **nothing is written**, and the 422 carries that reason. ⚠ **The k-swap shape failed with `span-sentinel-failed`, an INTERNAL error this clause does not catch — recorded because it is why the shape had to change rather than be guarded**;
6. one journal push, subject unchanged; `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string | null {` needs no new arm;
7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.

⚠ **`parentOid: null` CHAINS ARE ADMITTED, AND SAYING SO IS A RULING (M9).** `wflbl3`/`wfval7` carry it — they are declared in a helper outside the default export, so the extractor records no oid-bearing parent — and they are **pressable, admissible, flex-parented** subjects (their DOM parent is `flex flex-col`). **`parentOid` is not consulted by this design at all**: order comes from `prev`/`next`, geometry from `subjectEl.parentElement`. The server's own chain re-derivation is likewise positional. **Nothing special is owed; the case is recorded so an implementer does not add a `parentOid !== null` guard that would refuse a working subject.**

**ONE Cmd+Z AFTER A 4-POSITION DRAG TAKES THE ELEMENT BACK FOUR POSITIONS** — one request, one entry, one undo, byte-exact from the entry's whole-file `before` bytes.

⚠ **The anchor receipt is slightly more permissive than a gap receipt, and that is a property.** A gap receipt refuses when either neighbour changed; an anchor receipt names **the element the user aimed at**, so a concurrent edit elsewhere in the chain **re-targets rather than refuses**. The origin `expect` still refuses any change to the subject's own position, and the receipt is still a COORDINATE rather than a count — **G47-10's argument is unchanged.**

**Why this is not a new write class — the enumeration is the argument.** No new `StructuralOp` member, no new wire verb, no new journal arm, no new `reselectTargetFor` arm, no new `REASON_TEXT` key. ⚠ *(r0's appeal to `structural-edit.ts`'s header sentence was withdrawn in round 1: it names one class contrasted with literal replacement and carries no taxonomy.)*

### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)

**C47-4.** Three new nodes in `#dsh-ring-layer`, all **readouts by role**: no `data-dsh-handle`, no `data-v3-glyph-control`, `pointerEvents = "none"` set **inline** (a class-only rule reads back `auto` in jsdom and the gate could not go RED).

- **`#dsh-reorder-indicator`** — the blue insertion line, in the destination gap, spanning the cross-axis extent of the **resolved** members, perpendicular to the main axis.
- **`#dsh-reorder-readout`** — **the DROP POSITION `n / N`**, per the owner's ruling. ⚠ **`N` is the count of RESOLVED members and `n` the subject's 1-based position among them — deliberately the count the user can see, not the source chain length**, which §4.2(2)'s drop-on-absence ruling makes differ whenever a conditional sibling is not rendering. Showing a total the user cannot count would be the readout's own version of KI-17.
  ⚠ **AND THE CONSEQUENCE THAT RULING CARRIES MUST BE STATED, BECAUSE r3 RULED IT AND DID NOT (r4): `n / N` IS INSTANCE-LOCAL.** Measured on the chain this plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`, six step columns, per-instance **`2/3/3/3/3/3` — in DOCUMENT order, and the SHORT one is the FIRST** (⚠ *r4 wrote `3/3/3/3/3/2`, which reads positional and is wrong in order; the connector `src/app/shop/order-detail/page.tsx#                  <div data-oid="rpb6hb"` sits under an `{i > 0 && (` guard, so column 0 is the one that lacks it, and a lane building the U9 material from the sixth column would conclude the effect does not exist*), all flex — **every column admits** (ruling (iii) works there), and the readout then shows `n / 3` in five columns and **`n / 2` in the **first**, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16). **The per-instance inconsistency was not dissolved; it was relocated out of the refusal and into the readout by the consequence ruled in the same paragraph.** Stated plainly: **`n / N` describes neither the source order the edit acts on** — in column 0, `5s41w1` reads `2 / 2` while being source index **3 of 3** on the same 1-based reading §4.4 defines `n` by — **nor the scope of the edit**, which is every instance. The affordance that carries the scope is `#dsh-ring-instance-hint`, which §4.1(h) keeps visible for exactly this reason.
  ⚠ **The KI-17 argument for showing what the user can count still holds, so the ruling stands — but the readout's SEMANTICS are ground the owner personally ruled, so they are routed rather than settled here: §8 U9.**
- **`#dsh-reorder-refusal`** — §4.5's sentence. ⚠ **On a refusing arm the DROP-POSITION readout is ABSENT (M9), not blanked**: there is no position to report, and a `0 / 0` would be a number about nothing.

⚠ **THE READOUT AND THE REFUSAL ARE TWO NODES, NOT ONE RE-STYLED NODE.** They are mutually exclusive in time, and re-styling one node per paint means re-running the `border` shorthand, which resets all four sides and wipes the accent — the trap `use-spacing-drag.ts`'s own comment warns about.

⚠ **THE READOUT IS CLIPPED AT THE FRAME EDGE, AND THAT IS RULED HERE RATHER THAN LEFT TO U1 (M9).** `#dsh-ring-layer` carries `overflow-hidden` (§3.8). **The readout is therefore CLAMPED to the layer's rect rather than following the pointer past it** — it stops at the edge and stays legible, which is what phase-42's own refusal marker does when it flips above rather than clamping off-screen. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too, and this is the answer.

**Z: all three take `zIndex = 44`**, matching the shipped drag readout (§3.8), with the popup above at 45. ⚠ *r2 briefly moved them to 41 on two false premises — that 41 is "the readout family's own" z (it is the STACK family's) and that §4.1(h)'s hiding replaces the need for a z privilege (that is U4, settled after the story that ships the indicator).* **Ordering among the three at equal z is by DOM order**, the repo's own precedent — and nearly moot, since the readout and the refusal never coexist.

**THE `styleReadout` EXTRACTION, WITH ALL FOUR COSTS PAID.** It takes **`tone`, `zIndex` AND `accentPx`** as parameters — ⚠ `accentPx` is a parameter and not an import, because `READOUT_ACCENT_PX` is module-private in **both** files and importing from either would create a cycle; **neither declaration moves**, because the shipped regex gate requires both and requires the spacing copy to survive. **`use-resize-handles.ts`'s THREE call sites** migrate in the same commit. Placement is pointer-relative and clamped, never `layoutReadouts`'.

⚠ Colour, weight, inset and the gap convention are NOT settleable here (§8 U1/U2); G47-6 asserts only a property.

### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)

**C47-5.** A total `Record<StructuralRefusalReason, BilingualMessage>` rendered through `packages/descvi/src/react/overlay/shared/refusal-messages.ts#export function bilingualLine(message: BilingualMessage): string {`, **plus an `undefined` arm** (required by the producer's type; measured at zero occurrences today — §3.1), **plus the client-only set: SIX KEYS OVER THREE CONDITIONS** — E1, E2 and E3, exactly as §4.1(a) enumerates them. ⚠ *(The count has been spelled four different ways across r2 and r3 — "three conditions" over a five-row table, then "four conditions, five keys" derivable under no consistent reading. It is stated ONCE, here, and §4.1(a), the table below and §12 are the three sites that must agree with it. r4's new key makes it six.)*

**Engine-keyed rows** (counts are **refusal** counts over `move-up`/`move-down` across `src/app` — §3.1):

| key | ko | en |
|---|---|---|
| `no-adjacent-sibling` (541) | 이 방향에 **형제 요소가 없습니다.** | **There is no sibling in that direction.** |
| `unsupported-sibling` (189 = 165 arm-time + 24 fold-step) | 옆에 있는 요소가 **편집할 수 있는 단위가 아닙니다** — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit** — something invisible, such as a comment, may sit between them. |
| `unsupported-parent` (52) | **부모가 순서 편집을 지원하는 형태가 아닙니다.** | **The parent is not a shape that supports reordering.** |
| `target-bears-data-screen` (48) | **화면 경계는 순서를 바꿀 수 있는 자리가 아닙니다.** | **A screen boundary is not a position that can be reordered.** |
| `unsupported-container` (18) | **감싸고 있는 조건부 묶음이 지원되는 형태가 아닙니다.** | **The conditional wrapper around it is not a supported shape.** |
| `non-canonical-separator` (6) | **형제 요소 사이 간격이 편집 가능한 형태가 아닙니다.** | **The spacing between the siblings is not in an editable form.** |
| `unequal-indent` (0 — R47-3) | 지나가야 하는 형제 요소와 **들여쓰기가 달라** 이동할 수 없습니다. | The move is blocked because **a sibling it must pass has a different indent**. |
| every remaining engine reason, and `undefined` | **이 위치에서는 순서를 바꿀 수 없습니다.** | **Reordering is not available at this position.** |

⚠ **`unsupported-sibling`'s WORDING MUST BE TRUE AT BOTH MOMENTS, AND r2 FIXED ONLY ONE (M9).** R1 scoped it to *"a step of the fold"* and worded it *"a sibling it must pass"*; r2 corrected the scope to arm-time. **Measured, it is both: 165 arm-time and 24 fold-step** — and **the 24 genuinely ARE the "a sibling it must pass" case.** The row above names the **relationship** (the neighbour is not an editable unit) rather than a traversal, which is true at both, and its second clause names what the user cannot see — §3.1's driven JSX-comment cause is the evidence.

⚠ **The generic arm names the POSITION, not the element.** R1's read *"이 요소는 … / This element cannot be reordered here"* — the element as subject, differing from rule 1's own counterexample by one word, so G47-11 leg (ii) fired on the plan's own text. The three largest causes (52 + 48 + 18 = 118 refusals) now have relationship-naming sentences of their own.

**The client-only set — three conditions, six keys:**

| key | condition | ko | en |
|---|---|---|---|
| `no-reorderable-sibling` | E1, the **22** | 같은 부모 안에 **순서를 바꿀 형제 요소가 없습니다.** | There is **no sibling to reorder with** inside this parent. |
| `sibling-not-editable` | E1, the **108** | 옆에 있는 요소가 **편집할 수 있는 단위가 아니라** 순서를 바꿀 수 없습니다 — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit**, so the order cannot be changed — something invisible, such as a comment, may sit between them. |
| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |

⚠ Two of these name the panel as the working alternative deliberately: the flow-axis refusal is a GESTURE policy, not a write constraint, so telling the user the buttons still work is the true and actionable sentence.

⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**

**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.

**Where each is shown.** E1, E2 and E3 are known at arm time (E3 at the first geometry read): the gesture arms into a refusing state, paints `#dsh-reorder-refusal`, draws no indicator, shows no drop-position readout, and issues nothing. Step-refusals arrive as the 422's typed reason after release.

⚠ **The indicator can therefore be shown for a destination the server refuses — and R47-3 explains why that is safe rather than merely asserting it (M8).** `unequal-indent` is the only move-only precondition a chain-derived destination can trip, **and the mechanism is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."*** Because the chain is built **only across links `adjacentOpUnit` already admitted**, every other move-only condition was already satisfied when the link was made. A lane tried to break this with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. **And `unequal-indent` is measured at zero, so the cost lands entirely on G47-9's synthetic fixture.**

### 4.6 `undo-focus-ownership` — ONE fix and ONE placement improvement (RULED — DR47-9 — C47-6)

⚠ **NAMING NOTE, RECORDED BECAUSE PER-COMMIT BRIEFS CITE CONTRACT IDS VERBATIM (M9): C47-6a and C47-6b SWAPPED MEANINGS BETWEEN r1 AND r2.** In r1, `a` was the `focusStageIfOrphaned` call and `b` the ownership widening; from r2 onward `a` is the ownership widening (the fix) and `b` the focus placement. **A brief drafted against r1 would build the other thing.** The r3 meanings are below and are final.

**C47-6a — THE FIX, and it closes BOTH dead windows on its own.** `document.body` counts as owned in the Cmd+Z keydown effect. The backlog row names `document.body` as the mechanism for both windows. ⚠ **The `null` half is DROPPED**: `packages/descvi/src/react/overlay/OverlayShell.tsx#      if (!(active instanceof Element)) return;` bails on `null` two guards above ownership and **above** the text-entry guard, so implementing it would mean moving an early return past that guard — the exact shape G47-12 exists to police, inside the fix. **`stageRef.current?.isConnected` is NOT re-checked**; it is proven one line above.

**C47-6b — THE PLACEMENT IMPROVEMENT, and it is NOT what restores Cmd+Z.** It calls `focusStageIfOrphaned` after a panel value commit so the canvas keyboard surface is live again. ⚠ **It must land on the flush AFTER the `key={value}` remount**, because in the commit callback the ticket element is still connected and focused, `orphaned` is false, and the call does nothing.

⚠ **THE CONTROL AND THE REACH, both stated precisely (M9).** The physics — *"the remount lands on a LATER flush than this callback"* — is measured in `focusStageIfOwned`'s three-row table, **which measured the canvas-click ticket-restore path, not the panel value-commit flush**. The physics generalises; **calling that table "the control" for this claim over-claims by one call path, so it is named as the EVIDENCE and S47-5 owes the control on its own path.** And the reach is one control of three: `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever there — **which is correct, not a gap**, because focus staying in a text field is where Cmd+Z should reach the field's own undo. **C47-6b is reachable only on the chip add-input and the `key={value}` numeric value fields, and G47-12 row (a) names the chip add-input as its subject.**

### 4.7 The ontology rows, and what no gate watches (RULED — C47-7)

**C47-7.** `.omc/specs/interaction-ontology.md` §3.F-1 has **six** rows; all six get a disposition, because no gate watches them:

| §3.F-1 row | disposition |
|---|---|
| element in flex parent, within-parent | **SHIPPED at phase-47**, with an anchor into the composer — **and the row states the modelled subset** (LTR, horizontal writing mode, equal `order`), because an unqualified SHIPPED is the false half of the browser falsification written into the register |
| element in flex parent, cross-parent | unchanged `deferred-v2 (hard)` |
| element in non-flex parent | **the gate this phase clarifies** — flips to a REFUSAL row naming `parent-has-no-flow-axis`; *"undefined blue-line; clarify at gate"* is discharged |
| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
| selection box (drag the selection) | **SHIPS**; its own cell already says *"== dragging the node"*, and §4.1(c) makes subject ≡ selection at arm time |
| stage background (empty) | unchanged — §2 exclusion 2, G47-2 keeps it so |

⚠ **AND THE SWEEP DISCIPLINE THIS SECTION DEPENDS ON GETS ITS LESSON RECORDED HERE, BECAUSE IT IS NOW FIVE ROUNDS OLD (r5): A SWEEP LIST HAS TURNED OUT TO BE A PROPER SUBSET IN FIVE OF THE SEVEN ROUNDS THIS PLAN HAS HAD — the two clean rounds were the exception, not the turn.** **The portable rule: the BY-CAUSE GREP is the instrument and the enumerated list never is.** A list is a record of what one reader thought of; `git grep -n '<the key or claim being changed>'` over `.omc/plans .omc/specs docs` is a record of what is there. **When a ruling changes a KEY's meaning, sweep the key, not the sections.**

⚠ **`node scripts/check-v3-registers.mjs` does NOT gate these rows** (its census is over `**deferred-v3` markers and the eleven v3 slugs; these are `deferred-v2`). `check-citation-anchors.mjs` protects only the new anchors; a review lane is the rest.

⚠ **BOTH PREAMBLE SENTENCES ARE REWRITTEN, AND r2's CLAIM THAT THE SECOND WAS "STILL LITERALLY TRUE" IS WITHDRAWN — IT IS FALSE AT HEAD, INDEPENDENTLY OF THIS PHASE (M7).** Sentence 1 (*"every drag variant resolves to select-on-press-then-nothing-on-move"*) has been false since phase-42. Sentence 2 asserts *"There are NO `dragstart`/`mousemove`/`dragover`/`drop` listeners (grep-confirmed)"* — but `packages/descvi/src/react/overlay/canvas/use-canvas-hover-ring.ts#    stage.addEventListener("mousemove", onMouseMove);` ships today. ⚠ **Keeping a false sentence and calling it verified is the process failure this plan's own status block records, committed by the revision that wrote the record.** **The amendment describes the shipped listener set rather than asserting an absence whose terms have drifted.** ⚠ It also carries **two banned line pins that are now dead** — `selection-shield.ts:75-78` lands on a docblock tail and `OverlayShell.tsx:292-293` on `[],\n  );` — **converted to anchors in the same amendment**, since `AGENTS.md`'s rule is binding and `check-citation-anchors.mjs` cannot see either form.

---

## 5. Stories, in ship order

**S47-0 — the fixtures, the routing record, and the two counts this phase owes.**

⚠ **WHICH HALVES ALREADY SHIP — AND r3 WROTE THIS INVENTORY FROM THE AUTHORED PROXY IN EXACTLY THE PLACES §4.2(3) RULES THE PROXY MUST NOT BE TRUSTED (r4).** That is pre-mortem 3's own class arriving in the fixture list: **D47-2's whole story is that the authored token is corroboration and the live read is authoritative**, and then the inventory was written from the token. Corrected against the live reader:
- **"three flex-row chains of 7" is TWO.** The two `shop/member-list` chains (`ohpkna…lqaxc2`, `xaro3n…1hzfxp`) stand. ⚠ **`shop/order-detail`'s `kh1mfx…thbzev` does NOT** — its parent `src/app/shop/order-detail/page.tsx#      <div data-oid="grpeul" className="flex-wrap gap-x-3 gap-y-1 text-gray-500 text-sm table">` computes `display: table`, so it refuses at E2 and **can never be a drag subject.** *(Control: `4jpxin` on the same page reads `flex row` through the same reader, so the reader can see flex.)*

**Genuinely absent and owed:**
- a **flex-col chain of ≥5 whose members all render together** — ⚠ **and r3's stated reason for excluding the corpus's flex-col 5-chains was WRONG (r4): `sandbox/resize-flex-col`, `sandbox/resize-flex-row` and `sandbox/resize-repeat-list` all compute `block` at the chain's parent, so they fail at E2 — not because of their conditional members.** *(Control: the same reader returns `flex row` for `smcell`'s parent on `resize-repeat-list`.)* The conditional-member observation is true and is not the disqualifier;
- a **`flex-row-reverse` chain with oid-bearing children** — the three reverse containers in `lab/tests/align-enablement` have none (§4.2(5));
- a **variant (`md:flex-*`) chain with oid-bearing children** (G47-5c);
- **an `rtl` chain, a `vertical-rl` chain and an unequal-`order` chain** (G47-5d) — **all three declared SYNTHETIC: measured at zero subjects (§4.2(3))**;
- **an ambiguity subject for `chain-member-not-locatable`** — **SYNTHETIC: both of r2's "shipped subjects" were measured not to fire, and the several-matches and direct-child arms have zero subjects at parent scope (§4.2(2))**;
- **a flex parent whose DOM element-child count differs from its chain length**, for G47-19;
- **an ordinary reorderable subject reachable in `e2e/spacing-gesture.spec.ts`'s own fixture**, for G47-1's fourth press;
- **an `unequal-indent` pair — SYNTHETIC and unconditional** (measured at zero, §3.1).

⚠ **AND ONE SUBJECT THIS STORY DOES NOT OWE, SAID SO NOBODY AUTHORS IT TWICE: `no-sibling-in-this-copy` (G47-11d) is the ONE client-only refusal whose subject already SHIPS** — `lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, five flex-parented instances resolving 2/2/2/2/1 in default state.

**Two counts owed and not gettable from source**, both DOM reads: **(i)** the direct-child violation rate at parent scope — measured **0 of 601** by round 3, so this is now a *confirmation* rather than an unknown, re-run at the fixture set; **(ii)** nothing else: **D47-2's live prevalence is settled (§3.1).**

**And one DOC deliverable, placed FIRST so it cannot be lost:** route DR47-8 reading (a) back to **B-Q4's row in `docs/post-loop-backlog.md`** with the 2026-08-27 owner ruling recorded and **no phase number invented**.

The regenerated `.descvi/screens.json` diff **is** the deliverable. **Verification: `pnpm gates`.**

**S47-1 ∥ — the headless reorder model.** The chain walk; the drop table's two lifetimes and its resolved-members-only rule; the total hit-test; the scoped layout admissibility and its refusal branches; the reversal flip; no-op detection; the candidate/eligible split with term 5's two-reader predicate; the one-per-press rule; the terminal totality; the refusal map's engine-total shape plus its `undefined` arm and six client-only keys. **Verification: unit, jsdom-free.**

**S47-2 ∥ — the wire and the server composer.** The move-arm split; `expectDestination: {anchorOid, side}` REQUIRED-on-move / FORBIDDEN-elsewhere with its total parser and its self-anchor 400; the exported `resolveMoveDestination`; **the span-rearrangement primitive beside `swapSpans` and the ONE-SPLICE composer**; the direction-disagreement 400; the atomic abort; the applied-`k` echo; **an instrumented `parse` counter in the sidecar's test harness** so G47-20 can observe what §3.3 measured. **Verification: unit + the sidecar suite, plus the cost re-derivation against R47-4's threshold with the same controls (byte-equality against the naive fold, no-move, wrong-destination).**

**S47-3 — the gesture wiring and the guard.** `canvas/use-reorder-drag.ts`; the two shield edits; `setPointerCapture` on the stage; the terminal set **and the reorder guard's own teardown reset**; the request-gated latch; furniture suppression by `visibility` **with the instance hint's explicit re-declaration**; DR47-11's second guard, the `terminateActiveCanvasGesture()` wrapper and the migration of all 7 boundary sites — ⚠ **the brief must NAME THE WRAPPER'S MODULE, because `packages/descvi/src/react/overlay/__tests__/caller-scan.ts#    if (rel === definitionFile) continue;` excludes the definition file, so a wrapper living in `resize-gesture-guard.ts` makes G47-14's scan return ZERO rather than "exactly one" (M9)**; the `POINTER_DRAG_THRESHOLD_PX` header correction; the `armTrailingClickSuppression` docstring correction; the §3.F preamble amendment including its two dead line pins. ⚠ The brief must require the implementer to state what the new predicate must NOT match. **Verification: jsdom for the wiring; a live `descvi:dev` smoke is REQUIRED.**

**S47-4 — the indicator, the readout and the refusal surface.** The three nodes at z 44, the readout clamped to the ring layer's rect and absent on a refusing arm; the `styleReadout` extraction with `tone`/`zIndex`/`accentPx` parameterised, **three** callers migrated, both `READOUT_ACCENT_PX` declarations left in place; the engine-total bilingual refusal map with its six client-only keys. **Verification: jsdom for structure and non-operability; Playwright for position; the owner for look.**

**S47-5 — `undo-focus-ownership`.** C47-6a and C47-6b, each with its own rows, and **C47-6b's own control on the panel value-commit path** (§4.6). **Verification: jsdom + `e2e/undo-cmdz.spec.ts`.**

**S47-6 — live coverage, the six ontology rows, the landing audit and the tracker section.** `e2e/reorder-drag.spec.ts` with its `spec-classes.json` declaration argued (§12); the §3.F-1 dispositions with their anchors; **the F46-D `readScene` grep as a named deliverable**; the whole-set audit **as this phase lands**; the tracker row.

⚠ **AND ONE CONSTRAINT S47-6 MUST READ BEFORE IT WRITES A SPEC (M10). On the design view, an in-page control cannot be activated by a click.** `shop/member-detail`'s three tab buttons drive a plain React `useState`; on :3001 three consecutive clicks produced **no state change** (oid counts 84/84/84) while the byte-identical script on :3000 produced 84/69/35. **The canvas selection shield claims the press.** A cross-host control ran first: 20/20 screens identical at default state. **This is not phase-47's defect and not phase-47's to fix, but it constrains how any Playwright spec drives in-page state on the design view** — a spec that needs a non-default page state must drive it on :3000, or reach the state without a click. ⚠ **Whether it deserves a `docs/known-issues.md` entry is a LEAD RULING, not this plan's** (§9.6).

---


hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '258,300p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '301,342p' .omc/plans/ralplan-phase-47-drag-reorder.md
sed -n '455,472p' .omc/plans/ralplan-phase-47-drag-reorder.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
### 4.3 The write — one request, an ANCHOR receipt, a ONE-SPLICE composer, one Cmd+Z (RULED — DR47-4 — C47-3)

**C47-3.** `target: 'structure'`, verb `move-up`/`move-down` by the sign of the source-order displacement, unchanged `expect` for the ORIGIN, plus **`expectDestination: { anchorOid, side }`**, **REQUIRED on the two move verbs and FORBIDDEN on the other four**, with a total switch beside the shipped `parseExpectForOp`. **Both producers can construct it**, so §2's "does NOT touch" list needs no exception.

⚠ **THE UNION SPLIT IS BY BASELINE ON THE SERVER AND BY PAYLOAD ON THE CLIENT.** `packages/descvi/src/sidecar/server.ts#export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;` carries **all five** ops, so splitting the moves off the server's baselined arm leaves **`{delete, duplicate, insert-after}`**; the client's `packages/descvi/src/react/overlay/engine/sidecar-bridge.ts#export type PayloadFreeStructureOp = Exclude<StructureOp, 'insert-after' | 'insert-child'>;` leaves **`{delete, duplicate}`**.

Server, inside `computeStructuralEdit`'s move arm, under the write lock:
1. resolve the op-unit and re-derive the live origin baseline; mismatch ⇒ `stale-baseline` (409);
2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
4. **rearrange in ONE SPLICE (M1).** Read every member's span from **one** `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. ⚠ **This is not the k-swap loop r2 specified: that shape does not run, and the repo had already written the lesson down in this very file** — `packages/descvi/src/extractor/structural-edit.ts#calls are the wrong tool: each re-parses, and every span after the first is stale.` **S47-2 therefore owes a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** ⚠ *r2's clause "`expect` consulted on the first step only" dies with the steps: there is one step.*
5. a typed refusal aborts `prepare`, so **nothing is written**, and the 422 carries that reason. ⚠ **The k-swap shape failed with `span-sentinel-failed`, an INTERNAL error this clause does not catch — recorded because it is why the shape had to change rather than be guarded**;
6. one journal push, subject unchanged; `packages/descvi/src/sidecar/commit-write.ts#export function reselectTargetFor(subject: JournalSubject): string | null {` needs no new arm;
7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.

⚠ **`parentOid: null` CHAINS ARE ADMITTED, AND SAYING SO IS A RULING (M9).** `wflbl3`/`wfval7` carry it — they are declared in a helper outside the default export, so the extractor records no oid-bearing parent — and they are **pressable, admissible, flex-parented** subjects (their DOM parent is `flex flex-col`). **`parentOid` is not consulted by this design at all**: order comes from `prev`/`next`, geometry from `subjectEl.parentElement`. The server's own chain re-derivation is likewise positional. **Nothing special is owed; the case is recorded so an implementer does not add a `parentOid !== null` guard that would refuse a working subject.**

**ONE Cmd+Z AFTER A 4-POSITION DRAG TAKES THE ELEMENT BACK FOUR POSITIONS** — one request, one entry, one undo, byte-exact from the entry's whole-file `before` bytes.

⚠ **The anchor receipt is slightly more permissive than a gap receipt, and that is a property.** A gap receipt refuses when either neighbour changed; an anchor receipt names **the element the user aimed at**, so a concurrent edit elsewhere in the chain **re-targets rather than refuses**. The origin `expect` still refuses any change to the subject's own position, and the receipt is still a COORDINATE rather than a count — **G47-10's argument is unchanged.**

**Why this is not a new write class — the enumeration is the argument.** No new `StructuralOp` member, no new wire verb, no new journal arm, no new `reselectTargetFor` arm, no new `REASON_TEXT` key. ⚠ *(r0's appeal to `structural-edit.ts`'s header sentence was withdrawn in round 1: it names one class contrasted with literal replacement and carries no taxonomy.)*

### 4.4 The indicator and the drop-position readout (RULED — DR47-3, DR47-7, DR47-8 — C47-4)

**C47-4.** Three new nodes in `#dsh-ring-layer`, all **readouts by role**: no `data-dsh-handle`, no `data-v3-glyph-control`, `pointerEvents = "none"` set **inline** (a class-only rule reads back `auto` in jsdom and the gate could not go RED).

- **`#dsh-reorder-indicator`** — the blue insertion line, in the destination gap, spanning the cross-axis extent of the **resolved** members, perpendicular to the main axis.
- **`#dsh-reorder-readout`** — **the DROP POSITION `n / N`**, per the owner's ruling. ⚠ **`N` is the count of RESOLVED members and `n` the subject's 1-based position among them — deliberately the count the user can see, not the source chain length**, which §4.2(2)'s drop-on-absence ruling makes differ whenever a conditional sibling is not rendering. Showing a total the user cannot count would be the readout's own version of KI-17.
  ⚠ **AND THE CONSEQUENCE THAT RULING CARRIES MUST BE STATED, BECAUSE r3 RULED IT AND DID NOT (r4): `n / N` IS INSTANCE-LOCAL.** Measured on the chain this plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`, six step columns, per-instance **`2/3/3/3/3/3` — in DOCUMENT order, and the SHORT one is the FIRST** (⚠ *r4 wrote `3/3/3/3/3/2`, which reads positional and is wrong in order; the connector `src/app/shop/order-detail/page.tsx#                  <div data-oid="rpb6hb"` sits under an `{i > 0 && (` guard, so column 0 is the one that lacks it, and a lane building the U9 material from the sixth column would conclude the effect does not exist*), all flex — **every column admits** (ruling (iii) works there), and the readout then shows `n / 3` in five columns and **`n / 2` in the **first**, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16). **The per-instance inconsistency was not dissolved; it was relocated out of the refusal and into the readout by the consequence ruled in the same paragraph.** Stated plainly: **`n / N` describes neither the source order the edit acts on** — in column 0, `5s41w1` reads `2 / 2` while being source index **3 of 3** on the same 1-based reading §4.4 defines `n` by — **nor the scope of the edit**, which is every instance. The affordance that carries the scope is `#dsh-ring-instance-hint`, which §4.1(h) keeps visible for exactly this reason.
  ⚠ **The KI-17 argument for showing what the user can count still holds, so the ruling stands — but the readout's SEMANTICS are ground the owner personally ruled, so they are routed rather than settled here: §8 U9.**
- **`#dsh-reorder-refusal`** — §4.5's sentence. ⚠ **On a refusing arm the DROP-POSITION readout is ABSENT (M9), not blanked**: there is no position to report, and a `0 / 0` would be a number about nothing.

⚠ **THE READOUT AND THE REFUSAL ARE TWO NODES, NOT ONE RE-STYLED NODE.** They are mutually exclusive in time, and re-styling one node per paint means re-running the `border` shorthand, which resets all four sides and wipes the accent — the trap `use-spacing-drag.ts`'s own comment warns about.

⚠ **THE READOUT IS CLIPPED AT THE FRAME EDGE, AND THAT IS RULED HERE RATHER THAN LEFT TO U1 (M9).** `#dsh-ring-layer` carries `overflow-hidden` (§3.8). **The readout is therefore CLAMPED to the layer's rect rather than following the pointer past it** — it stops at the edge and stays legible, which is what phase-42's own refusal marker does when it flips above rather than clamping off-screen. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too, and this is the answer.

**Z: all three take `zIndex = 44`**, matching the shipped drag readout (§3.8), with the popup above at 45. ⚠ *r2 briefly moved them to 41 on two false premises — that 41 is "the readout family's own" z (it is the STACK family's) and that §4.1(h)'s hiding replaces the need for a z privilege (that is U4, settled after the story that ships the indicator).* **Ordering among the three at equal z is by DOM order**, the repo's own precedent — and nearly moot, since the readout and the refusal never coexist.

**THE `styleReadout` EXTRACTION, WITH ALL FOUR COSTS PAID.** It takes **`tone`, `zIndex` AND `accentPx`** as parameters — ⚠ `accentPx` is a parameter and not an import, because `READOUT_ACCENT_PX` is module-private in **both** files and importing from either would create a cycle; **neither declaration moves**, because the shipped regex gate requires both and requires the spacing copy to survive. **`use-resize-handles.ts`'s THREE call sites** migrate in the same commit. Placement is pointer-relative and clamped, never `layoutReadouts`'.

⚠ Colour, weight, inset and the gap convention are NOT settleable here (§8 U1/U2); G47-6 asserts only a property.

### 4.5 The refusal — total over the engine AND over the client-only set (RULED — DR47-7 — C47-5)

**C47-5.** A total `Record<StructuralRefusalReason, BilingualMessage>` rendered through `packages/descvi/src/react/overlay/shared/refusal-messages.ts#export function bilingualLine(message: BilingualMessage): string {`, **plus an `undefined` arm** (required by the producer's type; measured at zero occurrences today — §3.1), **plus the client-only set: SIX KEYS OVER THREE CONDITIONS** — E1, E2 and E3, exactly as §4.1(a) enumerates them. ⚠ *(The count has been spelled four different ways across r2 and r3 — "three conditions" over a five-row table, then "four conditions, five keys" derivable under no consistent reading. It is stated ONCE, here, and §4.1(a), the table below and §12 are the three sites that must agree with it. r4's new key makes it six.)*

**Engine-keyed rows** (counts are **refusal** counts over `move-up`/`move-down` across `src/app` — §3.1):

| key | ko | en |
|---|---|---|
| `no-adjacent-sibling` (541) | 이 방향에 **형제 요소가 없습니다.** | **There is no sibling in that direction.** |
| `unsupported-sibling` (189 = 165 arm-time + 24 fold-step) | 옆에 있는 요소가 **편집할 수 있는 단위가 아닙니다** — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit** — something invisible, such as a comment, may sit between them. |
| `unsupported-parent` (52) | **부모가 순서 편집을 지원하는 형태가 아닙니다.** | **The parent is not a shape that supports reordering.** |
| `target-bears-data-screen` (48) | **화면 경계는 순서를 바꿀 수 있는 자리가 아닙니다.** | **A screen boundary is not a position that can be reordered.** |
| `unsupported-container` (18) | **감싸고 있는 조건부 묶음이 지원되는 형태가 아닙니다.** | **The conditional wrapper around it is not a supported shape.** |
| `non-canonical-separator` (6) | **형제 요소 사이 간격이 편집 가능한 형태가 아닙니다.** | **The spacing between the siblings is not in an editable form.** |
| `unequal-indent` (0 — R47-3) | 지나가야 하는 형제 요소와 **들여쓰기가 달라** 이동할 수 없습니다. | The move is blocked because **a sibling it must pass has a different indent**. |
| every remaining engine reason, and `undefined` | **이 위치에서는 순서를 바꿀 수 없습니다.** | **Reordering is not available at this position.** |

⚠ **`unsupported-sibling`'s WORDING MUST BE TRUE AT BOTH MOMENTS, AND r2 FIXED ONLY ONE (M9).** R1 scoped it to *"a step of the fold"* and worded it *"a sibling it must pass"*; r2 corrected the scope to arm-time. **Measured, it is both: 165 arm-time and 24 fold-step** — and **the 24 genuinely ARE the "a sibling it must pass" case.** The row above names the **relationship** (the neighbour is not an editable unit) rather than a traversal, which is true at both, and its second clause names what the user cannot see — §3.1's driven JSX-comment cause is the evidence.

⚠ **The generic arm names the POSITION, not the element.** R1's read *"이 요소는 … / This element cannot be reordered here"* — the element as subject, differing from rule 1's own counterexample by one word, so G47-11 leg (ii) fired on the plan's own text. The three largest causes (52 + 48 + 18 = 118 refusals) now have relationship-naming sentences of their own.

**The client-only set — three conditions, six keys:**

| key | condition | ko | en |
|---|---|---|---|
| `no-reorderable-sibling` | E1, the **22** | 같은 부모 안에 **순서를 바꿀 형제 요소가 없습니다.** | There is **no sibling to reorder with** inside this parent. |
| `sibling-not-editable` | E1, the **108** | 옆에 있는 요소가 **편집할 수 있는 단위가 아니라** 순서를 바꿀 수 없습니다 — 사이에 주석처럼 보이지 않는 것이 있을 수 있습니다. | **The neighbouring element is not an editable unit**, so the order cannot be changed — something invisible, such as a comment, may sit between them. |
| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |

⚠ Two of these name the panel as the working alternative deliberately: the flow-axis refusal is a GESTURE policy, not a write constraint, so telling the user the buttons still work is the true and actionable sentence.

⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**

**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.

**Where each is shown.** E1, E2 and E3 are known at arm time (E3 at the first geometry read): the gesture arms into a refusing state, paints `#dsh-reorder-refusal`, draws no indicator, shows no drop-position readout, and issues nothing. Step-refusals arrive as the 422's typed reason after release.

⚠ **The indicator can therefore be shown for a destination the server refuses — and R47-3 explains why that is safe rather than merely asserting it (M8).** `unequal-indent` is the only move-only precondition a chain-derived destination can trip, **and the mechanism is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."*** Because the chain is built **only across links `adjacentOpUnit` already admitted**, every other move-only condition was already satisfied when the link was made. A lane tried to break this with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. **And `unequal-indent` is measured at zero, so the cost lands entirely on G47-9's synthetic fixture.**

## 7. Risks, each paired with a MECHANISM

| id | Risk | Mechanism |
|---|---|---|
| **R47-1** | The new predicate on the ordinary arm matches more than it means to — the ONE failure class the record contains. | (i) **G47-5c, G47-5d, G47-2** are breadth assertions. (ii) The S47-3 brief requires the implementer to state **what the predicate must NOT match and which target class each existing arm claims**. (iii) G47-1's fourth press, with a constructible mutation. ⚠ The obligation attaches to the ordinary-arm call; the wrapper swap is mechanical and policed by G47-14. |
| **R47-2** | The client's chain is one edit stale. | The anchor receipt makes it a **409 with no write**; G47-10 substitutes the unverifiable alternative to prove it. |
| **R47-3** | The indicator promises a drop the server refuses. | ⚠ **The MECHANISM, not just the conclusion (M8):** the chain is built **only across links `adjacentOpUnit` already admitted**, and that function's docblock rules *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."* So **indent is the only move-only precondition a chain-derived destination can trip** — a lane tried `unsupported-sibling` and `non-canonical-separator` mid-chain and could not break it — **and `unequal-indent` is measured at zero.** The cost lands entirely on G47-9's synthetic fixture. |
| **R47-4** ⚠ **THRESHOLD RE-DERIVED (M2)** | The in-lock rearrangement stalls the sidecar. | k ≤ chainLength − 1 ≤ 6. ⚠ **r2's *"under 19 ms"* was unreachable by a CORRECT implementation of the design it was written to accept**: a correct k-swap fold's best case is **21.49 ms**, so the criterion would have fired on a correct build and returned the k = 1 clamp for a reason unrelated to the design's merit. *(It was also self-inconsistent: "closer to the floor than to the ceiling" is `< 18.92`, not `< 19`.)* **Under the one-splice shape (§4.3(4)) the floor an implementation can occupy is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ 7.5 ms.** **Pre-committed acceptance, written before the measurement so it can go RED: the k = 6 rearrangement must complete in under 12 ms on `src/app/shop/order-detail/page.tsx`'s 7-member chain `kh1mfx…thbzev` (**40,979 bytes**), or the design is re-opened.** ⚠ **THAT CHAIN IS A COMPOSER BENCHMARK, NOT A DRAGGABLE SUBJECT (r4)** — its parent computes `display: table` and refuses at E2 (§5), so the lane building the Playwright row must not assume it can be dragged. The criterion is a server-side measurement over source bytes and is unaffected. ⚠ **The threshold is met: round 4 built the one-splice composer and measured 6.803 ms — 1.76× headroom — with the naive fold (33.0 ms) and a correct k-swap (≈21 ms) both RED against it, and byte-exactness confirmed in both directions including an interior up-move (index 3 → 1), a direction no earlier round had tested.** ⚠ **The subject is named because these numbers are page-size dependent — the same three primitives read 0.662 / 1.490 / 9.041 ms on `shop/member-list` (9,656 B).** Controls: byte-equality against the naive fold, no-move, wrong-destination. G47-20 pins the parse count. |
| **R47-5** | The trailing-click latch has two producers. | Co-occurrence needs two simultaneous pointers (disjoint targets); bounded by the shipped unconditional drop-on-press. The docstring's precondition is corrected in S47-3. |
| **R47-6** | Widening Cmd+Z ownership to `document.body` intercepts a keystroke meant for something else. | The text-entry guard runs first and is untouched; `body` is unowned rather than outside the overlay. G47-12(b-ii) asserts the order, meaningful only because the `null` half was dropped. |
| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
| **R47-8** | One drag, N rows move, and the user is surprised. | §4.1(h) keeps `#dsh-ring-instance-hint` visible **through an explicit `visibility: visible` re-declaration**, because the hint is a child of the layer being hidden; G47-16(ii) is aimed at deleting that override. ⚠ **Without the override this risk had NO working mechanism (M4).** |
| **R47-9** | A boundary forgets the second guard call, or the teardown. | One wrapper, 7 sites migrated in S47-3's own commit, G47-14's caller-scan leg **with the wrapper's module named**; and the reorder guard's own teardown reset (§4.1(f)). |
| **R47-10** | The §3.F-1 amendments and the preamble go stale and no gate notices. | Six rows with dispositions, amended in the commit that makes them true; the two dead line pins converted; `check-citation-anchors.mjs` protects the new anchors; the S47-6 whole-set audit is the rest. **Stated as an uncovered surface rather than believed covered — and r2's own "still literally true" claim about the preamble is why (M7).** |
| **R47-11** ⚠ **RE-PRICED (round 3)** | The modelled subset is narrower than the corpus and users meet the refusal. | ⚠ **MEASURED AT ZERO in this corpus** — `rtl` 0/930, non-`horizontal-tb` 0/930, `order !== "0"` 0/930 (§4.2(3)) — so nothing is lost today, and the refusal names the panel as the working alternative. **What is UNMEASURED is whether that stays true as the corpus grows**, and the gate subjects are synthetic precisely so the clauses keep working when it does not. |

---


hook: PostToolUse
hook: PostToolUse Completed
codex
현재 가설은 두 가지입니다. 첫째, anchor receipt 자체는 stale coordinate를 검증할 수 있지만, 계획이 “direction-disagreement를 splice 전에 판정”하고 “applied `k`를 결과에서 복구”하는 알고리즘을 충분히 규정하지 않으면 구현자가 요청값을 재진술하는 잘못된 구현도 계약을 통과할 수 있습니다. 둘째, render-inert 모집단과 scoped-zero 표기는 마지막 수정에서 여전히 검증 범위가 서로 섞였을 가능성이 있습니다. 이제 shipped server 경로와 실제 corpus를 각각 실행 가능한 형태로 대조하겠습니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "rg --files packages/descvi/src | rg 'structural-edit|server|sidecar-bridge|commit-write|StructureSection|source-resolver|test'
rg -n \"computeStructuralEdit|parseExpectForOp|resolveJsxChildOp|adjacentOpUnit|baselineFor|swapSpans|move-up|move-down|applied|expectDestination|structureSubjectFor\" packages/descvi/src/sidecar packages/descvi/src/extractor packages/descvi/src/react/overlay/engine packages/descvi/src/react/overlay/panel
rg -n '\"scripts\"|tsx|playwright|vitest' package.json packages/descvi/package.json pnpm-workspace.yaml
rg -n \"conditional-container|opUnitKind|d4b6s3|omy3i9|jbtzr7|xpy5eu|benefits\" .descvi/edit-map.json src/app/shop/member-detail/page.tsx src/app/lab/tests/shared-oid/page.tsx
git log -n 8 --oneline -- packages/descvi/src/sidecar/server.ts packages/descvi/src/extractor/structural-edit.ts" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 93ms:
400f1fa fix(extractor): one unclassifiable screen no longer blocks every other screen's edits (KI-33)
22c24e1 fix(sidecar): the description path gets the lost-update guard its four siblings already had (KI-36)
8add04f docs(descvi): the prose that still named the retired sandbox namespace
e2330c8 feat(descvi): insert-child admits the zero-child container, and one composer covers both shapes
120846b fix(sidecar): mint the dev token per launch, and delete the constant it only claimed not to be (KI-12)
d3bf733 fix(sidecar): cap the resolve body and stop splicing raw wire values into logs (KI-14, KI-13)
2a7ee4d fix(sidecar): emit `detail` on extract-failed — the branch that explains a failure was the one the client rejected

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,120p' packages/descvi/src/sidecar/server.ts
sed -n '180,430p' packages/descvi/src/sidecar/server.ts
sed -n '460,590p' packages/descvi/src/sidecar/server.ts
sed -n '1560,1765p' packages/descvi/src/extractor/structural-edit.ts
sed -n '1810,1875p' packages/descvi/src/extractor/structural-edit.ts
sed -n '2360,2410p' packages/descvi/src/extractor/structural-edit.ts
sed -n '1710,1830p' packages/descvi/src/sidecar/server.ts" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { loadManifest } from '../react/load-manifest.ts';
import {
  replaceDescription,
  StaleDescriptionError,
  replaceName,
  createComponentEntry,
  componentEntryExists,
} from '../extractor/description-edit.ts';
import {
  replaceClassName,
  ClassNameNotEditableError,
  StaleClassNameError,
} from '../extractor/classname-edit.ts';
import {
  replaceText,
  replaceTextSlot,
  TextNotEditableError,
  StaleTextError,
  EmptyTextError,
} from '../extractor/text-edit.ts';
import { replaceBinding } from '../extractor/binding-edit.ts';
import { resolveEditTarget } from '../extractor/resolve-edit-target.ts';
import { runExtractor } from '../extractor/run.ts';
import { publishDerivedPair } from '../extractor/derived-pair.ts';
import { findReductionRefusal, scopeReductionRefusal } from '../extractor/screen-scan.ts';
import { commitWrite, findUndoCandidate, resolveTransaction, reselectTargetFor, structureSubjectOid, transactionRefusal, type CommitOutcome, type JournalEntry, type JournalRuntime, type JournalState, type JournalSubject, type PrepareResult, type TransactionRefusal } from './commit-write.ts';
import type { ScreenGraphType } from '@descvi/core/schema';
import { blobValidity, collectResolvableUnresolved, collectUnresolved, quarantinedRecords, recoverStartup, recoveryChoices, recordKindOf, resolutionToken, sweepBlobs, sweepTransactionTemps, txState } from './recovery.ts';
import {
  moduleContext,
  resolveJsxChildOp,
  deleteSubtree,
  moveAdjacent,
  duplicateSubtree,
  insertAfterOpUnit,
  insertChildAtEnd,
  removeSpecEntries,
  removeEdgeSpecs,
  seedOidsFromAst,
  StructuralNotEditableError,
  STRUCTURAL_WIRE_VERBS,
  type StructuralBaseline,
  type StructuralWireVerb,
} from '../extractor/structural-edit.ts';
import { isSnippetId, SNIPPET_IDS, type SnippetId } from '../extractor/snippet-registry.ts';
import { seedUsedOids } from '../extractor/oid.ts';
import { objectProps, keyName, strOf, nodeType, type AnyNode } from '../extractor/parse.ts';
import fg from 'fast-glob';

/**
 * Dev-only, `next`-import-free write-back sidecar. Maps a
 * `POST /edit { screenId, specId?, newText, dryRun? }` — the DESCRIPTION path, selected by an absent (or
 * `'description'`) `target` — to a safe `spec.ts` description swap + a fresh `screens.json`, reusing the
 * proven `replaceDescription` + `runExtractor` primitives. Bound to `127.0.0.1` only.
 *
 * ⚠ THAT BODY SHAPE IS THIS ONE PATH'S, NOT THE ENDPOINT'S. `target` selects among nine paths and each has its own required fields ({@link EditBody} documents them per field): `className` / `className-batch` / `name` / `text` / `text-slot` / `binding` / `structure` / `undo`, plus this one.
 * **`dryRun` in particular belongs to this path alone** — every other target refuses `dryRun: true` with a 400, because none of them has a preview to give.
 * This header advertised it unscoped while **seven** write paths silently ignored it, which is how a `dryRun: true` structural edit came to perform its write — and a `dryRun: true` UNDO came to perform the undo, measured.
 * `undo` restores files, so it is a write path and not a separate category; the earlier revision of this sentence said six, which is the same off-by-one as the defect it documents, in the one sentence whose own next clause is: a client author reads this header first.
 *
 * SECURITY (this is a localhost SOURCE-FILE WRITER — the top risk). CORS is response
 * policy ONLY, never the write gate: a cross-origin simple-request POST is processed
 * even when CORS forbids reading the reply, and the mutated `spec.ts` IS the payload.
 * So admission is enforced server-side on the REAL POST, all routed through the pure
 * {@link createSidecar}.`handleEdit(body, meta)` seam (socket-free, unit-testable):
 *   Origin not in the dev allowlist            → 403
 *   Host not 127.0.0.1/localhost:<port>        → 403 (DNS-rebinding guard)
 *   Content-Type not application/json          → 415 (kills no-preflight CSRF)
 *   missing/wrong X-Descvi-Dev-Token           → 403 (custom header forces preflight)
 *   NODE_ENV==='production'                     → 404 (+ listen() refuses to start)
 * plus a manifest-derived path + traversal assert, bounded input, an in-process write
 * mutex, and 200 ONLY after write + extract both succeed. On an extract failure the
 * pre-edit source is rolled back in-process (no disk backups; git is the recovery net).
 */

export const DEFAULT_SIDECAR_PORT = 7331;
export const DEFAULT_DEV_ORIGINS = [
  // Plain prototype view (`vite.config.mts`, `server.port: 3000`).
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  // Design-view (`descvi.vite.config.mts`, `server.port: 3001`) — the overlay
  // editor write-back runs ONLY here, so its origin must be allowlisted.
  'http://localhost:3001',
  'http://127.0.0.1:3001',
  // Vite's stock default port, as a safety net for an unpinned design-view config.
  'http://localhost:5173',
  'http://127.0.0.1:5173',
];
const MAX_NEW_TEXT = 20_000;

/** Thrown by listen() when refusing to start under NODE_ENV=production. */
export class SidecarProductionRefusalError extends Error {
  constructor() {
    super('descvi-sidecar refuses to start under NODE_ENV=production (dev-only source-file writer)');
    this.name = 'SidecarProductionRefusalError';
  }
}

export interface EditBody {
  screenId?: unknown;
  specId?: unknown;
  newText?: unknown;
  /**
   * preview-only, and DESCRIPTION-PATH ONLY. `true` on a description edit computes the new `spec.ts`,
   * returns `{ ok: true, dryRun: true, diff }` and writes NOTHING.
   *
   * ON EVERY OTHER TARGET (`className` / `className-batch` / `name` / `text` / `text-slot` / `binding` / `structure` / `undo`) IT IS A 400.
   * Those paths have no preview to give: the description diff is a text splice in one file, while the others rewrite source — up to two files, through the AST engine — so a real preview means running the whole composer, which is a feature and not a flag.
   *
   * `false` is accepted everywhere: it asks for exactly what those paths do. A non-boolean is a 400 on
   * every path, description included.
   *
   * It read as universal until phase-22 and was silently IGNORED by all seven non-description targets, so a
   * `dryRun: true` structural edit performed the write and answered 200. If you add a target, it inherits
   * the refusal automatically — the guard keys on "not the description path", not on a list of targets.
   */
   * CURRENT fingerprint inside the write lock and 409s on a mismatch (the guard
   * that closes the identical-value slotIndex-shift hole). REQUIRED for a
   * text-slot edit; an absent fingerprint → 400 (symmetric to `prevText`).
   */
  slotsFingerprint?: unknown;
  /**
   * the module-const object identity + field name a `target: 'binding'` edit
   * (E3 v1.11) asserts — the D6 delta-4 binding-identity guard `replaceBinding`
   * re-derives on the fresh parse and compares against, closing the
   * concurrent-rebind + value-coincidence hole `prevText` alone cannot see. The
   * panel passes both through from the loaded `selectedText.binding`. REQUIRED
   * (non-empty strings) for a binding edit; a mismatch → 409 (symmetric to a
   * stale `prevText`); absent → 400 (symmetric to v1.10's required
   * `slotsFingerprint`).
   */
  constName?: unknown;
  field?: unknown;
  /**
   * the structural op (`target: 'structure'` branch, E3 v2) — a member of
   * `STRUCTURAL_WIRE_VERBS`, which the deny-ladder and its 400 message both read.
   * The element is addressed by `oid`; no source spans are ever sent. REQUIRED (a
   * known wire verb) for a structural edit; anything else → 400.
   */
  op?: unknown;
  /**
   * the structural staleness baseline (`target: 'structure'` branch, D7) — the
   * `{ parentOid, prevOid, nextOid }` (each `string | null`) the panel captured
   * from the edit-map at load. The engine re-derives the LIVE baseline under the
   * write lock and 409s on a mismatch (a concurrent reorder).
   *
   * ITS REQUIREMENT IS PER-OP, and it runs in BOTH directions. Every verb that
   * names a coordinate REQUIRES it — a missing or malformed baseline → 400,
   * symmetric to the other paths' required fields. `insert-child` names a
   * container plus an intent instead, so it carries none and REFUSES one: a
   * present `expect` on that verb → 400 with its own message. See
   * {@link parseExpectForOp}, which is where both rules live.
   */
  expect?: unknown;
  /**
   * WHAT to insert (`target: 'structure'`, the insert verbs) — a KEY of the palette registry
   * (`extractor/snippet-registry.ts`), never source text. `box` / `heading` / `text` / `button` / `divider`
   * today; an unrecognised key is a 400 that lists what is available.
   *
   * ⚠ IT IS A KEY BECAUSE ACCEPTING TEXT WOULD BE A NEW SECURITY SURFACE, not because a key is tidier. Every
   * guard on this endpoint constrains WHERE a write lands — the `src/app` path guard, the manifest-validated
   * `screenId`, the span sentinels. None constrains WHAT is written. Free JSX from the wire would be bytes a
   * caller chose, spliced into the user's source, with nothing shipped standing between the two. It is also
   * what makes the snippet's compilation provable: a registry entry's bytes live in a `.tsx` fixture the root
   * `pnpm typecheck` compiles, and a wire-supplied string has no fixture and no such proof.
   *
   * REQUIRED for `insert-after` / `insert-child` — there is nothing to insert without it. FORBIDDEN
   * everywhere else: for the four other structural verbs, which move or remove bytes that already exist, AND
   * for every non-structure target, none of which has a payload at all. A caller sending one has
   * misunderstood the verb, and accepting-and-ignoring it would hide that. Both directions are a 400 with
   * their own message.
   *
   * ⚠ ABSENCE MEANS THE KEY IS ABSENT, and that is a constraint on the CLIENT. JSON has no `undefined`, so
   * `{"snippetId": null}` is a value the caller chose to send and is refused with the rest — a panel must
   * OMIT the field on every non-insert edit rather than serialize one fixed body shape with nulls. Same rule
   * as `expect`, and the same trap.
   *
   * The wire validates MEMBERSHIP only. Resolving a key to its text is the composer's job, so the sidecar
   * never holds snippet source at all.
   */
  snippetId?: unknown;
}

// ---------------------------------------------------------------------------
// Structural edit (E3 v2, Phase 2 / D7) — pure compute helpers (no I/O)
// ---------------------------------------------------------------------------

/** Reads an edge object-literal's `via` oid — the delete-cascade predicate source (mirrors the 1B tests). */
function edgeViaOf(expression: AnyNode): string | undefined {
  if (nodeType(expression) !== 'ObjectExpression') return undefined;
  for (const p of objectProps(expression)) {
    if (keyName(p['key']) === 'via') return strOf(p['value']);
  }
  return undefined;
}

/**
 * Validates the `{ parentOid, prevOid, nextOid }` staleness baseline. Each field must be PRESENT and be
 * `string | null`; a missing key (undefined) fails, so an absent/partial `expect` is a 400 exactly like a
 * missing `prevText` on the other paths.
 */
function parseExpectBaseline(expect: unknown): StructuralBaseline | null {
  if (expect === null || typeof expect !== 'object') return null;
  const e = expect as Record<string, unknown>;
  const ok = (v: unknown): v is string | null => v === null || typeof v === 'string';
  if (!ok(e['parentOid']) || !ok(e['prevOid']) || !ok(e['nextOid'])) return null;
  return {
    parentOid: e['parentOid'] as string | null,
    prevOid: e['prevOid'] as string | null,
    nextOid: e['nextOid'] as string | null,
  };
}

/** Every wire verb EXCEPT `insert-child` names a COORDINATE the client picked, so every one of them carries the `{parentOid, prevOid, nextOid}` receipt that says "was it still there?". */
export type BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>;

/**
 * A wire verb PAIRED with the `expect` receipt its own arm requires. The two travel as one value from the moment the request is parsed, so nothing downstream can recombine a verb with a receipt that belongs to another verb — the correlation is the type, not a convention.
 */
export type StructuralEditIntent =
  | { op: BaselinedWireVerb; expect: StructuralBaseline }
  | { op: 'insert-child'; expect: null };

/** The wire's op deny-ladder, as a predicate over the SHIPPED verb list — a real membership test, so no `as` is needed to reach the typed verb. */
function isStructuralWireVerb(op: unknown): op is StructuralWireVerb {
  return typeof op === 'string' && STRUCTURAL_WIRE_VERBS.some((verb) => verb === op);
}

/**
 * The two 400s the `expect` axis can produce, kept apart because they say opposite things to the client —
 * one is "you owe a receipt", the other is "you must not send one".
 *
 * MODULE-PRIVATE ON PURPOSE. They were briefly exported for the tests to import, which is the wrong
 * direction: a test that asserts a wire payload by importing the constant that produced it agrees with
 * itself no matter what either says. The gate and the payload matrix both re-declare these as literals, so
 * the shipped bytes and the expected bytes come from two different places.
 */
const EXPECT_REQUIRED_400 = 'expect must carry { parentOid, prevOid, nextOid } (string|null each)';
const EXPECT_FORBIDDEN_400 =
  'insert-child must not carry expect: it names a container and an intent, never a coordinate, so no baseline can go stale';

type ParsedExpect = { ok: true; intent: StructuralEditIntent } | { ok: false; error: string };

/**
 * Selects the `expect` parser BY OP, and is TOTAL by construction: every arm returns, there is no
 * `default`, and the declared return type excludes `undefined` — so a wire verb added to
 * {@link StructuralWireVerb} without an arm here is a COMPILE error, never a runtime fallthrough onto
 * whichever parser happened to be written first (plan OPEN FINDING #5).
 *
 * `insert-child` is the one verb that requires NO baseline. It names a container plus an intent ("at the
 * end") rather than a coordinate, so there is nothing that can go stale and nothing to receipt. Every
 * other verb keeps the requirement UNCHANGED — it is made per-op here, not relaxed.
 *
 * (The defect this replaced: a single unconditional {@link parseExpectBaseline} call ran for every verb, so
 * `insert-child` 400ed at the wire before the engine was reached, with every engine test green — they all
 * sit below it. That is history, not behaviour; nothing calls the parser unconditionally any more.)
 *
 * ⚠ AND `insert-child` REJECTS a receipt rather than ignoring one, which is a rule about the CLIENT and not
 * about parsing. The whole addressing ruling is that the client stops claiming to know the coordinate; a
 * client that sends a baseline is making exactly that claim, and accepting-and-discarding it would let the
 * client-side mirror the ruling deleted become representable again SILENTLY. A loud, self-healing failure
 * beats a silent mis-resolution — this repo already rules that way (KI-10's disposition) — so the absence
 * is enforced at the wire, where it is a 400 the client author sees immediately. Absent means ABSENT: an
 * explicit `null` is a value the client chose to send and is refused with the rest.
 */
function parseExpectForOp(op: StructuralWireVerb, expect: unknown): ParsedExpect {
  switch (op) {
    case 'delete':
    case 'move-up':
    case 'move-down':
    case 'duplicate':
    case 'insert-after': {
      const baseline = parseExpectBaseline(expect);
      return baseline === null ? { ok: false, error: EXPECT_REQUIRED_400 } : { ok: true, intent: { op, expect: baseline } };
    }
    case 'insert-child':
      return expect === undefined ? { ok: true, intent: { op, expect: null } } : { ok: false, error: EXPECT_FORBIDDEN_400 };
  }
}

/** What the insert verbs owe, and what the other FOUR structural verbs must not send. Listed from the shipped registry so the message and the accepted set cannot drift. */
const SNIPPET_REQUIRED_400 = `snippetId is required for an insert — it names a palette entry, one of ${SNIPPET_IDS.join('|')}`;

type ParsedSnippet = { ok: true; snippetId: SnippetId | null } | { ok: false; error: string };

/**
 * Renders a rejected `snippetId` for its 400 WITHOUT coercing it to a string first.
 *
 * `String(['box'])` is `'box'`, so the coercing form produced `unknown snippetId "box" — available: …|box|…`:
 * a message naming a value as unknown while listing that same value as available. `String(null)` is `'null'`,
 * which reads as a key someone might have typed. A non-string is reported as its TYPE, because that is the
 * actual complaint — the field is a key, and a key is a string.
 */
function describeSnippetId(value: unknown): string {
  if (typeof value === 'string') return JSON.stringify(value);
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'an array';
  const kind = typeof value;
  return `${/^[aeiou]/.test(kind) ? 'an' : 'a'} ${kind}`;
}

/**
 * Selects the `snippetId` rule BY OP, total by the same construction as {@link parseExpectForOp}: every arm
 * returns, there is no `default`, and the declared return type excludes `undefined`, so a wire verb added
 * without an arm is a COMPILE error.
 *
 * ⚠ THE WIRE CARRIES A KEY, NEVER SOURCE TEXT — and this function is where that ruling is enforced. The
 * reason is VALUE versus PARSE TREE, not novelty: caller bytes already reach the source tree through six
 * wire fields and always have, but every one of them lands inside a STRING LITERAL and is defended three
 * ways — the active delimiter is loud-rejected, what remains is escaped, and the result is defensively
 * re-parsed. Free JSX is caller-controlled STRUCTURE, for which none of those exists or could: no delimiter
 * to reject, nothing to escape, and a re-parse proves only that it parsed. So the only accepted values are
 * keys of {@link SNIPPET_REGISTRY}, whose text is proven to compile by `test/fixtures/snippet-compile.tsx`.
 *
 * The asymmetry is the same shape as `expect`'s and for the same reason: the insert verbs REQUIRE a payload
 * because there is nothing to insert without one, and the other FOUR structural verbs FORBID it because they
 * move or remove bytes that already exist — a caller sending one has misunderstood the verb, and
 * accepting-and-ignoring it would hide that. Absence means absence on both sides, and absence is the key
 * being ABSENT: `null` is a value a client chose to send and is refused with the rest, so a panel must OMIT
 * the field rather than null it. (The same rule one level up refuses it on every non-structure target — see
 * the guard in `handleEditInner`, which is where that symmetry is enforced.)
 */
function parseSnippetForOp(op: StructuralWireVerb, snippetId: unknown): ParsedSnippet {
  switch (op) {
    case 'delete':
    case 'move-up':
    case 'move-down':
    case 'duplicate':
      return snippetId === undefined
        ? { ok: true, snippetId: null }
        : { ok: false, error: `snippetId is not accepted for ${op} — only an insert carries a payload` };
    case 'insert-after':
    case 'insert-child':
      if (snippetId === undefined) return { ok: false, error: SNIPPET_REQUIRED_400 };
      return isSnippetId(snippetId)
        ? { ok: true, snippetId }
        : { ok: false, error: `unknown snippetId ${describeSnippetId(snippetId)} — available: ${SNIPPET_IDS.join('|')}` };
  }
}

/**
 * Builds the journal subject for a structural write — a TOTAL switch for the same reason the parser above
 * is one: the two arms of {@link JournalSubject}'s structure case carry DIFFERENT keys (`oid` vs
 * `reselectOid`, which {@link reselectTargetFor} reads to decide what to reselect after an undo), so a verb
 * without an arm here would have to be given one of them by guesswork.
 *
 * ⚠ BOTH ARMS ARE HANDED THE SAME `oid` AND THE DIFFERENCE IS ENTIRELY IN WHAT IT MEANS DOWNSTREAM, which is why the key names are not interchangeable. For the four element-addressing verbs the value is the element the op acted ON, and it still exists afterwards. For the two inserts it is the element the request was addressed AGAINST — an anchor for `insert-after`, the PARENT for `insert-child`, which under this feature's addressing ruling resolves no anchor at all — and it is what selection must fall back to once the insert is undone and the new element is gone. The key was called `anchorOid` until US-8a, a name that was true of one arm and false of the other.
 */
function structureSubjectFor(op: StructuralWireVerb, screenId: string, oid: string): JournalSubject {
  switch (op) {
    case 'delete':
    case 'move-up':
    case 'move-down':
    case 'duplicate':
      return { kind: 'structure', op, screenId, oid };
    case 'insert-after':
    case 'insert-child':
      return { kind: 'structure', op, screenId, reselectOid: oid };
  }
}

/**
 * Whether a verb MINTS a fresh oid, and therefore owes the corpus-wide seed before it composes.
 *
 * Exported so it can be gated against the engine's own behaviour rather than trusted: a verb whose plan comes
 * back carrying `newOid` and which is NOT in here mints against an empty set, and can produce an oid that
 * already exists in another file. The damage never shows at insert time — it shows when a LATER edit resolves
 * ({@link removeSpecEntries}, multi-doc), and every spec-declared edge whose `via` is a deleted oid is
 * cascade-removed ({@link removeEdgeSpecs}). Native `<Link>`/`<a>`/`router.push` edges disappear on their
 * own when the page subtree is cut (they are re-derived from page.tsx), and the Phase-1B `mergeEdges`
 * downgrade keeps any residual dangle (e.g. a suppress whose native lived in the subtree) a WARNING, not
 * an extraction crash. Both new sources are defensively re-parsed by the composers before return.
 *
 * `op` is the WIRE union rather than `StructuralOp`, and it is widened rather than cast: the two insert verbs are real wire input that is NOT a `StructuralOp`, so the parameter has to admit them honestly instead of pretending they are members of a union they are permanently outside.
 *
 * ⚠ THE OLD REASON FOR THE WIDENING — *"this handler does not compose for them, so they reach the engine and come back as its own typed refusal"* — IS DEAD AS OF US-8a. Both insert arms compose here now. The widening survives for a reason that never depended on refusal: `insert-child` is not and will not be a `StructuralOp` (`edit-map.ts` iterates that array to publish one flag per op, and this verb's verdict comes from its own `resolveInsertChild` descent instead), so the wire's six-verb vocabulary and the ladder's five-verb one are genuinely different types. A cast would have claimed they are the same.
 *
 * ⚠ THE TOTALITY THAT MAKES THAT SAFE IS `resolveAtLocation`'s, NOT THIS FUNCTION'S — and it is only
 * reached because the switch below hands the resolver the op the CALLER named. Before this change the
 * delete tail passed a hardcoded `'delete'`, so widening this parameter alone would not have produced a
 * refusal at all: an `insert-child` request would have been resolved AS A DELETE and answered 200 with the
 * element cut. Measured, not reasoned — `test/gate/insert-wire-contract.test.ts` was watched RED against
 * exactly that shape and reported the removed `<li>` as a byte diff.
 */
export function computeStructuralEdit(
  params: StructuralEditIntent & {
    pageSource: string;
    specSource: string;
    fullScreenId: string;
    oid: string;
    usedOids: Set<string>;
    /** The palette key the wire validated, or `null` for the verbs that carry no payload. Resolved to TEXT only inside the composer, so the sidecar never holds snippet source. */
    snippetId: SnippetId | null;
  },
): StructuralWritePlan {
  const { pageSource, specSource, fullScreenId, oid, usedOids } = params;

  // A TOTAL switch, and the totality is load-bearing rather than tidy: this used to fall THROUGH to a
  // delete tail that passed a hardcoded `'delete'` to the resolver, so a verb reaching it by accident
  // would have been resolved and CUT — a 200 that deletes the element the caller asked to insert into.
  // A verb with no arm here is now a compile error instead.
  switch (params.op) {
    case 'move-up':
    case 'move-down': {
      const nextPage = moveAdjacent(pageSource, fullScreenId, oid, params.op === 'move-up' ? 'up' : 'down', params.expect);
      return { nextPage, nextSpec: null };
    }

    case 'duplicate': {
      const dup = duplicateSubtree(pageSource, fullScreenId, oid, usedOids, { expect: params.expect });
      return { nextPage: dup.source, nextSpec: null, newOid: dup.newOid };
    }

    case 'insert-after': {
      // ⚠ THE WHOLE VERB IS ONE CALL, and that is the design rather than brevity. `insertAfterOpUnit` is
      // `duplicateSubtree` with the copied bytes swapped for a registry snippet: the same `resolveJsxChildOp`
      // in the same shipped precedence, an op-ladder arm literally SHARED with `duplicate`, and a separator
      // the resolver proved. (US-7's panel reads `canInsertAfter` rather than `canDuplicate`; the identity stays the engine's own.) It is
      // load-bearing and the corpus gate asserts it — booleans AND reason strings.
      if (!isSnippetId(params.snippetId)) {
        // Unreachable from the wire, which validates the payload for this verb before the engine is reached.
        // Kept as a typed refusal because this function is EXPORTED, and written as `!isSnippetId` rather than
        // `=== null` for a reason found by running it: a non-handler caller reaching this with `undefined` (or
        // any non-key) slipped past a null check and reached `snippetById`, which throws a PLAIN `Error` — and
        // a plain error out of `prepare` is a 500, not the typed 422 every other refusal on this path produces.
        // The membership test is the same one the wire uses, so both ends agree on what a payload is.
        throw new StructuralNotEditableError('internal', `insert-after needs a valid snippetId, got ${JSON.stringify(params.snippetId ?? null)}`);
      }
      const inserted = insertAfterOpUnit(pageSource, fullScreenId, oid, params.snippetId, usedOids, { expect: params.expect });
      // page.tsx ONLY. A bare oid never reaches `components[]` (`assemble.ts:98-105`), so the new element is
      // artifact-invisible until it is named — there is no spec entry to create and nothing to cascade.
      return { nextPage: inserted.source, nextSpec: null, newOid: inserted.newOid };
    }

    case 'insert-child': {
      // ⚠ THIS CALL IS NOT `resolveJsxChildOp`, AND THE SUBSTITUTION IS THE WHOLE OF US-4. The addressing
      // ruling takes `insert-child` off that path entirely, so it inherits nothing: `resolveInsertChild`
      // assembles its own identity (`findTargets`, never `locateOpUnitAt`, whose `target-bears-data-screen`
      // refusal is correct for the five shipped ops and WRONG for a page root the user is legitimately
      // inserting into), its own explicit `filePoison` consultation, its own closing-tag POSITION sentinel,
      // and its own trailing-gap proof. Until US-4 this arm ran the op ladder and every subject that got as
      // far as the ladder came back `internal`.
      //
      // ⚠ AND THIS ARM IS NOW WIRED (US-8a).
      // Until it was, the verb refused on EVERY input and only WHICH refusal changed: a parent the admission rejects draws the reason for its own shape (`child-region-ends-in-text`, `non-canonical-separator`, `unprovable-child-indent`, `self-closing-parent`), and a parent it ADMITS drew an `internal` stub reading "admitted, and there is nothing here to write it with".
      // That stub is deleted here rather than reworded, because an admitted parent now composes.
      // What must NOT come back is the shape it replaced: a verb whose admission passes with no composition behind it falling through into another verb's tail — the pre-US-1 form of this handler did exactly that, with a hardcoded `'delete'`, and answered 200 having cut the element the caller asked to insert into.
      //
      // `insertChildAtEnd` re-runs `resolveInsertChild` itself and throws the same typed refusal, so the admission is not consulted twice here.
      // That is the same shape `insert-after` has — `insertAfterOpUnit` owns its own resolve — and it is what keeps the admission and the composition from being able to disagree about the target: they are one call, over one parse.
      if (!isSnippetId(params.snippetId)) {
        // Unreachable from the wire, which validates the payload for this verb before the engine is reached — the same typed refusal `insert-after` above keeps, for the same reason: this function is EXPORTED, and a non-handler caller reaching `snippetById` with a non-key gets a PLAIN `Error`, which is a 500 rather than the typed 422 every other refusal on this path produces.
        throw new StructuralNotEditableError('internal', `insert-child needs a valid snippetId, got ${JSON.stringify(params.snippetId ?? null)}`);
      }
      const inserted = insertChildAtEnd(pageSource, fullScreenId, oid, params.snippetId, usedOids);
      // page.tsx ONLY, exactly as `insert-after` is: a bare oid never reaches `components[]` (`assemble.ts:98-105`), so the new element is artifact-invisible until it is named — there is no spec entry to create and nothing to cascade.
      return { nextPage: inserted.source, nextSpec: null, newOid: inserted.newOid };
    }

    case 'delete': {
      // resolve once to obtain the subtree's oids + validate (incl. the baseline 409), then cut.
      const ctx = moduleContext(pageSource);
      const resolved = resolveJsxChildOp(ctx, fullScreenId, oid, 'delete', params.expect);
      if (!resolved.ok) {
        throw new StructuralNotEditableError(resolved.fail, resolved.detail, resolved.baseline);
      }
      const removedOids = new Set(resolved.oids);
      const parentOid = resolved.baseline.parentOid;
      const nextPage = deleteSubtree(pageSource, fullScreenId, oid);
      const specAfterEntries = removeSpecEntries(specSource, [...removedOids]);
      const nextSpec = removeEdgeSpecs(specAfterEntries, fullScreenId, (expr) => {
        const via = edgeViaOf(expr);
        return via !== undefined && removedOids.has(via);
      });
      return { nextPage, nextSpec: nextSpec !== specSource ? nextSpec : null, parentOid };
    }
  }

  // A switch with no `default` FALLS OFF THE END for a verb outside the union, and this function is
  // EXPORTED — so for any caller that is not the wire handler (which proves membership first), compile-time
  // totality is the whole guarantee. Returning `undefined` would surface far away as a TypeError on
  // `plan.nextPage`, outside the handler's try/catch; the assignment below is a compile error the moment an
  // arm is missing, and the throw makes the runtime failure typed and local instead.
  const unhandled: never = params;
  throw new StructuralNotEditableError(
    'internal',
    `unhandled structural wire verb ${JSON.stringify(String((unhandled as { op?: unknown }).op))}`,
  );
}

const MAX_CLASS_NAME = 20_000;
const MAX_NAME = 1_000;

/**
 * The most members a `className-batch` may carry AFTER the oid collapse (DR45-6).
 *
 * It prices PARSES, not selection size: the fold re-parses page.tsx once per surviving member inside the write lock, measured at ~2.6 ms/parse on the largest page in the corpus, so 32 collapsed members hold the lock for ~83 ms. That is the cost of "N edits, one undo" and it is stated rather than buried.
 *
  if (nodeType(node) !== 'JSXExpressionContainer') return undefined;
  const expr = node['expression'] as AnyNode | undefined;
  if (expr === undefined || nodeType(expr) !== 'BinaryExpression' || expr['operator'] !== '&&') return undefined;
  const right = peelOnceParenthesis(expr['right'] as AnyNode);
  return nodeType(right) === 'JSXElement' ? right : undefined;
}

/**
 * The adjacent ADMISSIBLE op-unit in `dir`, reachable across exactly one canonical separator and
 * bearing a well-formed oid. This ONE function computes both the D7 baseline neighbours and the
 * move swap partner, so the client's edit-map flags and the server's re-derivation cannot drift.
 * Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour.
 */
function adjacentOpUnit(
  ctx: ModuleContext,
  children: AnyNode[],
  index: number,
  dir: -1 | 1,
): { node: AnyNode; index: number; oid: string; kind: OpUnitKind } | undefined {
  const separator = separatorAt(ctx, children[index + dir]);
  if (separator === undefined || separator.kind !== 'sep') return undefined;
  const candidate = children[index + 2 * dir];
  if (candidate === undefined) return undefined;
  const kind: OpUnitKind | undefined =
    nodeType(candidate) === 'JSXElement'
      ? 'element'
      : nodeType(candidate) === 'JSXExpressionContainer'
        ? 'conditional-container'
        : undefined;
  if (kind === undefined) return undefined;
  const element = opUnitElement(candidate);
  if (element === undefined) return undefined;
  const oid = oidOrNull(ctx, element);
  if (oid === null) return undefined;
  return { node: candidate, index: index + 2 * dir, oid, kind };
}

/**
 * The live `{parentOid, prevOid, nextOid}` for a target, or `undefined` when the target does not
 * resolve to an admissible op-unit at all. The client captures this at render time and sends it back
 * as `expect`; the server re-derives it under the write lock with this same function and 409s on mismatch.
 */
export function deriveStructuralBaseline(
  ctx: ModuleContext,
  screenId: string,
  oid: string,
): StructuralBaseline | undefined {
  try {
    const loc = locateOpUnit(ctx, screenId, oid);
    return baselineFor(ctx, loc);
  } catch (e) {
    if (e instanceof RefusalSignal) return undefined;
    throw e;
  }
}

function baselineFor(ctx: ModuleContext, loc: OpUnitLocation): StructuralBaseline {
  const parentOid = nodeType(loc.parent) === 'JSXElement' ? oidOrNull(ctx, loc.parent) : null;
  return {
    parentOid,
    prevOid: adjacentOpUnit(ctx, loc.children, loc.index, -1)?.oid ?? null,
    nextOid: adjacentOpUnit(ctx, loc.children, loc.index, 1)?.oid ?? null,
  };
}

function baselineMatches(expect: StructuralBaseline, live: StructuralBaseline): boolean {
  return (
    expect.parentOid === live.parentOid && expect.prevOid === live.prevOid && expect.nextOid === live.nextOid
  );
}

// ---------------------------------------------------------------------------
// Layer 2 — the JSX child-op resolver
// ---------------------------------------------------------------------------

/** Everything a composer needs to splice, all file-local. */
export interface ResolvedJsxChildOp {
  /** The verb the CALLER named, echoed back unchanged — the wire union, because a verb the ladder has no branch for still reaches this resolver and must be refused BY it rather than rewritten on the way in. */
  readonly op: StructuralWireVerb;
  readonly opUnitSpan: ByteSpan;
  readonly opUnitKind: OpUnitKind;
  readonly opUnitNode: AnyNode;
  readonly targetElement: AnyNode;
  readonly parent: AnyNode;
  readonly parentChildren: AnyNode[];
  readonly index: number;
  /** `null` when that boundary is the parent's own open/close tag. */
  readonly leadingSeparator: ByteSpan | null;
  readonly trailingSeparator: ByteSpan | null;
  /** move-{up,down} only: the swap partner's op-unit span (never overlapping `opUnitSpan`). */
  readonly siblingSpan?: ByteSpan | undefined;
  readonly siblingIndex?: number | undefined;
  /** Every `data-oid` VALUE span (quotes included) inside the op-unit, ascending. */
  readonly oidValueSpans: readonly ByteSpan[];
  readonly oids: readonly string[];
  readonly baseline: StructuralBaseline;
}

export type ResolvedJsxChildOpResult =
  | ({ ok: true } & ResolvedJsxChildOp)
  | { ok: false; fail: StructuralRefusalReason; detail: string; baseline?: StructuralBaseline };

/**
 * Resolves `op` on an ALREADY-LOCATED op-unit. Throws {@link RefusalSignal}; never returns a failure
 * except the one that carries a payload (`stale-baseline`). Shared verbatim by the per-oid resolver
 * and the batch classifier, so the two cannot drift.
 *
 * PRECEDENCE (pinned by test), once the target is located and its bytes pass the sentinel:
 *  1. `stale-baseline` (409). A stale client is operating on a node it can no longer see; answering it
 *     with a 422 computed from source it never loaded strands it with a wrong world model and no
 *     resync payload.
 *  2. The FILE-scope non-static-`data-oid` poison ({@link scanFilePoison}). It is memoized and O(1) here,
 *     it is op-independent, and it invalidates the very identity the remaining axes reason about — so it
 *     wins over the per-target content and separator axes rather than paying for them.
 *  3. The per-target axes: content, separators, move partner.
 *  4. The FILE-scope `{...spread}` poison — the same class, arrived at indirectly. It comes LAST so that
 *     a spread the user can see keeps the reason that names it (`spread-attribute-in-subtree` on the
 *     target or in its op-unit, `unprovable-screen-scope` on an ancestor); only a spread on some OTHER
 *     element in the file surfaces as `unprovable-oid-in-file`. Eligibility is identical either way —
 *     both refuse — so the ordering buys an honest disabled-reason tooltip and costs nothing but the
 *     per-target work on a file that is pathological anyway (the corpus carries zero spreads).
 */
function resolveAtLocation(
  ctx: ModuleContext,
  loc: OpUnitLocation,
  op: StructuralWireVerb,
  expect: StructuralBaseline | undefined,
  cache: SubtreeCache | undefined,
): ResolvedJsxChildOpResult {
  const opUnitSpan = spanOf(ctx, loc.opUnit);
  assertOpUnitSentinel(ctx, opUnitSpan, loc.opUnitKind);

  const baseline = baselineFor(ctx, loc);
  if (expect !== undefined && !baselineMatches(expect, baseline)) {
    return {
      ok: false,
      fail: 'stale-baseline',
      detail: 'the element’s structural context changed since it was loaded',
      baseline,
    };
  }

  const poison = filePoison(ctx);
  if (poison.dynamicOid !== undefined) refuse('unprovable-oid-in-file', poison.dynamicOid);

  // Content axis over the WHOLE op-unit — for a conditional container that includes the condition.
  const { oidValueSpans, oids } = inspectSubtreeCached(ctx, loc.opUnit, cache);

  // D2: both boundaries are op-relevant for every op (a false-NO only disables a button).
  const leading = boundaryOf(ctx, loc.children, loc.index, -1);
  const trailing = boundaryOf(ctx, loc.children, loc.index, 1);

  let siblingSpan: ByteSpan | undefined;
  let siblingIndex: number | undefined;

  if (op === 'duplicate' || op === 'insert-after') {
    // ⚠ ONE ARM FOR BOTH VERBS, AND IT IS SHARED RATHER THAN COPIED. Two arms asserting the same condition are equal on the day they are written and free to drift on every day after; one arm cannot drift at all. That is the whole reason, and it does not depend on anything downstream existing.
    //
    // (An earlier version of this comment justified it with "the panel reads `뒤에 넣기`'s enabled state straight off `canDuplicate`, so any divergence is a lying button" — in the present tense, about a panel that did not wire this verb in any form. That was false when written and it is now false in the other direction: US-7 shipped the panel, and it reads `canInsertAfter` — NOT `canDuplicate`. `edit-map.ts` publishes `canInsertAfter` as its own field precisely so a client never has to encode the identity, and the panel honours that, so an identity break is no longer a lying button but two flags disagreeing where the artifact says they need not.)
    //
    // The new element lands on its own correctly-indented line, so a preceding canonical separator is
    // REQUIRED — a single-line parent has none and refuses rather than inventing formatting.
    if (leading.kind !== 'sep') {
      // The detail NAMES THE VERB IT IS ANSWERING. The reason CODE is shared and identical — that is the identity, and it is what the panel's `REASON_TEXT` is keyed on — but the free-text half reaches a client verbatim in the 422 body's `error`, and an `insert-after` request being told about "duplicating a copy" describes an operation the caller did not ask for.
      //
      // ⚠ IT DOES NOT REACH THE ARTIFACT, contrary to how this was first reported to me. The edit-map's `reasons` map is `Partial<Record<StructuralOp, StructuralRefusalReason>>` — codes only — so no tooltip was ever built from this string and none named the wrong verb. Verified twice: the artifact's own type, and `test/helpers/insert-classification.ts`, which already compares `reason` and not `detail` and cites this exact sentence as the reason why.
      refuse('non-canonical-separator', `${op} needs a preceding newline separator to indent the new element`);
    }
  } else if (op === 'move-up' || op === 'move-down') {
    const dir = op === 'move-up' ? -1 : 1;
    const partner = adjacentOpUnit(ctx, loc.children, loc.index, dir);
    if (partner === undefined) {
      // Distinguish "there is nothing there" from "there is something we refuse to swap with".
      const neighbour = loc.children[loc.index + 2 * dir];
      if (neighbour === undefined || boundaryOf(ctx, loc.children, loc.index, dir).kind === 'tag') {
        refuse('no-adjacent-sibling', `no sibling op-unit ${dir === -1 ? 'above' : 'below'} the target`);
      }
      refuse('unsupported-sibling', 'the adjacent sibling is not an oid-bearing admissible op-unit');
    }

    // The partner must satisfy the SAME two axes, including its own boundaries — its bytes move too.
    // Anything unprovable ABOUT THE PARTNER surfaces as `unsupported-sibling`: the user selected the
    // target, so a raw `subtree-contains-data-screen` here would name a subtree they are not looking at.
    // (The separator BETWEEN the two units was already proven canonical by `adjacentOpUnit`, and keeps
    // its own reason above; the indent comparison below is a property of the pair, not of the partner.)
    const partnerSpan = spanOf(ctx, partner.node);
    let partnerLeading: Boundary;
    try {
      assertOpUnitSentinel(ctx, partnerSpan, partner.kind);
      inspectSubtreeCached(ctx, partner.node, cache);
      partnerLeading = boundaryOf(ctx, loc.children, partner.index, -1);
      boundaryOf(ctx, loc.children, partner.index, 1);
    } catch (e) {
      if (e instanceof RefusalSignal) {
        refuse('unsupported-sibling', `the swap partner is not an admissible op-unit: ${e.message}`);
      }
      throw e;
    }

    // Unequal indentation would swap the two units into each other's depth — parse-valid damage
    // the defensive re-parse cannot see. Both leading separators must therefore exist and agree.
    if (leading.kind !== 'sep' || partnerLeading.kind !== 'sep') {
      refuse('non-canonical-separator', 'a move needs both units to carry a leading newline separator');
    }
    if (leading.indent !== partnerLeading.indent) {
      refuse(
    if (e instanceof StructuralNotEditableError) return { ok: false, fail: e.reason, detail: e.message };
    // Unknown failure → fail closed, never a best-effort mutation.
    return { ok: false, fail: 'internal', detail: (e as Error).message };
  }
}

/**
 * Resolves `op` on `oid` to concrete byte spans, proving all three axes first. TOTAL — never throws.
 *
 * Its own parent-and-sibling-tracking descent is not an accident of style: `findElementNodeByOid`
 * returns only the matched element and tracks no parent, index or siblings, so it cannot serve a
 * structural op (find-element-by-spec.ts:178-184).
 *
 * This is the O(AST)-per-call SERVER-SIDE RE-PROOF (one request, one op — the right cost there).
 * The extractor must NOT call it per (oid, op): use {@link classifyAllStructuralOps}.
 *
 * When `expect` is supplied it is compared against the freshly-derived baseline; a mismatch is a
 * `stale-baseline` refusal carrying the live baseline (the sidecar turns that into a 409 + resync).
 *
 * `op` is the WIRE union, not `StructuralOp`: the sidecar accepts `insert-after`/`insert-child` and hands them straight here, where the ladder's catch-all refuses them `internal`. That is why the sidecar needs no cast and no stub of its own — the refusal it returns is this resolver's own. **`insert-after` becomes a real verdict here the moment US-3 adds its branch; `insert-child` never does — the addressing ruling resolves it off this path entirely (see the catch-all's own comment).**
 */
export function resolveJsxChildOp(
  ctx: ModuleContext,
  screenId: string,
  oid: string,
  op: StructuralWireVerb,
  expect?: StructuralBaseline,
): ResolvedJsxChildOpResult {
  return totalize(() => resolveAtLocation(ctx, locateOpUnit(ctx, screenId, oid), op, expect, undefined));
}

// ---------------------------------------------------------------------------
// Layer 2b — the eligibility classifiers (edit-map flags; re-proven server-side)
// ---------------------------------------------------------------------------

export type StructuralEligibility =
  | { eligible: true; opUnitKind: OpUnitKind }
  | { eligible: false; reason: StructuralRefusalReason; detail: string };

function eligibilityOf(resolved: ResolvedJsxChildOpResult): StructuralEligibility {
  return resolved.ok
    ? { eligible: true, opUnitKind: resolved.opUnitKind }
    : { eligible: false, reason: resolved.fail, detail: resolved.detail };
}

/**
 * The CLOSED positive eligibility check for ONE op on ONE oid. NEVER throws.
 *
 * It is a thin projection of {@link resolveJsxChildOp} on purpose: the extractor's display flags and
 * the sidecar's write-time proof are then the SAME decision by construction, and cannot drift into a
 * button that is enabled but refuses (or, far worse, enabled and wrong).
 */
export function classifyStructuralEligibility(
  ctx: ModuleContext,
  screenId: string,
  oid: string,
  op: StructuralOp,
): StructuralEligibility {
  return eligibilityOf(resolveJsxChildOp(ctx, screenId, oid, op));
}

/** One oid's four verdicts plus its D7 baseline. `baseline` is `undefined` iff no op-unit resolves at all. */
export interface StructuralOpsEntry {
  readonly ops: Record<StructuralOp, StructuralEligibility>;
  readonly baseline: StructuralBaseline | undefined;
}
 * The preceding separator is consumed when present — including for a first element child, whose
 * preceding separator is the newline+indent that follows the parent's open tag — otherwise the
 * following one, otherwise neither (a lone same-line child). Consumption is BOUNDED BY THAT NODE'S
 * SPAN; there is no greedy byte scan, so a `&nbsp;`-bearing run can never be partially eaten.
 * Because exactly one of the two separators survives, no two JSXText runs are ever left adjacent.
 */
export function deleteSubtree(
  source: string,
  screenId: string,
  oid: string,
  expect?: StructuralBaseline,
): string {
  const ctx = moduleContext(source);
  const r = orThrow(resolveJsxChildOp(ctx, screenId, oid, 'delete', expect));
  const cut: ByteSpan =
    r.leadingSeparator !== null
      ? { start: r.leadingSeparator.start, end: r.opUnitSpan.end }
      : r.trailingSeparator !== null
        ? { start: r.opUnitSpan.start, end: r.trailingSeparator.end }
        : r.opUnitSpan;
  return cutSpan(source, cut);
}

/**
 * Swaps the op-unit with its adjacent sibling op-unit. The separators stay positionally fixed, so
 * indentation and blank lines are preserved and every `data-oid` travels byte-identically with its node.
 */
export function moveAdjacent(
  source: string,
  screenId: string,
  oid: string,
  direction: 'up' | 'down',
  expect?: StructuralBaseline,
): string {
  const ctx = moduleContext(source);
  const op: StructuralOp = direction === 'up' ? 'move-up' : 'move-down';
  const r = orThrow(resolveJsxChildOp(ctx, screenId, oid, op, expect));
  const sibling = r.siblingSpan;
  if (sibling === undefined) {
    throw new StructuralNotEditableError('internal', 'move resolved without a sibling span');
  }
  const [first, second] = r.opUnitSpan.start < sibling.start ? [r.opUnitSpan, sibling] : [sibling, r.opUnitSpan];
  return swapSpans(source, first, second);
}

export interface DuplicateResult {
  readonly source: string;
  /** The fresh oid stamped onto the copy of the TARGET element — the selection handoff target. */
  readonly newOid: string;
  /** original oid → fresh oid, for every `data-oid` in the copied subtree. */
  readonly oidMap: ReadonlyMap<string, string>;
        /* an unparseable (mid-edit) page keeps just the regex seed above */
      }
    }
    return used;
  }

  /**
   * structural edit branch (E3 v2, Phase 2 / D7) — every verb in `STRUCTURAL_WIRE_VERBS` on
   * page.tsx, addressed by `data-oid`, re-proven server-side under the write lock. Branches ABOVE the
   * terminal unknown-target guard. SHARES the shipped admission → loadManifest/resolveEditTarget →
   * path-guard → withWriteLock lifecycle, but is the FIRST TWO-FILE writer: a delete cascades into
   * spec.ts, so both new sources are computed + defensively re-parsed BEFORE any write, spec.ts is
   * written FIRST and page.tsx LAST (the page write triggers HMR on the final consistent pair), and a
   * `.sidecar-write` marker suppresses the Vite plugin's cross-process extract loop for the window.
   * Rollback is BEST-EFFORT compensation (git is the recovery of record): a failed restore yields a
   * distinct inconsistent-state 500 naming the file(s) that remain modified.
   */
  async function handleStructureEdit(body: EditBody): Promise<HandleEditResult> {
    const { screenId, oid, op, expect } = body;
    const oidValue: string | null = typeof oid === 'string' && oid.length > 0 ? oid : null;
    if (typeof screenId !== 'string' || screenId.length === 0) {
      return { status: 400, json: { ok: false, error: 'screenId must be a non-empty string' } };
    }
    if (oidValue === null) {
      return { status: 400, json: { ok: false, error: 'oid must be a non-empty string' } };
    }
    // The deny-ladder and the message it returns both read the SHIPPED verb list, so the wire vocabulary
    // and the error that reports it cannot drift apart.
    if (!isStructuralWireVerb(op)) {
      return { status: 400, json: { ok: false, error: `op must be one of ${STRUCTURAL_WIRE_VERBS.join('|')}` } };
    }
    // The `expect` parser is selected BY OP (OPEN FINDING #5). This ladder rejected `insert-child` FIRST,
    // so the unconditional parse three lines below it was never reachable for that verb — which is why the
    // two fixes cannot be split: extend one alone and the 400 simply moves.
    const parsed = parseExpectForOp(op, expect);
    if (!parsed.ok) {
      // The parser owns the WORDING as well as the verdict: "you owe a receipt" and "you must not send one"
      // are opposite instructions, and a shared message would tell half the clients the wrong thing.
      return { status: 400, json: { ok: false, error: parsed.error } };
    }
    const intent = parsed.intent;
    // The payload axis, selected by the same total switch discipline as `expect` above. It runs SECOND so
    // that a request malformed on both axes reports the receipt first, which is the older contract.
    //
    // ⚠ THE RESULT IS THREADED, AND THE NOTE HERE SAYING IT DELIBERATELY WAS NOT IS THREE STORIES STALE.
    // It read *"no verb has a composer yet, so there is nothing to hand a snippet to"* and promised the threading for US-3b. `insert-after` took it in US-3b and `insert-child` in US-8a; `parsedSnippet.snippetId` is passed into `computeStructuralEdit` a few dozen lines below and both insert arms hand it to their composer, which is the whole reason `parseSnippetForOp` rejects an unknown key before any write.
    // What the original note was right about, and the reason validation still lives HERE rather than in the engine: the wire proves membership so the composer never sees a non-key, and the two ends agree on what a payload is by using the same `isSnippetId` test.
    const parsedSnippet = parseSnippetForOp(intent.op, body.snippetId);
    if (!parsedSnippet.ok) {
      return { status: 400, json: { ok: false, error: parsedSnippet.error } };
    }
    // Named for what it is — a WIRE verb, not a `StructuralOp`. `insert-child` is not one and must never become one.
    const wireOp = intent.op;

    // Resolve the page.tsx + spec.ts + full screenId from the validated manifest (no specId — resolvable
    // from screenId alone, incl. a `::` modal suffix for partition scoping).
    const loaded = await loadManifest({ repoRoot });
    if (!loaded.ok) {
      return { status: 500, json: { ok: false, error: loaded.error } };
    }
    const resolved = resolveEditTarget(loaded.data, screenId, undefined);
    if (resolved === null) {
      return unresolvedEditTarget(screenId);
    }

    // Path-traversal guard: BOTH resolved files MUST stay under <repoRoot>/src/app.
    const absPage = path.resolve(repoRoot, resolved.pageRelPath);
    if (absPage !== appRoot && !absPage.startsWith(appRoot + path.sep)) {
      return { status: 400, json: { ok: false, error: 'resolved page path escapes src/app' } };
    }
    const absSpec = path.resolve(repoRoot, resolved.specRelPath);
    if (absSpec !== appRoot && !absSpec.startsWith(appRoot + path.sep)) {
      return { status: 400, json: { ok: false, error: 'resolved spec path escapes src/app' } };
    }

    // The two writes go through the choke point (D1): commitWrite owns the lock, pre-images and CASes BOTH
    // declared files, writes spec.ts first / page.tsx last (g5), and on failure NAMES every file left
    // modified (g6). computeStructuralEdit moves into prepare, computing BOTH sources under the lock.
    let plan: StructuralWritePlan | null = null;
    const outcome = await commitWrite(
        { files: [absSpec, absPage], subject: structureSubjectFor(intent.op, screenId, oidValue), journal: { mode: 'push' } },
        (pre): PrepareResult => {
          const pageSource = pre.get(absPage) as string;
          const specSource = pre.get(absSpec) as string;
          // duplicate mints corpus-unique oids — seed across the whole app BEFORE generating.
          // EVERY VERB THAT MINTS AN OID PAYS THE CORPUS SEED, and the condition is written as that
          // property rather than as a list of verbs. `duplicate` re-stamps the oids it copied; an insert
          // mints one for a registry snippet, which carries none by construction. Minting against an empty
          // set can produce an oid that ALREADY EXISTS in another file — and the damage is not at insert
          // time: it surfaces when a LATER edit resolves that oid and lands on an element the user never
          // selected, which reads as a targeting bug rather than an insert bug. Two independent review lanes
          // found this seeding gap before the composer existed.
          const usedOids = mintsFreshOid(wireOp) ? seedCorpusUsedOids() : new Set<string>();
          try {
            // The verb and its `expect` are spread from ONE value, so the pair the parser proved cannot be
            // taken apart and recombined here.
            plan = computeStructuralEdit({
              ...intent,
              snippetId: parsedSnippet.snippetId,
              pageSource,
              specSource,
              fullScreenId: resolved.fullScreenId,
              oid: oidValue,
              usedOids,
            });
          } catch (err) {
            if (err instanceof StructuralNotEditableError) {
              if (err.reason === 'stale-baseline') {
                // 409 lost update — echo the LIVE baseline as the resync payload (D7).
                return {
                  ok: false,
                  status: 409,
                  reason: err.reason,
                  json: { ok: false, screenId, oid: oidValue, op: wireOp, error: err.message, staleStructure: true, baseline: err.baseline ?? null },
                };
              }
              // 422 — a typed refusal (ineligible shape / content / separator / not found / …).
              return {
                ok: false,
                status: 422,
                reason: err.reason,

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '440,575p' packages/descvi/src/sidecar/server.ts
sed -n '1800,1875p' packages/descvi/src/sidecar/server.ts
sed -n '1200,1235p' packages/descvi/src/extractor/structural-edit.ts
sed -n '1530,1640p' packages/descvi/src/extractor/structural-edit.ts
sed -n '1690,1765p' packages/descvi/src/extractor/structural-edit.ts
sed -n '780,845p' packages/descvi/src/extractor/structural-edit.ts" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
interface StructuralWritePlan {
  readonly nextPage: string;
  /** `null` when spec.ts is unchanged (move / duplicate / a delete that touches no spec entry or edge). */
  readonly nextSpec: string | null;
  /**
   * The selection-handoff target — the oid a MINTING verb produced, and there are THREE of them: `duplicate` (the copy's re-stamped ROOT oid), `insert-after` and `insert-child` (the snippet's minted oid).
   *
   * ⚠ IT SAID "duplicate:" UNTIL US-8b, WHICH WAS TRUE WHEN WRITTEN AND WRONG FOR TWO STORIES. The set of verbs that return this field is exactly the set `mintsFreshOid` names, and that is not a coincidence to be restated in prose: a verb returning `newOid` without joining that predicate composes against an EMPTY used-oid set and can mint an oid that already lives in another file. `test/gate/insert-after-composer.test.ts` derives the two sets from the engine and compares them, so the coupling is gated rather than documented.
   */
  readonly newOid?: string;
  /** delete: the parent op-unit's oid (the selection-handoff fallback). */
  readonly parentOid?: string | null;
}

/**
 * Computes BOTH new sources for a structural op WITHOUT touching the filesystem, re-proving the op
 * against the LIVE (write-locked) source. Throws {@link StructuralNotEditableError} — with the typed
 * reason, and the live baseline for `stale-baseline` — on any refusal, so a refusal writes NOTHING.
 *
 * DELETE additionally sweeps spec.ts: every oid in the cut subtree loses its component entry
 * ({@link removeSpecEntries}, multi-doc), and every spec-declared edge whose `via` is a deleted oid is
 * cascade-removed ({@link removeEdgeSpecs}). Native `<Link>`/`<a>`/`router.push` edges disappear on their
 * own when the page subtree is cut (they are re-derived from page.tsx), and the Phase-1B `mergeEdges`
 * downgrade keeps any residual dangle (e.g. a suppress whose native lived in the subtree) a WARNING, not
 * an extraction crash. Both new sources are defensively re-parsed by the composers before return.
 *
 * `op` is the WIRE union rather than `StructuralOp`, and it is widened rather than cast: the two insert verbs are real wire input that is NOT a `StructuralOp`, so the parameter has to admit them honestly instead of pretending they are members of a union they are permanently outside.
 *
 * ⚠ THE OLD REASON FOR THE WIDENING — *"this handler does not compose for them, so they reach the engine and come back as its own typed refusal"* — IS DEAD AS OF US-8a. Both insert arms compose here now. The widening survives for a reason that never depended on refusal: `insert-child` is not and will not be a `StructuralOp` (`edit-map.ts` iterates that array to publish one flag per op, and this verb's verdict comes from its own `resolveInsertChild` descent instead), so the wire's six-verb vocabulary and the ladder's five-verb one are genuinely different types. A cast would have claimed they are the same.
 *
 * ⚠ THE TOTALITY THAT MAKES THAT SAFE IS `resolveAtLocation`'s, NOT THIS FUNCTION'S — and it is only
 * reached because the switch below hands the resolver the op the CALLER named. Before this change the
 * delete tail passed a hardcoded `'delete'`, so widening this parameter alone would not have produced a
 * refusal at all: an `insert-child` request would have been resolved AS A DELETE and answered 200 with the
 * element cut. Measured, not reasoned — `test/gate/insert-wire-contract.test.ts` was watched RED against
 * exactly that shape and reported the removed `<li>` as a byte diff.
 */
export function computeStructuralEdit(
  params: StructuralEditIntent & {
    pageSource: string;
    specSource: string;
    fullScreenId: string;
    oid: string;
    usedOids: Set<string>;
    /** The palette key the wire validated, or `null` for the verbs that carry no payload. Resolved to TEXT only inside the composer, so the sidecar never holds snippet source. */
    snippetId: SnippetId | null;
  },
): StructuralWritePlan {
  const { pageSource, specSource, fullScreenId, oid, usedOids } = params;

  // A TOTAL switch, and the totality is load-bearing rather than tidy: this used to fall THROUGH to a
  // delete tail that passed a hardcoded `'delete'` to the resolver, so a verb reaching it by accident
  // would have been resolved and CUT — a 200 that deletes the element the caller asked to insert into.
  // A verb with no arm here is now a compile error instead.
  switch (params.op) {
    case 'move-up':
    case 'move-down': {
      const nextPage = moveAdjacent(pageSource, fullScreenId, oid, params.op === 'move-up' ? 'up' : 'down', params.expect);
      return { nextPage, nextSpec: null };
    }

    case 'duplicate': {
      const dup = duplicateSubtree(pageSource, fullScreenId, oid, usedOids, { expect: params.expect });
      return { nextPage: dup.source, nextSpec: null, newOid: dup.newOid };
    }

    case 'insert-after': {
      // ⚠ THE WHOLE VERB IS ONE CALL, and that is the design rather than brevity. `insertAfterOpUnit` is
      // `duplicateSubtree` with the copied bytes swapped for a registry snippet: the same `resolveJsxChildOp`
      // in the same shipped precedence, an op-ladder arm literally SHARED with `duplicate`, and a separator
      // the resolver proved. (US-7's panel reads `canInsertAfter` rather than `canDuplicate`; the identity stays the engine's own.) It is
      // load-bearing and the corpus gate asserts it — booleans AND reason strings.
      if (!isSnippetId(params.snippetId)) {
        // Unreachable from the wire, which validates the payload for this verb before the engine is reached.
        // Kept as a typed refusal because this function is EXPORTED, and written as `!isSnippetId` rather than
        // `=== null` for a reason found by running it: a non-handler caller reaching this with `undefined` (or
        // any non-key) slipped past a null check and reached `snippetById`, which throws a PLAIN `Error` — and
        // a plain error out of `prepare` is a 500, not the typed 422 every other refusal on this path produces.
        // The membership test is the same one the wire uses, so both ends agree on what a payload is.
        throw new StructuralNotEditableError('internal', `insert-after needs a valid snippetId, got ${JSON.stringify(params.snippetId ?? null)}`);
      }
      const inserted = insertAfterOpUnit(pageSource, fullScreenId, oid, params.snippetId, usedOids, { expect: params.expect });
      // page.tsx ONLY. A bare oid never reaches `components[]` (`assemble.ts:98-105`), so the new element is
      // artifact-invisible until it is named — there is no spec entry to create and nothing to cascade.
      return { nextPage: inserted.source, nextSpec: null, newOid: inserted.newOid };
    }

    case 'insert-child': {
      // ⚠ THIS CALL IS NOT `resolveJsxChildOp`, AND THE SUBSTITUTION IS THE WHOLE OF US-4. The addressing
      // ruling takes `insert-child` off that path entirely, so it inherits nothing: `resolveInsertChild`
      // assembles its own identity (`findTargets`, never `locateOpUnitAt`, whose `target-bears-data-screen`
      // refusal is correct for the five shipped ops and WRONG for a page root the user is legitimately
      // inserting into), its own explicit `filePoison` consultation, its own closing-tag POSITION sentinel,
      // and its own trailing-gap proof. Until US-4 this arm ran the op ladder and every subject that got as
      // far as the ladder came back `internal`.
      //
      // ⚠ AND THIS ARM IS NOW WIRED (US-8a).
      // Until it was, the verb refused on EVERY input and only WHICH refusal changed: a parent the admission rejects draws the reason for its own shape (`child-region-ends-in-text`, `non-canonical-separator`, `unprovable-child-indent`, `self-closing-parent`), and a parent it ADMITS drew an `internal` stub reading "admitted, and there is nothing here to write it with".
      // That stub is deleted here rather than reworded, because an admitted parent now composes.
      // What must NOT come back is the shape it replaced: a verb whose admission passes with no composition behind it falling through into another verb's tail — the pre-US-1 form of this handler did exactly that, with a hardcoded `'delete'`, and answered 200 having cut the element the caller asked to insert into.
      //
      // `insertChildAtEnd` re-runs `resolveInsertChild` itself and throws the same typed refusal, so the admission is not consulted twice here.
      // That is the same shape `insert-after` has — `insertAfterOpUnit` owns its own resolve — and it is what keeps the admission and the composition from being able to disagree about the target: they are one call, over one parse.
      if (!isSnippetId(params.snippetId)) {
        // Unreachable from the wire, which validates the payload for this verb before the engine is reached — the same typed refusal `insert-after` above keeps, for the same reason: this function is EXPORTED, and a non-handler caller reaching `snippetById` with a non-key gets a PLAIN `Error`, which is a 500 rather than the typed 422 every other refusal on this path produces.
        throw new StructuralNotEditableError('internal', `insert-child needs a valid snippetId, got ${JSON.stringify(params.snippetId ?? null)}`);
      }
      const inserted = insertChildAtEnd(pageSource, fullScreenId, oid, params.snippetId, usedOids);
      // page.tsx ONLY, exactly as `insert-after` is: a bare oid never reaches `components[]` (`assemble.ts:98-105`), so the new element is artifact-invisible until it is named — there is no spec entry to create and nothing to cascade.
      return { nextPage: inserted.source, nextSpec: null, newOid: inserted.newOid };
    }

    case 'delete': {
      // resolve once to obtain the subtree's oids + validate (incl. the baseline 409), then cut.
      const ctx = moduleContext(pageSource);
      const resolved = resolveJsxChildOp(ctx, fullScreenId, oid, 'delete', params.expect);
      if (!resolved.ok) {
        throw new StructuralNotEditableError(resolved.fail, resolved.detail, resolved.baseline);
      }
      const removedOids = new Set(resolved.oids);
      const parentOid = resolved.baseline.parentOid;
      const nextPage = deleteSubtree(pageSource, fullScreenId, oid);
      const specAfterEntries = removeSpecEntries(specSource, [...removedOids]);
      const nextSpec = removeEdgeSpecs(specAfterEntries, fullScreenId, (expr) => {
        const via = edgeViaOf(expr);
        return via !== undefined && removedOids.has(via);
      });
      return { nextPage, nextSpec: nextSpec !== specSource ? nextSpec : null, parentOid };
    }
  }

  // A switch with no `default` FALLS OFF THE END for a verb outside the union, and this function is
  // EXPORTED — so for any caller that is not the wire handler (which proves membership first), compile-time
  // totality is the whole guarantee. Returning `undefined` would surface far away as a TypeError on
  // `plan.nextPage`, outside the handler's try/catch; the assignment below is a compile error the moment an
  // arm is missing, and the throw makes the runtime failure typed and local instead.
          // selected, which reads as a targeting bug rather than an insert bug. Two independent review lanes
          // found this seeding gap before the composer existed.
          const usedOids = mintsFreshOid(wireOp) ? seedCorpusUsedOids() : new Set<string>();
          try {
            // The verb and its `expect` are spread from ONE value, so the pair the parser proved cannot be
            // taken apart and recombined here.
            plan = computeStructuralEdit({
              ...intent,
              snippetId: parsedSnippet.snippetId,
              pageSource,
              specSource,
              fullScreenId: resolved.fullScreenId,
              oid: oidValue,
              usedOids,
            });
          } catch (err) {
            if (err instanceof StructuralNotEditableError) {
              if (err.reason === 'stale-baseline') {
                // 409 lost update — echo the LIVE baseline as the resync payload (D7).
                return {
                  ok: false,
                  status: 409,
                  reason: err.reason,
                  json: { ok: false, screenId, oid: oidValue, op: wireOp, error: err.message, staleStructure: true, baseline: err.baseline ?? null },
                };
              }
              // 422 — a typed refusal (ineligible shape / content / separator / not found / …).
              return {
                ok: false,
                status: 422,
                reason: err.reason,
                json: { ok: false, screenId, oid: oidValue, op: wireOp, error: err.message, reason: err.reason },
              };
            }
            return {
              ok: false,
              status: 422,
              reason: 'engine-error',
              json: { ok: false, screenId, oid: oidValue, op: wireOp, error: String((err as Error).message ?? err) },
            };
          }
          // The EFFECTIVE set: page.tsx always; spec.ts ONLY when the delete cascade changed it. A bare
          // delete DECLARES spec (it is pre-imaged and CAS'd) but does not WRITE it — next ⊆ files, never
          // files ⊆ next (D4).
          const next = new Map<string, string>([[absPage, plan.nextPage]]);
          if (plan.nextSpec !== null) next.set(absSpec, plan.nextSpec);
          return { ok: true, next };
        },
        writeDeps(loaded.data),
      );

    return renderStructureOutcome(outcome, {
        echo: { screenId, oid: oidValue, op: wireOp },
        specRelPath: resolved.specRelPath,
        pageRelPath: resolved.pageRelPath,
        onSuccess: () => {
          // op-specific handoff keys — newOid (any verb that MINTED one) / parentOid (delete).
          //
          // ⚠ `newOid` IS KEYED ON THE PLAN, NOT ON THE VERB, and that is a correction rather than a tidy-up.
          // It read `wireOp === 'duplicate' && …`, so `insert-after` minted an oid, wrote it to disk and
          // answered 200 WITHOUT echoing it — leaving the panel unable to reselect the element it had just
          // created, which is the one thing the handoff key exists for. The condition now says what it means:
          // if this write minted an oid, the client is told which.
          const json: Record<string, unknown> = { ok: true, screenId, oid: oidValue, target: 'structure', op: wireOp };
          if (plan?.newOid !== undefined) json['newOid'] = plan.newOid;
          // ⚠ `parentOid` STAYS VERB-KEYED, and that is a contract rather than the line we did not get to —
          // it is deliberately NOT the shape corrected one line above. A delete must emit this key EVEN WHEN
          // THE VALUE IS NULL, so the client can tell "deleted a root, which had no parent" from "this was not
          // a delete at all". Plan-keying it (`plan?.parentOid !== undefined`) would silently drop the key on
          // exactly the null case, collapsing those two into one. Gated: a delete of a parentless subject is
          // asserted to emit `parentOid: null` rather than to omit it.
          if (wireOp === 'delete') json['parentOid'] = plan?.parentOid ?? null;
          return json;
        },
    });
  }
}

// ---------------------------------------------------------------------------
// Shape axis (plan D3) — the target's parent / container form
// ---------------------------------------------------------------------------

export type OpUnitKind = 'element' | 'conditional-container';
export type StructuralOp = 'delete' | 'move-up' | 'move-down' | 'duplicate' | 'insert-after';

export const STRUCTURAL_OPS: readonly StructuralOp[] = ['delete', 'move-up', 'move-down', 'duplicate', 'insert-after'];

/**
 * The verbs the WIRE accepts — a strict SUPERSET of {@link StructuralOp}, and deliberately a separate type rather than an extension of it.
 *
 * `'insert-child'` must NEVER join `StructuralOp` (plan OPEN FINDING #4). `STRUCTURAL_OPS` is what `edit-map.ts` iterates to publish one eligibility flag per op, so a member whose resolver branch does not exist would ship a flag derived from the op ladder's `internal` catch-all — an artifact stating a verdict nothing computed. It is also the one verb that carries no {@link StructuralBaseline} at all: the client names a container plus an intent ("at the end"), never a coordinate, so there is nothing that can go stale.
 *
 * ⚠ AND THE ARTIFACT DOES NOW STATE THIS VERB'S VERDICT — WITHOUT THE UNION MEMBERSHIP, WHICH IS THE POINT. OPEN FINDING #4 was closed in US-8b by giving `StructureEntry` its own `canInsertChild` + `insertChildReason` fields, fed by a per-oid {@link resolveInsertChild} descent that runs BESIDE the op-ladder sweep rather than inside it. So "not a `StructuralOp`" never meant "unpublishable"; it meant the verdict cannot come from the ladder, and the fix was a second source of truth for one field rather than a sixth member here. Anyone tempted to add the member to shorten the emitter is undoing that.
 *
 * `'insert-after'` USED to be listed here explicitly, for the same reason and only until it had one: joining `StructuralOp` without a resolver branch would have published a `canInsertAfter` derived from that catch-all. US-3b landed the branch, the composer and the flag together, so it joined and this union collapsed as planned — which leaves `'insert-child'` as the only member that is a wire verb and not a `StructuralOp`, and for it that is PERMANENT rather than transitional.
 */
export type StructuralWireVerb = StructuralOp | 'insert-child';

/**
 * ⚠ THE SPREAD IS WHY `'insert-after'` HAD TO LEAVE THIS LINE IN THE SAME CHANGE THAT JOINED IT TO
 * `STRUCTURAL_OPS`, and it did. The union above tolerates a redundant member silently (`StructuralOp |
 * 'insert-after'` is just `StructuralOp` once it joins); this ARRAY does not — it would have carried the verb
 * TWICE and the wire advertises the duplicate verbatim in its own deny-ladder message
 * (`op must be one of …|insert-after|insert-after|…`). The type system cannot see it, since a
 * `readonly StructuralWireVerb[]` is happy with any multiset. What caught it, exactly as designed, was
 * `test/gate/insert-wire-contract.test.ts`'s literal pin on this array plus its duplicate-freeness
 * assertion. **The same hazard binds whoever lands `'insert-child'`.**
 */
export const STRUCTURAL_WIRE_VERBS: readonly StructuralWireVerb[] = [...STRUCTURAL_OPS, 'insert-child'];

/** True for a node that owns a plain JSX children list. */
function isChildrenBearing(node: AnyNode | undefined): boolean {
  const neighbour = children[index + dir];
  const boundary = separatorAt(ctx, neighbour);
  if (boundary === undefined) {
    refuse(
      'non-canonical-separator',
      `the ${dir === -1 ? 'leading' : 'trailing'} boundary of the op-unit is a ${String(nodeType(neighbour))}, ` +
        'not a newline-bearing whitespace separator',
    );
  }
  return boundary;
}

// ---------------------------------------------------------------------------
// Baseline (plan D7) + move partner
// ---------------------------------------------------------------------------

/** The `expect` structural staleness baseline. `null` means "no admissible op-unit in that direction". */
export interface StructuralBaseline {
  readonly parentOid: string | null;
  readonly prevOid: string | null;
  readonly nextOid: string | null;
}

/**
 * The op-unit's own oid-bearing element (the element itself, or the container's result element).
 *
 * Exported for resume-condition 3b, and it is the function an `insertedSpan` obligation is stated against: for a bare element the op-unit span is the element's, for a `{cond && <El/>}` insertion it is the CONTAINER's, which strictly contains the element's. A gate that has to invert that relation must reach this function rather than model it.
 */
export function opUnitElement(node: AnyNode): AnyNode | undefined {
  if (nodeType(node) === 'JSXElement') return node;
  if (nodeType(node) !== 'JSXExpressionContainer') return undefined;
  const expr = node['expression'] as AnyNode | undefined;
  if (expr === undefined || nodeType(expr) !== 'BinaryExpression' || expr['operator'] !== '&&') return undefined;
  const right = peelOnceParenthesis(expr['right'] as AnyNode);
  return nodeType(right) === 'JSXElement' ? right : undefined;
}

/**
 * The adjacent ADMISSIBLE op-unit in `dir`, reachable across exactly one canonical separator and
 * bearing a well-formed oid. This ONE function computes both the D7 baseline neighbours and the
 * move swap partner, so the client's edit-map flags and the server's re-derivation cannot drift.
 * Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour.
 */
function adjacentOpUnit(
  ctx: ModuleContext,
  children: AnyNode[],
  index: number,
  dir: -1 | 1,
): { node: AnyNode; index: number; oid: string; kind: OpUnitKind } | undefined {
  const separator = separatorAt(ctx, children[index + dir]);
  if (separator === undefined || separator.kind !== 'sep') return undefined;
  const candidate = children[index + 2 * dir];
  if (candidate === undefined) return undefined;
  const kind: OpUnitKind | undefined =
    nodeType(candidate) === 'JSXElement'
      ? 'element'
      : nodeType(candidate) === 'JSXExpressionContainer'
        ? 'conditional-container'
        : undefined;
  if (kind === undefined) return undefined;
  const element = opUnitElement(candidate);
  if (element === undefined) return undefined;
  const oid = oidOrNull(ctx, element);
  if (oid === null) return undefined;
  return { node: candidate, index: index + 2 * dir, oid, kind };
}

/**
 * The live `{parentOid, prevOid, nextOid}` for a target, or `undefined` when the target does not
 * resolve to an admissible op-unit at all. The client captures this at render time and sends it back
 * as `expect`; the server re-derives it under the write lock with this same function and 409s on mismatch.
 */
export function deriveStructuralBaseline(
  ctx: ModuleContext,
  screenId: string,
  oid: string,
): StructuralBaseline | undefined {
  try {
    const loc = locateOpUnit(ctx, screenId, oid);
    return baselineFor(ctx, loc);
  } catch (e) {
    if (e instanceof RefusalSignal) return undefined;
    throw e;
  }
}

function baselineFor(ctx: ModuleContext, loc: OpUnitLocation): StructuralBaseline {
  const parentOid = nodeType(loc.parent) === 'JSXElement' ? oidOrNull(ctx, loc.parent) : null;
  return {
    parentOid,
    prevOid: adjacentOpUnit(ctx, loc.children, loc.index, -1)?.oid ?? null,
    nextOid: adjacentOpUnit(ctx, loc.children, loc.index, 1)?.oid ?? null,
  };
}

function baselineMatches(expect: StructuralBaseline, live: StructuralBaseline): boolean {
  return (
    expect.parentOid === live.parentOid && expect.prevOid === live.prevOid && expect.nextOid === live.nextOid
  );
}

// ---------------------------------------------------------------------------
// Layer 2 — the JSX child-op resolver
// ---------------------------------------------------------------------------

/** Everything a composer needs to splice, all file-local. */
export interface ResolvedJsxChildOp {
  /** The verb the CALLER named, echoed back unchanged — the wire union, because a verb the ladder has no branch for still reaches this resolver and must be refused BY it rather than rewritten on the way in. */
  readonly op: StructuralWireVerb;
  readonly opUnitSpan: ByteSpan;
  readonly opUnitKind: OpUnitKind;
  assertOpUnitSentinel(ctx, opUnitSpan, loc.opUnitKind);

  const baseline = baselineFor(ctx, loc);
  if (expect !== undefined && !baselineMatches(expect, baseline)) {
    return {
      ok: false,
      fail: 'stale-baseline',
      detail: 'the element’s structural context changed since it was loaded',
      baseline,
    };
  }

  const poison = filePoison(ctx);
  if (poison.dynamicOid !== undefined) refuse('unprovable-oid-in-file', poison.dynamicOid);

  // Content axis over the WHOLE op-unit — for a conditional container that includes the condition.
  const { oidValueSpans, oids } = inspectSubtreeCached(ctx, loc.opUnit, cache);

  // D2: both boundaries are op-relevant for every op (a false-NO only disables a button).
  const leading = boundaryOf(ctx, loc.children, loc.index, -1);
  const trailing = boundaryOf(ctx, loc.children, loc.index, 1);

  let siblingSpan: ByteSpan | undefined;
  let siblingIndex: number | undefined;

  if (op === 'duplicate' || op === 'insert-after') {
    // ⚠ ONE ARM FOR BOTH VERBS, AND IT IS SHARED RATHER THAN COPIED. Two arms asserting the same condition are equal on the day they are written and free to drift on every day after; one arm cannot drift at all. That is the whole reason, and it does not depend on anything downstream existing.
    //
    // (An earlier version of this comment justified it with "the panel reads `뒤에 넣기`'s enabled state straight off `canDuplicate`, so any divergence is a lying button" — in the present tense, about a panel that did not wire this verb in any form. That was false when written and it is now false in the other direction: US-7 shipped the panel, and it reads `canInsertAfter` — NOT `canDuplicate`. `edit-map.ts` publishes `canInsertAfter` as its own field precisely so a client never has to encode the identity, and the panel honours that, so an identity break is no longer a lying button but two flags disagreeing where the artifact says they need not.)
    //
    // The new element lands on its own correctly-indented line, so a preceding canonical separator is
    // REQUIRED — a single-line parent has none and refuses rather than inventing formatting.
    if (leading.kind !== 'sep') {
      // The detail NAMES THE VERB IT IS ANSWERING. The reason CODE is shared and identical — that is the identity, and it is what the panel's `REASON_TEXT` is keyed on — but the free-text half reaches a client verbatim in the 422 body's `error`, and an `insert-after` request being told about "duplicating a copy" describes an operation the caller did not ask for.
      //
      // ⚠ IT DOES NOT REACH THE ARTIFACT, contrary to how this was first reported to me. The edit-map's `reasons` map is `Partial<Record<StructuralOp, StructuralRefusalReason>>` — codes only — so no tooltip was ever built from this string and none named the wrong verb. Verified twice: the artifact's own type, and `test/helpers/insert-classification.ts`, which already compares `reason` and not `detail` and cites this exact sentence as the reason why.
      refuse('non-canonical-separator', `${op} needs a preceding newline separator to indent the new element`);
    }
  } else if (op === 'move-up' || op === 'move-down') {
    const dir = op === 'move-up' ? -1 : 1;
    const partner = adjacentOpUnit(ctx, loc.children, loc.index, dir);
    if (partner === undefined) {
      // Distinguish "there is nothing there" from "there is something we refuse to swap with".
      const neighbour = loc.children[loc.index + 2 * dir];
      if (neighbour === undefined || boundaryOf(ctx, loc.children, loc.index, dir).kind === 'tag') {
        refuse('no-adjacent-sibling', `no sibling op-unit ${dir === -1 ? 'above' : 'below'} the target`);
      }
      refuse('unsupported-sibling', 'the adjacent sibling is not an oid-bearing admissible op-unit');
    }

    // The partner must satisfy the SAME two axes, including its own boundaries — its bytes move too.
    // Anything unprovable ABOUT THE PARTNER surfaces as `unsupported-sibling`: the user selected the
    // target, so a raw `subtree-contains-data-screen` here would name a subtree they are not looking at.
    // (The separator BETWEEN the two units was already proven canonical by `adjacentOpUnit`, and keeps
    // its own reason above; the indent comparison below is a property of the pair, not of the partner.)
    const partnerSpan = spanOf(ctx, partner.node);
    let partnerLeading: Boundary;
    try {
      assertOpUnitSentinel(ctx, partnerSpan, partner.kind);
      inspectSubtreeCached(ctx, partner.node, cache);
      partnerLeading = boundaryOf(ctx, loc.children, partner.index, -1);
      boundaryOf(ctx, loc.children, partner.index, 1);
    } catch (e) {
      if (e instanceof RefusalSignal) {
        refuse('unsupported-sibling', `the swap partner is not an admissible op-unit: ${e.message}`);
      }
      throw e;
    }

    // Unequal indentation would swap the two units into each other's depth — parse-valid damage
    // the defensive re-parse cannot see. Both leading separators must therefore exist and agree.
    if (leading.kind !== 'sep' || partnerLeading.kind !== 'sep') {
      refuse('non-canonical-separator', 'a move needs both units to carry a leading newline separator');
    }
    if (leading.indent !== partnerLeading.indent) {
      refuse(
    const matched = new Set<number>();
    for (let i = 0; i < elements.length; i++) {
      const expression = plainArrayElementExpression(elements[i]);
      if (expression !== undefined && predicate(expression)) matched.add(i);
    }
    // `prevRemoved` lets the LAST element's cut take its own trailing comma when the predecessor is also
    // removed, instead of orphaning it (mirrors removeSpecEntries).
    for (const i of matched) spans.push(arrayElementSpan(ctx, array, i, matched.has(i - 1)));
  }
  // Adjacent selected elements each include the shared separator, so their spans touch/overlap; sort +
  // coalesce into a disjoint set before the single cut (mirrors removeSpecEntries).
  return spans.length === 0 ? specSource : cutSpans(specSource, mergeSpans(spans));
}

/** Inserts `text` at the file-local byte offset `pos`. `pos === byteLength` appends. */
export function insertTextAt(source: string, pos: number, text: string): string {
  const buf = Buffer.from(source, 'utf8');
  assertSpanInBounds(buf, { start: pos, end: pos }, 'insert');
  const out = Buffer.concat([
    buf.subarray(0, pos),
    Buffer.from(text, 'utf8'),
    buf.subarray(pos),
  ]).toString('utf8');
  return reparseOrThrow(out);
}

// ⚠ A `replaceSpan` CUT-AND-SPLICE PRIMITIVE LIVED HERE AND WAS DELETED WITH THE COMPOSITION THAT NEEDED IT. `insert-child`'s first form re-emitted the parent's trailing separator around the new element, which is a range replacement; the shipped form inserts BEFORE that separator and leaves it alone, which `insertTextAt` already expresses. The primitive then had no caller, and an unused primitive carrying its own gate is a branch with no live subject — the shape this round keeps finding rotted. If a verb ever genuinely needs to replace a range, write it back with its consumer rather than ahead of one; the module's four span primitives (`cutSpan`, `cutSpans`, `insertTextAt`, `swapSpans`) are the set every shipped verb has needed so far.

/**
 * Swaps two disjoint spans, `a` strictly before `b`: `prefix + B + between + A + suffix`.
 * The bytes BETWEEN them (the separators) stay positionally fixed — that is what makes a move
 * preserve indentation and blank lines without any reformatting.
 */
export function swapSpans(source: string, a: ByteSpan, b: ByteSpan): string {
  const buf = Buffer.from(source, 'utf8');
  assertSpanInBounds(buf, a, 'swap-a');
  assertSpanInBounds(buf, b, 'swap-b');
  if (a.end > b.start) {
    throw new StructuralNotEditableError(
      'span-sentinel-failed',
      `swapSpans requires a before b — got [${a.start}, ${a.end}) and [${b.start}, ${b.end})`,
    );
  }
  const out = Buffer.concat([
    buf.subarray(0, a.start),
    buf.subarray(b.start, b.end),
    buf.subarray(a.end, b.start),
    buf.subarray(a.start, a.end),
    buf.subarray(b.end),
  ]).toString('utf8');
  return reparseOrThrow(out);
}

// ---------------------------------------------------------------------------
// Attribute readers
// ---------------------------------------------------------------------------

/** A JSX attribute's plain identifier name (`JSXNamespacedName` → undefined; it is never `data-*`). */
function attrName(attr: AnyNode): string | undefined {
  const n = attr['name'];
  if (nodeType(n) !== 'Identifier') return undefined;
  const v = (n as AnyNode)['value'];
  return typeof v === 'string' ? v : undefined;
}

function openingOf(node: AnyNode): AnyNode | undefined {

hook: PostToolUse
hook: PostToolUse Completed
codex
서버 계약에서 즉시 검증할 가치가 있는 경계가 하나 보입니다. self-anchor 외에도 다른 sibling을 anchor로 삼아 현재 위치를 그대로 표현하는 receipt가 존재합니다(예: `[A,B,C]`에서 B를 `trailing(A)` 또는 `leading(C)`로 지정). 계획의 “direction-disagreement 400”이 0-displacement까지 명시적으로 포함하는지와 게이트가 이를 RED로 만들 수 있는지를 exhaustive model로 확인하겠습니다. 동시에 refusal 문구에서는 “flex로 바꾸면 가능”이 실제로 충분조건인지 shipped eligibility 순서와 대조하겠습니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node - <<'NODE'
function destination(chain, subject, anchor, side) {
  const without = chain.filter(x => x "'!== subject);
  const ai = without.indexOf(anchor);
  if (ai < 0) throw new Error('"'missing anchor');
  const ni = ai + (side === 'trailing' ? 1 : 0);
  const out = [...without.slice(0, ni), subject, ...without.slice(ni)];
  return {out, oldIndex: chain.indexOf(subject), newIndex: out.indexOf(subject)};
}
let valid=0, noopNonSelf=[];
for (let n=2;n<=7;n++) {
  const chain=Array.from({length:n},(_,i)=>String.fromCharCode(65+i));
  for (const subject of chain) for (const anchor of chain) for (const side of ['leading','trailing']) {
    if (anchor===subject) continue;
    const r=destination(chain,subject,anchor,side); valid++;
    if (r.oldIndex===r.newIndex) noopNonSelf.push({chain:chain.join(''),subject,anchor,side,index:r.oldIndex});
    const appliedK=Math.abs(r.out.indexOf(subject)-chain.indexOf(subject));
    if (appliedK"'!==Math.abs(r.newIndex-r.oldIndex)) throw new Error('"'k recovery failed');
  }
}
// Positive control: deliberately use the anchor index before subject removal; this must disagree somewhere.
let badFormulaCaught=0;
for (let n=2;n<=7;n++) {
  const chain=Array.from({length:n},(_,i)=>String.fromCharCode(65+i));
  for (const subject of chain) for (const anchor of chain) for (const side of ['leading','trailing']) {
    if(anchor===subject) continue;
    const r=destination(chain,subject,anchor,side);
    const wrong=chain.indexOf(anchor)+(side==='trailing'?1:0);
    if(wrong"'!==r.newIndex) badFormulaCaught++;
  }
}
console.log(JSON.stringify({validReceipts:valid, nonSelfNoops:noopNonSelf.length, examples:noopNonSelf.slice(0,8), positiveControlBadFormulaCaught:badFormulaCaught},null,2));
NODE
jq '"'keys' .descvi/edit-map.json
jq 'to_entries[0]' .descvi/edit-map.json | head -120
lsof -nP -iTCP:3000 -sTCP:LISTEN || true
lsof -nP -iTCP:3001 -sTCP:LISTEN || true
rg -n \"DescviPageRouter|screenId|pathname|routes\" packages/descvi/src/vite src/app | head -120" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
{
  "validReceipts": 224,
  "nonSelfNoops": 42,
  "examples": [
    {
      "chain": "AB",
      "subject": "A",
      "anchor": "B",
      "side": "leading",
      "index": 0
    },
    {
      "chain": "AB",
      "subject": "B",
      "anchor": "A",
      "side": "trailing",
      "index": 1
    },
    {
      "chain": "ABC",
      "subject": "A",
      "anchor": "B",
      "side": "leading",
      "index": 0
    },
    {
      "chain": "ABC",
      "subject": "B",
      "anchor": "A",
      "side": "trailing",
      "index": 1
    },
    {
      "chain": "ABC",
      "subject": "B",
      "anchor": "C",
      "side": "leading",
      "index": 1
    },
    {
      "chain": "ABC",
      "subject": "C",
      "anchor": "B",
      "side": "trailing",
      "index": 2
    },
    {
      "chain": "ABCD",
      "subject": "A",
      "anchor": "B",
      "side": "leading",
      "index": 0
    },
    {
      "chain": "ABCD",
      "subject": "B",
      "anchor": "A",
      "side": "trailing",
      "index": 1
    }
  ],
  "positiveControlBadFormulaCaught": 112
}
[
  "oids",
  "version"
]
{
  "key": "version",
  "value": "10"
}
packages/descvi/src/vite/bootstrap-entry.ts:11: *     <DescviPageRouter manifest importers />   // = the overlay's children
packages/descvi/src/vite/bootstrap-entry.ts:27:import { DescviPageRouter } from './DescviPageRouter';
packages/descvi/src/vite/bootstrap-entry.ts:188:   * tree `DescviOverlay > DescviPageRouter`; `false` = the plain prototype view —
packages/descvi/src/vite/bootstrap-entry.ts:189:   * a bare `DescviPageRouter` with NO overlay wrapper (so no `DescviStateProvider`
packages/descvi/src/vite/bootstrap-entry.ts:308:  // SAME `DescviPageRouter` WITHOUT the overlay wrapper (no `DescviStateProvider`
packages/descvi/src/vite/bootstrap-entry.ts:311:    return h(DescviPageRouter, { manifest, importers, rootImporter });
packages/descvi/src/vite/bootstrap-entry.ts:316:    children: h(DescviPageRouter, { manifest, importers, rootImporter }),
packages/descvi/src/vite/bootstrap-entry.ts:333:   * (`false` — bare `DescviPageRouter`, no overlay wrapper). See {@link DescviBootstrapProps.overlay}.
src/app/__tests__/home-page.test.tsx:59:  it('links every routable screen to /{id} (slash IDs map directly to routes)', async () => {
packages/descvi/src/vite/PageRouter.ts:5: * thin interface `{ match(pathname) }` whose default implementation is the
packages/descvi/src/vite/PageRouter.ts:6: * hand-rolled `createDescviPageRouter` (Option B). A future swap to e.g. a
packages/descvi/src/vite/PageRouter.ts:34: * `/` pathname (→ empty screen-id) to this importer when present.
packages/descvi/src/vite/PageRouter.ts:40:   * The matched lazy page for a `pathname`, or `null` for a 404 — an unknown,
packages/descvi/src/vite/PageRouter.ts:43:   * re-render nor a REBUILT ROUTER changes its identity (keyed by pathname only,
packages/descvi/src/vite/PageRouter.ts:46:  match(pathname: string): LazyExoticComponent<PageComponent> | null;
packages/descvi/src/vite/PageRouter.ts:50:export function pathnameToScreenId(pathname: string): string {
packages/descvi/src/vite/PageRouter.ts:51:  return pathname.replace(/^\/+/, '');
packages/descvi/src/vite/PageRouter.ts:64: * The DescviPageRouter additionally cross-checks every key against the manifest's
packages/descvi/src/vite/PageRouter.ts:108: * ⚠ **A PER-INSTANCE CACHE IS EMPTY EXACTLY WHEN IT IS NEEDED, AND THAT WAS MEASURED, NOT REASONED ABOUT (phase-45 H45-B, two tracer lanes in real Chrome).** Every tab return runs the liveness wake → `bootstrap-entry`'s `load()` → `setManifest` with a **fresh object even when the served bytes are identical** (`packages/descvi/src/vite/bootstrap-entry.ts#  return Object.fromEntries(screens.map((s) => [s.id, s])) as ManifestMap;`) → `DescviPageRouter`'s manifest-IDENTITY-keyed `useMemo` rebuilds the router → a cache owned by that instance starts empty → `match()` mints a NEW `lazy()` for a page whose module is already loaded. React then re-suspends the page — a ~300 ms Suspense fallback on 100% of wakes, during which every selected element measures an all-zero rect while staying connected — and once the page module has been HMR-updated at least once in that browser session the re-suspend resolves to a react-refresh family React cannot reconcile in place: `#dsh-screen`'s page subtree is REPLACED, every selected element is detached, and the overlay's rings freeze on nodes that no longer exist.
packages/descvi/src/vite/PageRouter.ts:110: * KEYING ON THE IMPORTER FUNCTION IS WHAT MAKES ONE CACHE SAFE TO SHARE ACROSS ROUTERS. A `lazy`'s entire content is its importer, so two routers over two different manifests cannot disagree about what a given importer resolves to; the manifest remains the keying AUTHORITY because {@link createDescviPageRouter} runs its `isRoutable` + importer-present gate BEFORE consulting this cache. The importers are minted once per page load by the bootstrap module's `import.meta.glob`, so a `WeakMap` entry lives exactly as long as the module that produced its key and a full reload starts clean.
packages/descvi/src/vite/PageRouter.ts:128: * `match` gates a pathname on (routable manifest screen) ∧ (importer present),
packages/descvi/src/vite/PageRouter.ts:134: * Root portal: when `rootImporter` is supplied, the `/` pathname (→
packages/descvi/src/vite/PageRouter.ts:138: * pathnames are unchanged.
packages/descvi/src/vite/PageRouter.ts:140:export function createDescviPageRouter(
packages/descvi/src/vite/PageRouter.ts:146:    match(pathname: string): LazyExoticComponent<PageComponent> | null {
packages/descvi/src/vite/PageRouter.ts:147:      const id = pathnameToScreenId(pathname);
packages/descvi/src/vite/index.ts:33:  DescviPageRouter,
packages/descvi/src/vite/index.ts:34:  type DescviPageRouterProps,
packages/descvi/src/vite/index.ts:35:} from './DescviPageRouter';
packages/descvi/src/vite/index.ts:38:  createDescviPageRouter,
packages/descvi/src/vite/index.ts:41:  pathnameToScreenId,
packages/descvi/src/vite/shims/next-navigation.tsx:27:  return window.location.pathname;
packages/descvi/src/vite/DescviPageRouter.tsx:11:  createDescviPageRouter,
packages/descvi/src/vite/DescviPageRouter.tsx:19: * DescviPageRouter — the popstate-driven page swapper for descvi's design-view
packages/descvi/src/vite/DescviPageRouter.tsx:21: * **keyed by `pathname` ONLY** (never `href`/search) so a search-only `?open=`
packages/descvi/src/vite/DescviPageRouter.tsx:25: * The page-keying authority is the manifest (`createDescviPageRouter` → the
packages/descvi/src/vite/DescviPageRouter.tsx:29:export interface DescviPageRouterProps {
packages/descvi/src/vite/DescviPageRouter.tsx:42:  renderNotFound?: (pathname: string) => ReactNode;
packages/descvi/src/vite/DescviPageRouter.tsx:45:function DefaultNotFound({ pathname }: { pathname: string }) {
packages/descvi/src/vite/DescviPageRouter.tsx:48:      404 — no manifest screen for <code>{pathname || '/'}</code>
packages/descvi/src/vite/DescviPageRouter.tsx:53:function RouteCommitToken({ pathname }: { pathname: string }) {
packages/descvi/src/vite/DescviPageRouter.tsx:54:  useEffect(() => publishUndoRouteCommitToken(pathname), [pathname]);
packages/descvi/src/vite/DescviPageRouter.tsx:58:export function DescviPageRouter({
packages/descvi/src/vite/DescviPageRouter.tsx:65:}: DescviPageRouterProps) {
packages/descvi/src/vite/DescviPageRouter.tsx:72:    () => router ?? createDescviPageRouter(manifest, importers, rootImporter),
packages/descvi/src/vite/DescviPageRouter.tsx:76:  const [pathname, setPathname] = useState<string>(() =>
packages/descvi/src/vite/DescviPageRouter.tsx:77:    typeof window !== 'undefined' ? window.location.pathname : '/',
packages/descvi/src/vite/DescviPageRouter.tsx:81:    // One popstate drives the page swap; `?open=` (search-only) leaves pathname
packages/descvi/src/vite/DescviPageRouter.tsx:83:    const onPop = () => setPathname(window.location.pathname);
packages/descvi/src/vite/DescviPageRouter.tsx:88:  // The matched component is a lazy page selected per pathname; the PageRouter
packages/descvi/src/vite/DescviPageRouter.tsx:93:  const Page = pageRouter.match(pathname);
packages/descvi/src/vite/DescviPageRouter.tsx:99:          ? renderNotFound(pathname)
packages/descvi/src/vite/DescviPageRouter.tsx:100:          : <DefaultNotFound pathname={pathname} />}
packages/descvi/src/vite/DescviPageRouter.tsx:109:      {/* key = pathname ONLY (never href/search) → ?open= does not remount.
packages/descvi/src/vite/DescviPageRouter.tsx:112:      <Page key={pathname} />
packages/descvi/src/vite/DescviPageRouter.tsx:113:      <RouteCommitToken pathname={pathname} />
packages/descvi/src/vite/shims/Link.tsx:11: * page's `<Link href>` drives `DescviPageRouter` AND the overlay's open-intent.
packages/descvi/src/vite/shims/Link.tsx:17:  href: string | { pathname?: string };
packages/descvi/src/vite/shims/Link.tsx:22:  const to = typeof href === 'string' ? href : (href?.pathname ?? '#');
packages/descvi/src/vite/plugin.ts:142:   * Render the design-view overlay (`true`, default — `DescviOverlay > DescviPageRouter`)
packages/descvi/src/vite/plugin.ts:143:   * or the plain prototype view (`false` — a bare `DescviPageRouter`, no overlay
packages/descvi/src/vite/plugin.ts:524:        // `usePolling` routes chokidar through `fs.watchFile`, which stats a PATH on an interval and is therefore inode-agnostic. It was the arm that proved the deaf-watcher hypothesis: 0/75 isolated failures against 7/75 for the default watcher, on identical code (run `31016935157`).
packages/descvi/src/vite/__tests__/shims.test.tsx:31:      expect(window.location.pathname).toBe('/claude/order-list');
packages/descvi/src/vite/__tests__/shims.test.tsx:42:    expect(window.location.pathname).toBe('/start');
packages/descvi/src/vite/__tests__/shims.test.tsx:73:    const pathname = usePathname();
packages/descvi/src/vite/__tests__/shims.test.tsx:78:      createElement('span', { 'data-test': 'pathname' }, pathname),
packages/descvi/src/vite/__tests__/shims.test.tsx:89:    expect(container.querySelector('[data-test="pathname"]')?.textContent).toBe(
packages/descvi/src/vite/__tests__/shims.test.tsx:96:    expect(container.querySelector('[data-test="pathname"]')?.textContent).toBe(
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:8:import { DescviPageRouter } from '../DescviPageRouter';
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:10:  createDescviPageRouter,
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:13:  pathnameToScreenId,
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:76:describe('pathnameToScreenId', () => {
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:78:    expect(pathnameToScreenId('/foo/bar')).toBe('foo/bar');
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:79:    expect(pathnameToScreenId('/')).toBe('');
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:83:describe('createDescviPageRouter — manifest-keyed, routable-only', () => {
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:85:    const r = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:90:    const r = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:95:    const r = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:101:    const r = createDescviPageRouter(
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:109:    const r = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:115:  // object even when the bytes are identical, so `DescviPageRouter`'s identity-keyed `useMemo` rebuilds the router.
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:126:    const first = createDescviPageRouter(beforeWake, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:127:    const rebuilt = createDescviPageRouter(afterWake, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:133:    const first = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:137:    expect(createDescviPageRouter(manifest, otherImporters).match('/foo')).not.toBe(first.match('/foo'));
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:141:describe('DescviPageRouter — render', () => {
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:144:    render(createElement(DescviPageRouter, { manifest, importers }));
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:151:      createElement(DescviPageRouter, { manifest, importers }),
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:174:        : finalized({ ok: true, target: 'undo', entryId: 8, kind: 'name', screenId: 'destination', reselectOid: 'destination-item' });
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:184:    render(createElement('div', { id: 'dsh-screen' }, createElement(DescviPageRouter, { manifest: routeManifest, importers: routeImporters })));
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:225:describe('createDescviPageRouter — root portal at `/`', () => {
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:233:    const r = createDescviPageRouter(manifest, importers, rootImporter);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:238:    const r = createDescviPageRouter(manifest, importers);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:245:    const r = createDescviPageRouter(manifest, withEmpty);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:250:    const r = createDescviPageRouter(manifest, importers, rootImporter);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:255:    const first = createDescviPageRouter({ ...manifest } as ManifestMap, importers, rootImporter);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:256:    const rebuilt = createDescviPageRouter({ ...manifest } as ManifestMap, importers, rootImporter);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:261:describe('DescviPageRouter — root portal render in both overlay modes', () => {
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:268:  // The router itself is overlay-agnostic (the overlay wraps it as children); rendering it bare here proves both `overlay:true` and `overlay:false` trees resolve `/` to the portal, since both mount the SAME DescviPageRouter.
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:272:      createElement(DescviPageRouter, { manifest, importers, rootImporter }),
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:279:    const r = createDescviPageRouter(manifest, importers, rootImporter);
packages/descvi/src/vite/__tests__/DescviPageRouter.test.tsx:281:    // A `?open=` change is search-only → pathname unchanged → same matched id.
packages/descvi/src/vite/__tests__/bootstrap.test.tsx:35:    // A non-manifest path → after mount, the overlay renders children bare and DescviPageRouter renders its 404 — proving the tree mounted past loading.
packages/descvi/src/vite/__tests__/bootstrap.test.tsx:120:  // A manifest screen whose id matches the active pathname → DescviOverlay renders its shell (`#dsh-root[data-descvi-overlay]`) instead of bare children.
packages/descvi/src/vite/__tests__/design-view-behavior.test.tsx:3: * Heavy behavioral suite — tests the REAL design-view tree (DescviOverlay → DescviPageRouter → WindowHostRouter), the same components the Vite bootstrap mounts.
packages/descvi/src/vite/__tests__/design-view-behavior.test.tsx:25:import { DescviPageRouter } from '../DescviPageRouter';
packages/descvi/src/vite/__tests__/design-view-behavior.test.tsx:69:/** Lives INSIDE DescviStateProvider but OUTSIDE the pathname-keyed page → counts provider-subtree mounts independently of page remounts. */
packages/descvi/src/vite/__tests__/design-view-behavior.test.tsx:114:      <DescviPageRouter manifest={MANIFEST} importers={IMPORTERS} />
packages/descvi/src/vite/__tests__/design-view-behavior.test.tsx:150:    // Search-only change → pathname unchanged → no page key change → no remount.

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc 'pnpm dev' in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "jq '.oids[\"omy3i9\"], .oids[\"0cyt4v\"], .oids[\"z76fvu\"], .oids[\"d29ipo\"], .oids[\"d4b6s3\"], .oids[\"d8m1w7\"]' .descvi/edit-map.json
jq -r '.oids | to_entries[] | select(.value.structure.opUnitKind == \"conditional-container\") | [.key, .value.screenId, .value.structure.parentOid, .value.structure.prevOid, .value.structure.nextOid] | @tsv' .descvi/edit-map.json | head -40
jq -r '.oids | to_entries[] | select(.value.structure.opUnitKind == \"conditional-container\") | .value.screenId' .descvi/edit-map.json | sort -u" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
null
null
null
null
null
null

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "jq '.oids | type, keys[0:5]' .descvi/edit-map.json
jq '.oids | to_entries[0]' .descvi/edit-map.json | head -160" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
"object"
[
  "lab/challenge/dynamic-shapes",
  "lab/challenge/focus-steal",
  "lab/challenge/insert-scratch",
  "lab/challenge/nested-scroll",
  "lab/challenge/relocation"
]
{
  "key": "lab/challenge/dynamic-shapes",
  "value": {
    "dxroot": {
      "className": "flex flex-col gap-6 mx-auto p-6 max-w-2xl",
      "editable": true,
      "text": {
        "value": null,
        "editable": false,
        "reason": "dynamic-text"
      },
      "structure": {
        "canMoveUp": false,
        "canMoveDown": false,
        "canDelete": false,
        "canDuplicate": false,
        "canInsertAfter": false,
        "canInsertChild": true,
        "parentOid": null,
        "prevOid": null,
        "nextOid": null,
        "reasons": {
          "delete": "target-bears-data-screen",
          "move-up": "target-bears-data-screen",
          "move-down": "target-bears-data-screen",
          "duplicate": "target-bears-data-screen",
          "insert-after": "target-bears-data-screen"
        }
      },
      "name": "screen-root",
      "description": "화면 뿌리이자 `data-screen` 파티션 경계. 짚는 스펙은 없다. 이 요소가 파티션을 선언하므로 아래 모든 oid가 이 화면 소속으로 해석된다"
    },
    "dxhead": {
      "className": "font-bold text-2xl tracking-tight",
      "editable": true,
      "text": {
        "value": "되풀이되는 자리들",
        "editable": true
      },
      "structure": {
        "canMoveUp": false,
        "canMoveDown": true,
        "canDelete": true,
        "canDuplicate": true,
        "canInsertAfter": true,
        "canInsertChild": false,
        "insertChildReason": "child-region-ends-in-text",
        "insertChildDetail": "the child region of data-oid=\"dxhead\" ends in rendered text, so a new element there would share its text node and could never be addressed",
        "parentOid": null,
        "prevOid": null,
        "nextOid": "dxintr",
        "reasons": {
          "move-up": "no-adjacent-sibling"
        }
      },
      "name": "page-heading",
      "description": "화면 제목. 짚는 스펙은 없다. 되풀이가 아닌 평범한 요소가 한 화면에 같이 있어야 거절이 화면 전체의 성질이 아니라 특정 자리의 성질임을 가릴 수 있다"
    },
    "dxintr": {
      "className": "text-neutral-500 text-sm",
      "editable": true,
      "text": {
        "value": "이 화면의 줄들은 하나씩 적힌 것이 아니라 한 곳에서 되풀이되어 나옵니다.\n          그래서 화면에서는 여러 줄로 보여도 소스에서는 자리가 하나뿐이고, 요소를 고르면 같은 식별자를 단 줄이 여럿 잡힙니다.\n          엔진이 어려워하는 자리를 한 화면에 모아 두려고 만든 화면이라, 삽입 버튼이 꺼져 있거나 거절 문구가 뜨는 것이 정상입니다.",
        "editable": true
      },
      "structure": {
        "canMoveUp": true,
        "canMoveDown": false,
        "canDelete": true,
        "canDuplicate": true,
        "canInsertAfter": true,
        "canInsertChild": false,
        "insertChildReason": "child-region-ends-in-text",
        "insertChildDetail": "the child region of data-oid=\"dxintr\" ends in rendered text, so a new element there would share its text node and could never be addressed",
        "parentOid": null,
        "prevOid": "dxhead",
        "nextOid": null,
        "reasons": {
          "move-down": "no-adjacent-sibling"
        }
      },
      "name": "intro-text",
      "description": "화면의 줄들이 하나씩 적힌 것이 아니라 한 자리에서 되풀이되어 나온다는 점, 그래서 삽입이 꺼져 있거나 거절되는 것이 정상이라는 점을 적어 둔 안내. 짚는 스펙은 없다"
    },
    "dxlgsc": {
      "className": "flex flex-col gap-2",
      "editable": true,
      "text": {
        "value": null,
        "editable": false,
        "reason": "dynamic-text"
      },
      "structure": {
        "canMoveUp": false,
        "canMoveDown": true,
        "canDelete": true,
        "canDuplicate": true,
        "canInsertAfter": true,
        "canInsertChild": true,
        "parentOid": "dxroot",
        "prevOid": null,
        "nextOid": "dxncsc",
        "reasons": {
          "move-up": "unsupported-sibling"
        }
      },
      "name": "legend-section",
      "description": "도우미 컴포넌트에서 나오는 꼬리표들을 담은 절. 짚는 스펙은 없다"
    },
    "dxlghd": {
      "className": "font-medium text-neutral-700 text-sm",
      "editable": true,
      "text": {
        "value": "되풀이되는 꼬리표 — 도우미 컴포넌트에서 나옵니다",
        "editable": true
      },
      "structure": {
        "canMoveUp": false,
        "canMoveDown": true,
        "canDelete": true,
        "canDuplicate": true,
        "canInsertAfter": true,
        "canInsertChild": false,
        "insertChildReason": "child-region-ends-in-text",
        "insertChildDetail": "the child region of data-oid=\"dxlghd\" ends in rendered text, so a new element there would share its text node and could never be addressed",
        "parentOid": "dxlgsc",
        "prevOid": null,
        "nextOid": "dxlgbx",
        "reasons": {
          "move-up": "no-adjacent-sibling"
        }
      },
      "name": "legend-heading",
      "description": "꼬리표 절의 제목. 짚는 스펙은 없다. 이 꼬리표들이 화면 파일이 아니라 도우미 컴포넌트에서 나온다는 사실을 화면에서 알리는 유일한 자리다"
    },
    "dxlgbx": {
      "className": "flex flex-wrap gap-1.5",
      "editable": true,
      "text": {
        "value": null,
        "editable": false,
        "reason": "no-text"
      },
      "structure": {
        "canMoveUp": true,
        "canMoveDown": false,
        "canDelete": true,
        "canDuplicate": true,
        "canInsertAfter": true,
        "canInsertChild": true,
        "parentOid": "dxlgsc",
        "prevOid": "dxlghd",
        "nextOid": null,
        "reasons": {
          "move-down": "no-adjacent-sibling"
        }
      },
      "name": "legend-box",
      "description": "⚠ **화면에 보이는 꼬리표들에는 스펙 항목이 없고, 그것이 정상이다.** 꼬리표를 만드는 `dxlgnd`는 default export 위에 선언된 도우미 컴포넌트 안에 있어서 추출기가 조용히 버린다(KI-43이 잰 동작이며 `lab/challenge/swallowed-oid`가 그 사실을 붙들고 있다). 이 상자는 그 버려지는 자리를 담고 있는, 스펙에 남는 마지막 조상이다. **`dxlgnd`에 항목을 주지 말 것** — 매니페스트에 닿지 않으므로 조용히 버려진다"
    },

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "jq '.oids[\"shop/member-detail\"][\"omy3i9\"], .oids[\"lab/tests/shared-oid\"][\"d4b6s3\"]' .descvi/edit-map.json
jq -r '.oids | to_entries[] as "'$s | $s.value | to_entries[] | select(.value.structure.opUnitKind == "conditional-container") | [.key, $s.key, .value.structure.parentOid, .value.structure.prevOid, .value.structure.nextOid] | @tsv'"' .descvi/edit-map.json | head -80
jq -r '.oids | to_entries[] as "'$s | $s.value | to_entries[] | select(.value.structure.opUnitKind == "conditional-container") | $s.key'"' .descvi/edit-map.json | sort -u" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
{
  "className": null,
  "editable": false,
  "reason": "dynamic-class",
  "text": {
    "value": null,
    "editable": false,
    "reason": "dynamic-text"
  },
  "structure": {
    "canMoveUp": false,
    "canMoveDown": true,
    "canDelete": true,
    "canDuplicate": true,
    "canInsertAfter": true,
    "canInsertChild": true,
    "parentOid": "jgdhrc",
    "prevOid": null,
    "nextOid": "0cyt4v",
    "reasons": {
      "move-up": "no-adjacent-sibling"
    }
  }
}
{
  "className": "whitespace-nowrap",
  "editable": true,
  "text": {
    "value": null,
    "editable": false,
    "reason": "dynamic-text"
  },
  "structure": {
    "canMoveUp": false,
    "canMoveDown": true,
    "canDelete": true,
    "canDuplicate": true,
    "canInsertAfter": true,
    "canInsertChild": false,
    "insertChildReason": "non-canonical-separator",
    "insertChildDetail": "the child region of data-oid=\"d4b6s3\" ends flush against its closing tag, after a JSXExpressionContainer",
    "parentOid": "d7c2h9",
    "prevOid": null,
    "nextOid": "d8m1w7",
    "reasons": {
      "move-up": "no-adjacent-sibling"
    }
  },
  "name": "track-step-label",
  "description": "소스에 한 번 적히고 **다섯 번** 그려지는 단계 이름. `selection-consistency.spec.ts` (c)와 `structural-editing.spec.ts` (d)가 쓰는 가로 간극의 왼쪽 경계이고, `insert-live.spec.ts`의 반복 영역 행은 세 번째 인스턴스의 이 요소 사각형을 재서 클릭 좌표를 만든다. 라벨이 행의 나머지를 덮기 때문에 부모 행은 이 요소 옆 틈으로만 잡힌다"
}
d8m1w7	lab/tests/shared-oid	d7c2h9	d4b6s3	
dn6y1c	lab/tests/shared-oid	d5w9j4	d1z5g6	dq9t3f
dq9t3f	lab/tests/shared-oid	d5w9j4	dn6y1c	dv2h7x
dv2h7x	lab/tests/shared-oid	d5w9j4	dq9t3f	
bwrn5t	lab/tests/single-screen	bbdy3p	bbta9r	
axe5g7	lab/tests/three-screen			
avd6j8	lab/tests/three-screen			
scndaa	sandbox/resize-flex-col	scroot	scstck	scndbb
scndbb	sandbox/resize-flex-col	scroot	scndaa	scndcc
scndcc	sandbox/resize-flex-col	scroot	scndbb	sclnkk
srndaa	sandbox/resize-flex-row	srroot	srstrp	srndbb
srndbb	sandbox/resize-flex-row	srroot	srndaa	srndcc
srndcc	sandbox/resize-flex-row	srroot	srndbb	srlnkk
smndaa	sandbox/resize-repeat-list	smroot	smlist	smndbb
smndbb	sandbox/resize-repeat-list	smroot	smndaa	smndcc
smndcc	sandbox/resize-repeat-list	smroot	smndbb	smlnkk
95y6zf	shop/member-detail	5chpob		
xttsu7	shop/member-detail	5chpob		
y3ngs5	shop/member-detail	xttsu7		
jw5z9l	shop/member-detail	rd7gp2	adaq8c	39ln4d
xpy5eu	shop/member-detail	ejll90	jbtzr7	
nuxbli	shop/member-detail	np09eb	ejll90	f5pwkq
i3b9gu	shop/member-detail	xttsu7		
jvbbn7	shop/member-detail	e53g6p	2dtotc	cmsa36
cmsa36	shop/member-detail	e53g6p	jvbbn7	
z76fvu	shop/member-detail	jgdhrc	0cyt4v	d29ipo
86s7gx	shop/member-detail	i3b9gu	i5sk5q	
pk9pwr	shop/member-detail	xttsu7		
bklj64	shop/member-detail	pk9pwr	ww57qb	4b6oqr
ljncrn	shop/member-list	nc5v2e		
t3aflz	shop/member-list	nc5v2e		
2z01ij	shop/member-list	nc5v2e		
vf4lm7	shop/member-list	nc5v2e		
salutd	shop/member-list	q175qy		
rpb6hb	shop/order-detail	4jpxin		hjo7s4
1dd4x7	shop/order-detail	aau1w5		
wp51oi	shop/order-detail	a1294a		ke5zva
e7kz03	shop/order-detail	aau1w5		
g6xkj6	shop/order-detail	z1w45d		rigpu4
javb9h	shop/order-detail	aau1w5		
zlz7vi	shop/order-detail	uycbxe		v9lftf
yeg086	shop/order-detail	aau1w5		
1v34iy	shop/order-detail	xp79xk		3fw879
w8fvzn	shop/order-detail	aau1w5		
q161xy	shop/order-detail	ttpq05		gf1mho
4sj549	shop/order-detail	6tvqoa		
rzp0bi	shop/order-detail	6tvqoa		
ip53iw	shop/order-detail	6tvqoa		
fmd08j	shop/order-detail	6tvqoa		
w8r5oe	shop/order-detail	6tvqoa		
lkkx2z	shop/order-detail	6tvqoa		
91aoav	shop/order-detail	6tvqoa		
px9sdo	shop/order-detail	6tvqoa		
w6qjeo	shop/order-detail	6tvqoa		
glaiqv	shop/order-detail	6tvqoa		
nprnz5	shop/order-detail	6tvqoa		
ngpp03	shop/order-detail	6tvqoa		
fkgdt7	shop/order-detail	6tvqoa		
obbwp0	shop/order-detail	6tvqoa		
sv688b	shop/order-detail	6tvqoa		
jyo6c7	shop/order-detail	6tvqoa		
ze87pu	shop/order-detail	6tvqoa		
eyxple	shop/order-detail	6tvqoa		
zotg9a	shop/order-list	u8j60k		
vd17a8	shop/order-list	u8j60k		
neurer	shop/order-list	u8j60k		
ntqtdg	shop/order-list	u8j60k		
lab/tests/shared-oid
lab/tests/single-screen
lab/tests/three-screen
sandbox/resize-flex-col
sandbox/resize-flex-row
sandbox/resize-repeat-list
shop/member-detail
shop/member-list
shop/order-detail
shop/order-list

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from 'node:fs';
import { chromium } from 'playwright';
const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids;
const chains=[];
for (const [screen, entries] of Object.entries(map)) {
  const movable=Object.entries(entries).filter(([,e])=>e.structure?.canMoveUp||e.structure?.canMoveDown);
  const seen=new Set();
  for (const [oid] of movable) {
    if(seen.has(oid)) continue;
    let head=oid;
    while(entries[head]?.structure?.prevOid) head=entries[head].structure.prevOid;
    const oids=[]; let cur=head;
    while(cur && "'!seen.has(cur)){seen.add(cur);oids.push(cur);cur=entries[cur]?.structure?.nextOid;}
    if(oids.length>=2) chains.push({screen,oids});
  }
}
if(chains.length!==235) throw new Error(`chain instrument expected 235, got ${chains.length}`);
function syntheticPositive(){
 const src=['"'A','H','B']; const visible=['A','B']; const out=['H','A','B'];
 return src.join()"'!==out.join() && out.filter(x=>visible.includes(x)).join()===visible.join();
}
if(!syntheticPositive()) throw new Error('"'positive control failed');
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1440,height:900}});
async function scanScreen(screen,label){
 const relevant=chains.filter(c=>c.screen===screen);
 return await page.evaluate(({relevant,label})=>{
   const same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]);
   const findings=[];
   for(const chain of relevant){
     for(const subjectOid of chain.oids){
       const subjects=[...document.querySelectorAll("'`[data-oid="${CSS.escape(subjectOid)}"]`)];
       for(const subject of subjects){
         const parent=subject.parentElement; if(!parent) continue;
         const cs=getComputedStyle(parent);
         if(!['"'flex','inline-flex'].includes(cs.display)||cs.direction"'!=='"'ltr'||cs.writingMode"'!=='"'horizontal-tb') continue;
         const matches=new Map();
         for(const oid of chain.oids){
           const ms=[...parent.children].filter(el=>el.getAttribute('data-oid')===oid);
           matches.set(oid,ms);
         }
         if([...matches.values()].some(ms=>ms.length>1)) continue;
         const visible=chain.oids.filter(oid=>matches.get(oid).length===1);
         if(visible.length<2||"'!visible.includes(subjectOid)) continue;
         const orders=visible.map(oid=>getComputedStyle(matches.get(oid)[0]).order);
         if(new Set(orders).size!==1) continue;
         for(const anchorOid of visible){
           if(anchorOid===subjectOid) continue;
           for(const side of ['"'leading','trailing']){
             const without=chain.oids.filter(x=>x"'!==subjectOid);
             const ai=without.indexOf(anchorOid);
             const ni=ai+(side==='"'trailing'?1:0);
             const out=[...without.slice(0,ni),subjectOid,...without.slice(ni)];
             if(same(out,chain.oids)) continue;
             const renderedAfter=out.filter(x=>visible.includes(x));
             if(same(renderedAfter,visible)) findings.push({label,screen,chain:chain.oids,visible,subjectOid,anchorOid,side,display:cs.display,flexDirection:cs.flexDirection});
           }
         }
       }
     }
   }
   const key=x=>JSON.stringify([x.screen,x.chain,x.visible,x.subjectOid,x.anchorOid,x.side]);
   return [...new Map(findings.map(x=>[key(x),x])).values()];
 },{relevant,label});
}
const all=[];
for(const screen of [...new Set(chains.map(c=>c.screen))]){
 await page.goto("'`http://127.0.0.1:3000/${screen}`,{waitUntil:'"'networkidle'});
 all.push(...await scanScreen(screen,'default'));
}
await page.goto('http://127.0.0.1:3000/shop/member-detail',{waitUntil:'networkidle'});
const benefits=page.getByRole('button',{name:/혜택/});
if(await benefits.count()"'!==1) throw new Error(`benefits positive path button count ${await benefits.count()}`);
await benefits.click();
await page.waitForTimeout(100);
const known=await scanScreen('"'shop/member-detail','benefits-click');
if("'!known.some(x=>x.chain.includes('"'omy3i9'))) throw new Error('positive control known benefits chain did not fire');
all.push(...known);
const uniq=[...new Map(all.map(x=>[JSON.stringify([x.screen,x.chain,x.visible,x.subjectOid,x.anchorOid,x.side]),x])).values()];
console.log(JSON.stringify({chainControl:chains.length,syntheticPositive:syntheticPositive(),defaultFindings:all.filter(x=>x.label==='default').length,benefitsFindings:known.length,uniqueFindings:uniq},null,2));
await browser.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 exited 1 in 0ms:
node:internal/modules/package_json_reader:301
  throw new ERR_MODULE_NOT_FOUND(packageName, fileURLToPath(base), null);
        ^

Error [ERR_MODULE_NOT_FOUND]: Cannot find package 'playwright' imported from /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/[eval1]
    at Object.getPackageJSONURL (node:internal/modules/package_json_reader:301:9)
    at packageResolve (node:internal/modules/esm/resolve:764:81)
    at moduleResolve (node:internal/modules/esm/resolve:855:18)
    at defaultResolve (node:internal/modules/esm/resolve:988:11)
    at #cachedDefaultResolve (node:internal/modules/esm/loader:697:20)
    at #resolveAndMaybeBlockOnLoaderThread (node:internal/modules/esm/loader:714:38)
    at ModuleLoader.resolveSync (node:internal/modules/esm/loader:746:52)
    at #resolve (node:internal/modules/esm/loader:679:17)
    at ModuleLoader.getOrCreateModuleJob (node:internal/modules/esm/loader:599:35)
    at ModuleJob.syncLink (node:internal/modules/esm/module_job:162:33) {
  code: 'ERR_MODULE_NOT_FOUND'
}

Node.js v25.9.0

hook: PostToolUse
hook: PostToolUse Completed
codex
첫 live-scan 실행은 저장소에 `playwright` 패키지가 직접 설치되어 있지 않고 `@playwright/test`만 설치된 의존성 차이로 시작 전에 실패했습니다. 측정 로직은 실행되지 않았으므로 수치로 취급하지 않으며, 같은 probe를 저장소의 실제 Playwright 진입점으로 다시 구동합니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from 'node:fs';
import { chromium } from '@playwright/test';
const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids;
const chains=[];
for (const [screen, entries] of Object.entries(map)) {
  const movable=Object.entries(entries).filter(([,e])=>e.structure?.canMoveUp||e.structure?.canMoveDown);
  const seen=new Set();
  for (const [oid] of movable) {
    if(seen.has(oid)) continue;
    let head=oid;
    while(entries[head]?.structure?.prevOid) head=entries[head].structure.prevOid;
    const oids=[]; let cur=head;
    while(cur && "'!seen.has(cur)){seen.add(cur);oids.push(cur);cur=entries[cur]?.structure?.nextOid;}
    if(oids.length>=2) chains.push({screen,oids});
  }
}
if(chains.length!==235) throw new Error(`chain instrument expected 235, got ${chains.length}`);
function syntheticPositive(){const src=['"'A','H','B'],visible=['A','B'],out=['H','A','B'];return src.join()"'!==out.join()&&out.filter(x=>visible.includes(x)).join()===visible.join();}
if(!syntheticPositive()) throw new Error('"'positive control failed');
const browser=await chromium.launch({headless:true});
const page=await browser.newPage({viewport:{width:1440,height:900}});
async function scanScreen(screen,label){
 const relevant=chains.filter(c=>c.screen===screen);
 return await page.evaluate(({relevant,label})=>{
   const same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]); const findings=[];
   for(const chain of relevant) for(const subjectOid of chain.oids){
     const subjects=[...document.querySelectorAll("'`[data-oid="${CSS.escape(subjectOid)}"]`)];
     for(const subject of subjects){
       const parent=subject.parentElement;if(!parent)continue;const cs=getComputedStyle(parent);
       if(!['"'flex','inline-flex'].includes(cs.display)||cs.direction"'!=='"'ltr'||cs.writingMode"'!=='"'horizontal-tb')continue;
       const matches=new Map();for(const oid of chain.oids)matches.set(oid,[...parent.children].filter(el=>el.getAttribute('data-oid')===oid));
       if([...matches.values()].some(ms=>ms.length>1))continue;
       const visible=chain.oids.filter(oid=>matches.get(oid).length===1);if(visible.length<2||"'!visible.includes(subjectOid))continue;
       const orders=visible.map(oid=>getComputedStyle(matches.get(oid)[0]).order);if(new Set(orders).size!==1)continue;
       for(const anchorOid of visible){if(anchorOid===subjectOid)continue;for(const side of ['"'leading','trailing']){
         const without=chain.oids.filter(x=>x"'!==subjectOid),ai=without.indexOf(anchorOid),ni=ai+(side==='"'trailing'?1:0),out=[...without.slice(0,ni),subjectOid,...without.slice(ni)];
         if(same(out,chain.oids))continue;const renderedAfter=out.filter(x=>visible.includes(x));
         if(same(renderedAfter,visible))findings.push({label,screen,chain:chain.oids,visible,subjectOid,anchorOid,side,display:cs.display,flexDirection:cs.flexDirection});
       }}
     }
   }
   const key=x=>JSON.stringify([x.screen,x.chain,x.visible,x.subjectOid,x.anchorOid,x.side]);return [...new Map(findings.map(x=>[key(x),x])).values()];
 },{relevant,label});
}
const defaults=[];
for(const screen of [...new Set(chains.map(c=>c.screen))]){await page.goto("'`http://127.0.0.1:3000/${screen}`,{waitUntil:'"'networkidle'});defaults.push(...await scanScreen(screen,'default'));}
await page.goto('http://127.0.0.1:3000/shop/member-detail',{waitUntil:'networkidle'});
const benefits=page.getByRole('button',{name:/혜택/});const count=await benefits.count();if(count"'!==1)throw new Error(`benefits positive path button count ${count}`);await benefits.click();await page.waitForTimeout(100);
const known=await scanScreen('"'shop/member-detail','benefits-click');if("'!known.some(x=>x.chain.includes('"'omy3i9')))throw new Error('positive control known benefits chain did not fire');
console.log(JSON.stringify({chainControl:chains.length,syntheticPositive:true,defaultFindings:defaults,benefitsFindings:known},null,2));
await browser.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 exited 1 in 450ms:
node:internal/modules/run_main:107
    triggerUncaughtException(
    ^

page.goto: net::ERR_CONNECTION_REFUSED at http://127.0.0.1:3000/lab/challenge/dynamic-shapes
Call log:
[2m  - navigating to "http://127.0.0.1:3000/lab/challenge/dynamic-shapes", waiting until "networkidle"[22m

    at /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/[eval1]:46:71 {
  name: 'Error'
}

Node.js v25.9.0

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc 'lsof -nP -iTCP:3000 -sTCP:LISTEN || true
curl -I --max-time 3 http://localhost:3000/lab/challenge/dynamic-shapes || true
curl -I --max-time 3 http://127.0.0.1:3000/lab/challenge/dynamic-shapes || true' in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
COMMAND   PID USER   FD   TYPE             DEVICE SIZE/OFF NODE NAME
node    63789 kein   18u  IPv6 0x53ddf87425089653      0t0  TCP [::1]:3000 (LISTEN)
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0
HTTP/1.1 200 OK
Vary: Origin
Content-Type: text/html
Cache-Control: no-cache
Etag: W/"4fb-AfrCISaKN0cbtVALBYobi+mFQyg"
Date: Thu, 27 Aug 2026 16:48:35 GMT
Connection: keep-alive
Keep-Alive: timeout=5

  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0  0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0
curl: (7) Failed to connect to 127.0.0.1 port 3000 after 0 ms: Couldn't connect to server

hook: PostToolUse
hook: PostToolUse Completed
codex
두 번째 시도는 Vite가 이 환경에서 IPv6 loopback(`[::1]`)에만 바인딩되어 있어 `127.0.0.1` 연결이 거절되었습니다. `localhost:3000`의 200 응답과 `[::1]:3000` 리스너를 확인했으며, probe URL만 실제 바인딩에 맞춰 재실행합니다. 앞선 실패에서도 corpus 측정값은 생성되지 않았습니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from 'node:fs';import{chromium}from'@playwright/test';
const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids,chains=[];
for(const[screen,entries]of Object.entries(map)){const movable=Object.entries(entries).filter(([,e])=>e.structure?.canMoveUp||e.structure?.canMoveDown),seen=new Set();for(const[oid]of movable){if(seen.has(oid))continue;let head=oid;while(entries[head]?.structure?.prevOid)head=entries[head].structure.prevOid;const oids=[];let cur=head;while(cur&&"'!seen.has(cur)){seen.add(cur);oids.push(cur);cur=entries[cur]?.structure?.nextOid}if(oids.length>=2)chains.push({screen,oids})}}
if(chains.length!==235)throw new Error(`chain instrument expected 235, got ${chains.length}`);
const syntheticPositive=(()=>{const s=['"'A','H','B'],v=['A','B'],o=['H','A','B'];return s.join()"'!=o.join()&&o.filter(x=>v.includes(x)).join()==v.join()})();if(!syntheticPositive)throw new Error('"'positive control failed');
const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:900}});
async function scan(screen,label){const relevant=chains.filter(c=>c.screen===screen);return page.evaluate(({relevant,label})=>{const same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]),f=[];for(const chain of relevant)for(const subjectOid of chain.oids)for(const subject of document.querySelectorAll("'`[data-oid="${CSS.escape(subjectOid)}"]`)){const parent=subject.parentElement;if(!parent)continue;const cs=getComputedStyle(parent);if(!['"'flex','inline-flex'].includes(cs.display)||cs.direction"'!=='"'ltr'||cs.writingMode"'!=='"'horizontal-tb')continue;const m=new Map();for(const oid of chain.oids)m.set(oid,[...parent.children].filter(el=>el.getAttribute('data-oid')===oid));if([...m.values()].some(x=>x.length>1))continue;const visible=chain.oids.filter(oid=>m.get(oid).length===1);if(visible.length<2||"'!visible.includes(subjectOid))continue;if(new Set(visible.map(oid=>getComputedStyle(m.get(oid)[0]).order)).size!==1)continue;for(const anchorOid of visible){if(anchorOid===subjectOid)continue;for(const side of['"'leading','trailing']){const w=chain.oids.filter(x=>x"'!==subjectOid),ai=w.indexOf(anchorOid),ni=ai+(side==='"'trailing'),out=[...w.slice(0,ni),subjectOid,...w.slice(ni)];if("'!same(out,chain.oids)&&same(out.filter(x=>visible.includes(x)),visible))f.push({label,screen,chain:chain.oids,visible,subjectOid,anchorOid,side,display:cs.display,flexDirection:cs.flexDirection})}}}const key=x=>JSON.stringify([x.screen,x.chain,x.visible,x.subjectOid,x.anchorOid,x.side]);return[...new Map(f.map(x=>[key(x),x])).values()]},{relevant,label})}
const defaults=[];for(const screen of[...new Set(chains.map(c=>c.screen))]){await page.goto(`http://localhost:3000/${screen}`,{waitUntil:'"'networkidle'});defaults.push(...await scan(screen,'default'))}
await page.goto('http://localhost:3000/shop/member-detail',{waitUntil:'networkidle'});const benefits=page.getByRole('button',{name:/혜택/}),count=await benefits.count();if(count"'!==1)throw new Error(`benefits button count ${count}`);await benefits.click();await page.waitForTimeout(100);const known=await scan('"'shop/member-detail','benefits-click');if("'!known.some(x=>x.chain.includes('"'omy3i9')))throw new Error('known benefits chain did not fire');console.log(JSON.stringify({chainControl:chains.length,syntheticPositive,defaultFindings:defaults,benefitsFindings:known},null,2));await browser.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 14969ms:
{
  "chainControl": 235,
  "syntheticPositive": true,
  "defaultFindings": [],
  "benefitsFindings": [
    {
      "label": "benefits-click",
      "screen": {},
      "chain": [
        "omy3i9",
        "0cyt4v",
        "z76fvu",
        "d29ipo"
      ],
      "visible": [
        "omy3i9",
        "0cyt4v",
        "d29ipo"
      ],
      "subjectOid": "0cyt4v",
      "anchorOid": "d29ipo",
      "side": "leading",
      "display": "flex",
      "flexDirection": "row"
    },
    {
      "label": "benefits-click",
      "screen": {},
      "chain": [
        "omy3i9",
        "0cyt4v",
        "z76fvu",
        "d29ipo"
      ],
      "visible": [
        "omy3i9",
        "0cyt4v",
        "d29ipo"
      ],
      "subjectOid": "d29ipo",
      "anchorOid": "0cyt4v",
      "side": "trailing",
      "display": "flex",
      "flexDirection": "row"
    }
  ]
}

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from'node:fs';import{chromium}from'@playwright/test';const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids,chains=[];
for(const[route,entries]of Object.entries(map)){const movable=Object.entries(entries).filter(([,e])=>e.structure?.canMoveUp||e.structure?.canMoveDown),seen=new Set();for(const[oid]of movable){if(seen.has(oid))continue;let head=oid;while(entries[head]?.structure?.prevOid)head=entries[head].structure.prevOid;const oids=[];let cur=head;while(cur&&"'!seen.has(cur)){seen.add(cur);oids.push(cur);cur=entries[cur]?.structure?.nextOid}if(oids.length>=2)chains.push({route,oids})}}
const conditionalRoutes=[...new Set(Object.entries(map).flatMap(([route,entries])=>Object.values(entries).some(e=>e.structure?.opUnitKind==='"'conditional-container')?[route]:[]))];
if(chains.length"'!==235||conditionalRoutes.length!==10)throw new Error(`controls failed chains=${chains.length} routes=${conditionalRoutes.length}`);
const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:900}});
async function scan(route,label){const relevant=chains.filter(c=>c.route===route);return page.evaluate(({relevant,route,label})=>{const same=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]),f=[];for(const chain of relevant)for(const subjectOid of chain.oids)for(const subject of document.querySelectorAll(`[data-oid="${CSS.escape(subjectOid)}"]`)){const parent=subject.parentElement;if(!parent)continue;const cs=getComputedStyle(parent);if(!['"'flex','inline-flex'].includes(cs.display)||cs.direction"'!=='"'ltr'||cs.writingMode"'!=='"'horizontal-tb')continue;const m=new Map();for(const oid of chain.oids)m.set(oid,[...parent.children].filter(el=>el.getAttribute('data-oid')===oid));if([...m.values()].some(x=>x.length>1))continue;const visible=chain.oids.filter(oid=>m.get(oid).length===1);if(visible.length<2||"'!visible.includes(subjectOid)||new Set(visible.map(oid=>getComputedStyle(m.get(oid)[0]).order)).size!==1)continue;for(const anchorOid of visible){if(anchorOid===subjectOid)continue;for(const side of['"'leading','trailing']){const w=chain.oids.filter(x=>x"'!==subjectOid),ai=w.indexOf(anchorOid),ni=ai+(side==='"'trailing'),out=[...w.slice(0,ni),subjectOid,...w.slice(ni)];if("'!same(out,chain.oids)&&same(out.filter(x=>visible.includes(x)),visible))f.push({route,label,chain:chain.oids,visible,subjectOid,anchorOid,side})}}}return f},{relevant,route,label})}
let attempted=0,clicked=0;const findings=[];
for(const route of conditionalRoutes){await page.goto(`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});findings.push(...await scan(route,'default'));const n=await page.getByRole('button').count();for(let i=0;i<n;i++){attempted++;await page.goto("'`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});const buttons=page.getByRole('button');if(i>=await buttons.count())continue;const b=buttons.nth(i);if("'!await b.isVisible()||!await b.isEnabled())continue;const text=(await b.innerText().catch(()=>'"'' )).trim().replace(/\\s+/g,' ').slice(0,80);try{await b.click({timeout:1500});clicked++;await page.waitForTimeout(80);findings.push(...await scan(route,"'`button[${i}]=${text}`))}catch{}}
}
const chainKey=x=>JSON.stringify([x.route,x.chain]);const uniqueChains=[...new Map(findings.map(x=>[chainKey(x),x])).values()];if(!uniqueChains.some(x=>x.chain.includes('"'omy3i9')))throw new Error('positive control benefits chain absent');console.log(JSON.stringify({controls:{chainCount:chains.length,conditionalRoutes:conditionalRoutes.length,buttonStatesAttempted:attempted,buttonStatesClicked:clicked,knownPositive:true},uniqueConstructibleChains:uniqueChains,allFindingCount:findings.length},null,2));await browser.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 21835ms:
{
  "controls": {
    "chainCount": 235,
    "conditionalRoutes": 10,
    "buttonStatesAttempted": 24,
    "buttonStatesClicked": 23,
    "knownPositive": true
  },
  "uniqueConstructibleChains": [
    {
      "route": "shop/member-detail",
      "label": "button[2]=혜택 (2)",
      "chain": [
        "omy3i9",
        "0cyt4v",
        "z76fvu",
        "d29ipo"
      ],
      "visible": [
        "omy3i9",
        "0cyt4v",
        "d29ipo"
      ],
      "subjectOid": "d29ipo",
      "anchorOid": "0cyt4v",
      "side": "trailing"
    }
  ],
  "allFindingCount": 2
}

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from'node:fs';import{chromium}from'@playwright/test';const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids,chains=[];
for(const[route,entries]of Object.entries(map)){const seen=new Set();for(const[oid,e]of Object.entries(entries)){if("'!(e.structure?.canMoveUp||e.structure?.canMoveDown)||seen.has(oid))continue;let h=oid;while(entries[h]?.structure?.prevOid)h=entries[h].structure.prevOid;const o=[];let c=h;while(c&&!seen.has(c)){seen.add(c);o.push(c);c=entries[c]?.structure?.nextOid}if(o.length>=2)chains.push({route,oids:o})}}
if(chains.length!==235)throw new Error(`chain positive control failed ${chains.length}`);const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:900}});let zero=[],nonzero=[];
for(const route of[...new Set(chains.map(c=>c.route))]){await page.goto(`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});const rs=await page.evaluate(cs=>cs.map(c=>({oids:c.oids,count:c.oids.reduce((n,oid)=>n+document.querySelectorAll("'`[data-oid="${CSS.escape(oid)}"]`).length,0)})),chains.filter(c=>c.route===route));for(const x of rs)(x.count===0?zero:nonzero).push({route,...x})}
const known=nonzero.find(x=>x.route==='"'lab/tests/shared-oid'&&x.oids.includes('d4b6s3'));if("'!known)throw new Error('"'known-visible positive control failed');console.log(JSON.stringify({total:chains.length,zeroDefault:zero.length,nonzeroDefault:nonzero.length,positiveControl:{route:known.route,chain:known.oids,count:known.count},zeroByRoute:Object.fromEntries([...new Set(zero.map(x=>x.route))].map(r=>[r,zero.filter(x=>x.route===r).length]))},null,2));await browser.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 13731ms:
{
  "total": 235,
  "zeroDefault": 112,
  "nonzeroDefault": 123,
  "positiveControl": {
    "route": "lab/tests/shared-oid",
    "chain": [
      "d4b6s3",
      "d8m1w7"
    ],
    "count": 9
  },
  "zeroByRoute": {
    "lab/challenge/swallowed-oid": 1,
    "lab/tests/three-screen": 1,
    "lab/tests/three-screen::approve-modal": 2,
    "lab/tests/three-screen::reject-modal": 2,
    "shop/member-detail": 11,
    "shop/member-detail::point-adjust-modal": 5,
    "shop/member-detail::benefit-add-modal": 11,
    "shop/member-list": 1,
    "shop/order-detail": 77,
    "shop/order-list": 1
  }
}

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc 'rg -n -- "zero subjects in this corpus|ZERO SUBJECTS in this corpus|MEASURED AT ZERO in this corpus|0/930|zero subjects|ZERO SUBJECTS|all with zero subjects|all three SYNTHETIC|ambiguity" .omc/plans/ralplan-phase-47-drag-reorder.md
rg -n -- "parent-has-no-flow-axis|auto-layout|패널의 ↑ / ↓|no-sibling-in-this-copy|another copy|다른 복사본" .omc/plans/ralplan-phase-47-drag-reorder.md
rg -n -- "anchorOid ===|direction disagree|APPLIED `k`|applied-`k`|no-move|self-anchor" .omc/plans/ralplan-phase-47-drag-reorder.md' in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
240:   ⚠ **THE 9 "SOMETIMES" CHAINS ARE THE HALF THAT FORCED A RULING RATHER THAN A SENTENCE: under r2's rule the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed** — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, the **first** missing `rpb6hb` and the other five complete, giving 55 passing scopes and 11 refusing. **A per-instance verdict on a per-chain contract, and no refusal wording survives a user who just did the same drag successfully one column over.** **Options: (i) accept the per-instance verdict and word around it; (ii) refuse the chain everywhere it can ever be incomplete — not decidable client-side, since it requires knowing every state; (iii) DROP unrendered members from the table and refuse only on ambiguity or on fewer than two survivors. RULED (iii).** It costs nothing, because **the anchor receipt never computes an index** — the client names a rendered sibling and a side, and the server resolves it against the live source chain, which still contains the unrendered member. The only consequence is that a user cannot drop *between* two positions separated solely by unrendered members, which is invisible to them.
245:   ⚠ **THE DIRECT-CHILD CLAUSE HAS ZERO SUBJECTS TOO** — 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — **with a planted control (`C-B` wrapped a member in a fresh `<div>` and the analyzer reported it immediately)**. ⚠ **AND r2's ATTRIBUTION OF IT TO `wflbl3` IS FACTUALLY WRONG AND IS DELETED: `wflbl3` is a DIRECT CHILD of its own `Field` wrapper** (`src/app/lab/challenge/swallowed-oid/page.tsx#    <div className="flex flex-col gap-0.5 bg-white px-3 py-2 border border-neutral-300 rounded-md">`), so it passes both clauses. The one prop-swallowing component in the repo produces the **opposite** failure: `Field`'s *exterior* oids (`wcall1…wcall4`) reach no node and are caught by the zero-match arm — and under ruling (iii) that is a DROP, not a refusal, and in any case **`wcall1…wcall4` cannot be pressed at all** (term 4 requires the press to resolve to a `[data-oid]` element; they have zero DOM nodes in every state, the only such chain in the corpus, and their parent `wgrid1` is `grid`, so E2 would refuse first).
248:   ⚠ **The three exclusions are correct about the browser (§3.4) and have ZERO SUBJECTS in this corpus** (round 3, each with a planted control returning the planted value): `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930**. **They stay, their subjects are synthetic and owed by S47-0.**
252:5. **VISUAL → SOURCE.** `sourceSide = reversed ? flip(side) : side`. The result is `(anchorOid = S, side = sourceSide)` — **which is the wire receipt itself**, so no conversion step exists. ⚠ **The `reversed` branch has ZERO SUBJECTS: three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1), but none of their children carries a `data-oid`, so none can be a chain member.** Clause kept, subject synthetic and owed by S47-0.
330:| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
362:| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
385:- **an `rtl` chain, a `vertical-rl` chain and an unequal-`order` chain** (G47-5d) — **all three declared SYNTHETIC: measured at zero subjects (§4.2(3))**;
386:- **an ambiguity subject for `chain-member-not-locatable`** — **SYNTHETIC: both of r2's "shipped subjects" were measured not to fire, and the several-matches and direct-child arms have zero subjects at parent scope (§4.2(2))**;
428:| **G47-5d** | The modelled subset — **three independent legs**: an `rtl` flex row refuses; a `vertical-rl` flex row refuses; a chain with unequal child `order` refuses. All paint `layout-not-modelled`. | (i) Drop the `ltr` clause → the `rtl` subject admits and the drop lands mirrored. (ii) Drop the `writingMode` clause → the axis read is 90° wrong. (iii) Drop the `order`-equality clause → the source moves and **nothing on screen moves** — the failure with no visible symptom, which is why it needs its own leg. **Positive control: a plain LTR flex chain admits and reorders.** | **all three SYNTHETIC** — measured 0/930, 0/930, `order === "0"` on 930/930 (§4.2(3)) |
438:| **G47-11c** ⚠ **SUBJECT REPLACED (M5)** | `chain-member-not-locatable` fires on **ambiguity**: a member resolving to two nodes within one parent, and a member resolving to a deeper descendant. | Relax the join to "first match wins" → the two-node subject proceeds against an arbitrary box. Drop the direct-child clause → the descendant subject hands the hit-test a box that is not a flex item of the parent whose axis was read. | ⚠ **SYNTHETIC, and now cleanly so.** r2 named `wcall1…wcall4` and `wflbl3`/`wfval7`; **round 3 measured that neither fires** — the first cannot be pressed at all, the second resolves once as a direct child at parent scope, and both stated mutations change nothing on it; **round 4 independently reproduced 0 several-matches and 0 deeper-descendant readings at parent scope with a planted control that fires.** ⚠ **The fewer-than-two arm has LEFT this gate for G47-11d, where its subject is SHIPPED** — r3 filed it here and called the whole cell synthetic, which under-claimed the evidence. |
465:| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
469:| **R47-11** ⚠ **RE-PRICED (round 3)** | The modelled subset is narrower than the corpus and users meet the refusal. | ⚠ **MEASURED AT ZERO in this corpus** — `rtl` 0/930, non-`horizontal-tb` 0/930, `order !== "0"` 0/930 (§4.2(3)) — so nothing is lost today, and the refusal names the panel as the working alternative. **What is UNMEASURED is whether that stays true as the corpus grows**, and the gate subjects are synthetic precisely so the clauses keep working when it does not. |
529:- **The gesture refuses on four layout shapes it does not model and on chain ambiguity — all with zero subjects in this corpus**, so their gates carry authored subjects rather than a false claim to shipped ones.
553:- **Playwright — `e2e/reorder-drag.spec.ts`, declared `ambient`, plus the fourth press added to `e2e/spacing-gesture.spec.ts`.** ⚠ **The classification is argued (G47-13 leg ii):** the spec drives structural edits through the sidecar and asserts the resulting bytes on disk, so it **fails without a sidecar** — the `$doc`'s stated criterion. It resembles `e2e/structural-editing.spec.ts` (ambient, destructive, on-disk assertions), not `e2e/resize-handles.spec.ts` (neutral, a pure DOM-geometry checker). Rows: a full drag with on-disk bytes asserted; capture across the frame edge; the no-op-still-selects row; one Cmd+Z reverting a 3-position drag; the stage-background rows; wrap and overlap on their shipped subjects; the live-variant predicate; the three modelled-subset refusals with their LTR positive control; the `.map()` multi-instance row **and the instance-hint visibility leg**; the ambiguity refusals on S47-0's authored subjects; **the sub-floor row on `d4b6s3,d8m1w7` — admit in instances 0–3, `no-sibling-in-this-copy` in instance 4 (G47-11d), the one client-only refusal with a shipped subject**; the boundary-termination row. ⚠ **Destructive** — every mutating row owes the same `finally` snapshot-and-re-derive net `structural-editing.spec.ts` carries. ⚠ **And no row may depend on driving an in-page control by clicking on :3001 (§5, S47-6).**
206:- **E3 — the drop table can be built** (§4.2(2)). **Failure splits two ways: AMBIGUITY → `chain-member-not-locatable`; FEWER THAN TWO RESOLVED MEMBERS IN THIS COPY → `no-sibling-in-this-copy` (r4).** ⚠ **E3 is the only one of the three that is INSTANCE-SCOPED** — E1 is a property of the source chain and E2 of the parent, while E3 is a property of *which rendered copy the user pressed*, and that is why its second arm's sentence names the copy.
237:   - ⚠ **and when FEWER THAN TWO members resolve, the refusal is a DIFFERENT key — `no-sibling-in-this-copy` — because nothing failed to be found (r4).** A run of one is a well-defined *nothing here to trade places with* state, and it is **INSTANCE-SCOPED**: the same chain in the copy next door has two. Routing it through `chain-member-not-locatable` would tell the user the siblings could not be located when the sibling simply is not rendered here — the wrong relationship, which is wording rule 1's own failure.
328:| `parent-has-no-flow-axis` | E2, `display` not flex | 이 요소의 **부모에 흐름 축이 없어** 끌어서 순서를 바꿀 수 없습니다 — 부모를 auto-layout(flex)으로 바꾸면 가능합니다. | This element's **parent has no flow axis**, so it cannot be reordered by dragging — make the parent an auto-layout (flex) container first. |
329:| `layout-not-modelled` | E2, `rtl` / vertical writing mode / unequal `order` | 이 부모의 배치 방식은 **끌어서 순서 바꾸기가 아직 다루지 않는 형태입니다.** 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **This parent's layout is a form drag-to-reorder does not yet model.** The panel's ↑ / ↓ still work here. |
330:| `chain-member-not-locatable` | E3 — **ambiguity only**: the subject unresolvable, a member resolving to several nodes, or a member resolving to a deeper descendant | 화면에서 **형제 요소의 위치를 확정할 수 없어** 끌어서 바꿀 수 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **The siblings' positions on screen cannot be determined**, so dragging is refused. The panel's ↑ / ↓ still work here. |
331:| `no-sibling-in-this-copy` ⚠ **NEW (r4), SECOND CLAUSE REPLACED (r5)** | E3 — fewer than two members resolve in **this** rendered copy | **이 복사본에는 자리를 바꿀 형제 요소가 그려지지 않았습니다** — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다. | **In this rendered copy there is no sibling rendered to trade places with.** The panel's ↑ / ↓ still work here. |
335:⚠ **A GAP IN THIS MAP'S GATES, NAMED EVEN THOUGH r5's FIX CLOSES TODAY'S INSTANCE: NO GATE WATCHES THE TRUTH OF A REFUSAL SENTENCE'S SECOND CLAUSE.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check WHICH KEY fires. **Nothing checks that an alternative a sentence promises actually exists.** r4's `no-sibling-in-this-copy` promised *"another copy of the same element may allow it"* — an existential claim about other rendered copies **the refusal cannot check at paint time**, true on today's only subject (a five-copy `.map()`) and false the first time it fires on a SINGLE-copy conditional sibling, which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape — one instance, flex/row, resolved 2 at default, with `{nextThreshold && …}` as its sibling. **r5 replaced the prediction with the INVARIANT the class already uses** (*the panel's ↑ / ↓ still work here*), which holds by construction: sub-floor implies E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp: false, canMoveDown: true`). **Any future copy-prediction must be a SECOND variant gated on the instance count the client already has (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.**
337:**Wording rules:** (1) **the subject is the RELATIONSHIP that refused, never the element** — KI-17's filed defect was a sentence attached to the wrong relationship, and this plan broke the rule once and stated a relationship falsely once; (2) **`parent-has-no-flow-axis` must not name a display value** — §4.2(3) reads `display` only to test membership in `{flex, inline-flex}`, and **15 of the 79 className-carrying non-flex parents are `grid`**, so "block" would be wrong on 19 % of the population it addresses; (3) **ko + en**, per `AGENTS.md` and phase-46 S46-4 — `StructureSection`'s Korean-only `packages/descvi/src/react/overlay/panel/StructureSection.tsx#const REASON_TEXT: Record<StructuralRefusalReason, string> = {` is untouched.
361:| element in non-flex parent | **the gate this phase clarifies** — flips to a REFUSAL row naming `parent-has-no-flow-axis`; *"undefined blue-line; clarify at gate"* is discharged |
362:| **component instance** | **SHIPS WHERE THE OID REACHES THE DOM.** ⚠ **AND r3's *"refused as `chain-member-not-locatable` otherwise"* IS WRONG BOTH WAYS UNDER THE r4 RULE, AND IS DELETED (r5).** As a **SUBJECT** it is never refused at all — this plan's own text says such an oid *"cannot be pressed"*, so §4.1(a) term 4 never makes it a candidate and nothing is painted. As a **MEMBER** ruling (iii) **drops** it, and only where that leaves fewer than two survivors does that copy refuse — as **`no-sibling-in-this-copy`**, never as an ambiguity. ⚠ **This is the eighth of nine `chain-member-not-locatable` sites and the one the r4 by-cause sweep missed; it would have shipped a false sentence into a durable register this very section says NO GATE WATCHES.** ⚠ **r2's unqualified SHIPPED was false for the class this repo keeps a fixture of (M9):** an oid-bearing instance is an admissible op-unit for the **write**, but the **drag** needs a DOM node and `<Field data-oid="wcall1"/>` has none. **This is the exact shape the row above it flags, one row apart.** The `def move = v5` half is untouched |
391:⚠ **AND ONE SUBJECT THIS STORY DOES NOT OWE, SAID SO NOBODY AUTHORS IT TWICE: `no-sibling-in-this-copy` (G47-11d) is the ONE client-only refusal whose subject already SHIPS** — `lab/tests/shared-oid`'s `d4b6s3,d8m1w7`, five flex-parented instances resolving 2/2/2/2/1 in default state.
439:| **G47-11d** ⚠ **NEW (r4), AND ITS SUBJECT IS SHIPPED** | The sub-floor arm is INSTANCE-SCOPED and carries its own words. Two legs on one chain: pressing `d4b6s3` in **any of instances 0–3** admits and reorders; pressing it in **instance 4** paints `no-sibling-in-this-copy` — **not** `chain-member-not-locatable`, and **not** `no-reorderable-sibling`. | (i) Route the fewer-than-two case to `chain-member-not-locatable` → instance 4 tells the user the siblings could not be located when the sibling simply is not rendered there — the wrong relationship, wording rule 1. (ii) Route it to `no-reorderable-sibling` → the sentence claims no sibling exists in the parent, which is **false at source** (`d8m1w7` is a chain member with `prevOid: d4b6s3`). (iii) Restore r3's rule and refuse the whole chain when any member is missing → instances 0–3 stop admitting, which is the per-instance inconsistency (iii) exists to dissolve. | ⚠ **SHIPPED** — `src/app/lab/tests/shared-oid/page.tsx`'s `d4b6s3,d8m1w7`, default state, five flex-parented instances resolving **2/2/2/2/1**. Controls (round 4): remove the separator from instance 0 → `1,2,2,2,1`; plant one into the last → `1,2,2,2,2`. |
465:| **R47-7** ⚠ **POPULATION CORRECTED TWICE (r2 §C4, r3 §M5)** | A chain member joins to the wrong DOM node, or to none. | §4.2(2): parent-scoped, direct-child, resolved-members-only, with ambiguity refusing the whole gesture. ⚠ **r1 named "`insert-scratch` duplicate oid strings" (false — the corpus has one duplicated oid string and it is a comment). r2 named `.map()` bodies for the several-matches arm and `wflbl3` for the direct-child arm; round 3 measured BOTH wrong** — `.map()` produces 52 many-node readings at *partition* scope and **0 at parent scope**, and `wflbl3` is a **direct child** of its own wrapper. **The two AMBIGUITY arms are kept and their subjects are synthetic (G47-11c).** The real population the require-all rule would have refused — conditional siblings — is **dissolved by §4.2(2)'s drop-on-absence ruling wherever two survivors remain**. ⚠ **Where fewer than two survive it is not dissolved and it is not this risk**: nothing joined wrongly, the sibling simply is not rendered in that copy. That case left this arm at r4 for `no-sibling-in-this-copy`, whose subject is SHIPPED (G47-11d). |
553:- **Playwright — `e2e/reorder-drag.spec.ts`, declared `ambient`, plus the fourth press added to `e2e/spacing-gesture.spec.ts`.** ⚠ **The classification is argued (G47-13 leg ii):** the spec drives structural edits through the sidecar and asserts the resulting bytes on disk, so it **fails without a sidecar** — the `$doc`'s stated criterion. It resembles `e2e/structural-editing.spec.ts` (ambient, destructive, on-disk assertions), not `e2e/resize-handles.spec.ts` (neutral, a pure DOM-geometry checker). Rows: a full drag with on-disk bytes asserted; capture across the frame edge; the no-op-still-selects row; one Cmd+Z reverting a 3-position drag; the stage-background rows; wrap and overlap on their shipped subjects; the live-variant predicate; the three modelled-subset refusals with their LTR positive control; the `.map()` multi-instance row **and the instance-hint visibility leg**; the ambiguity refusals on S47-0's authored subjects; **the sub-floor row on `d4b6s3,d8m1w7` — admit in instances 0–3, `no-sibling-in-this-copy` in instance 4 (G47-11d), the one client-only refusal with a shipped subject**; the boundary-termination row. ⚠ **Destructive** — every mutating row owes the same `finally` snapshot-and-re-derive net `structural-editing.spec.ts` carries. ⚠ **And no row may depend on driving an in-page control by clicking on :3001 (§5, S47-6).**
zsh:3: command not found: k
zsh:3: command not found: k
266:2. re-derive the live chain via the new exported `resolveMoveDestination` (§3.2); **`anchorOid` absent from the subject's own parent chain ⇒ `stale-baseline` (409)** carrying the live origin baseline, so the shipped resync path needs no new client arm; ⚠ **`anchorOid === the subject's own oid` is a 400 (M9)** — §4.2(4) hit-tests over all members *including* the subject and §4.2(6) catches it client-side, so a request carrying it is a client that contradicted itself;
267:3. compute the destination slot and the direction; a direction disagreeing with the wire verb is a **400**;
271:7. **the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`** — a suffix built from the request echoes the *requested* k, identical under a correct fold and a broken one.
401:**S47-2 ∥ — the wire and the server composer.** The move-arm split; `expectDestination: {anchorOid, side}` REQUIRED-on-move / FORBIDDEN-elsewhere with its total parser and its self-anchor 400; the exported `resolveMoveDestination`; **the span-rearrangement primitive beside `swapSpans` and the ONE-SPLICE composer**; the direction-disagreement 400; the atomic abort; the applied-`k` echo; **an instrumented `parse` counter in the sidecar's test harness** so G47-20 can observe what §3.3 measured. **Verification: unit + the sidecar suite, plus the cost re-derivation against R47-4's threshold with the same controls (byte-equality against the naive fold, no-move, wrong-destination).**
435:| **G47-10b** | REQUIRED-or-FORBIDDEN: the field on a `delete`/`duplicate`/`insert-after` request is a **400**; its absence on a `move-up` is a **400**; **`anchorOid === the subject's oid` is a 400.** | Make the field optional → the first two rows stop being 400. Accept a self-anchor → the third returns 200 and writes nothing while reporting success. | shipped |
462:| **R47-4** ⚠ **THRESHOLD RE-DERIVED (M2)** | The in-lock rearrangement stalls the sidecar. | k ≤ chainLength − 1 ≤ 6. ⚠ **r2's *"under 19 ms"* was unreachable by a CORRECT implementation of the design it was written to accept**: a correct k-swap fold's best case is **21.49 ms**, so the criterion would have fired on a correct build and returned the k = 1 clamp for a reason unrelated to the design's merit. *(It was also self-inconsistent: "closer to the floor than to the ceiling" is `< 18.92`, not `< 19`.)* **Under the one-splice shape (§4.3(4)) the floor an implementation can occupy is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ 7.5 ms.** **Pre-committed acceptance, written before the measurement so it can go RED: the k = 6 rearrangement must complete in under 12 ms on `src/app/shop/order-detail/page.tsx`'s 7-member chain `kh1mfx…thbzev` (**40,979 bytes**), or the design is re-opened.** ⚠ **THAT CHAIN IS A COMPOSER BENCHMARK, NOT A DRAGGABLE SUBJECT (r4)** — its parent computes `display: table` and refuses at E2 (§5), so the lane building the Playwright row must not assume it can be dragged. The criterion is a server-side measurement over source bytes and is unaffected. ⚠ **The threshold is met: round 4 built the one-splice composer and measured 6.803 ms — 1.76× headroom — with the naive fold (33.0 ms) and a correct k-swap (≈21 ms) both RED against it, and byte-exactness confirmed in both directions including an interior up-move (index 3 → 1), a direction no earlier round had tested.** ⚠ **The subject is named because these numbers are page-size dependent — the same three primitives read 0.662 / 1.490 / 9.041 ms on `shop/member-list` (9,656 B).** Controls: byte-equality against the naive fold, no-move, wrong-destination. G47-20 pins the parse count. |
552:- **Sidecar / integration:** the anchor receipt's 409 arms and its self-anchor 400; the REQUIRED/FORBIDDEN 400s; the direction-disagreement 400; **the one-splice composer's byte-exact equality against the naive fold with the no-move and wrong-destination controls, its parse count (2), and its in-lock time against R47-4's pre-committed 12 ms on the named subject**; atomic abort; one journal push; the applied-`k` echo.

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import{chromium}from'@playwright/test';const b=await chromium.launch({headless:true}),p=await b.newPage();await p.setContent("'`<div id="p" style="display:block;direction:rtl"><span style="order:0">A</span><span style="order:0">B</span></div><div id="control" style="display:flex;direction:ltr;writing-mode:horizontal-tb"><span style="order:0">A</span><span style="order:0">B</span></div>`);const r=await p.evaluate(()=>{const admissible=el=>{const cs=getComputedStyle(el),kids=[...el.children];return ['"'flex','inline-flex'].includes(cs.display)&&cs.direction==='ltr'&&cs.writingMode==='horizontal-tb'&&new Set(kids.map(k=>getComputedStyle(k).order)).size===1};const parent=document.querySelector('#p'),before=admissible(parent);parent.style.display='flex';return{before,afterFlexOnly:admissible(parent),afterStyle:{display:getComputedStyle(parent).display,direction:getComputedStyle(parent).direction},positiveControl:admissible(document.querySelector('#control'))}});if("'!r.positiveControl||r.afterFlexOnly)throw new Error('"'instrument/control failed');console.log(JSON.stringify(r,null,2));await b.close();
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 120ms:
{
  "before": false,
  "afterFlexOnly": false,
  "afterStyle": {
    "display": "flex",
    "direction": "rtl"
  },
  "positiveControl": true
}

hook: PostToolUse
hook: PostToolUse Completed
codex
현재까지 세 가지 결함 후보가 재현되었습니다: non-self no-op anchor receipt, 충분조건이 아닌 flex 대안 문구, 그리고 scoped 측정과 “in this corpus” 절대 표현의 충돌입니다. 결론을 내리기 전에 `systematic-debugging`으로 각 후보의 원인·패턴·반증 가능성을 정리하고, `verification-before-completion` 절차로 probe 양성 대조·작업트리 무변경·서버 종료 상태를 다시 확인하겠습니다. 이 두 스킬 때문에 지금은 verdict를 보류합니다.
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '1,320p' /Users/kein/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/systematic-debugging/SKILL.md
sed -n '1,320p' /Users/kein/.codex/plugins/cache/openai-curated-remote/superpowers/6.3.0/skills/verification-before-completion/SKILL.md" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
---
name: systematic-debugging
description: Use when encountering any bug, test failure, or unexpected behavior, before proposing fixes
---

# Systematic Debugging

## Overview

**Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

**Violating the letter of this process is violating the spirit of debugging.**

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

If you haven't completed Phase 1, you cannot propose fixes.

## When to Use

Use for ANY technical issue:
- Test failures
- Bugs in production
- Unexpected behavior
- Performance problems
- Build failures
- Integration issues

**Use this ESPECIALLY when:**
- Under time pressure (emergencies make guessing tempting)
- "Just one quick fix" seems obvious
- You've already tried multiple fixes
- Previous fix didn't work
- You don't fully understand the issue

**Don't skip when:**
- Issue seems simple (simple bugs have root causes too)
- You're in a hurry (rushing guarantees rework)
- Manager wants it fixed NOW (systematic is faster than thrashing)

## The Four Phases

You MUST complete each phase before proceeding to the next.

### Phase 1: Root Cause Investigation

**BEFORE attempting ANY fix:**

1. **Read Error Messages Carefully**
   - Don't skip past errors or warnings
   - They often contain the exact solution
   - Read stack traces completely
   - Note line numbers, file paths, error codes

2. **Reproduce Consistently**
   - Can you trigger it reliably?
   - What are the exact steps?
   - Does it happen every time?
   - If not reproducible → gather more data, don't guess

3. **Check Recent Changes**
   - What changed that could cause this?
   - Git diff, recent commits
   - New dependencies, config changes
   - Environmental differences

4. **Gather Evidence in Multi-Component Systems**

   **WHEN system has multiple components (CI → build → signing, API → service → database):**

   **BEFORE proposing fixes, add diagnostic instrumentation:**
   ```
   For EACH component boundary:
     - Log what data enters component
     - Log what data exits component
     - Verify environment/config propagation
     - Check state at each layer

   Run once to gather evidence showing WHERE it breaks
   THEN analyze evidence to identify failing component
   THEN investigate that specific component
   ```

   **Example (multi-layer system):**
   ```bash
   # Layer 1: Workflow
   echo "=== Secrets available in workflow: ==="
   echo "IDENTITY: ${IDENTITY:+SET}${IDENTITY:-UNSET}"

   # Layer 2: Build script
   echo "=== Env vars in build script: ==="
   env | grep IDENTITY || echo "IDENTITY not in environment"

   # Layer 3: Signing script
   echo "=== Keychain state: ==="
   security list-keychains
   security find-identity -v

   # Layer 4: Actual signing
   codesign --sign "$IDENTITY" --verbose=4 "$APP"
   ```

   **This reveals:** Which layer fails (secrets → workflow ✓, workflow → build ✗)

5. **Trace Data Flow**

   **WHEN error is deep in call stack:**

   See `root-cause-tracing.md` in this directory for the complete backward tracing technique.

   **Quick version:**
   - Where does bad value originate?
   - What called this with bad value?
   - Keep tracing up until you find the source
   - Fix at source, not at symptom

### Phase 2: Pattern Analysis

**Find the pattern before fixing:**

1. **Find Working Examples**
   - Locate similar working code in same codebase
   - What works that's similar to what's broken?

2. **Compare Against References**
   - If implementing pattern, read reference implementation COMPLETELY
   - Don't skim - read every line
   - Understand the pattern fully before applying

3. **Identify Differences**
   - What's different between working and broken?
   - List every difference, however small
   - Don't assume "that can't matter"

4. **Understand Dependencies**
   - What other components does this need?
   - What settings, config, environment?
   - What assumptions does it make?

### Phase 3: Hypothesis and Testing

**Scientific method:**

1. **Form Single Hypothesis**
   - State clearly: "I think X is the root cause because Y"
   - Write it down
   - Be specific, not vague

2. **Test Minimally**
   - Make the SMALLEST possible change to test hypothesis
   - One variable at a time
   - Don't fix multiple things at once

3. **Verify Before Continuing**
   - Did it work? Yes → Phase 4
   - Didn't work? Form NEW hypothesis
   - DON'T add more fixes on top

4. **When You Don't Know**
   - Say "I don't understand X"
   - Don't pretend to know
   - Ask for help
   - Research more

### Phase 4: Implementation

**Fix the root cause, not the symptom:**

1. **Create Failing Test Case**
   - Simplest possible reproduction
   - Automated test if possible
   - One-off test script if no framework
   - MUST have before fixing
   - Use the `superpowers:test-driven-development` skill for writing proper failing tests

2. **Implement Single Fix**
   - Address the root cause identified
   - ONE change at a time
   - No "while I'm here" improvements
   - No bundled refactoring

3. **Verify Fix**
   - Test passes now?
   - No other tests broken?
   - Issue actually resolved?
   - Use the `superpowers:verification-before-completion` skill before claiming success

4. **If Fix Doesn't Work**
   - STOP
   - Count: How many fixes have you tried?
   - If < 3: Return to Phase 1, re-analyze with new information
   - **If ≥ 3: STOP and question the architecture (step 5 below)**
   - DON'T attempt Fix #4 without architectural discussion

5. **If 3+ Fixes Failed: Question Architecture**

   **Pattern indicating architectural problem:**
   - Each fix reveals new shared state/coupling/problem in different place
   - Fixes require "massive refactoring" to implement
   - Each fix creates new symptoms elsewhere

   **STOP and question fundamentals:**
   - Is this pattern fundamentally sound?
   - Are we "sticking with it through sheer inertia"?
   - Should we refactor architecture vs. continue fixing symptoms?

   **Discuss with your human partner before attempting more fixes**

   This is NOT a failed hypothesis - this is a wrong architecture.

## Red Flags - STOP and Follow Process

If you catch yourself thinking:
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "Skip the test, I'll manually verify"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "Pattern says X but I'll adapt it differently"
- "Here are the main problems: [lists fixes without investigation]"
- Proposing solutions before tracing data flow
- **"One more fix attempt" (when already tried 2+)**
- **Each fix reveals new problem in different place**

**ALL of these mean: STOP. Return to Phase 1.**

**If 3+ fixes failed:** Question the architecture (see Phase 4.5)

## your human partner's Signals You're Doing It Wrong

**Watch for these redirections:**
- "Is that not happening?" - You assumed without verifying
- "Will it show us...?" - You should have added evidence gathering
- "Stop guessing" - You're proposing fixes without understanding
- "Ultra-think this" - Question fundamentals, not just symptoms
- "We're stuck?" (frustrated) - Your approach isn't working

**When you see these:** STOP. Return to Phase 1.

## Common Rationalizations

| Excuse | Reality |
|--------|---------|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is FASTER than guess-and-check thrashing. |
| "Just try this first, then investigate" | First fix sets the pattern. Do it right from the start. |
| "I'll write test after confirming fix works" | Untested fixes don't stick. Test first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "Reference too long, I'll adapt the pattern" | Partial understanding guarantees bugs. Read it completely. |
| "I see the problem, let me fix it" | Seeing symptoms ≠ understanding root cause. |
| "One more fix attempt" (after 2+ failures) | 3+ failures = architectural problem. Question pattern, don't fix again. |

## Quick Reference

| Phase | Key Activities | Success Criteria |
|-------|---------------|------------------|
| **1. Root Cause** | Read errors, reproduce, check changes, gather evidence | Understand WHAT and WHY |
| **2. Pattern** | Find working examples, compare | Identify differences |
| **3. Hypothesis** | Form theory, test minimally | Confirmed or new hypothesis |
| **4. Implementation** | Create test, fix, verify | Bug resolved, tests pass |

## When Process Reveals "No Root Cause"

If systematic investigation reveals issue is truly environmental, timing-dependent, or external:

1. You've completed the process
2. Document what you investigated
3. Implement appropriate handling (retry, timeout, error message)
4. Add monitoring/logging for future investigation

**But:** 95% of "no root cause" cases are incomplete investigation.

## Supporting Techniques

These techniques are part of systematic debugging and available in this directory:

- **`root-cause-tracing.md`** - Trace bugs backward through call stack to find original trigger
- **`defense-in-depth.md`** - Add validation at multiple layers after finding root cause
- **`condition-based-waiting.md`** - Replace arbitrary timeouts with condition polling
---
name: verification-before-completion
description: Use when about to claim work is complete, fixed, or passing, before committing or creating PRs - requires running verification commands and confirming output before making any success claims; evidence before assertions always
---

# Verification Before Completion

## Overview

**Core principle:** Evidence before claims, always.

**Violating the letter of this rule is violating the spirit of this rule.**

## The Iron Law

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

If you haven't run the verification command in this message, you cannot claim it passes.

## The Gate Function

```
BEFORE claiming any status or expressing satisfaction:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute the FULL command (fresh, complete)
3. READ: Full output, check exit code, count failures
4. VERIFY: Does output confirm the claim?
   - If NO: State actual status with evidence
   - If YES: State claim WITH evidence
5. ONLY THEN: Make the claim

Skip any step = lying, not verifying
```

## Common Failures

| Claim | Requires | Not Sufficient |
|-------|----------|----------------|
| Tests pass | Test command output: 0 failures | Previous run, "should pass" |
| Linter clean | Linter output: 0 errors | Partial check, extrapolation |
| Build succeeds | Build command: exit 0 | Linter passing, logs look good |
| Bug fixed | Test original symptom: passes | Code changed, assumed fixed |
| Regression test works | Red-green cycle verified | Test passes once |
| Agent completed | VCS diff shows changes | Agent reports "success" |
| Requirements met | Line-by-line checklist | Tests passing |

## Red Flags - STOP

- Using "should", "probably", "seems to"
- Expressing satisfaction before verification ("Great!", "Perfect!", "Done!", etc.)
- About to commit/push/PR without verification
- Trusting agent success reports
- Relying on partial verification
- Thinking "just this once"
- Tired and wanting work over
- **ANY wording implying success without having run verification**

## Rationalization Prevention

| Excuse | Reality |
|--------|---------|
| "Should work now" | RUN the verification |
| "I'm confident" | Confidence ≠ evidence |
| "Just this once" | No exceptions |
| "Linter passed" | Linter ≠ compiler |
| "Agent said success" | Verify independently |
| "I'm tired" | Exhaustion ≠ excuse |
| "Partial check is enough" | Partial proves nothing |
| "Different words so rule doesn't apply" | Spirit over letter |

## Key Patterns

**Tests:**
```
✅ [Run test command] [See: 34/34 pass] "All tests pass"
❌ "Should pass now" / "Looks correct"
```

**Regression tests (TDD Red-Green):**
```
✅ Write → Run (pass) → Revert fix → Run (MUST FAIL) → Restore → Run (pass)
❌ "I've written a regression test" (without red-green verification)
```

**Build:**
```
✅ [Run build] [See: exit 0] "Build passes"
❌ "Linter passed" (linter doesn't check compilation)
```

**Requirements:**
```
✅ Re-read plan → Create checklist → Verify each → Report gaps or completion
❌ "Tests pass, phase complete"
```

**Agent delegation:**
```
✅ Agent reports success → Check VCS diff → Verify changes → Report actual state
❌ Trust agent report
```

## When To Apply

**ALWAYS before:**
- ANY variation of success/completion claims
- ANY expression of satisfaction
- ANY positive statement about work state
- Committing, PR creation, task completion
- Moving to next task
- Delegating to agents

**Rule applies to:**
- Exact phrases
- Paraphrases and synonyms
- Implications of success
- ANY communication suggesting completion/correctness

hook: PostToolUse
hook: PostToolUse Completed
 exited 1 in 274636ms:

> descvi-dogfood@0.1.0 dev /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
> vite
























[1;1H[0J
  VITE v5.4.21  ready in 265 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
^C[41m[30m ELIFECYCLE [39m[49m [31mCommand failed.[39m

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc 'pnpm dev' in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "node --input-type=module - <<'NODE'
import fs from'node:fs';import{chromium}from'@playwright/test';
function receipt(chain,subject,anchor,side){const w=chain.filter(x=>x"'!==subject),i=w.indexOf(anchor)+(side==='"'trailing'?1:0),out=[...w.slice(0,i),subject,...w.slice(i)];return{out,old:chain.indexOf(subject),next:out.indexOf(subject)}}let receipts=0,noops=0,badFormulaCaught=0,kMismatch=0;for(let n=2;n<=7;n++){const c=Array.from({length:n},(_,i)=>String.fromCharCode(65+i));for(const s of c)for(const a of c)for(const side of['leading','trailing']){if(s===a)continue;const x=receipt(c,s,a,side);receipts++;if(x.old===x.next)noops++;if(c.indexOf(a)+(side==='trailing'?1:0)"'!==x.next)badFormulaCaught++;if(Math.abs(x.out.indexOf(s)-c.indexOf(s))!==Math.abs(x.next-x.old))kMismatch++}}if(receipts!==224||noops!==42||badFormulaCaught===0||kMismatch!==0)throw new Error('"'anchor model control failed');
const map=JSON.parse(fs.readFileSync('.descvi/edit-map.json','utf8')).oids,chains=[];for(const[route,entries]of Object.entries(map)){const seen=new Set();for(const[oid,e]of Object.entries(entries)){if("'!(e.structure?.canMoveUp||e.structure?.canMoveDown)||seen.has(oid))continue;let h=oid;while(entries[h]?.structure?.prevOid)h=entries[h].structure.prevOid;const o=[];let c=h;while(c&&!seen.has(c)){seen.add(c);o.push(c);c=entries[c]?.structure?.nextOid}if(o.length>=2)chains.push({route,oids:o})}}if(chains.length!==235)throw new Error('"'chain census control failed');
const conditionalRoutes=[...new Set(Object.entries(map).flatMap(([route,e])=>Object.values(e).some(x=>x.structure?.opUnitKind==='conditional-container')?[route]:[]))];const browser=await chromium.launch({headless:true}),page=await browser.newPage({viewport:{width:1440,height:900}});
async function inert(route,label){const relevant=chains.filter(c=>c.route===route);return page.evaluate(({relevant,route,label})=>{const eq=(a,b)=>a.length===b.length&&a.every((x,i)=>x===b[i]),f=[];for(const c of relevant)for(const s of c.oids)for(const el of document.querySelectorAll("'`[data-oid="${CSS.escape(s)}"]`)){const p=el.parentElement;if(!p)continue;const cs=getComputedStyle(p);if(!['"'flex','inline-flex'].includes(cs.display)||cs.direction"'!=='"'ltr'||cs.writingMode"'!=='"'horizontal-tb')continue;const m=new Map(c.oids.map(o=>[o,[...p.children].filter(x=>x.getAttribute('data-oid')===o)]));if([...m.values()].some(x=>x.length>1))continue;const v=c.oids.filter(o=>m.get(o).length===1);if(v.length<2||"'!v.includes(s)||new Set(v.map(o=>getComputedStyle(m.get(o)[0]).order)).size!==1)continue;for(const a of v){if(a===s)continue;for(const side of['"'leading','trailing']){const w=c.oids.filter(x=>x"'!==s),i=w.indexOf(a)+(side==='"'trailing'?1:0),out=[...w.slice(0,i),s,...w.slice(i)];if("'!eq(out,c.oids)&&eq(out.filter(x=>v.includes(x)),v))f.push({route,label,chain:c.oids})}}}return f},{relevant,route,label})}
let zeroDefault=0,nonzeroDefault=0,knownVisible=false;for(const route of[...new Set(chains.map(c=>c.route))]){await page.goto(`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});const rs=await page.evaluate(cs=>cs.map(c=>c.oids.reduce((n,o)=>n+document.querySelectorAll("'`[data-oid="${CSS.escape(o)}"]`).length,0)),chains.filter(c=>c.route===route));rs.forEach((n,i)=>{n===0?zeroDefault++:nonzeroDefault++;if(route==='"'lab/tests/shared-oid'&&chains.filter(c=>c.route===route)[i].oids.includes('d4b6s3')&&n>0)knownVisible=true})}if(zeroDefault"'!==112||!knownVisible)throw new Error('"'default-state population control failed');
let attempts=0,clicks=0,findings=[];for(const route of conditionalRoutes){await page.goto("'`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});findings.push(...await inert(route,'default'));const n=await page.getByRole('button').count();for(let i=0;i<n;i++){attempts++;await page.goto("'`http://localhost:3000/${route}`,{waitUntil:'"'networkidle'});const b=page.getByRole('button').nth(i);if("'!await b.isVisible()||!await b.isEnabled())continue;try{const text=(await b.innerText()).trim().replace(/'"\\s+/g,' ');await b.click({timeout:1500});clicks++;await page.waitForTimeout(80);findings.push(...await inert(route,text))}catch{}}}const unique=[...new Map(findings.map(x=>[JSON.stringify([x.route,x.chain]),x])).values()];if(unique.length"'!==1||!unique[0].chain.includes('"'omy3i9'))throw new Error("'`render-inert expected known-only, got ${JSON.stringify(unique)}`);
await page.setContent(`<div id=p style="display:block;direction:rtl"><span>A</span><span>B</span></div><div id=c style="display:flex;direction:ltr;writing-mode:horizontal-tb"><span>A</span><span>B</span></div>`);const wording=await page.evaluate(()=>{const ok=e=>{const c=getComputedStyle(e);return['"'flex','inline-flex'].includes(c.display)&&c.direction==='ltr'&&c.writingMode==='horizontal-tb'&&new Set([...e.children].map(x=>getComputedStyle(x).order)).size===1},p=document.querySelector('#p'),before=ok(p);p.style.display='flex';return{before,afterFlexOnly:ok(p),positive:ok(document.querySelector('#c'))}});if(wording.afterFlexOnly||"'!wording.positive)throw new Error('"'wording control failed');await browser.close();console.log(JSON.stringify({anchor:{receipts,nonSelfNoops:noops,positiveControlBadFormulaCaught:badFormulaCaught,kMismatch},corpus:{chains:chains.length,zeroDefault,nonzeroDefault,conditionalRoutes:conditionalRoutes.length,buttonStatesAttempted:attempts,buttonStatesClicked:clicks,renderInertChains:unique},refusalAlternative:wording},null,2));
NODE" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 35986ms:
{
  "anchor": {
    "receipts": 224,
    "nonSelfNoops": 42,
    "positiveControlBadFormulaCaught": 112,
    "kMismatch": 0
  },
  "corpus": {
    "chains": 235,
    "zeroDefault": 112,
    "nonzeroDefault": 123,
    "conditionalRoutes": 10,
    "buttonStatesAttempted": 24,
    "buttonStatesClicked": 23,
    "renderInertChains": [
      {
        "route": "shop/member-detail",
        "label": "혜택 (2)",
        "chain": [
          "omy3i9",
          "0cyt4v",
          "z76fvu",
          "d29ipo"
        ]
      }
    ]
  },
  "refusalAlternative": {
    "before": false,
    "afterFlexOnly": false,
    "positive": true
  }
}

hook: PostToolUse
hook: PostToolUse Completed
 exited 1 in 74568ms:

> descvi-dogfood@0.1.0 dev /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
> vite
























[1;1H[0J
  VITE v5.4.21  ready in 214 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: use --host to expose
  ➜  press h + enter to show help
^C[41m[30m ELIFECYCLE [39m[49m [31mCommand failed.[39m

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc 'lsof -nP -iTCP:3000 -sTCP:LISTEN || true
lsof -nP -iTCP:3001 -sTCP:LISTEN || true
git status --short
git diff --stat
git diff -- .descvi/screens.json' in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
?? .omc/plans/ralplan-phase-47-drag-reorder.md

hook: PostToolUse
hook: PostToolUse Completed
hook: PreToolUse
hook: PreToolUse Completed
exec
/bin/zsh -lc "sed -n '495,535p' src/app/shop/member-detail/page.tsx
sed -n '1570,1605p' packages/descvi/src/extractor/structural-edit.ts
sed -n '477,510p' packages/descvi/src/sidecar/server.ts
sed -n '329,350p' packages/descvi/src/sidecar/server.ts" in /Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc
 succeeded in 0ms:
                {activeBenefits.length === 0 ? (
                  <Card data-oid="aawe0c" className="p-6 text-muted-foreground text-sm text-center">
                    활성 혜택이 없습니다
                  </Card>
                ) : (
                  activeBenefits.map(b => (
                    <Card data-oid="qyze89"
                      key={b.id}
                      className="p-4"
                    >
                      <div data-oid="jgdhrc" className="flex items-start gap-3">
                        <div data-oid="omy3i9"
                          className={`p-1.5 rounded-md text-xs ${BENEFIT_TYPE_COLORS[b.type]}`}
                        >
                          {b.type === 'coupon' ? '&#127991;' : b.type === 'point_bonus' ? '&#11088;' : '&#128666;'}
                        </div>
                        <div data-oid="0cyt4v" className="flex-1 min-w-0">
                          <div data-oid="dh7okh" className="flex flex-wrap items-center gap-2">
                            <p data-oid="jcey9r" className="font-medium text-sm">{b.title}</p>
                            <Badge data-oid="jws8kv"
                              variant="outline"
                              className={`text-[10px] ${BENEFIT_TYPE_COLORS[b.type]}`}
                            >
                              {BENEFIT_TYPE_LABELS[b.type]}
                            </Badge>
                          </div>
                          <p data-oid="e284af" className="mt-0.5 text-muted-foreground text-xs">{b.description}</p>
                          <div data-oid="e53g6p" className="flex flex-wrap gap-3 mt-1.5 text-muted-foreground text-xs">
                            <span data-oid="2dtotc">발급일 {b.issuedAt}</span>
                            {b.expiresAt && <span data-oid="jvbbn7">만료일 {b.expiresAt}</span>}
                            {b.minOrderAmount && <span data-oid="cmsa36">최소주문 {formatPrice(b.minOrderAmount)}</span>}
                          </div>
                        </div>
                        {b.value > 0 && (
                          <p data-oid="z76fvu" className="font-bold text-sm shrink-0">
                            {b.type === 'coupon' && b.value < 100
                              ? `${b.value}%`
                              : b.type === 'coupon'
                              ? formatPrice(b.value)
                              : b.type === 'point_bonus'
                              ? `${b.value}배`
 * move swap partner, so the client's edit-map flags and the server's re-derivation cannot drift.
 * Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour.
 */
function adjacentOpUnit(
  ctx: ModuleContext,
  children: AnyNode[],
  index: number,
  dir: -1 | 1,
): { node: AnyNode; index: number; oid: string; kind: OpUnitKind } | undefined {
  const separator = separatorAt(ctx, children[index + dir]);
  if (separator === undefined || separator.kind !== 'sep') return undefined;
  const candidate = children[index + 2 * dir];
  if (candidate === undefined) return undefined;
  const kind: OpUnitKind | undefined =
    nodeType(candidate) === 'JSXElement'
      ? 'element'
      : nodeType(candidate) === 'JSXExpressionContainer'
        ? 'conditional-container'
        : undefined;
  if (kind === undefined) return undefined;
  const element = opUnitElement(candidate);
  if (element === undefined) return undefined;
  const oid = oidOrNull(ctx, element);
  if (oid === null) return undefined;
  return { node: candidate, index: index + 2 * dir, oid, kind };
}

/**
 * The live `{parentOid, prevOid, nextOid}` for a target, or `undefined` when the target does not
 * resolve to an admissible op-unit at all. The client captures this at render time and sends it back
 * as `expect`; the server re-derives it under the write lock with this same function and 409s on mismatch.
 */
export function deriveStructuralBaseline(
  ctx: ModuleContext,
  screenId: string,
  oid: string,
export function computeStructuralEdit(
  params: StructuralEditIntent & {
    pageSource: string;
    specSource: string;
    fullScreenId: string;
    oid: string;
    usedOids: Set<string>;
    /** The palette key the wire validated, or `null` for the verbs that carry no payload. Resolved to TEXT only inside the composer, so the sidecar never holds snippet source. */
    snippetId: SnippetId | null;
  },
): StructuralWritePlan {
  const { pageSource, specSource, fullScreenId, oid, usedOids } = params;

  // A TOTAL switch, and the totality is load-bearing rather than tidy: this used to fall THROUGH to a
  // delete tail that passed a hardcoded `'delete'` to the resolver, so a verb reaching it by accident
  // would have been resolved and CUT — a 200 that deletes the element the caller asked to insert into.
  // A verb with no arm here is now a compile error instead.
  switch (params.op) {
    case 'move-up':
    case 'move-down': {
      const nextPage = moveAdjacent(pageSource, fullScreenId, oid, params.op === 'move-up' ? 'up' : 'down', params.expect);
      return { nextPage, nextSpec: null };
    }

    case 'duplicate': {
      const dup = duplicateSubtree(pageSource, fullScreenId, oid, usedOids, { expect: params.expect });
      return { nextPage: dup.source, nextSpec: null, newOid: dup.newOid };
    }

    case 'insert-after': {
      // ⚠ THE WHOLE VERB IS ONE CALL, and that is the design rather than brevity. `insertAfterOpUnit` is
      // `duplicateSubtree` with the copied bytes swapped for a registry snippet: the same `resolveJsxChildOp`
      // in the same shipped precedence, an op-ladder arm literally SHARED with `duplicate`, and a separator
      // the resolver proved. (US-7's panel reads `canInsertAfter` rather than `canDuplicate`; the identity stays the engine's own.) It is
function parseExpectForOp(op: StructuralWireVerb, expect: unknown): ParsedExpect {
  switch (op) {
    case 'delete':
    case 'move-up':
    case 'move-down':
    case 'duplicate':
    case 'insert-after': {
      const baseline = parseExpectBaseline(expect);
      return baseline === null ? { ok: false, error: EXPECT_REQUIRED_400 } : { ok: true, intent: { op, expect: baseline } };
    }
    case 'insert-child':
      return expect === undefined ? { ok: true, intent: { op, expect: null } } : { ok: false, error: EXPECT_FORBIDDEN_400 };
  }
}

/** What the insert verbs owe, and what the other FOUR structural verbs must not send. Listed from the shipped registry so the message and the accepted set cannot drift. */
const SNIPPET_REQUIRED_400 = `snippetId is required for an insert — it names a palette entry, one of ${SNIPPET_IDS.join('|')}`;

type ParsedSnippet = { ok: true; snippetId: SnippetId | null } | { ok: false; error: string };

/**
 * Renders a rejected `snippetId` for its 400 WITHOUT coercing it to a string first.

hook: PostToolUse
hook: PostToolUse Completed
codex
## Summary

최종 판정은 **REVISE**입니다. Anchor receipt의 기본 방향·거리 계산은 성립하지만, non-self no-op receipt가 서버 검증에서 빠져 있습니다. 또한 refusal 대안 문구 하나가 충분조건을 약속하고, scoped-zero 측정이 여러 곳에서 다시 corpus 전체의 절대값으로 서술됩니다.

## Analysis

### MUST-FIX

#### 1. Anchor receipt의 non-self no-op 누락 — 최우선 blocker

- **계획의 주장:** “`anchorOid === the subject's own oid` is a 400”; “a direction disagreeing with the wire verb is a 400.”
- **실제:** self-anchor가 아니어도 현재 위치를 표현할 수 있습니다. `[A,B,C]`에서 B의 목적지를 `trailing(A)` 또는 `leading(C)`로 지정하면 displacement는 0입니다. 이때 `move-up`/`move-down` 어느 쪽도 유효하지 않습니다.
- **검증:** 길이 2–7의 모든 chain에서 subject·anchor·side 조합을 exhaustive 실행했습니다. self-anchor를 제외한 224 receipts 중 **42개가 non-self no-op**였습니다. 잘못된 pre-removal anchor-index 공식을 심은 양성 대조는 112회 발화했습니다. 나머지 182개 non-noop receipt에서는 splice 전 방향 판정과 결과 순서에서의 `k` 복원이 모두 일치했습니다.
- **수정 요구:** §4.3에 `destinationIndex === sourceIndex ⇒ 400`을 명시하고 G47-10b에 adjacent-anchor no-op 두 형태를 추가해야 합니다. `resolveMoveDestination`은 splice 전에 normalized `{sourceIndex, destinationIndex, direction, appliedK}`를 만들고, zero와 verb-sign 불일치를 모두 거절해야 합니다.

#### 2. `parent-has-no-flow-axis`의 대안 약속이 충분조건이 아님 — blocker

- **계획의 주장:** “부모를 auto-layout(flex)으로 바꾸면 가능합니다 / make the parent an auto-layout (flex) container first.”
- **실제:** flex는 필요조건일 뿐 충분조건이 아닙니다. 같은 부모가 `rtl`, vertical writing mode 또는 unequal `order`를 가지면 flex로 바꾼 뒤에도 `layout-not-modelled`에서 거절됩니다.
- **검증:** headless Chromium에서 `display:block; direction:rtl` 부모를 `display:flex`로만 변경했지만 계획의 admissibility conjunction은 계속 false였습니다. 같은 probe의 LTR/horizontal/equal-order 양성 대조는 true였습니다.
- **수정 요구:** paint-time에 검증 가능한 불변식으로 바꾸십시오. E1이 이미 통과했으므로 다음 문구가 정확합니다:  
  `부모에 끌기 순서를 정할 흐름 축이 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다.`  
  `This parent has no flow axis for drag-to-reorder. The panel's ↑ / ↓ still work here.`

#### 3. Scoped zero가 downstream에서 다시 절대 corpus claim으로 바뀜 — blocker

- **계획의 주장:** R47-11의 “MEASURED AT ZERO in this corpus … nothing is lost today”와 Consequences의 “all with zero subjects in this corpus.”
- **실제:** status block은 올바르게 “no sweep has enumerated the state space”라고 밝히지만, §4.2, R47-11, S47-0 및 Consequences는 다시 무범위 절대 표현을 사용합니다.
- **검증:** 기본 상태 sweep은 양성 대조가 있는 상태에서 **112/235 chains가 zero-render**, 123개가 nonzero임을 재현했습니다. conditional-container가 있는 10 routes에서 기본 상태와 24개 단일-button 상태를 조사했고, 23개를 실제 클릭했습니다. Render-inert drag는 계획과 동일한 `shop/member-detail`의 `omy3i9,0cyt4v,z76fvu,d29ipo` chain만 검출됐습니다. 이는 조사한 범위에서의 재확인이지, 미도달 복합 상태까지 포함한 부재 증명은 아닙니다.
- **수정 요구:** 모든 zero claim을 probe scope와 결합하십시오. 예: “zero among the 930 elements observed by round 3” 및 “no additional subject in default plus single-button states driven by the final vendor sweep.” 특히 R47-11의 미측정 범위는 “future corpus growth”뿐 아니라 **현재 corpus의 unobserved states**도 포함해야 합니다.

### WORTH-CONSIDERING

#### Applied `k`의 결과 타입을 명시

- **계획의 주장:** “the 200 payload echoes the APPLIED `k` and the sidecar's log suffix reads the RESULT, not `body`.”
- **실제:** 계산은 가능합니다. Exhaustive probe에서 모든 182 nonzero receipt의 결과 순서로부터 `k`가 정확히 복원됐습니다. 다만 현재 계획은 “RESULT”가 어떤 타입인지 명시하지 않습니다.
- **권고:** `StructuralWritePlan` 또는 one-splice composer 결과에 `appliedK`를 명시적으로 포함시키고, response와 log가 그 필드만 읽도록 고정하십시오. 이는 실행 중 타입 설계로 처리할 수도 있지만, #1 수정과 함께 적으면 gate가 더 명확해집니다.

## Root Cause

마지막 수정은 개별 발견을 국소적으로 고쳤지만 동일 의미의 다른 표현까지 정규화하지 않았습니다.

- Anchor 검증은 “self-anchor”라는 입력 모양만 금지하고, 정규화된 destination의 의미인 zero displacement를 금지하지 않았습니다.
- Refusal 문구는 가능한 개선책을 충분조건으로 승격했습니다.
- Scope qualification은 status block에만 남고 risks·stories·consequences의 절대 표현으로 전파되지 않았습니다.

## Recommendations

1. **Non-self zero displacement를 400으로 규정하고 G47-10b에 RED mutation 추가** — 낮은 노력, 계약 blocker 제거.
2. **`parent-has-no-flow-axis`의 두 언어 문구를 panel-button 불변식으로 교체** — 낮은 노력, 거짓 대안 제거.
3. **`zero`/`0/930`/`zero subjects in this corpus`를 by-cause grep하여 관찰 범위로 한정** — 낮은 노력, 네 SYNTHETIC 선언의 증거 경계 복구.
4. **Normalized destination/result 타입에 direction과 `appliedK` 명시** — 낮은 노력, 구현 및 observability 오해 방지.

## Trade-offs

| Option | Pros | Cons |
|---|---|---|
| Zero displacement → 400 | 무의미한 journal entry와 `k=0` 성공 응답 방지 | 서버 검증 및 gate 두 행 추가 |
| Zero displacement → 200 no-op | 구현이 단순함 | verb 계약과 one-request/one-undo 의미를 흐림 |
| Flex 안내 유지 | 구체적인 사용자 조언 | 다른 E2 조건 때문에 거짓 약속 가능 |
| Panel ↑/↓ 안내 | E1 이후 항상 검증 가능한 대안 | auto-layout 교육성은 감소 |
| Scope-qualified zero | 측정과 주장이 정확히 대응 | 반복 문구가 조금 길어짐 |
| Corpus-wide zero | 간결함 | 현재 probe가 증명하지 않은 범위를 주장 |

## Consensus Addendum

- **Antithesis (steelman):** `k=1`로 제한하면 기존 `moveAdjacent` 경로를 그대로 사용하고 anchor normalization, no-op receipt, applied-`k` observability를 모두 제거할 수 있습니다.
- **Tradeoff tension:** 다중 위치 drag의 UX 가치와 서버 계약·composer 복잡성 사이의 긴장입니다.
- **Synthesis:** 다중 위치 anchor 설계는 유지하되, 서버가 receipt를 normalized displacement로 변환한 뒤 zero/sign 검증을 완료하고 그 결과 객체를 splice·response·log의 단일 권위로 사용하십시오.
- **Principle violations:** P47-5 위반 가능성 높음—현재 G47-10b는 non-self no-op mutation에서 RED가 되도록 규정되지 않았습니다. Standing evidence rule 위반은 중간 수준—status의 scope가 downstream 절대 주장에 전파되지 않았습니다.

## References

- `packages/descvi/src/sidecar/server.ts#function parseExpectForOp(` — 현재 per-op receipt parser의 기준 구조.
- `packages/descvi/src/sidecar/server.ts#export function computeStructuralEdit(` — 현재 move write plan과 response 결과의 출발점.
- `packages/descvi/src/extractor/structural-edit.ts#function adjacentOpUnit(` — origin baseline과 source chain adjacency의 권위.
- `packages/descvi/src/extractor/structural-edit.ts#export function moveAdjacent(` — 현재 단일-step composer.
- `src/app/shop/member-detail/page.tsx#                      <div data-oid="jgdhrc" className="flex items-start gap-3">` — 확인된 render-inert chain의 flex parent.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §4.3 — anchor receipt 서버 계약.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §4.5 — bilingual refusal map.
- `.omc/plans/ralplan-phase-47-drag-reorder.md` §7 — scoped-zero reachability risk.

검토 중 파일은 수정하지 않았고, 실행한 Vite 서버는 종료했습니다. tracked diff와 잔류 listener는 없으며 `git status --short`에는 계획 파일 자체만 untracked로 남아 있습니다.

**VERDICT: REVISE**

판정은 순서대로 (1) non-self no-op anchor receipt의 서버 계약 누락, (2) 검증 불가능한 flex 대안 약속, (3) scoped-zero의 절대 corpus claim 재발에 근거합니다. Render-inert 모집단은 제가 구동한 기본 및 단일-button 상태 범위에서는 계획의 한 chain만 재확인됐습니다.
hook: Stop
hook: Stop Completed
tokens used
291,331

```

## Concise summary

Provider completed successfully. Review the raw output for details.

## Action items

- Review the response and extract decisions you want to apply.
- Capture follow-up implementation tasks if needed.
