# phase-47 — LIVE PROBE LANE (round 3)

You are the **live measurement lane**. You are not reviewing prose. **Your deliverable is numbers, driven against a real browser and a real DOM**, for a set of claims this plan has carried for three revisions as UNVERIFIED or UNMEASURED.

This lane exists because the plan's two best findings so far came from running things rather than reading them: a headless-Chromium run falsified its CSS model, and a timing probe found its in-lock bound was 2.2× wrong. **Everything left on the plan's own "least confident" list needs a DOM.** That is what you supply.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout, and never touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read first

1. `.omc/plans/ralplan-phase-47-drag-reorder.md` — the plan. Read §4.1 (arming, capture, the terminal), §4.2 (the drop table and the join), and the risks. You need enough of it to know what each number is FOR.
2. `AGENTS.md` and `docs/prompt/worker-brief.md`.

## Rules you work under

- **Do not edit the plan or any source file.** Probes and scratch go under `.omc/state/probe-r3/` (gitignored). Leave the tree clean; `git status --porcelain` at the end must show only the pre-existing untracked plan.
- **Never own git.** No commit, add, stash, checkout, branch, reset.
- **Do not spawn anything that writes or judges your work.**
- **Positive-control every instrument before any number leaves your hands.** A zero is evidence only after you have shown the probe can produce a non-zero. Plant the signature you are hunting and confirm the search finds it. This project has had instrument failures caught by controls and **none** caught by reading — including a probe that returned every subject because it passed the wrong argument shape, and one that returned zero because of a shell-escaping bug in its own tokenizer.
- **Report the command beside every number**, and say what its control was. A number without a re-derivable command is not a measurement.
- **If a measurement is impossible, say so and say why.** A stated gap is worth more than an estimate. Do not fill a hole with a guess.

## Running the app

`npm run descvi:dev` serves the design view on **:3001** with the `descvi-sidecar` on **:7331**. The user has standing authorisation for this lane to kill existing `descvi:dev` listeners on those ports if they block a clean run — do it without asking, but say in your report that you did. Playwright is already set up in this repo (`e2e/`); reuse its config and helpers rather than building a harness from scratch, and read how an existing spec boots the app before writing your own driver.

⚠ **Do not leave a server running when you finish.**

## What to measure — six questions, in priority order

The first three are the plan's own top uncertainties. The rest are cheaper and still owed.

### Q1 — The uniqueness join: how many chain members do NOT resolve to exactly one element?

§4.2(2) refuses the whole gesture if any chain member fails to resolve to exactly one element under the subject's own `parentElement`. Its population is **unmeasured**, and the plan knows two shapes exist in both directions:
- **Zero nodes** — `src/app/lab/challenge/swallowed-oid/page.tsx`'s `Field({label, value})` takes no `...rest`, so `wcall1`–`wcall4` are a fully eligible four-member chain in the artifact that reaches **no** DOM node.
- **Many nodes** — `.map()` bodies. `src/app/sandbox/resize-repeat-list/page.tsx`'s `smcell`/`smname`/`smtagg` render four times each; the same file's neighbours and `swallowed-oid`'s `wflbl3`/`wfval7` likewise.

**Measure, over every screen the app serves:** for each admissible multi-member chain, how many of its members resolve to 0, 1, or >1 elements within the subject's `parentElement` subtree — and therefore **how many whole chains the uniqueness rule would refuse.** Report as a count and as a fraction of the 235 multi-member chains.

### Q2 — The direct-child rule: how many chain members render as non-direct children?

§4.2(2) also requires (or is being asked to require) that a chain member be a **direct child** of the subject's `parentElement`. Uniqueness is not sibling-hood: a member wrapped by a component renders as a *grandchild*, resolves uniquely, and hands the hit-test a box that is not a flex item of the parent whose axis was just read.

**Measure:** over the same population, how many members resolve to an element whose `parentElement` is NOT the subject's `parentElement`. The plan says a high count makes the rule the wrong trade — so this number decides a contract.

### Q3 — The CSS-refusal population: rtl, vertical writing, unequal `order`

The plan now refuses reorder unless the parent computes `direction: ltr`, `writing-mode: horizontal-tb`, and **all** sibling `order` values are equal. Nothing counts how often that fires.

**Measure, in the live DOM:** across every screen, over the parents of admissible multi-member chains — how many compute `direction: rtl`; how many compute a non-`horizontal-tb` `writing-mode`; how many have children with unequal computed `order`. ⚠ **`order` is the one to be careful with**: its default is `0` and it can be set by a class the corpus author never thought of as layout, so read it computed, per child, and report the distribution rather than a boolean.

### Q4 — `setPointerCapture` on a STAGE host

Phase-42 measured that the pointer stream and `pointerup` survive the pointer leaving the frame by 500 px — **on a handle host**. The plan proposes capturing on `#dsh-stage` and **explicitly does not re-claim that measurement**.

**Measure:** with `setPointerCapture` on `#dsh-stage`, does a drag that leaves the viewport keep delivering `pointermove`, and does `pointerup` still arrive and stay attributable? Drive it with real pointer events (Playwright's `mouse` API or CDP), not synthetic dispatch. **State the browser and its version** — this is a capture-semantics question and it is not guaranteed uniform.

### Q5 — Do real corpus flex containers actually wrap, and do sibling rects overlap?

§4.2(4)'s hit-test is written for wrapping parents and for overlapping rects, with tie-breaks the plan admits are **reasoned, not observed**.

**Measure:** across the corpus's admissible chains, how many parents actually produce a multi-line (wrapped) flex layout at the default viewport, and how many sibling pairs have overlapping bounding rects. If the answer is zero for either, say so — a tie-break rule with no subject is worth knowing about before it gets a gate.

### Q6 — The refusal populations the plan asserts from the artifact, confirmed in the DOM

The plan's 22 / 108 / 62 singleton split and its 133/83/19 parent-layout split are **artifact** measurements, re-derived four times and solid. But the plan's own D47-2 now says live prevalence is UNVERIFIED.

**Measure the live version of the parent-layout split**: over the parents of admissible chains, how many compute `display: flex` or `inline-flex` in the running app. Compare against the authored-token proxy's 83 / 133 / 19. **This is the number that either grounds or retires the "majority case" claim**, and the plan has deliberately stopped asserting it pending a live census.

## Report

Your report is your **FINAL MESSAGE** — printed text reaches nobody.

Structure it as: one table of Q1–Q6 with the headline number and the command; then per question, the method, the control (what you planted and what it produced), the full result, and **what it means for the plan's contract** — which claim it confirms, which it falsifies, and which gate it gives or removes a subject.

End with an explicit list: **claims this lane CONFIRMED**, **claims it FALSIFIED**, and **claims it could not reach, with the reason**. Do not give a verdict on the plan as a whole — that is the other lanes' job. Give the measurements.
