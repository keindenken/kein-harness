# phase-47 ralplan — FRESH REVIEW

You are reviewing a plan you have not seen before. **Read it as a new reviewer would**, and find what is wrong with it — including anything earlier readers may have missed.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout, and never read, write or reason about the sibling worktree `phase-47-drag-reorder-in-kein` — a different harness owns it.

## Read

1. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the plan under review.
2. **`.omc/state/phase47-context.md`** — the planning context: the owner's ruling on what this phase is, the lead's rulings on what it is not, and the bar.
3. **`AGENTS.md`** — binding project rules. Its verification-gates and workflow sections are not background.
4. **`docs/prompt/worker-brief.md`** — the rules you work under.

⚠ **There are other files under `.omc/state/` from this planning round. Do not read them.** They are earlier reviews, and this lane's value is that it has not seen them. If you find yourself wanting to know what a previous round said, that is the impulse to resist — the question is what is wrong with the text in front of you, not whether someone already said so.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch goes under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE** — printed text reaches nobody.

## The bar

- Acceptance criteria concrete enough to FAIL; no vague term without a metric.
- Every risk paired with a MECHANISM, not a restatement of intent.
- Gates that can go RED, each with a stated RED-when naming the mutation. **A gate that is green on the implementation AND on its negation is vacuous** — this repo has shipped one.
- An ADR: decision, drivers, alternatives, why chosen, consequences, follow-ups.
- Code cited by ANCHOR (`path#exact source text`, unique in that file), never by line number.
- **A decision closed for a WEAK reason is a defect.** A reviewer who defeats the weak reason reopens a decision that was actually closed.
- **A conclusion can be RIGHT while its REASON is FALSE, and the reason is what builds the gate.** Five of seven falsified facts on an earlier phase here were exactly that shape. When you accept a decision, accept the REASONING.
- **A fact checked against an ARTIFACT is not verified until it is checked against the RUNNING APP.** The plan tags claims VERIFIED / UNVERIFIED. Check the tags are honest — and flag any VERIFIED that is really artifact-only.

## How to work

**Probe rather than reason where a claim is about what code DOES.** Import the module and call it; write a throwaway probe under `.omc/state/`; run the existing suite; execute the script the plan says is or is not a gate. Reading and concluding is the weaker instrument.

**Positive-control every instrument before any number leaves your hands.** A zero result is evidence only after you have shown the probe can produce a non-zero one — plant the signature you are hunting and confirm the search finds it. This project has had instrument failures caught by controls and none caught by reading, including a probe that silently returned every subject because it passed the wrong argument shape.

**Verify what the plan asserts about the repo.** It makes many claims about shipped code — what a function is, what a gate watches, what a docblock records, what a population measures. Any of them can be false, and a false claim that survives into execution costs a phase.

## Nothing withheld

This plan is complete as it stands — there is no pending decision being kept from you, and nothing in it is a placeholder. Review it as the finished artifact it claims to be.

## Report

Separate **MUST-FIX** from **WORTH-CONSIDERING**. For every finding: quote the claim, state what is actually true, say how you established it (the command you ran or the exact source text you read), and say what the plan should say instead.

End with an explicit verdict: **APPROVE** or **REVISE**. A conditional approve is a REVISE.
