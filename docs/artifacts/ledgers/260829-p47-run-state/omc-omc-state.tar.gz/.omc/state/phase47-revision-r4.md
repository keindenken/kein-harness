# phase-47 ralplan — SHORT FINAL EDIT (after the round-4 delta check)

⚠ **Seven edits, all named. Do not re-open anything else.** The delta lane verified every other delta CLOSED, built M1's composer and confirmed it, and reported that the design layer has stopped moving everywhere except one paragraph. **After this edit the plan goes to codex for its single remaining vendor-independent call.**

**What was confirmed, so you do not re-do it:** the one-splice composer runs, is byte-exact against the naive fold **in both directions including an interior up-move (index 3 → 1)** — a direction nobody had tested — parses **2** against the naive fold's **12** (measured with an instrumented `parseSync`, not arithmetic), and lands at **6.803 ms** against your 12 ms pre-commitment (1.76× headroom; the naive fold at 33.0 ms and a correct k-swap at ≈21 ms both go RED). R47-4's threshold is sound. The citation gate is GREEN over **980** anchors. M4's parentage, M7's shipped `mousemove` listener, M8's docblock and M10's host-specific mechanism all verified at source.

⚠ **The lane's own scope caveat, carried so nothing is over-read:** it enumerated **215** of 235 multi-member chains (naive screen-id derivation, no `::` sub-screens) and swept **default state only**. Its zero-counts are therefore lower bounds on coverage. **Every positive finding below is a default-state observation on a named chain and stands on its own.**

---

## 1. ⚠ THE BLOCKING ONE — the drop-on-absence ruling's dividend is false on a shipped subject

Your §4.2(2) concludes: *"Under (iii) all 15 chains admit in every instance, and the per-instance inconsistency does not exist."*

**Measured, default state, all five instances flex-parented** — `src/app/lab/tests/shared-oid/page.tsx`, chain `d4b6s3,d8m1w7`:

```
per-instance resolved members: 2 / 2 / 2 / 2 / 1      flex: true ×5
```

Five `<li data-oid="d7c2h9">` instances; the separator `src/app/lab/tests/shared-oid/page.tsx#{i < arr.length - 1 && <span data-oid="d8m1w7"` is conditional on not being last, so the fifth resolves **one** member. Under your own floor (*"or when fewer than two members resolve"*) that instance takes `chain-member-not-locatable` — while every arming precondition holds: term 4 passes (`d4b6s3` renders in all five), E1 passes (`canMoveUp=false, canMoveDown=true`, measured), E2 passes (all five parents compute flex).

**So the user drags the last step label, is refused, drags the identical label one column left, and it works** — which is verbatim the sentence §4.2(2) uses to reject option (i). **The ruling moved the boundary from "any member missing" to "fewer than two survive". It did not remove it.**

The lane's controls make this evidence rather than a blind spot: removing the separator from instance 0 → `1,2,2,2,1`; planting one into the last → `1,2,2,2,2`. The detector produces a 1 from a change and erases the observed 1 by adding the missing node.

**Root cause worth stating in the plan, because it is this phase's recurring shape:** the ruling was derived from the right measurement but validated against the wrong population — chains where *some* member goes missing, never chains where **enough** go missing to fall below its own floor. **For a 2-member chain with one conditional sibling those are the same event.**

### LEAD RULING — the sub-floor case is a THIRD condition with its own key, not `chain-member-not-locatable`

Keep ruling (iii); it is correct on its merits and genuinely dissolves the refusal wherever two survivors remain. **Do not reopen it.** But a run whose resolved length is 1 is not an *unlocatable member* — nothing failed to be found. **It is a well-defined "nothing here to trade places with" state, and it is INSTANCE-SCOPED**, which is exactly what distinguishes it from the neighbouring instance that succeeded.

So: a new client-only key whose sentence **names the instance**. `no-reorderable-sibling` will not do — its wording (*"같은 부모 안에 순서를 바꿀 형제 요소가 없습니다"*) is false here at source, where the sibling exists. The honest sentence says that in *this* rendered copy no sibling is rendered. **Wording is yours** — you have made the per-cause relationship sentences work three times and this is the same craft — but it must satisfy wording rule 1 and it must survive a user who just succeeded one column over.

**Then:** give the arm a gate leg with `d4b6s3,d8m1w7` as its **shipped** subject, and correct G47-11c's subject cell — the two ambiguity arms stay SYNTHETIC (the lane independently reproduced 0 several-matches and 0 deeper-descendant readings at parent scope, with a planted control that fires), but the fewer-than-two arm is shipped. **This is the one place in the text where the plan is LESS confident than the evidence permits, and it under-claims rather than over-claims.**

---

## 2. `N` is instance-local, and the consequence is unstated

Measured on the chain the plan itself names — `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1`: six step columns, per-instance `3/3/3/3/3/2`, all flex. **All six admit** — ruling (iii) works here. But the readout then shows `n / 3` in five columns and **`n / 2` in the sixth, for a write that is a single template edit changing all six identically** (§4.2(7), G47-16).

So the per-instance inconsistency was not dissolved; it was **relocated from the refusal into the readout**, by the consequence ruled in the same paragraph.

**Keep the ruling — the KI-17 argument for it is right.** What it does not answer is that *a denominator which changes between visually identical rows is also a number the user cannot reconcile.* State plainly that `n / N` is **instance-local**: it describes neither the source order the edit acts on (in column 0, `5s41w1` shows `2 / 2` while being source index 2 of 3) nor the scope of the edit. Tie it to §4.2(7) and to the instance hint §4.1(h) deliberately keeps visible for exactly this purpose. **Then route the readout's semantics to a new U-item** — the readout is ground the owner personally ruled, so its meaning is not yours or mine to settle silently.

---

## 3. §4.2(6)'s no-op detection names no order-space

*"A destination equal to the subject's current position issues no request"* was unambiguous until members could be dropped. Now source order and rendered order differ: source `[A, B_unrendered, C, D]`, rendered `[A, C, D]` — drag `A`, drop leading-of-`C`, source becomes `[B, A, C, D]` and **the render does not change.**

**LEAD RULING: no-op detection is over SOURCE position.** That is what the write acts on, what the receipt addresses, and what the undo entry restores; a render-space check would refuse a reordering the user actually expressed. **State the residual rather than preventing it:** a source-effective, render-inert drag issues a real request, consumes an undo slot, and arms the latch. Say so, and note the lane's finding that **no flex-parented subject can construct it today** (the nearest shape, `shop/member-detail`'s `ww57qb,bklj64,4b6oqr,3fz48z`, computes `display: block` and refuses at E2 first) — so this is a stated design consequence, not a shipped defect.

**And cover the edge the current sentence omits:** when the unrendered member is **first**, the user cannot express "make this the first child" at all — there is no rendered sibling to aim leading-of.

---

## 4. §5's fixture inventory was written from the authored proxy, in the places §4.2(3) rules the proxy must not be trusted

⚠ **This is pre-mortem 3's own class, and the irony is worth one clause in the plan: D47-2's whole story is that the authored token is corroboration and the live read is authoritative — and then the inventory was written from the token.**

- **"three flex-row chains of 7" is two.** `shop/order-detail`'s `kh1mfx…thbzev` has a parent computing **`display: table`**, so it refuses at E2 and **can never be a drag subject**. The two `shop/member-list` chains stand. *(Control: `4jpxin` on the same page reads `flex row` through the same reader, so the reader can see flex.)*
- **The three "flex-col 5-chains" are non-flex-parented.** `sandbox/resize-flex-col`, `sandbox/resize-flex-row` and `sandbox/resize-repeat-list` all compute **`block`** at the chain's parent. They cannot serve G47-8 because of **E2**, not because of their conditional members — the stated reason is wrong. *(Control: the same reader returns `flex row` for `smcell`'s parent on `resize-repeat-list`.)* ⚠ §4.2(2) also calls `sandbox/resize-repeat-list` *"the clearest"* conditional-sibling example — true at source level, but it is **not a draggable subject** and the sentence reads as though it were. Qualify it.
- **R47-4 keeps `kh1mfx…thbzev` as its acceptance subject and that is fine** — the criterion is a server-side composer measurement and the plan already says the numbers are page-size-dependent. But add one clause: **it is a composer benchmark, not a draggable chain**, or the lane building the Playwright row will assume it is.
- **Unit slip in the same sentence:** *"39.8 KB"* is `order-detail`'s JS **string length**; the file is **40,979 bytes**. `member-list`'s 9,656 B is correct. Two units in one sentence, in the acceptance criterion for a byte-oriented composer.

---

## 5. The conditions count regressed while closing M9

Four spellings now: §4.5's C47-5 says *"FIVE KEYS OVER FOUR CONDITIONS"*, the table heading says *"four conditions, five keys"*, §4.1 enumerates **E1/E2/E3 — three**, §12 says *"the eligible split's three questions"*. **Four is not derivable under any consistent reading.** r2's "three" was at least consistent with §4.1. Pick one and make all four sites agree — and note that §1 above adds a key, so recount after that edit rather than before.

---

## 6. Pre-mortem 3 under-counts its own record, by its newest entry

It heads *"A GATE PASSES BECAUSE ITS SUBJECT CANNOT PRODUCE THE FAILURE"* and counts four. Two of those four belong to that class (r2's G47-11c, r2's G47-19). **r0's G47-1 was an UNCONSTRUCTIBLE mutation and r1's G47-11b(i) a NON-DISCRIMINATING one** — P47-5's other two clauses, different failures.

**And it is one short: M4 / G47-16 leg (ii) — this revision's own defect — is described at §4.1(h) and in G47-16 in the identical words used for r1's G47-11b(i)** (*"green on the defect and on the correct behaviour alike"*), and appears in neither P47-5's enumeration nor pre-mortem 3's. **The paragraph whose entire point is the count under-counts by its freshest instance.**

Correct it to **five, split by class**: two subject-class, three mutation-class. And say plainly that §6's subject column and the SYNTHETIC declarations are mechanisms **for the subject class only** — for the mutation classes the plan offers the standing *"every gate is shown RED under its named mutation before it is believed green"* obligation, which is a **resolution, not a mechanism.** Naming that gap honestly is worth more than papering it.

---

## 7. Sweep

The drop-on-absence ruling's sweep was complete for what it touched (§4.2(1)–(5), §4.4, DR47-4(f), §4.5, G47-11c, G47-19, R47-7, S47-0, the ADR, §12). **It did not reach: §4.2(6) (item 3), §6 (item 1 — no leg for the arm it created), §8 (no U-item — item 2), §11 (no pre-mortem row).** Close those four, then re-sweep by cause for the new key item 1 mints. Round 3 completed both its sweeps; this would make three in a row.
