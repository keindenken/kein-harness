import { chromium } from '@playwright/test';
const BASE = process.env.PBASE;
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1440, height: 950 } })).newPage();
await page.goto(BASE + '/shop/member-detail', { waitUntil: 'load' });
await page.waitForSelector('[data-screen="shop/member-detail"]');
await page.waitForTimeout(600);
const base = await page.evaluate(() => document.querySelectorAll('[data-oid]').length);
console.log('baseline oidEls', base);
for (const i of [1, 2, 0]) {
  const n = await page.evaluate((idx) => {
    const b = document.querySelectorAll('[data-oid="x5hoyo"]')[idx];
    if (!b) return 'no-button';
    b.click();
    return 'clicked';
  }, i);
  await page.waitForTimeout(400);
  const after = await page.evaluate(() => ({
    oids: document.querySelectorAll('[data-oid]').length,
    i3b9gu: document.querySelectorAll('[data-oid="i3b9gu"]').length,
    pk9pwr: document.querySelectorAll('[data-oid="pk9pwr"]').length,
  }));
  console.log('tab', i, n, JSON.stringify(after));
}
await browser.close();
