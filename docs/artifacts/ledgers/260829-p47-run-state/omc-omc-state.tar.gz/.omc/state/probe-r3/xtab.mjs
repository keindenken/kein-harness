import { readFileSync } from 'node:fs';
const ROOT = process.env.PROOT;
const L3 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', 'utf8'));
const L4 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live4-raw.json', 'utf8'));
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));
const editMap = JSON.parse(readFileSync(ROOT + '.descvi/edit-map.json', 'utf8'));

const key = (s, m) => s + '|' + m.join(',');
const live = new Map();
const take = (raw, allowTab) => {
  for (const r of raw.runs) {
    if (r.unreached) continue;
    if (allowTab && !(r.tab > 0 && r.tabMoved === true)) continue;
    for (const ch of r.chains) {
      const k = key(r.screenId, ch.members);
      if (live.has(k) || ch.scopes.length === 0) continue;
      live.set(k, ch.scopes[0].parent.display);
    }
  }
};
take(L3, false);
take(L4, true);

const tab = {};
let n = 0;
for (const c of chains) {
  const e = editMap.oids[c.screen], p = c.parentOid;
  let proxy;
  if (p === null || e[p] === undefined) proxy = 'unknown';
  else {
    const cn = e[p].className;
    if (cn === null || cn === undefined) proxy = 'nonflex(no-class)';
    else {
      const t = String(cn).split(' ');
      proxy = t.includes('flex') || t.includes('inline-flex') ? 'flex' : (t.includes('grid') || t.includes('inline-grid') ? 'nonflex(grid)' : 'nonflex(other)');
    }
  }
  const l = live.get(key(c.screen, c.members)) || 'NOT-RENDERED';
  const k = proxy + '  ->  ' + l;
  tab[k] = (tab[k] || 0) + 1;
  n++;
}
console.log('cross-tab, authored-token PROXY -> LIVE computed display, over all', n, 'chains');
for (const k of Object.keys(tab).sort()) console.log('  ', k.padEnd(44), tab[k]);
