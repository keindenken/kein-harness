/**
 * Q4 — setPointerCapture on the STAGE host (#dsh-stage), driven with REAL pointer input.
 *
 * Three runs, so the instrument is proved able to report a LOSS before a survival is believed:
 *   A  capture on #dsh-stage                       -> the claim under test
 *   B  NO capture, listeners on #dsh-stage         -> what the stage sees unaided
 *   C  NO capture, listeners on a small inner box  -> the LOSS control: the pointer leaves the
 *                                                     element, so delivery MUST stop
 * Every run drags from inside the viewport to 500px BEYOND each edge and releases there.
 */
import { chromium } from '@playwright/test';

const BASE = process.env.PBASE;
const SCREEN = 'sandbox/resize-repeat-list';
const VW = 1280, VH = 800;

const browser = await chromium.launch();
console.log('BROWSER', browser.version(), '| channel: bundled chromium, headless');
const ctx = await browser.newContext({ viewport: { width: VW, height: VH } });
const page = await ctx.newPage();

async function arm(mode) {
  await page.goto(BASE + '/' + SCREEN, { waitUntil: 'load' });
  await page.waitForSelector('[data-screen="' + SCREEN + '"]');
  await page.waitForTimeout(500);
  return page.evaluate((m) => {
    const stage = document.getElementById('dsh-stage');
    let host = stage;
    if (m === 'C') {
      host = document.createElement('div');
      host.id = 'q4-box';
      host.style.cssText = 'position:fixed;left:100px;top:100px;width:60px;height:60px;background:rgba(255,0,0,.2);z-index:99999';
      document.body.appendChild(host);
    }
    const log = [];
    window.__q4 = { log: log, host: host, captured: null, lost: 0 };
    const rec = (e) => {
      log.push({
        t: e.type, id: e.pointerId, x: Math.round(e.clientX), y: Math.round(e.clientY),
        target: e.target && e.target.id ? '#' + e.target.id : (e.target && e.target.getAttribute ? (e.target.getAttribute('data-oid') || e.target.tagName) : '?'),
        cap: host.hasPointerCapture ? host.hasPointerCapture(e.pointerId) : null,
        buttons: e.buttons,
      });
    };
    for (const t of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel']) {
      host.addEventListener(t, (e) => {
        if (t === 'pointerdown' && m === 'A') {
          try { host.setPointerCapture(e.pointerId); window.__q4.captured = host.hasPointerCapture(e.pointerId); }
          catch (err) { window.__q4.captured = 'THREW ' + String(err).slice(0, 80); }
        }
        rec(e);
      }, true);
    }
    host.addEventListener('lostpointercapture', () => { window.__q4.lost++; });
    return { host: host.id || host.tagName, rect: host.getBoundingClientRect().toJSON() };
  }, mode);
}

async function drag(startX, startY, path) {
  await page.mouse.move(startX, startY);
  await page.mouse.down();
  for (const [x, y] of path) await page.mouse.move(x, y, { steps: 4 });
  await page.mouse.up();
  await page.waitForTimeout(150);
  return page.evaluate(() => ({ log: window.__q4.log, captured: window.__q4.captured, lost: window.__q4.lost }));
}

const OFF = 500;
const PATHS = {
  'left  (-500 past edge)': [[400, 400], [-OFF, 400]],
  'right (+500 past edge)': [[400, 400], [VW + OFF, 400]],
  'top   (-500 past edge)': [[400, 400], [400, -OFF]],
  'bottom(+500 past edge)': [[400, 400], [400, VH + OFF]],
  'corner (-500,-500)': [[400, 400], [-OFF, -OFF]],
};

for (const mode of ['A', 'B', 'C']) {
  console.log('');
  console.log('---- RUN ' + mode + ' ----');
  for (const label of Object.keys(PATHS)) {
    const info = await arm(mode);
    const start = mode === 'C' ? [130, 130] : [400, 400];
    const r = await drag(start[0], start[1], PATHS[label]);
    const moves = r.log.filter((e) => e.t === 'pointermove');
    const outside = moves.filter((e) => e.x < 0 || e.y < 0 || e.x > VW || e.y > VH);
    const up = r.log.filter((e) => e.t === 'pointerup');
    const cancel = r.log.filter((e) => e.t === 'pointercancel');
    const last = r.log[r.log.length - 1];
    console.log(
      label.padEnd(24),
      'host=' + info.host,
      'captureFlagAtDown=' + JSON.stringify(r.captured),
      '| moves=' + moves.length,
      'movesOutsideViewport=' + outside.length,
      '| pointerup=' + up.length,
      up.length ? '(x=' + up[0].x + ',y=' + up[0].y + ' id=' + up[0].id + ' target=' + up[0].target + ' capHeld=' + up[0].cap + ')' : '',
      '| pointercancel=' + cancel.length,
      '| lostpointercapture=' + r.lost,
      '| lastEvent=' + (last ? last.t + '@' + last.x + ',' + last.y : 'none'),
    );
    if (outside.length > 0) console.log('     furthest outside sample:', JSON.stringify(outside[outside.length - 1]));
  }
}
await browser.close();
