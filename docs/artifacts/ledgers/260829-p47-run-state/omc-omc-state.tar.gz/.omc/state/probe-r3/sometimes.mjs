import { readFileSync } from 'node:fs';
const ROOT = process.env.PROOT;
const L3 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', 'utf8'));
const L4 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live4-raw.json', 'utf8'));
const want = new Set([
  'd4b6s3,d8m1w7', 'omy3i9,0cyt4v,z76fvu,d29ipo', '2dtotc,jvbbn7,cmsa36',
  'rpb6hb,hjo7s4,5s41w1', 'wp51oi,ke5zva', 'g6xkj6,rigpu4', 'zlz7vi,v9lftf',
  '1v34iy,3fw879', 'q161xy,gf1mho',
]);
const acc = new Map();
for (const raw of [L3, L4]) {
  for (const r of raw.runs) {
    if (r.unreached) continue;
    if (raw === L4 && !(r.tab > 0 && r.tabMoved === true)) continue;
    for (const ch of r.chains) {
      const k = ch.members.join(',');
      if (!want.has(k)) continue;
      if (!acc.has(k)) acc.set(k, { screen: r.screenId, ok: 0, bad: 0, states: 0, noScope: 0 });
      const a = acc.get(k);
      a.states++;
      if (ch.scopes.length === 0) { a.noScope++; continue; }
      for (const s of ch.scopes) { if (s.zero > 0 || s.many > 0) a.bad++; else a.ok++; }
    }
  }
}
console.log('the SOMETIMES-refused chains: scope observations that pass vs refuse');
for (const [k, a] of acc) console.log('  ', a.screen, '[' + k + ']', 'passing scopes', a.ok, '| refusing scopes', a.bad, '| driven states', a.states, '| states with no scope at all', a.noScope);
