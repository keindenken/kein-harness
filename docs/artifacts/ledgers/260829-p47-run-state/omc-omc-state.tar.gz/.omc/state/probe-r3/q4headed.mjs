/** Q4, repeated in a HEADED chromium window (real compositor), run A + the run-C loss control. */
import { chromium } from '@playwright/test';
const BASE = process.env.PBASE;
const SCREEN = 'sandbox/resize-repeat-list';
const VW = 1280, VH = 800;
const browser = await chromium.launch({ headless: false });
console.log('BROWSER', browser.version(), '| headed');
const page = await (await browser.newContext({ viewport: { width: VW, height: VH } })).newPage();

async function arm(mode) {
  await page.goto(BASE + '/' + SCREEN, { waitUntil: 'load' });
  await page.waitForSelector('[data-screen="' + SCREEN + '"]');
  await page.waitForTimeout(600);
  return page.evaluate((m) => {
    const stage = document.getElementById('dsh-stage');
    let host = stage;
    if (m === 'C') {
      host = document.createElement('div');
      host.id = 'q4-box';
      host.style.cssText = 'position:fixed;left:100px;top:100px;width:60px;height:60px;z-index:99999';
      document.body.appendChild(host);
    }
    const log = [];
    window.__q4 = { log, host, captured: null, lost: 0 };
    for (const t of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel']) {
      host.addEventListener(t, (e) => {
        if (t === 'pointerdown' && m === 'A') {
          try { host.setPointerCapture(e.pointerId); window.__q4.captured = host.hasPointerCapture(e.pointerId); }
          catch (err) { window.__q4.captured = 'THREW ' + String(err).slice(0, 60); }
        }
        log.push({ t: e.type, id: e.pointerId, x: Math.round(e.clientX), y: Math.round(e.clientY), target: e.target && e.target.id ? '#' + e.target.id : 'other', cap: host.hasPointerCapture(e.pointerId), buttons: e.buttons });
      }, true);
    }
    host.addEventListener('lostpointercapture', () => { window.__q4.lost++; });
    return host.id;
  }, mode);
}

for (const mode of ['A', 'B', 'C']) {
  const host = await arm(mode);
  const start = mode === 'C' ? [130, 130] : [400, 400];
  await page.mouse.move(start[0], start[1]);
  await page.mouse.down();
  await page.mouse.move(400, 400, { steps: 4 });
  await page.mouse.move(-500, -500, { steps: 6 });
  await page.mouse.up();
  await page.waitForTimeout(200);
  const r = await page.evaluate(() => ({ log: window.__q4.log, captured: window.__q4.captured, lost: window.__q4.lost }));
  const moves = r.log.filter((e) => e.t === 'pointermove');
  const outside = moves.filter((e) => e.x < 0 || e.y < 0 || e.x > 1280 || e.y > 800);
  const up = r.log.filter((e) => e.t === 'pointerup');
  console.log('RUN', mode, 'host=' + host, 'captureFlagAtDown=' + JSON.stringify(r.captured),
    '| moves=' + moves.length, 'outsideViewport=' + outside.length,
    '| pointerup=' + up.length, up.length ? JSON.stringify(up[0]) : '',
    '| lostpointercapture=' + r.lost);
}
await browser.close();
