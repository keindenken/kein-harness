/**
 * The in-page analyzer, shared by the census pass and the control pass so the CONTROLS
 * exercise byte-identical code to the measurement.
 */
export function analyze(arg) {
  const screenId = arg.screenId;
  const chainList = arg.chainList;
  const bogusOid = arg.bogusOid;
  const up = (el) => el.parentElement;
  const nearestScreen = (el) => {
    let n = el;
    for (let i = 0; i < 300 && n !== null; i++) {
      const a = n.getAttribute ? n.getAttribute('data-screen') : null;
      if (a !== null) return a;
      n = up(n);
    }
    return null;
  };
  const cs = (el) => getComputedStyle(el);
  const rectOf = (el) => {
    const r = el.getBoundingClientRect();
    return { x: +r.x.toFixed(2), y: +r.y.toFixed(2), w: +r.width.toFixed(2), h: +r.height.toFixed(2) };
  };
  const ovl = (a, b) =>
    Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x) > 0.01 &&
    Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y) > 0.01;
  const sel = (oid) => '[data-oid="' + oid + '"]';

  const out = { screenId: screenId, control: {}, chains: [] };
  out.control.totalOidEls = document.querySelectorAll('[data-oid]').length;
  out.control.bogusOidEls = document.querySelectorAll(sel(bogusOid)).length;
  out.control.screenRootPresent = document.querySelector('[data-screen="' + screenId + '"]') !== null;

  for (const ch of chainList) {
    const rec = { members: ch.members, len: ch.members.length, parentOid: ch.parentOid, liveEls: 0, scopes: [], rootCounts: [] };
    const cands = [];
    for (const m of ch.members) {
      let inPartition = 0;
      for (const el of document.querySelectorAll(sel(m))) {
        if (nearestScreen(el) === screenId) { cands.push(el); inPartition++; }
      }
      rec.rootCounts.push({ oid: m, n: inPartition });
    }
    rec.liveEls = cands.length;
    const scopes = [];
    for (const el of cands) {
      const p = up(el);
      if (p !== null && scopes.indexOf(p) === -1) scopes.push(p);
    }
    for (const P of scopes) {
      const s = { members: [], zero: 0, one: 0, many: 0, notDirect: 0 };
      for (const m of ch.members) {
        const hits = P.querySelectorAll(sel(m));
        const n = hits.length;
        let direct = null;
        if (n === 1) direct = up(hits[0]) === P;
        if (n === 0) s.zero++;
        else if (n === 1) { s.one++; if (direct === false) s.notDirect++; }
        else s.many++;
        s.members.push({ oid: m, n: n, direct: direct, rect: n === 1 ? rectOf(hits[0]) : null });
      }
      const p = cs(P);
      s.parent = {
        tag: P.tagName.toLowerCase(), oid: P.getAttribute('data-oid'),
        display: p.display, direction: p.direction, writingMode: p.writingMode,
        flexDirection: p.flexDirection, flexWrap: p.flexWrap,
        className: (P.getAttribute('class') || '').slice(0, 150),
      };
      const kids = [];
      for (const k of P.children) kids.push(k);
      s.childCount = kids.length;
      s.childOrders = kids.map((k) => cs(k).order);
      s.childRects = kids.map((k) => rectOf(k));
      s.memberOrders = [];
      for (const x of s.members) { if (x.n !== 1) continue; s.memberOrders.push(cs(P.querySelector(sel(x.oid))).order); }
      const mrects = [];
      for (const x of s.members) if (x.rect !== null) mrects.push(x.rect);
      let ov = 0;
      for (let i = 0; i < mrects.length; i++) for (let j = i + 1; j < mrects.length; j++) if (ovl(mrects[i], mrects[j])) ov++;
      s.overlapPairs = ov;
      s.memberPairs = (mrects.length * (mrects.length - 1)) / 2;
      rec.scopes.push(s);
    }
    out.chains.push(rec);
  }
  return out;
}
