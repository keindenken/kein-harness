import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { moduleContext, moveAdjacent, resolveJsxChildOp } from '../../../packages/descvi/src/extractor/structural-edit.ts';

const ROOT = process.env.REPO_ROOT;
const FILE = join(ROOT, 'src/app/shop/order-detail/page.tsx');
const SCREEN = 'shop/order-detail';
const CHAIN = ['kh1mfx', '6xrrnu', 'gwdd53', '288qqj', 'lj8bsm', 'mdpmc1', 'thbzev'];
const src = readFileSync(FILE, 'utf8');

function naiveFold(source, oid, k, dir) {
  let buf = source;
  for (let i = 0; i < k; i++) buf = moveAdjacent(buf, SCREEN, oid, dir);
  return buf;
}

// ONE-PARSE, ONE-SPLICE composer: read every chain member's op-unit span from ONE ctx,
// then write the slots back in the permuted order in a single buffer rebuild + one reparse.
function oneSplice(source, subjectIdx, destIdx) {
  const ctx = moduleContext(source);
  const spans = CHAIN.map((oid) => {
    const r = resolveJsxChildOp(ctx, SCREEN, oid, 'move-down');
    if (!r.ok && r.fail !== 'no-adjacent-sibling') throw new Error(`${oid}: ${r.fail}`);
    return r.ok ? r.opUnitSpan : resolveJsxChildOp(ctx, SCREEN, oid, 'move-up').opUnitSpan;
  });
  const slots = [...spans].sort((a, b) => a.start - b.start);
  const order = CHAIN.map((_, i) => i);
  const [moved] = order.splice(subjectIdx, 1);
  order.splice(destIdx, 0, moved);
  const buf = Buffer.from(source, 'utf8');
  const parts = [buf.subarray(0, slots[0].start)];
  for (let i = 0; i < slots.length; i++) {
    const from = spans[order[i]];
    parts.push(buf.subarray(from.start, from.end));
    const gapEnd = i + 1 < slots.length ? slots[i + 1].start : buf.length;
    parts.push(buf.subarray(slots[i].end, gapEnd));
  }
  return Buffer.concat(parts).toString('utf8');
}

const naive6 = naiveFold(src, CHAIN[0], 6, 'down');
const one = oneSplice(src, 0, 6);
console.log('one-splice k=6 equals the naive 6-step fold, byte for byte:', one === naive6);
console.log('CONTROL one-splice with NO move (0->0) is byte-identical to the source:', oneSplice(src, 0, 0) === src);
console.log('CONTROL a WRONG destination (0->5) is NOT equal to the naive k=6 result:', oneSplice(src, 0, 5) !== naive6);

function time(label, fn, reps = 25) {
  fn(); fn();
  const ts = [];
  for (let i = 0; i < reps; i++) { const t0 = performance.now(); fn(); ts.push(performance.now() - t0); }
  ts.sort((a, b) => a - b);
  console.log(`${label.padEnd(46)} median ${ts[Math.floor(reps / 2)].toFixed(3)} ms`);
}
time('naive k=6 fold', () => naiveFold(src, CHAIN[0], 6, 'down'));
time('one-parse one-splice k=6 (no verify reparse)', () => oneSplice(src, 0, 6));
