import { chromium } from '@playwright/test';
const BASE = process.env.PBASE;
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1440, height: 950 } })).newPage();
await page.goto(BASE + '/shop/order-detail', { waitUntil: 'load' });
await page.waitForSelector('[data-screen="shop/order-detail"]');
await page.waitForTimeout(600);
const before = await page.evaluate(() => ({
  oids: document.querySelectorAll('[data-oid]').length,
  panel: document.getElementById('dsh-panel') !== null,
  stateSec: document.getElementById('dsh-sec-state') !== null,
  stage: document.getElementById('dsh-stage') !== null,
  screenHost: document.getElementById('dsh-screen') !== null,
  codes: Array.from(document.querySelectorAll('#dsh-sec-state code')).map((c) => c.textContent),
  combos: document.querySelectorAll('#dsh-sec-state [role="combobox"]').length,
}));
console.log('BEFORE', JSON.stringify(before));

const row = page.locator('#dsh-sec-state div').filter({ has: page.locator('code', { hasText: /^orderStatus$/ }) }).first();
await row.getByRole('combobox').click();
await page.getByRole('option', { name: 'delivered', exact: true }).click();
await page.waitForTimeout(500);
const after = await page.evaluate(() => ({
  oids: document.querySelectorAll('[data-oid]').length,
  combo: document.querySelector('#dsh-sec-state [role="combobox"]').textContent,
}));
console.log('AFTER ', JSON.stringify(after));
await browser.close();
