/** Positive control for the WRAP detector: same page, same analyzer, wrap planted. */
import { chromium } from '@playwright/test';
import { analyze } from './analyzer.mjs';
import { lineCount } from './lines.mjs';

const BASE = process.env.PBASE;
const SCREEN = 'sandbox/resize-repeat-list';
const CHAIN = { members: ['smcell', 'smname', 'smtagg'], parentOid: 'smroww' };
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1440, height: 950 } })).newPage();

async function read(label) {
  const r = await page.evaluate(analyze, { screenId: SCREEN, chainList: [CHAIN], bogusOid: 'zzzz00' });
  const s = r.chains[0].scopes[0];
  console.log(label, 'flexWrap=' + s.parent.flexWrap, 'fd=' + s.parent.flexDirection,
    'kids=' + s.childRects.length, 'lines=' + lineCount(s.childRects, s.parent.flexDirection),
    JSON.stringify(s.childRects));
}
async function fresh() {
  await page.goto(BASE + '/' + SCREEN, { waitUntil: 'load' });
  await page.waitForSelector('[data-screen="' + SCREEN + '"]');
  await page.waitForTimeout(400);
}

await fresh();
await read('BASELINE (nowrap row, items-center)      ');
await page.evaluate(() => {
  const p = document.querySelectorAll('[data-oid="smroww"]')[0];
  p.style.flexWrap = 'wrap';
  p.style.width = '150px';
});
await page.waitForTimeout(200);
await read('C-G PLANTED (flex-wrap:wrap, width 150px)');
await browser.close();
