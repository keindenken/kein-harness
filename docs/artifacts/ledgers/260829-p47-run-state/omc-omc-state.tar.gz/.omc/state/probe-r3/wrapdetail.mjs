import { readFileSync } from 'node:fs';
import { lineCount } from './lines.mjs';
const ROOT = process.env.PROOT;
const L3 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', 'utf8'));
const seen = new Set();
for (const r of L3.runs) {
  if (r.unreached) continue;
  for (const ch of r.chains) {
    for (const s of ch.scopes) {
      const isFlex = s.parent.display === 'flex' || s.parent.display === 'inline-flex';
      if (!isFlex) continue;
      const lc = lineCount(s.childRects, s.parent.flexDirection);
      const wrappy = s.parent.flexWrap !== 'nowrap';
      if (lc <= 1 && !wrappy) continue;
      const k = r.screenId + '|' + s.parent.oid + '|' + lc + '|' + s.parent.flexWrap;
      if (seen.has(k)) continue;
      seen.add(k);
      console.log(r.screenId, 'parent=' + s.parent.oid, 'wrap=' + s.parent.flexWrap, 'fd=' + s.parent.flexDirection,
        'lines=' + lc, 'kids=' + s.childRects.length, JSON.stringify(s.childRects), '|', s.parent.className);
    }
  }
}
