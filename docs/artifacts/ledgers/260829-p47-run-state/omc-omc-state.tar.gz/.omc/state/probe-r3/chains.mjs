import { readdirSync, readFileSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { buildEditMap } from '../../../packages/descvi/src/extractor/edit-map.ts';

const ROOT = process.env.REPO_ROOT;
const APP = join(ROOT, 'src/app');
function walk(dir, out = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, out); else if (e.name === 'page.tsx') out.push(p);
  }
  return out;
}
const files = {};
const inputs = [];
for (const p of walk(APP).sort()) {
  const spec = join(dirname(p), 'spec.ts');
  let specSource;
  try { specSource = readFileSync(spec, 'utf8'); } catch { continue; }
  const src = readFileSync(p, 'utf8');
  inputs.push({ id: relative(APP, dirname(p)).split('/').join('-') || 'root', pageSource: src, specSource, relPagePath: relative(ROOT, p) });
}
const map = buildEditMap(inputs);
// which file holds each screen? scan sources for data-screen="<id>"
const byScreen = {};
for (const i of inputs) for (const m of i.pageSource.matchAll(/data-screen="([^"]+)"/g)) byScreen[m[1]] = i.relPagePath;

const out = [];
for (const [screenId, entries] of Object.entries(map.oids)) {
  const ids = Object.keys(entries);
  const parent = new Map(ids.map((i) => [i, i]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  const uni = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
  for (const oid of ids) { const s = entries[oid].structure; for (const n of [s.prevOid, s.nextOid]) if (n && parent.has(n)) uni(oid, n); }
  const groups = new Map();
  for (const oid of ids) { const r = find(oid); if (!groups.has(r)) groups.set(r, []); groups.get(r).push(oid); }
  for (const [, members] of groups) {
    if (members.length < 4) continue;
    // order them by walking prev/next
    let head = members.find((m) => !entries[m].structure.prevOid || !members.includes(entries[m].structure.prevOid));
    const ordered = [];
    let cur = head;
    while (cur) { ordered.push(cur); cur = entries[cur].structure.nextOid; }
    out.push({ screenId, file: byScreen[screenId], n: members.length, ordered, parentOid: entries[members[0]].structure.parentOid, parentClass: entries[entries[members[0]].structure.parentOid]?.className ?? null });
  }
}
out.sort((a, b) => b.n - a.n);
for (const c of out) console.log(c.n, '|', c.screenId, '|', c.file, '| parent', c.parentOid, JSON.stringify(c.parentClass), '|', c.ordered.join(','));
