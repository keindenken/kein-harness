/**
 * Q4 rider: under stage capture every event RETARGETS to #dsh-stage. Does the coordinate
 * channel the hit-test actually uses still resolve the real element? Measured with
 * elementFromPoint at each move, alongside e.target.
 */
import { chromium } from '@playwright/test';
const BASE = process.env.PBASE;
const SCREEN = 'sandbox/resize-repeat-list';
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
await page.goto(BASE + '/' + SCREEN, { waitUntil: 'load' });
await page.waitForSelector('[data-screen="' + SCREEN + '"]');
await page.waitForTimeout(600);

const box = await page.evaluate(() => {
  const els = document.querySelectorAll('[data-oid="smroww"]');
  return Array.from(els).map((e) => e.getBoundingClientRect().toJSON());
});
console.log('smroww rows:', JSON.stringify(box.map((b) => [Math.round(b.x), Math.round(b.y), Math.round(b.width), Math.round(b.height)])));

await page.evaluate(() => {
  const stage = document.getElementById('dsh-stage');
  const log = [];
  window.__q = log;
  stage.addEventListener('pointerdown', (e) => { stage.setPointerCapture(e.pointerId); }, true);
  for (const t of ['pointermove', 'pointerup']) {
    stage.addEventListener(t, (e) => {
      const hit = document.elementFromPoint(e.clientX, e.clientY);
      log.push({
        t: e.type, x: Math.round(e.clientX), y: Math.round(e.clientY),
        target: e.target.id ? '#' + e.target.id : (e.target.getAttribute('data-oid') || e.target.tagName),
        efp: hit === null ? null : (hit.id ? '#' + hit.id : (hit.getAttribute('data-oid') || hit.tagName)),
        efpOid: hit === null ? null : (hit.closest('[data-oid]') ? hit.closest('[data-oid]').getAttribute('data-oid') : null),
      });
    }, true);
  }
});

const y0 = Math.round(box[0].y + box[0].height / 2);
const y2 = Math.round(box[2].y + box[2].height / 2);
await page.mouse.move(400, y0);
await page.mouse.down();
await page.mouse.move(420, y0, { steps: 2 });
await page.mouse.move(420, y2, { steps: 3 });
await page.mouse.move(-300, y2, { steps: 3 });
await page.mouse.up();
await page.waitForTimeout(150);
const log = await page.evaluate(() => window.__q);
for (const e of log) console.log(' ', e.t, '(' + e.x + ',' + e.y + ')', 'e.target=' + e.target, 'elementFromPoint=' + e.efp, 'nearestOid=' + e.efpOid);
await browser.close();
