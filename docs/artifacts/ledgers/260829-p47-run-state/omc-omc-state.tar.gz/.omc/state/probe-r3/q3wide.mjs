/**
 * Q3 widened: the computed `direction`, `writing-mode`, `order` and `flex-direction` of EVERY
 * element under every screen root, not only the parents of admissible chains — so a zero means
 * "absent from the corpus", not "absent from the sampled subset".
 * Carries its own planted control at the end.
 */
import { readFileSync } from 'node:fs';
import { chromium } from '@playwright/test';
const ROOT = process.env.PROOT;
const BASE = process.env.PBASE;
const manifest = JSON.parse(readFileSync(ROOT + '.descvi/screens.json', 'utf8'));

const scan = (screenId) => {
  const root = document.querySelector('[data-screen="' + screenId + '"]');
  if (root === null) return null;
  const els = [root].concat(Array.from(root.querySelectorAll('*')));
  const dir = {}, wm = {}, ord = {}, fd = {};
  for (const el of els) {
    const c = getComputedStyle(el);
    dir[c.direction] = (dir[c.direction] || 0) + 1;
    wm[c.writingMode] = (wm[c.writingMode] || 0) + 1;
    ord[c.order] = (ord[c.order] || 0) + 1;
    if (c.display === 'flex' || c.display === 'inline-flex') fd[c.flexDirection] = (fd[c.flexDirection] || 0) + 1;
  }
  return { n: els.length, dir, wm, ord, fd };
};

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 1440, height: 950 } })).newPage();
const tot = { n: 0, dir: {}, wm: {}, ord: {}, fd: {} };
const add = (a, b) => { for (const k of Object.keys(b)) a[k] = (a[k] || 0) + b[k]; };

for (const sc of manifest.screens) {
  const sep = sc.id.indexOf('::');
  const route = sep === -1 ? sc.id : sc.id.slice(0, sep);
  const url = BASE + '/' + route + (sep === -1 ? '' : '?open=' + encodeURIComponent(sc.id));
  await page.goto(url, { waitUntil: 'load' });
  try { await page.waitForSelector('[data-screen="' + sc.id + '"]', { timeout: 8000 }); } catch { console.log('UNREACHED', sc.id); continue; }
  await page.waitForTimeout(300);
  const r = await page.evaluate(scan, sc.id);
  if (r === null) { console.log('NULL', sc.id); continue; }
  tot.n += r.n; add(tot.dir, r.dir); add(tot.wm, r.wm); add(tot.ord, r.ord); add(tot.fd, r.fd);
}
console.log('elements scanned under a screen root:', tot.n);
console.log('computed direction   :', JSON.stringify(tot.dir));
console.log('computed writing-mode:', JSON.stringify(tot.wm));
console.log('computed order       :', JSON.stringify(tot.ord));
console.log('computed flex-direction over flex/inline-flex elements:', JSON.stringify(tot.fd));

// planted control on the last page loaded
const ctl = await page.evaluate((screenId) => {
  const root = document.querySelector('[data-screen="' + screenId + '"]');
  root.style.direction = 'rtl';
  root.style.writingMode = 'vertical-rl';
  const kid = root.querySelector('*');
  kid.style.order = '7';
  const s = getComputedStyle(root);
  return { direction: s.direction, writingMode: s.writingMode, kidOrder: getComputedStyle(kid).order };
}, manifest.screens[manifest.screens.length - 1].id);
console.log('CONTROL (planted on the last screen scanned):', JSON.stringify(ctl));
await browser.close();
