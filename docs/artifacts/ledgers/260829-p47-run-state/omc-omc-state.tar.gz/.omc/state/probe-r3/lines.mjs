/**
 * Flex line count from child rects, by the BACKWARDS rule: walk the children in DOM order
 * along the main axis; a child whose main-axis start lies BEFORE the current line's running
 * end has started a new line. This is the only line detector that does not mistake an
 * `items-center` / `items-start` height difference in a `nowrap` row for a wrap.
 */
export function lineCount(childRects, flexDirection) {
  const isRow = flexDirection.indexOf('row') === 0;
  const rev = flexDirection.indexOf('-reverse') !== -1;
  const boxes = childRects.filter((r) => r.w > 0 || r.h > 0);
  if (boxes.length === 0) return 0;
  let lines = 1;
  let lineEnd = null;
  for (const r of boxes) {
    const start = isRow ? (rev ? -(r.x + r.w) : r.x) : (rev ? -(r.y + r.h) : r.y);
    const stop = isRow ? (rev ? -r.x : r.x + r.w) : (rev ? -r.y : r.y + r.h);
    if (lineEnd !== null && start < lineEnd - 0.5) { lines++; lineEnd = stop; }
    else lineEnd = lineEnd === null ? stop : Math.max(lineEnd, stop);
  }
  return lines;
}
