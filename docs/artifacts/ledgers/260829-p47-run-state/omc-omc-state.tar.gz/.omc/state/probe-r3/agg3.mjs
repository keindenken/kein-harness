import { readFileSync, writeFileSync } from 'node:fs';
import { lineCount } from './lines.mjs';
const ROOT = process.env.PROOT;
const L3 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', 'utf8'));
const L4 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live4-raw.json', 'utf8'));
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));
const editMap = JSON.parse(readFileSync(ROOT + '.descvi/edit-map.json', 'utf8'));

// ---------- cross-host control: design-view default state vs plain-view default state ----------
const d3 = new Map(), d4 = new Map();
for (const r of L3.runs) {
  if (r.unreached || r.tab !== 0) continue;
  const isDefault = Object.keys(r.combo).length === 0 || JSON.stringify(r.combo).indexOf('') === 0;
  if (!d3.has(r.screenId)) d3.set(r.screenId, r.control.totalOidEls);
}
for (const r of L4.runs) { if (r.unreached || r.tab !== 0) continue; d4.set(r.screenId, r.control.totalOidEls); }
let same = 0, diff = [];
for (const [k, v] of d4) { if (d3.get(k) === v) same++; else diff.push([k, d3.get(k), v]); }
console.log('CROSS-HOST CONTROL (design-view :3001 default vs plain :3000 default, oid-element count per screen)');
console.log('  screens comparable:', d4.size, '| identical:', same, '| differing:', JSON.stringify(diff));

// ---------- merge ----------
const key = (s, m) => s + '|' + m.join(',');
const M = new Map();
for (const c of chains) M.set(key(c.screen, c.members), { screen: c.screen, members: c.members, parentOid: c.parentOid, obs: [], root: [], reach: 0, seen: 0 });

function ingest(raw, host) {
  for (const r of raw.runs) {
    if (r.unreached) continue;
    for (const ch of r.chains) {
      const rec = M.get(key(r.screenId, ch.members));
      if (!rec) continue;
      rec.seen++;
      if (ch.scopes.length > 0) rec.reach++;
      rec.root.push({ host, counts: ch.rootCounts });
      for (const s of ch.scopes) rec.obs.push({ host, combo: r.combo || {}, tab: r.tab, s });
    }
  }
}
ingest(L3, 'design');
// only the two tab panes the design view cannot reach
ingest({ runs: L4.runs.filter((r) => !r.unreached && r.tab > 0 && r.tabMoved === true) }, 'plain-tab');

for (const rec of M.values()) {
  const seen = new Set();
  rec.u = [];
  for (const o of rec.obs) {
    const s = o.s;
    const sig = JSON.stringify([s.parent, s.members.map((m) => [m.oid, m.n, m.direct]), s.childOrders, s.overlapPairs, s.childRects.length]);
    if (seen.has(sig)) continue;
    seen.add(sig);
    rec.u.push(s);
  }
}
const all = [...M.values()];
const reachable = all.filter((r) => r.reach > 0);
const dead = all.filter((r) => r.reach === 0);

// ---------- Q1 ----------
let obs = 0, obsFail = 0, nZ = 0, nO = 0, nM = 0;
const alwaysRefused = [], someRefused = [];
for (const r of reachable) {
  let bad = 0;
  for (const s of r.u) {
    obs++; nZ += s.zero; nO += s.one; nM += s.many;
    if (s.zero > 0 || s.many > 0) { obsFail++; bad++; }
  }
  if (bad === r.u.length) alwaysRefused.push(r); else if (bad > 0) someRefused.push(r);
}

// ---------- Q1b: the SCREEN-ROOT (unscoped) uniqueness census, i.e. the rule WITHOUT the parent scope ----------
let rZ = 0, rO = 0, rM = 0, rootFailChains = 0;
const rootManyChains = [];
for (const r of reachable) {
  const best = r.root.find((x) => x.counts.some((c) => c.n > 0)) || r.root[0];
  let bad = false, many = false;
  for (const c of best.counts) {
    if (c.n === 0) { rZ++; bad = true; } else if (c.n === 1) rO++; else { rM++; bad = true; many = true; }
  }
  if (bad) rootFailChains++;
  if (many) rootManyChains.push({ screen: r.screen, members: r.members, counts: best.counts.map((c) => c.n) });
}

// ---------- Q2 ----------
let obsND = 0; const ndChains = [];
for (const r of reachable) { let nd = 0; for (const s of r.u) if (s.notDirect > 0) { obsND++; nd++; } if (nd > 0) ndChains.push(r); }

// ---------- Q3 / Q5 / Q6, one reading per reachable chain ----------
const disp = {}, dir = {}, wm = {}, fdir = {}, fwrap = {};
let unequalChild = 0, unequalMember = 0; const orderVals = {};
let flexN = 0, wrapCapable = 0, multiLine = 0, ovChains = 0, ovPairs = 0, mPairs = 0;
const wrapEx = [], ovEx = [], revEx = [];
for (const r of reachable) {
  const s = r.u[0];
  disp[s.parent.display] = (disp[s.parent.display] || 0) + 1;
  dir[s.parent.direction] = (dir[s.parent.direction] || 0) + 1;
  wm[s.parent.writingMode] = (wm[s.parent.writingMode] || 0) + 1;
  for (const o of s.childOrders) orderVals[o] = (orderVals[o] || 0) + 1;
  if (new Set(s.childOrders).size > 1) unequalChild++;
  if (new Set(s.memberOrders).size > 1) unequalMember++;
  const isFlex = s.parent.display === 'flex' || s.parent.display === 'inline-flex';
  if (isFlex) {
    flexN++;
    fdir[s.parent.flexDirection] = (fdir[s.parent.flexDirection] || 0) + 1;
    fwrap[s.parent.flexWrap] = (fwrap[s.parent.flexWrap] || 0) + 1;
    if (s.parent.flexWrap !== 'nowrap') wrapCapable++;
    if (s.parent.flexDirection.indexOf('-reverse') !== -1) revEx.push({ screen: r.screen, fd: s.parent.flexDirection, cls: s.parent.className });
    const lc = lineCount(s.childRects, s.parent.flexDirection);
    if (lc > 1) { multiLine++; if (wrapEx.length < 10) wrapEx.push({ screen: r.screen, parent: s.parent.oid, lines: lc, wrap: s.parent.flexWrap, fd: s.parent.flexDirection, cls: s.parent.className }); }
  }
  if (s.overlapPairs > 0) { ovChains++; if (ovEx.length < 10) ovEx.push({ screen: r.screen, members: r.members, parent: s.parent.oid, pairs: s.overlapPairs, cls: s.parent.className }); }
  ovPairs += s.overlapPairs; mPairs += s.memberPairs;
}

// ---------- the artifact proxy, recomputed ----------
let pF = 0, pN = 0, pU = 0;
for (const c of chains) {
  const e = editMap.oids[c.screen], p = c.parentOid;
  if (p === null || e[p] === undefined) { pU++; continue; }
  const cn = e[p].className;
  if (cn === null || cn === undefined) { pN++; continue; }
  const t = String(cn).split(' ');
  if (t.includes('flex') || t.includes('inline-flex')) pF++; else pN++;
}

console.log('');
console.log('=== POPULATION ===');
console.log('chains', all.length, '| reachable in >=1 driven state', reachable.length, '| NEVER reachable', dead.length);
console.log('distinct scope observations', obs);
console.log('');
console.log('=== Q1  uniqueness, scoped to subjectEl.parentElement (the plan\'s rule) ===');
console.log('member readings: n=0', nZ, ' n=1', nO, ' n>1', nM);
console.log('observations failing "exactly one":', obsFail, '/', obs);
console.log('chains refused in EVERY observation:', alwaysRefused.length);
for (const r of alwaysRefused) console.log('   ', r.screen, JSON.stringify(r.members));
console.log('chains refused in SOME observation only:', someRefused.length);
for (const r of someRefused) console.log('   ', r.screen, JSON.stringify(r.members));
console.log('');
console.log('=== Q1b uniqueness WITHOUT the parent scope (screen partition only) ===');
console.log('member readings: n=0', rZ, ' n=1', rO, ' n>1', rM);
console.log('chains that would be refused:', rootFailChains, 'of', reachable.length);
console.log('chains with a member resolving to MORE THAN ONE node in the partition:', rootManyChains.length);
console.log(JSON.stringify(rootManyChains));
console.log('');
console.log('=== Q2  direct-child ===');
console.log('observations with a uniquely-resolved member that is NOT a direct child:', obsND, '/', obs, '| chains:', ndChains.length);
console.log('');
console.log('=== Q3  CSS admissibility ===');
console.log('computed direction:', JSON.stringify(dir));
console.log('computed writing-mode:', JSON.stringify(wm));
console.log('chains whose parent has unequal computed `order` across direct children:', unequalChild);
console.log('chains whose chain MEMBERS carry unequal computed `order`:', unequalMember);
console.log('computed `order` census over every direct child:', JSON.stringify(orderVals));
console.log('');
console.log('=== Q5  wrap + overlap ===');
console.log('flex/inline-flex chains:', flexN, '| flex-direction', JSON.stringify(fdir), '| flex-wrap', JSON.stringify(fwrap));
console.log('wrap-CAPABLE parents (flex-wrap != nowrap):', wrapCapable, '| parents actually on >1 line:', multiLine);
console.log(JSON.stringify(wrapEx));
console.log('reverse-direction parents:', revEx.length, JSON.stringify(revEx));
console.log('chains with >=1 overlapping member-rect pair:', ovChains, '| overlapping pairs', ovPairs, 'of', mPairs);
console.log(JSON.stringify(ovEx));
console.log('');
console.log('=== Q6  live display census vs the authored-token proxy ===');
console.log('LIVE  (per reachable chain):', JSON.stringify(disp));
console.log('PROXY (per chain, all 235): flex', pF, '| nonflex', pN, '| unknown', pU);
console.log('');
console.log('=== NEVER-REACHABLE CHAINS ===');
for (const r of dead) console.log(' ', r.screen, JSON.stringify(r.members), 'parentOid=' + r.parentOid);
writeFileSync(ROOT + '.omc/state/probe-r3/agg3.json', JSON.stringify({ reachable: reachable.length, dead: dead.map((r) => ({ screen: r.screen, members: r.members })) }));
