import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { moduleContext, moveAdjacent, resolveJsxChildOp, swapSpans } from '../../../packages/descvi/src/extractor/structural-edit.ts';

const ROOT = process.env.REPO_ROOT;
const FILE = join(ROOT, 'src/app/shop/member-list/page.tsx');
const SCREEN = 'shop/member-list';
const OID = 'ohpkna'; // head of the 7-member chain
const src = readFileSync(FILE, 'utf8');
console.log('file bytes:', Buffer.byteLength(src), '| largest page?');

function naiveFold(source, k, dir) {
  let buf = source;
  for (let i = 0; i < k; i++) buf = moveAdjacent(buf, SCREEN, OID, dir);
  return buf;
}

// ONE-PARSE composer EXACTLY AS THE PLAN SPELLS IT:
// "moduleContext once, then k x (resolveJsxChildOp + swapSpans) over the evolving buffer"
function onePassFoldAsSpelled(source, k, dir) {
  const ctx = moduleContext(source);
  const op = dir === 'up' ? 'move-up' : 'move-down';
  let buf = source;
  for (let i = 0; i < k; i++) {
    const r = resolveJsxChildOp(ctx, SCREEN, OID, op);
    if (!r.ok) throw new Error(`step ${i}: ${r.fail}`);
    const sib = r.siblingSpan;
    const [a, b] = r.opUnitSpan.start < sib.start ? [r.opUnitSpan, sib] : [sib, r.opUnitSpan];
    buf = swapSpans(buf, a, b);
  }
  return buf;
}

// --- correctness ---
const naive6 = naiveFold(src, 6, 'down');
console.log('naive k=6 down: changed?', naive6 !== src);
const back = naiveFold(naive6, 6, 'up');
console.log('CONTROL 6-down-then-6-up byte-identical:', back === src);
try {
  const naive7 = naiveFold(src, 7, 'down');
  console.log('CONTROL k=7:', 'DID NOT REFUSE (unexpected)');
} catch (e) {
  console.log('CONTROL k=7 refuses:', e.reason ?? e.message);
}

let spelled6 = null;
try {
  spelled6 = onePassFoldAsSpelled(src, 6, 'down');
  console.log('one-parse-as-spelled k=6: equals naive?', spelled6 === naive6);
} catch (e) {
  console.log('one-parse-as-spelled k=6 THREW:', e.reason ?? e.message);
}
try {
  const spelled2 = onePassFoldAsSpelled(src, 2, 'down');
  const naive2 = naiveFold(src, 2, 'down');
  console.log('one-parse-as-spelled k=2: equals naive?', spelled2 === naive2);
} catch (e) {
  console.log('one-parse-as-spelled k=2 THREW:', e.reason ?? e.message);
}

// --- timing ---
function time(label, fn, reps = 30) {
  fn(); fn(); // warm
  const ts = [];
  for (let i = 0; i < reps; i++) { const t0 = performance.now(); fn(); ts.push(performance.now() - t0); }
  ts.sort((a, b) => a - b);
  console.log(`${label}: median ${ts[Math.floor(reps / 2)].toFixed(3)} ms | min ${ts[0].toFixed(3)} | max ${ts[reps - 1].toFixed(3)}`);
  return ts[Math.floor(reps / 2)];
}

const tCtx = time('moduleContext alone', () => moduleContext(src));
const tOne = time('one moveAdjacent', () => moveAdjacent(src, SCREEN, OID, 'down'));
const tNaive6 = time('naive k=6 fold', () => naiveFold(src, 6, 'down'));

// A CORRECT one-parse-per-step composer is impossible; the cheapest CORRECT fold re-parses
// the evolving buffer each step, which IS the naive fold. Measure the theoretical floor of the
// plan's design: 1 parse + 6 x (resolve+swap) where resolve+swap is measured on the ORIGINAL ctx.
const tResolveSwap = time('resolveJsxChildOp+swapSpans on a fixed ctx', () => {
  const ctx = moduleContext(src); // excluded below
});
const ctxFixed = moduleContext(src);
const tRS = time('resolve+swap only (fixed ctx, no parse)', () => {
  const r = resolveJsxChildOp(ctxFixed, SCREEN, OID, 'move-down');
  const sib = r.siblingSpan;
  const [a, b] = r.opUnitSpan.start < sib.start ? [r.opUnitSpan, sib] : [sib, r.opUnitSpan];
  swapSpans(src, a, b);
});
console.log('---');
console.log('implied one-parse composer k=6 =', (tCtx + 6 * tRS).toFixed(3), 'ms  (parse once + 6 x resolve/swap)');
console.log('plan R47-4 pre-committed threshold: under 19 ms');
