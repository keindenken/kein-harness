import { readFileSync } from 'node:fs';
const ROOT = process.env.PROOT;
const L3 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', 'utf8'));
const L4 = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live4-raw.json', 'utf8'));
const want = new Set(process.argv.slice(2));
for (const raw of [L3, L4]) {
  for (const r of raw.runs) {
    if (r.unreached) continue;
    for (const ch of r.chains) {
      const k = ch.members.join(',');
      if (!want.has(k)) continue;
      for (const s of ch.scopes) {
        console.log(r.screenId, JSON.stringify(r.combo || {}), 'tab' + r.tab,
          '| parent', s.parent.oid, s.parent.tag, s.parent.display,
          '| n=', JSON.stringify(s.members.map((m) => m.oid + ':' + m.n)),
          '| direct=', JSON.stringify(s.members.map((m) => m.direct)));
      }
      if (ch.scopes.length === 0) console.log(r.screenId, JSON.stringify(r.combo || {}), 'tab' + r.tab, '| NO SCOPE, rootCounts', JSON.stringify(ch.rootCounts.map((c) => c.oid + ':' + c.n)));
    }
  }
}
