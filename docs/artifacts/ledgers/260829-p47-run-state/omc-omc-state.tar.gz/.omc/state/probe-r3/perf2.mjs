import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { moduleContext, moveAdjacent, resolveJsxChildOp, swapSpans } from '../../../packages/descvi/src/extractor/structural-edit.ts';

const ROOT = process.env.REPO_ROOT;
const FILE = join(ROOT, 'src/app/shop/order-detail/page.tsx'); // the LARGEST page (40979 B)
const SCREEN = 'shop/order-detail';
const OID = 'kh1mfx'; // head of a 7-member chain in that file
const src = readFileSync(FILE, 'utf8');
console.log('file:', FILE, '| bytes:', Buffer.byteLength(src));

function naiveFold(source, k, dir) {
  let buf = source;
  for (let i = 0; i < k; i++) buf = moveAdjacent(buf, SCREEN, OID, dir);
  return buf;
}

// --- correctness controls ---
const naive6 = naiveFold(src, 6, 'down');
console.log('CONTROL naive k=6 changed the bytes:', naive6 !== src);
console.log('CONTROL 6-down-then-6-up byte-identical:', naiveFold(naive6, 6, 'up') === src);
try { naiveFold(src, 7, 'down'); console.log('CONTROL k=7: DID NOT REFUSE (!)'); }
catch (e) { console.log('CONTROL k=7 refuses:', e.reason ?? e.message); }

// --- the plan's spelled composer: moduleContext ONCE, then k x (resolveJsxChildOp + swapSpans) ---
function spelled(source, k, dir) {
  const ctx = moduleContext(source);
  const op = dir === 'up' ? 'move-up' : 'move-down';
  let buf = source;
  for (let i = 0; i < k; i++) {
    const r = resolveJsxChildOp(ctx, SCREEN, OID, op);
    if (!r.ok) throw new Error(`step ${i}: ${r.fail}`);
    const sib = r.siblingSpan;
    const [a, b] = r.opUnitSpan.start < sib.start ? [r.opUnitSpan, sib] : [sib, r.opUnitSpan];
    buf = swapSpans(buf, a, b);
  }
  return buf;
}
for (const k of [1, 2, 3, 6]) {
  try {
    const got = spelled(src, k, 'down');
    console.log(`spelled one-parse composer k=${k}: equals naive?`, got === naiveFold(src, k, 'down'));
  } catch (e) {
    console.log(`spelled one-parse composer k=${k} THREW:`, e.reason ?? e.message);
  }
}

// --- timing ---
function time(label, fn, reps = 25) {
  fn(); fn();
  const ts = [];
  for (let i = 0; i < reps; i++) { const t0 = performance.now(); fn(); ts.push(performance.now() - t0); }
  ts.sort((a, b) => a - b);
  const med = ts[Math.floor(reps / 2)];
  console.log(`${label.padEnd(46)} median ${med.toFixed(3)} ms  (min ${ts[0].toFixed(3)} / max ${ts[reps - 1].toFixed(3)})`);
  return med;
}

const ctxFixed = moduleContext(src);
const r0 = resolveJsxChildOp(ctxFixed, SCREEN, OID, 'move-down');
const sib0 = r0.siblingSpan;
const [a0, b0] = r0.opUnitSpan.start < sib0.start ? [r0.opUnitSpan, sib0] : [sib0, r0.opUnitSpan];

const tCtx = time('moduleContext(src)', () => moduleContext(src));
const tResolve = time('resolveJsxChildOp on a warm ctx', () => resolveJsxChildOp(ctxFixed, SCREEN, OID, 'move-down'));
const tSwap = time('swapSpans (includes its own reparse)', () => swapSpans(src, a0, b0));
const tOne = time('one moveAdjacent', () => moveAdjacent(src, SCREEN, OID, 'down'));
const tNaive6 = time('naive k=6 fold', () => naiveFold(src, 6, 'down'));

console.log('---');
console.log('BEST CASE a correct fold can reach = 1 moduleContext + 6 x (resolve + swapSpans) =',
  (tCtx + 6 * (tResolve + tSwap)).toFixed(3), 'ms');
console.log('naive k=6 measured                                                  =', tNaive6.toFixed(3), 'ms');
console.log('saving from hoisting moduleContext out of the loop                  =', (tNaive6 - (tCtx + 6 * (tResolve + tSwap))).toFixed(3), 'ms');
console.log('parses per step in the naive fold: moduleContext + swapSpans reparse = 2');
