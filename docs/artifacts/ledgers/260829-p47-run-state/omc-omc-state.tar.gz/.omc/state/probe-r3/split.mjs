import { readdirSync, readFileSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { buildEditMap } from '../../../packages/descvi/src/extractor/edit-map.ts';

const ROOT = process.env.REPO_ROOT;
const APP = join(ROOT, 'src/app');

function walk(dir, out = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.name === 'page.tsx') out.push(p);
  }
  return out;
}

const inputs = [];
for (const p of walk(APP).sort()) {
  const spec = join(dirname(p), 'spec.ts');
  let specSource;
  try { specSource = readFileSync(spec, 'utf8'); } catch { continue; }
  inputs.push({ id: relative(APP, dirname(p)).split('/').join('-') || 'root', pageSource: readFileSync(p, 'utf8'), specSource, relPagePath: relative(ROOT, p) });
}
const map = buildEditMap(inputs);

let flex = 0, nonflex = 0, unknown = 0, noclass = 0, realNonFlex = 0, grid = 0;
const chains = [];
for (const [screenId, entries] of Object.entries(map.oids)) {
  const ids = Object.keys(entries);
  const parent = new Map(ids.map((i) => [i, i]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  const uni = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
  for (const oid of ids) {
    const s = entries[oid].structure;
    for (const n of [s.prevOid, s.nextOid]) if (n && parent.has(n)) uni(oid, n);
  }
  const groups = new Map();
  for (const oid of ids) { const r = find(oid); if (!groups.has(r)) groups.set(r, []); groups.get(r).push(oid); }
  for (const [, members] of groups) {
    if (members.length < 2) continue;
    const pOid = entries[members[0]].structure.parentOid;
    chains.push({ screenId, members, pOid });
    if (!pOid || !entries[pOid]) { unknown++; continue; }
    const cn = entries[pOid].className;
    if (cn && /(^|[\s:])(inline-)?flex(\s|$)/.test(cn)) { flex++; continue; }
    nonflex++;
    if (cn === null || cn === '') noclass++;
    else { realNonFlex++; if (/(^|[\s:])grid(\s|$)/.test(cn)) grid++; }
  }
}
console.log('multi-member chains:', chains.length);
console.log('authored-flex parent:', flex, '| non-flex:', nonflex, '| unknown (no oid-bearing parent):', unknown);
console.log('of non-flex -> no-class:', noclass, '| real non-flex className:', realNonFlex, '| of which grid:', grid);

// swallowed-oid + map-body fixtures
for (const oid of ['wcall1', 'wcall2', 'wcall3', 'wcall4', 'wflbl3', 'wfval7', 'wgrid1', 'smroww', 'smcell', 'smname', 'smtagg']) {
  for (const [screen, entries] of Object.entries(map.oids)) {
    if (entries[oid]) { const s = entries[oid].structure; console.log(oid, '|', screen, '| parent', s.parentOid, '| prev', s.prevOid, '| next', s.nextOid, '| up/down', s.canMoveUp, s.canMoveDown, '| class', JSON.stringify(entries[oid].className)); }
  }
}
