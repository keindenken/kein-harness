import { readFileSync } from 'node:fs';
const ROOT = process.env.PROOT;
const raw = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live-raw.json', 'utf8'));

let totalChains = 0;
const noScope = [];          // chains with ZERO live subject elements
const multiScope = [];       // chains reachable from more than one subject scope
let scopeCount = 0;

// Q1
let scopesRefusedUniq = 0, chainsRefusedUniqAll = 0, chainsRefusedUniqAny = 0;
const uniqDetail = { zero: 0, one: 0, many: 0 };
const zeroExamples = [], manyExamples = [];
// Q2
let scopesNotDirect = 0, chainsNotDirectAny = 0, chainsNotDirectAll = 0;
const notDirectExamples = [];
// Q3 / Q6 - per FIRST scope of each chain (comparable with the artifact proxy)
const dispTally = {}, dirTally = {}, wmTally = {}, orderTally = {};
let unequalChildOrder = 0, unequalMemberOrder = 0;
const orderValues = {};
// Q5
let flexChains = 0, wrappedChains = 0, chainsWithOverlap = 0, overlapPairsTotal = 0, memberPairsTotal = 0;
const wrapExamples = [], overlapExamples = [];

const perScreen = {};

for (const r of raw.results) {
  if (r.unreached) { perScreen[r.screenId] = { unreached: true }; continue; }
  const ps = { chains: 0, noScope: 0, refusedUniq: 0, notDirect: 0, flex: 0 };
  for (const ch of r.chains) {
    totalChains++;
    ps.chains++;
    if (ch.scopes.length === 0) { noScope.push(ch); ps.noScope++; continue; }
    if (ch.scopes.length > 1) multiScope.push({ screen: ch.screen, members: ch.members, n: ch.scopes.length });
    scopeCount += ch.scopes.length;

    let anyUniq = false, allUniq = true, anyND = false, allND = true;
    for (const s of ch.scopes) {
      uniqDetail.zero += s.zero; uniqDetail.one += s.one; uniqDetail.many += s.many;
      const bad = s.zero > 0 || s.many > 0;
      if (bad) { scopesRefusedUniq++; anyUniq = true; } else allUniq = false;
      if (s.zero > 0 && zeroExamples.length < 12) zeroExamples.push({ screen: ch.screen, members: ch.members, zero: s.zero, parent: s.parent.oid, tag: s.parent.tag });
      if (s.many > 0 && manyExamples.length < 12) manyExamples.push({ screen: ch.screen, members: ch.members, many: s.many, parent: s.parent.oid, tag: s.parent.tag });
      if (s.notDirect > 0) { scopesNotDirect++; anyND = true;
        if (notDirectExamples.length < 12) notDirectExamples.push({ screen: ch.screen, members: ch.members, notDirect: s.notDirect, parent: s.parent.oid, tag: s.parent.tag, cls: s.parent.className });
      } else allND = false;
    }
    if (anyUniq) { chainsRefusedUniqAny++; ps.refusedUniq++; }
    if (allUniq) chainsRefusedUniqAll++;
    if (anyND) { chainsNotDirectAny++; ps.notDirect++; }
    if (allND) chainsNotDirectAll++;

    // Q3/Q5/Q6 over the FIRST scope (one reading per chain)
    const s0 = ch.scopes[0];
    dispTally[s0.parent.display] = (dispTally[s0.parent.display] || 0) + 1;
    dirTally[s0.parent.direction] = (dirTally[s0.parent.direction] || 0) + 1;
    wmTally[s0.parent.writingMode] = (wmTally[s0.parent.writingMode] || 0) + 1;
    for (const o of s0.childOrders) orderValues[o] = (orderValues[o] || 0) + 1;
    const uniqChild = Array.from(new Set(s0.childOrders));
    const uniqMember = Array.from(new Set(s0.memberOrders));
    if (uniqChild.length > 1) unequalChildOrder++;
    if (uniqMember.length > 1) unequalMemberOrder++;
    orderTally[uniqChild.join('|')] = (orderTally[uniqChild.join('|')] || 0) + 1;

    const isFlex = s0.parent.display === 'flex' || s0.parent.display === 'inline-flex';
    if (isFlex) { flexChains++; ps.flex++;
      if (s0.lineCount > 1) { wrappedChains++; if (wrapExamples.length < 10) wrapExamples.push({ screen: ch.screen, parent: s0.parent.oid, lines: s0.lineCount, wrap: s0.parent.flexWrap, kids: s0.boxedChildren }); }
    }
    if (s0.overlapPairs > 0) { chainsWithOverlap++; if (overlapExamples.length < 10) overlapExamples.push({ screen: ch.screen, members: ch.members, pairs: s0.overlapPairs, parent: s0.parent.oid }); }
    overlapPairsTotal += s0.overlapPairs; memberPairsTotal += s0.memberPairs;
  }
  perScreen[r.screenId] = ps;
}

console.log('=== POPULATION ===');
console.log('chains analysed', totalChains, '(expect 235)');
console.log('chains with ZERO live subject element (unreachable, no scope):', noScope.length);
console.log('chains reachable from >1 subject scope (repeat renders):', multiScope.length);
console.log('total subject scopes:', scopeCount);
console.log('');
console.log('=== Q1 UNIQUENESS (per member, within subjectEl.parentElement subtree) ===');
console.log('member-in-scope readings: n=0', uniqDetail.zero, ' n=1', uniqDetail.one, ' n>1', uniqDetail.many);
console.log('scopes where >=1 member fails uniqueness:', scopesRefusedUniq, 'of', scopeCount);
console.log('chains refused for AT LEAST ONE scope:', chainsRefusedUniqAny);
console.log('chains refused for EVERY scope:', chainsRefusedUniqAll);
console.log('zero examples:', JSON.stringify(zeroExamples));
console.log('many examples:', JSON.stringify(manyExamples));
console.log('');
console.log('=== Q2 DIRECT-CHILD ===');
console.log('scopes with >=1 uniquely-resolved member that is NOT a direct child:', scopesNotDirect, 'of', scopeCount);
console.log('chains affected for at least one scope:', chainsNotDirectAny, '| for every scope:', chainsNotDirectAll);
console.log('examples:', JSON.stringify(notDirectExamples));
console.log('');
console.log('=== Q3 CSS REFUSALS (first scope per chain) ===');
console.log('direction:', JSON.stringify(dirTally));
console.log('writing-mode:', JSON.stringify(wmTally));
console.log('chains whose parent has UNEQUAL computed order across ALL direct children:', unequalChildOrder);
console.log('chains whose CHAIN MEMBERS have unequal computed order:', unequalMemberOrder);
console.log('distinct-order-set histogram:', JSON.stringify(orderTally));
console.log('order value census over all direct children:', JSON.stringify(orderValues));
console.log('');
console.log('=== Q5 WRAP + OVERLAP ===');
console.log('chains whose first-scope parent computes flex/inline-flex:', flexChains);
console.log('of those, parents laying out on MORE THAN ONE flex line:', wrappedChains, JSON.stringify(wrapExamples));
console.log('chains with >=1 overlapping member-rect pair:', chainsWithOverlap, '| overlapping pairs', overlapPairsTotal, 'of', memberPairsTotal, 'member pairs');
console.log('overlap examples:', JSON.stringify(overlapExamples));
console.log('');
console.log('=== Q6 LIVE display CENSUS (first scope per chain) ===');
console.log(JSON.stringify(dispTally));
console.log('');
console.log('=== PER SCREEN ===');
for (const k of Object.keys(perScreen)) console.log(k, JSON.stringify(perScreen[k]));
console.log('');
console.log('=== NO-SCOPE CHAINS (zero live nodes) ===');
for (const c of noScope) console.log(' ', c.screen, JSON.stringify(c.members), 'parentOid=' + c.parentOid);
