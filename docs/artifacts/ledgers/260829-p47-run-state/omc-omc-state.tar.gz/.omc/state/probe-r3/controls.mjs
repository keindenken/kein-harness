/**
 * POSITIVE CONTROLS. Every zero this lane reports is re-measured here after PLANTING the
 * signature it claims not to have found, using the byte-identical analyzer.
 * Subject: sandbox/resize-repeat-list, chain [smcell, smname, smtagg] under `smroww`
 * (a `flex flex-row` <li> rendered four times by a .map()).
 */
import { chromium } from '@playwright/test';
import { analyze } from './analyzer.mjs';

const BASE = process.env.PBASE;
const SCREEN = 'sandbox/resize-repeat-list';
const CHAIN = { members: ['smcell', 'smname', 'smtagg'], parentOid: 'smroww' };

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 950 } });
const page = await ctx.newPage();

async function read() {
  const r = await page.evaluate(analyze, { screenId: SCREEN, chainList: [CHAIN], bogusOid: 'zzzz00' });
  const ch = r.chains[0];
  return ch.scopes.map((s) => ({
    zero: s.zero, one: s.one, many: s.many, notDirect: s.notDirect,
    n: s.members.map((m) => m.n), direct: s.members.map((m) => m.direct),
    display: s.parent.display, direction: s.parent.direction, writingMode: s.parent.writingMode,
    flexWrap: s.parent.flexWrap, childOrders: s.childOrders, lineCount: s.lineCount,
    overlapPairs: s.overlapPairs,
  }));
}

async function fresh() {
  await page.goto(BASE + '/' + SCREEN, { waitUntil: 'load' });
  await page.waitForSelector('[data-screen="' + SCREEN + '"]');
  await page.waitForTimeout(400);
}

const out = {};
await fresh();
out.BASELINE = await read();

// C-A — plant a SECOND element carrying a member oid inside the first scope.
await fresh();
await page.evaluate(() => {
  const el = document.querySelectorAll('[data-oid="smcell"]')[0];
  el.parentElement.appendChild(el.cloneNode(true));
});
out['C-A many'] = (await read())[0];

// C-B — plant a WRAPPER so a uniquely-resolved member becomes a GRANDCHILD.
await fresh();
await page.evaluate(() => {
  const el = document.querySelectorAll('[data-oid="smname"]')[0];
  const p = el.parentElement;
  const w = document.createElement('div');
  p.insertBefore(w, el);
  w.appendChild(el);
});
out['C-B notDirect'] = (await read())[0];

// C-C — plant direction: rtl on the parent.
await fresh();
await page.evaluate(() => { document.querySelectorAll('[data-oid="smroww"]')[0].style.direction = 'rtl'; });
out['C-C rtl'] = (await read())[0];

// C-D — plant a vertical writing mode on the parent.
await fresh();
await page.evaluate(() => { document.querySelectorAll('[data-oid="smroww"]')[0].style.writingMode = 'vertical-rl'; });
out['C-D vertical'] = (await read())[0];

// C-E — plant an unequal computed `order` on ONE child.
await fresh();
await page.evaluate(() => { document.querySelectorAll('[data-oid="smtagg"]')[0].style.order = '2'; });
out['C-E order'] = (await read())[0];

// C-F — plant a MISSING member (delete one element from the DOM).
await fresh();
await page.evaluate(() => { document.querySelectorAll('[data-oid="smtagg"]')[0].remove(); });
out['C-F zero'] = (await read())[0];

// C-G — plant a real WRAP: flex-wrap + a parent too narrow for one line.
await fresh();
await page.evaluate(() => {
  const p = document.querySelectorAll('[data-oid="smroww"]')[0];
  p.style.flexWrap = 'wrap';
  p.style.width = '120px';
});
out['C-G wrap'] = (await read())[0];

// C-H — plant OVERLAPPING sibling rects.
await fresh();
await page.evaluate(() => {
  const p = document.querySelectorAll('[data-oid="smroww"]')[0];
  p.style.position = 'relative';
  const el = document.querySelectorAll('[data-oid="smtagg"]')[0];
  el.style.position = 'absolute';
  el.style.left = '0px';
  el.style.top = '0px';
  el.style.width = '200px';
  el.style.height = '40px';
});
out['C-H overlap'] = (await read())[0];

// C-I — display: the same parent forced to block.
await fresh();
await page.evaluate(() => { document.querySelectorAll('[data-oid="smroww"]')[0].style.display = 'block'; });
out['C-I display'] = (await read())[0];

for (const k of Object.keys(out)) console.log(k, JSON.stringify(out[k]));
await browser.close();
