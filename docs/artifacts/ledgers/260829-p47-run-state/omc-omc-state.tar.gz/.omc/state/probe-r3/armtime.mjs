import { readdirSync, readFileSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { buildEditMap } from '../../../packages/descvi/src/extractor/edit-map.ts';
const ROOT = process.env.REPO_ROOT;
const APP = join(ROOT, 'src/app');
function walk(dir, out = []) { for (const e of readdirSync(dir, { withFileTypes: true })) { const p = join(dir, e.name); if (e.isDirectory()) walk(p, out); else if (e.name === 'page.tsx') out.push(p); } return out; }
const inputs = [];
for (const p of walk(APP).sort()) {
  const spec = join(dirname(p), 'spec.ts');
  let s; try { s = readFileSync(spec, 'utf8'); } catch { continue; }
  inputs.push({ id: relative(APP, dirname(p)).split('/').join('-'), pageSource: readFileSync(p, 'utf8'), specSource: s, relPagePath: relative(ROOT, p) });
}
const map = buildEditMap(inputs);
let onSingletons = 0, onChainMembers = 0;
for (const entries of Object.values(map.oids)) {
  const ids = Object.keys(entries);
  const parent = new Map(ids.map((i) => [i, i]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  const uni = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
  for (const oid of ids) { const s = entries[oid].structure; for (const n of [s.prevOid, s.nextOid]) if (n && parent.has(n)) uni(oid, n); }
  const size = new Map();
  for (const oid of ids) { const r = find(oid); size.set(r, (size.get(r) ?? 0) + 1); }
  for (const oid of ids) {
    const s = entries[oid].structure;
    const isSingleton = size.get(find(oid)) === 1;
    for (const op of ['move-up', 'move-down']) {
      if (s.reasons?.[op] === 'unsupported-sibling') { if (isSingleton) onSingletons++; else onChainMembers++; }
    }
  }
}
console.log('unsupported-sibling refusals on SINGLETONS (arm-time, subject cannot move at all):', onSingletons);
console.log('unsupported-sibling refusals on MULTI-MEMBER chain members (fold-step side):', onChainMembers);
console.log('total:', onSingletons + onChainMembers);
