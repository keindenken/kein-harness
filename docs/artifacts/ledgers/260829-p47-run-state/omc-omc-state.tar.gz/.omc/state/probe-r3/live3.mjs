import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from '@playwright/test';
import { analyze } from './analyzer.mjs';

const ROOT = process.env.PROOT;
const BASE = process.env.PBASE;
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));
const manifest = JSON.parse(readFileSync(ROOT + '.descvi/screens.json', 'utf8'));
const axesOf = {};
for (const sc of manifest.screens) axesOf[sc.id] = sc.stateAxes || {};

const byScreen = new Map();
for (const c of chains) {
  if (!byScreen.has(c.screen)) byScreen.set(c.screen, []);
  byScreen.get(c.screen).push(c);
}

function combos(axes) {
  const keys = Object.keys(axes);
  if (keys.length === 0) return [{}];
  let acc = [{}];
  for (const k of keys) {
    const next = [];
    for (const base of acc) for (const v of axes[k].values) next.push({ ...base, [k]: v });
    acc = next;
  }
  return acc;
}

// In-page tab controls that gate a chain but are NOT declared state axes.
// member-detail's `tab` is plain React useState driven by three buttons stamped `x5hoyo`.
const TABS = { 'shop/member-detail': 3, 'shop/member-detail::point-adjust-modal': 3, 'shop/member-detail::benefit-add-modal': 3 };

async function setAxis(page, key, value) {
  const row = page.locator('#dsh-sec-state div').filter({ has: page.locator('code', { hasText: new RegExp('^' + key + '$') }) }).first();
  await row.getByRole('combobox').click();
  await page.getByRole('option', { name: value, exact: true }).click();
  await page.waitForTimeout(260);
}

const browser = await chromium.launch();
const version = browser.version();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 950 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 160)));

const runs = [];
for (const entry of byScreen) {
  const screenId = entry[0];
  const list = entry[1];
  const sep = screenId.indexOf('::');
  const route = sep === -1 ? screenId : screenId.slice(0, sep);
  const url = BASE + '/' + route + (sep === -1 ? '' : '?open=' + encodeURIComponent(screenId));
  const axes = axesOf[screenId] || {};
  const tabCount = TABS[screenId] || 1;
  for (const combo of combos(axes)) {
    for (let t = 0; t < tabCount; t++) {
      await page.goto(url, { waitUntil: 'load' });
      try { await page.waitForSelector('[data-screen="' + screenId + '"]', { timeout: 8000 }); }
      catch { runs.push({ screenId, combo, tab: t, unreached: true }); console.log('UNREACHED', screenId); continue; }
      await page.waitForTimeout(320);
      let axisOk = true;
      for (const k of Object.keys(combo)) {
        if (combo[k] === axes[k].default) continue;
        try { await setAxis(page, k, combo[k]); } catch { axisOk = false; }
      }
      let tabOk = true;
      if (t > 0) {
        const btns = page.locator('[data-oid="x5hoyo"]');
        try { await btns.nth(t).click({ timeout: 3000 }); await page.waitForTimeout(280); } catch { tabOk = false; }
      }
      await page.waitForTimeout(220);
      const r = await page.evaluate(analyze, { screenId, chainList: list, bogusOid: 'zzzz00' });
      r.combo = combo; r.tab = t; r.axisOk = axisOk; r.tabOk = tabOk;
      runs.push(r);
      console.log('OK', screenId, JSON.stringify(combo), 'tab' + t, 'oidEls', r.control.totalOidEls, axisOk && tabOk ? '' : 'DRIVE-FAIL');
    }
  }
}
console.log('BROWSER', version, 'pageerrors', errors.length, errors.slice(0, 4).join(' | '));
writeFileSync(ROOT + '.omc/state/probe-r3/live3-raw.json', JSON.stringify({ version, runs }));
await browser.close();
