/**
 * Cross-host pass on the PLAIN prototype view (:3000, overlay-free).
 * Two jobs:
 *  (1) a default-state census over every screen, to be compared digit-for-digit with the
 *      design-view default-state census — the control that says the plain host is a valid
 *      stand-in for the chains the design view cannot reach;
 *  (2) the three `shop/member-detail` tab panes, which the design view's canvas shield
 *      swallows the activating click for.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from '@playwright/test';
import { analyze } from './analyzer.mjs';

const ROOT = process.env.PROOT;
const BASE = process.env.PBASE;
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));
const byScreen = new Map();
for (const c of chains) {
  if (!byScreen.has(c.screen)) byScreen.set(c.screen, []);
  byScreen.get(c.screen).push(c);
}
const TABS = { 'shop/member-detail': 3, 'shop/member-detail::point-adjust-modal': 3, 'shop/member-detail::benefit-add-modal': 3 };

const browser = await chromium.launch();
const version = browser.version();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 950 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 160)));

const runs = [];
for (const entry of byScreen) {
  const screenId = entry[0];
  const list = entry[1];
  const sep = screenId.indexOf('::');
  const route = sep === -1 ? screenId : screenId.slice(0, sep);
  const url = BASE + '/' + route + (sep === -1 ? '' : '?open=' + encodeURIComponent(screenId));
  const tabCount = TABS[screenId] || 1;
  for (let t = 0; t < tabCount; t++) {
    await page.goto(url, { waitUntil: 'load' });
    try { await page.waitForSelector('[data-screen="' + screenId + '"]', { timeout: 8000 }); }
    catch { runs.push({ screenId, tab: t, unreached: true }); console.log('UNREACHED', screenId, t); continue; }
    await page.waitForTimeout(350);
    let before = await page.evaluate(() => document.querySelectorAll('[data-oid]').length);
    let tabMoved = null;
    if (t > 0) {
      await page.evaluate((idx) => { const b = document.querySelectorAll('[data-oid="x5hoyo"]')[idx]; if (b) b.click(); }, t);
      await page.waitForTimeout(350);
      const after = await page.evaluate(() => document.querySelectorAll('[data-oid]').length);
      tabMoved = after !== before;
    }
    const r = await page.evaluate(analyze, { screenId, chainList: list, bogusOid: 'zzzz00' });
    r.tab = t; r.tabMoved = tabMoved;
    runs.push(r);
    console.log('OK', screenId, 'tab' + t, 'oidEls', r.control.totalOidEls, tabMoved === null ? '' : 'tabMoved=' + tabMoved);
  }
}
console.log('BROWSER', version, 'pageerrors', errors.length, errors.slice(0, 4).join(' | '));
writeFileSync(ROOT + '.omc/state/probe-r3/live4-raw.json', JSON.stringify({ version, runs }));
await browser.close();
