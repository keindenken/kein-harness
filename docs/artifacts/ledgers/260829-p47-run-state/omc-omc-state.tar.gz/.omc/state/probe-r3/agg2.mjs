import { readFileSync, writeFileSync } from 'node:fs';
const ROOT = process.env.PROOT;
const raw = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/live2-raw.json', 'utf8'));
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));
const editMap = JSON.parse(readFileSync(ROOT + '.descvi/edit-map.json', 'utf8'));

const key = (screen, members) => screen + '|' + members.join(',');
const M = new Map();
for (const c of chains) M.set(key(c.screen, c.members), { screen: c.screen, members: c.members, parentOid: c.parentOid, obs: [], reachStates: 0, states: 0 });

let runs = 0, unreached = 0, axisFails = 0;
for (const r of raw.runs) {
  if (r.unreached) { unreached++; continue; }
  runs++;
  if (r.axisOk === false) axisFails++;
  for (const ch of r.chains) {
    const rec = M.get(key(r.screenId, ch.members));
    rec.states++;
    if (ch.scopes.length > 0) rec.reachStates++;
    for (const s of ch.scopes) rec.obs.push({ combo: r.combo, s });
  }
}
console.log('runs', runs, 'unreached', unreached, 'axisFails', axisFails);

// dedupe observations per chain by a structural signature so the same DOM shape seen in
// several states is not double-counted.
for (const rec of M.values()) {
  const seen = new Set();
  rec.uobs = [];
  for (const o of rec.obs) {
    const s = o.s;
    const sig = JSON.stringify([s.parent, s.members.map((m) => [m.oid, m.n, m.direct]), s.childOrders, s.lineCount, s.overlapPairs]);
    if (seen.has(sig)) continue;
    seen.add(sig);
    rec.uobs.push(s);
  }
}

const all = Array.from(M.values());
const unreachable = all.filter((r) => r.reachStates === 0);
const reachable = all.filter((r) => r.reachStates > 0);

// ---- Q1 ----
let obsTotal = 0, obsUniqFail = 0, obsND = 0;
let nZero = 0, nOne = 0, nMany = 0;
const uniqAlways = [], uniqSome = [];
const ndAlways = [], ndSome = [];
for (const r of reachable) {
  let bad = 0, nd = 0;
  for (const s of r.uobs) {
    obsTotal++;
    nZero += s.zero; nOne += s.one; nMany += s.many;
    if (s.zero > 0 || s.many > 0) { obsUniqFail++; bad++; }
    if (s.notDirect > 0) { obsND++; nd++; }
  }
  if (bad === r.uobs.length) uniqAlways.push(r); else if (bad > 0) uniqSome.push(r);
  if (nd === r.uobs.length) ndAlways.push(r); else if (nd > 0) ndSome.push(r);
}

// ---- Q3 / Q5 / Q6: one reading per reachable chain (its FIRST distinct observation) ----
const disp = {}, dir = {}, wm = {}, fdir = {};
let unequalChildOrder = 0, unequalMemberOrder = 0;
const orderVals = {};
let flexChains = 0, wrapped = 0, ovChains = 0, ovPairs = 0, mPairs = 0;
const wrapEx = [], ovEx = [], flexWrapTally = {};
for (const r of reachable) {
  const s = r.uobs[0];
  disp[s.parent.display] = (disp[s.parent.display] || 0) + 1;
  dir[s.parent.direction] = (dir[s.parent.direction] || 0) + 1;
  wm[s.parent.writingMode] = (wm[s.parent.writingMode] || 0) + 1;
  for (const o of s.childOrders) orderVals[o] = (orderVals[o] || 0) + 1;
  if (new Set(s.childOrders).size > 1) unequalChildOrder++;
  if (new Set(s.memberOrders).size > 1) unequalMemberOrder++;
  const isFlex = s.parent.display === 'flex' || s.parent.display === 'inline-flex';
  if (isFlex) {
    flexChains++;
    fdir[s.parent.flexDirection] = (fdir[s.parent.flexDirection] || 0) + 1;
    flexWrapTally[s.parent.flexWrap] = (flexWrapTally[s.parent.flexWrap] || 0) + 1;
    if (s.lineCount > 1) { wrapped++; if (wrapEx.length < 14) wrapEx.push({ screen: r.screen, parent: s.parent.oid, lines: s.lineCount, wrap: s.parent.flexWrap, fd: s.parent.flexDirection, kids: s.boxedChildren, cls: s.parent.className }); }
  }
  if (s.overlapPairs > 0) { ovChains++; if (ovEx.length < 14) ovEx.push({ screen: r.screen, members: r.members, parent: s.parent.oid, pairs: s.overlapPairs, cls: s.parent.className }); }
  ovPairs += s.overlapPairs; mPairs += s.memberPairs;
}

// ---- the artifact proxy, recomputed here for the side-by-side ----
let pFlex = 0, pNon = 0, pUnk = 0;
for (const c of chains) {
  const e = editMap.oids[c.screen];
  const p = c.parentOid;
  if (p === null || e[p] === undefined) { pUnk++; continue; }
  const cn = e[p].className;
  if (cn === null || cn === undefined) { pNon++; continue; }
  const toks = String(cn).split(' ');
  if (toks.includes('flex') || toks.includes('inline-flex')) pFlex++; else pNon++;
}

console.log('');
console.log('=== POPULATION (union over every declared state-axis combination) ===');
console.log('chains total', all.length, '| reachable in >=1 state', reachable.length, '| NEVER reachable', unreachable.length);
console.log('distinct scope observations over reachable chains:', obsTotal);
console.log('');
console.log('=== Q1 UNIQUENESS ===');
console.log('per-member readings inside the subject parent subtree: n=0', nZero, ' n=1', nOne, ' n>1', nMany);
console.log('observations in which >=1 member fails "exactly one":', obsUniqFail, 'of', obsTotal);
console.log('chains refused in EVERY observation:', uniqAlways.length, '| in SOME but not all:', uniqSome.length);
console.log('  always-refused:', JSON.stringify(uniqAlways.map((r) => ({ screen: r.screen, members: r.members }))));
console.log('  sometimes-refused:', JSON.stringify(uniqSome.map((r) => ({ screen: r.screen, members: r.members }))));
console.log('');
console.log('=== Q2 DIRECT-CHILD ===');
console.log('observations with >=1 uniquely-resolved member that is NOT a direct child:', obsND, 'of', obsTotal);
console.log('chains affected always:', ndAlways.length, '| sometimes:', ndSome.length);
console.log('');
console.log('=== Q3 CSS ADMISSIBILITY ===');
console.log('computed direction:', JSON.stringify(dir));
console.log('computed writing-mode:', JSON.stringify(wm));
console.log('chains whose parent has UNEQUAL computed order across its direct children:', unequalChildOrder);
console.log('chains whose CHAIN MEMBERS carry unequal computed order:', unequalMemberOrder);
console.log('computed order value census over every direct child of every such parent:', JSON.stringify(orderVals));
console.log('');
console.log('=== Q5 WRAP + OVERLAP ===');
console.log('flex/inline-flex chains:', flexChains, '| flex-direction:', JSON.stringify(fdir), '| flex-wrap:', JSON.stringify(flexWrapTally));
console.log('flex parents laying out on >1 line:', wrapped);
console.log(JSON.stringify(wrapEx));
console.log('chains with >=1 overlapping member-rect pair:', ovChains, '| pairs', ovPairs, 'of', mPairs);
console.log(JSON.stringify(ovEx));
console.log('');
console.log('=== Q6 LIVE display CENSUS vs THE AUTHORED-TOKEN PROXY ===');
console.log('live (per reachable chain):', JSON.stringify(disp));
console.log('artifact proxy over all 235: flex', pFlex, 'nonflex', pNon, 'unknown', pUnk);
console.log('');
console.log('=== NEVER-REACHABLE CHAINS ===');
for (const r of unreachable) console.log(' ', r.screen, JSON.stringify(r.members), 'parentOid=' + r.parentOid);
writeFileSync(ROOT + '.omc/state/probe-r3/agg2.json', JSON.stringify({ reachable: reachable.length, unreachable: unreachable.map((r) => ({ screen: r.screen, members: r.members })) }));
