import { readdirSync, readFileSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { buildEditMap } from '../../../packages/descvi/src/extractor/edit-map.ts';

const ROOT = process.env.REPO_ROOT;
const APP = join(ROOT, 'src/app');

function walk(dir, out = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.name === 'page.tsx') out.push(p);
  }
  return out;
}

const pages = walk(APP).sort();
const inputs = [];
const skipped = [];
for (const p of pages) {
  const spec = join(dirname(p), 'spec.ts');
  let specSource;
  try { specSource = readFileSync(spec, 'utf8'); } catch { skipped.push(relative(ROOT, p)); continue; }
  inputs.push({
    id: relative(APP, dirname(p)).split('/').join('-') || 'root',
    pageSource: readFileSync(p, 'utf8'),
    specSource,
    relPagePath: relative(ROOT, p),
  });
}
console.log('pages found:', pages.length, '| with sibling spec.ts:', inputs.length, '| skipped:', JSON.stringify(skipped));

const map = buildEditMap(inputs);

let totalOids = 0, movable = 0;
const tally = {};
const singletonPairs = {};
let components = 0, multiMember = 0, membersInMulti = 0;
const hist = {};
let ge3 = 0, ge4 = 0, longest = 0;
const chainsAll = [];

for (const [screenId, entries] of Object.entries(map.oids)) {
  const ids = Object.keys(entries);
  totalOids += ids.length;
  for (const oid of ids) {
    const s = entries[oid].structure;
    if (s.canMoveUp || s.canMoveDown) movable++;
    for (const op of ['move-up', 'move-down']) {
      const r = s.reasons?.[op];
      if (r !== undefined) tally[r] = (tally[r] ?? 0) + 1;
    }
  }
  const parent = new Map(ids.map((i) => [i, i]));
  const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
  const uni = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) parent.set(ra, rb); };
  for (const oid of ids) {
    const s = entries[oid].structure;
    for (const n of [s.prevOid, s.nextOid]) if (n && parent.has(n)) uni(oid, n);
  }
  const groups = new Map();
  for (const oid of ids) {
    const r = find(oid);
    if (!groups.has(r)) groups.set(r, []);
    groups.get(r).push(oid);
  }
  for (const [, members] of groups) {
    components++;
    const n = members.length;
    hist[n] = (hist[n] ?? 0) + 1;
    if (n > longest) longest = n;
    if (n >= 3) ge3++;
    if (n >= 4) ge4++;
    if (n >= 2) { multiMember++; membersInMulti += n; chainsAll.push({ screenId, members }); }
    else {
      const s = entries[members[0]].structure;
      const key = `${s.reasons?.['move-up'] ?? 'NONE'} | ${s.reasons?.['move-down'] ?? 'NONE'}`;
      singletonPairs[key] = (singletonPairs[key] ?? 0) + 1;
    }
  }
}

console.log('oid entries:', totalOids, '| canMoveUp||canMoveDown:', movable);
console.log('components:', components, '| singletons:', hist[1] ?? 0);
console.log('multi-member chains (>=2):', multiMember, '| members in them:', membersInMulti);
console.log('chains >=3:', ge3, '| >=4:', ge4, '| longest:', longest);
console.log('histogram:', JSON.stringify(hist));
console.log('refusal tally:', JSON.stringify(tally, null, 1));
console.log('total refusals:', Object.values(tally).reduce((a, b) => a + b, 0));
console.log('singleton pairs:', JSON.stringify(singletonPairs, null, 1));
