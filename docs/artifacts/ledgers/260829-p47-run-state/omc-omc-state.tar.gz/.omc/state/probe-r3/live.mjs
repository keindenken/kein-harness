import { readFileSync, writeFileSync } from 'node:fs';
import { chromium } from '@playwright/test';

const ROOT = process.env.PROOT;
const BASE = process.env.PBASE;
const chains = JSON.parse(readFileSync(ROOT + '.omc/state/probe-r3/chains.json', 'utf8'));

const byScreen = new Map();
for (const c of chains) {
  if (!byScreen.has(c.screen)) byScreen.set(c.screen, []);
  byScreen.get(c.screen).push(c);
}

/**
 * In-page analyzer. For every admissible multi-member chain on this screen it enumerates
 * the SUBJECT SCOPES: the distinct `subjectEl.parentElement` nodes reachable by pressing
 * any member of the chain inside this screen partition. Then, per scope, it applies
 * exactly the rule the plan's §4.2(2) states: search that node's subtree for each chain
 * member, require exactly one hit, and require that hit to be a DIRECT CHILD of the node.
 */
function analyze(arg) {
  const screenId = arg.screenId;
  const chainList = arg.chainList;
  const bogusOid = arg.bogusOid;

  const up = (el) => el.parentElement;
  const nearestScreen = (el) => {
    let n = el;
    for (let i = 0; i < 200 && n !== null; i++) {
      const a = n.getAttribute ? n.getAttribute('data-screen') : null;
      if (a !== null) return a;
      n = up(n);
    }
    return null;
  };
  const cs = (el) => getComputedStyle(el);
  const rectOf = (el) => {
    const r = el.getBoundingClientRect();
    return { x: +r.x.toFixed(2), y: +r.y.toFixed(2), w: +r.width.toFixed(2), h: +r.height.toFixed(2) };
  };
  const ovl = (a, b) =>
    Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x) > 0.01 &&
    Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y) > 0.01;
  const sel = (oid) => '[data-oid="' + oid + '"]';

  const out = { screenId: screenId, control: {}, chains: [] };
  out.control.totalOidEls = document.querySelectorAll('[data-oid]').length;
  out.control.bogusOidEls = document.querySelectorAll(sel(bogusOid)).length;
  out.control.screenRootPresent = document.querySelector('[data-screen="' + screenId + '"]') !== null;

  for (const ch of chainList) {
    const rec = {
      screen: screenId,
      parentOid: ch.parentOid,
      members: ch.members,
      len: ch.members.length,
      liveEls: 0,
      scopes: [],
    };
    const cands = [];
    for (const m of ch.members) {
      for (const el of document.querySelectorAll(sel(m))) {
        if (nearestScreen(el) === screenId) cands.push(el);
      }
    }
    rec.liveEls = cands.length;

    const scopes = [];
    for (const el of cands) {
      const p = up(el);
      if (p !== null && scopes.indexOf(p) === -1) scopes.push(p);
    }

    for (const P of scopes) {
      const s = { members: [], zero: 0, one: 0, many: 0, notDirect: 0 };
      for (const m of ch.members) {
        const hits = P.querySelectorAll(sel(m));
        const n = hits.length;
        let direct = null;
        if (n === 1) direct = up(hits[0]) === P;
        if (n === 0) s.zero++;
        else if (n === 1) {
          s.one++;
          if (direct === false) s.notDirect++;
        } else s.many++;
        s.members.push({ oid: m, n: n, direct: direct, rect: n === 1 ? rectOf(hits[0]) : null });
      }
      const p = cs(P);
      s.parent = {
        tag: P.tagName.toLowerCase(),
        oid: P.getAttribute('data-oid'),
        display: p.display,
        direction: p.direction,
        writingMode: p.writingMode,
        flexDirection: p.flexDirection,
        flexWrap: p.flexWrap,
        className: (P.getAttribute('class') || '').slice(0, 140),
      };
      const kids = [];
      for (const k of P.children) kids.push(k);
      s.childCount = kids.length;
      s.childOrders = kids.map((k) => cs(k).order);
      s.memberOrders = [];
      for (const x of s.members) {
        if (x.n !== 1) continue;
        s.memberOrders.push(cs(P.querySelector(sel(x.oid))).order);
      }
      const isRow = p.flexDirection.indexOf('row') === 0;
      const boxes = kids.map((k) => rectOf(k)).filter((r) => r.w > 0 || r.h > 0);
      const lines = {};
      for (const r of boxes) lines[(isRow ? r.y : r.x).toFixed(1)] = 1;
      s.lineCount = Object.keys(lines).length;
      s.boxedChildren = boxes.length;
      const mrects = [];
      for (const x of s.members) if (x.rect !== null) mrects.push(x.rect);
      let ov = 0;
      for (let i = 0; i < mrects.length; i++) {
        for (let j = i + 1; j < mrects.length; j++) if (ovl(mrects[i], mrects[j])) ov++;
      }
      s.overlapPairs = ov;
      s.memberPairs = (mrects.length * (mrects.length - 1)) / 2;
      rec.scopes.push(s);
    }
    out.chains.push(rec);
  }
  return out;
}

const browser = await chromium.launch();
const version = browser.version();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on('pageerror', (e) => errors.push(String(e).slice(0, 200)));

const results = [];
for (const entry of byScreen) {
  const screenId = entry[0];
  const list = entry[1];
  const sep = screenId.indexOf('::');
  const route = sep === -1 ? screenId : screenId.slice(0, sep);
  const url = BASE + '/' + route + (sep === -1 ? '' : '?open=' + encodeURIComponent(screenId));
  await page.goto(url, { waitUntil: 'load' });
  let reached = true;
  try {
    await page.waitForSelector('[data-screen="' + screenId + '"]', { timeout: 8000 });
  } catch {
    reached = false;
  }
  if (!reached) {
    results.push({ screenId: screenId, url: url, unreached: true });
    console.log('UNREACHED', screenId, url);
    continue;
  }
  await page.waitForTimeout(400);
  const r = await page.evaluate(analyze, { screenId: screenId, chainList: list, bogusOid: 'zzzz00' });
  r.url = url;
  results.push(r);
  console.log('OK', screenId, 'chains', list.length, 'oidEls', r.control.totalOidEls, 'bogus', r.control.bogusOidEls);
}
console.log('BROWSER', version, 'pageerrors', errors.length, errors.slice(0, 3).join(' | '));
writeFileSync(ROOT + '.omc/state/probe-r3/live-raw.json', JSON.stringify({ version: version, results: results }));
await browser.close();
