# phase-47 ralplan — FINAL VENDOR-INDEPENDENT REVIEW

You are the **final approval gate** on a plan that has had five review rounds. This project's planning contract requires unanimous approval from Claude lanes **and** an independent vendor on the text as it now stands. The Claude side is done. **You are the vendor side, and this is your only call — there is no second pass after you.**

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout `/Users/kein/Documents/workspace/dev/descvi/repo`, and never read or reason about the sibling worktree `phase-47-drag-reorder-in-kein` — a different harness owns it.

## Read

1. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the plan (555 lines). This is what you approve or reject.
2. **`AGENTS.md`** — binding project rules. Its verification-gates and workflow sections are the bar.
3. **`docs/prompt/worker-brief.md`** — the rules you work under.

Do not read other files under `.omc/state/` — they are five rounds of review history, and your value here is that you are reading the artifact rather than the argument about it.

## Hard constraints

Do not edit the plan or any file. Do not run any git command that writes (no commit, add, stash, checkout, branch, reset). Do not spawn sub-agents that write. Scratch under `.omc/state/` (gitignored). **Your report is your final message.**

## What is CLOSED — do not spend this call re-deriving it

Each of these has been independently reproduced by two or more lanes, several of them by execution rather than reading. Re-deriving them costs the one thing this call is for.

- **The census and every number in §3.1.** Reproduced five times by five instruments, including the internal 578 = 578 control.
- **The one-splice composer, its parse counts (2 vs 2k, measured with an instrumented `parseSync`), and R47-4's 12 ms threshold.** Built and run twice, byte-exact against the naive fold in both directions including an interior up-move.
- **The drop-on-absence ruling (iii)** and its sub-floor key. Its shipped subject was confirmed unique by a whole-corpus live sweep.
- **DR47-4(f), the anchor-vs-gap receipt shape.** Settled.
- **DR47-8 and the owner ruling** on the drag readout.
- **The live measurements**: stage-host `setPointerCapture` (with a paired no-capture control), the 91/144 parent-layout census, and the zero-population findings for the CSS exclusions and the reversal branch.
- **The conditions count, the `styleReadout` costs, the ontology preamble correction, the Cmd+Z guard order.**

If you believe one of these is wrong, say so — but say that you are contradicting a settled item, and bring the command that shows it.

## Where this call is worth most — four targets

These are the seams no lane has been able to reach. The first is the largest.

1. **The server contract of the anchor receipt — the one substantial thing NOBODY has driven.** §4.3(2)–(3) and (7). Every measurement in five rounds has been client-side geometry or composer bytes; this seam is pure contract reasoning, which is where an independent vendor is worth most. Specifically: can the destination resolution always express a destination that the `move-up`/`move-down` verb ladder plus the **origin** `expect` can validate? Is the direction-disagreement 400 derivable **before** the splice or only after? Is the **applied** `k` recoverable from the result rather than from the request?

2. **The refusal map's Korean, as a second reader.** Does any row promise an alternative the refusal cannot verify at paint time? Is any row's second clause inconsistent with its class? ⚠ **Do not re-open wording rule 1 or the bilingual rule** — both are settled and the newest row was confirmed to satisfy them.

3. **The render-inert drag's population — re-derive it, do not trust the plan's answer.** The constraint, not the conclusion: §4.2(6) now names one flex-parented subject that constructs a source-effective, render-inert drag. **Find another or prove there is none.** The corpus's conditional members are enumerable from `.descvi/edit-map.json` via `opUnitKind: 'conditional-container'`, and 112 of 235 chains render nothing in default state. If you land on the same subject, the finding is confirmed twice; if you land elsewhere, the population is larger than anyone thinks.

4. **§7's reachability seam.** Three sweeps with three different scopes are now named side by side. **Four SYNTHETIC gate-subject declarations rest on their zero-counts.** Judge whether the plan states the scope honestly enough that a later lane cannot mistake a scoped zero for an absolute one.

## ⚠ One thing to hold to the full bar

**The last revision is itself unreviewed** — roughly 1,400 words of new prose, none of it driven, written after the last Claude lane reported. The plan's own status block now records that **every unreviewed addition in this planning round carried a defect, four for four, and every one was caught by building or driving it rather than by reading.** The author states plainly that this revision is subject to the same rate.

So: **where the plan makes a claim about what shipped code does, or about what the corpus contains, drive it rather than reasoning about it** — and positive-control your instrument before any number leaves your hands. A zero is evidence only after you have shown the probe can produce a non-zero. Every defect worth having in five rounds was found by running something.

## Report

Separate **MUST-FIX** from **WORTH-CONSIDERING**. For each: quote the claim, state what is actually true, say how you established it (the command you ran or the exact source text you read), and say what the plan should say instead. Cite code by file plus function name or by exact source text, **never by line number** — this project bans line-number citations and gates against them, because 19 of 20 pins into one file were wrong within eight commits.

End with an explicit verdict: **APPROVE** or **REVISE**. A conditional approve is a REVISE.

⚠ **Say what your verdict rests on.** If you APPROVE, name the two or three things you checked hardest, so the record shows what the vendor-independent pass actually covered. If you REVISE, rank the items — because there is no second vendor pass, the lead has to know which ones genuinely block and which can ride into execution and be caught by the phase's own RED-first gate obligation.
