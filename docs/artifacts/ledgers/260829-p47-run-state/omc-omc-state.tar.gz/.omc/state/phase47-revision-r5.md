# phase-47 ralplan — FOUR SENTENCE EDITS, THEN CODEX

**Four fixes plus two one-word Minors. No re-derivation, no ruling reopened.** The pre-codex lane verified the r4 package: the sub-floor ruling is correct and its subject is now **independently confirmed unique** (a whole-corpus 235-chain live sweep found exactly one flex-parented default-state instance below the floor, and it is `d4b6s3,d8m1w7`); §5's fixture inventory reproduced correction-for-correction; the conditions count reconciles arithmetically; pre-mortem 3's five-split is honest; the citation gate is GREEN over 982 anchors with a demonstrated RED on this file's own 63 citations.

**What did not survive is prose written in the last edit round.** Three of r4's five new paragraphs carry a factual error, and none was findable by reading — each was driven. That is the base rate this phase has now produced four times running: **every unreviewed addition has carried a defect, and every one was caught by building or driving it.** Worth one sentence somewhere durable, because it is the most portable thing this planning round has learned.

---

## 1. §4.2(6)'s containment claim is FALSE — a flex-parented subject constructs the render-inert drag today

The text says *"No flex-parented subject can construct it today — the nearest shape, `shop/member-detail`'s `ww57qb,bklj64,4b6oqr,3fz48z`, computes `display: block`…"*

**Measured live, Chromium 1440×900, `/shop/member-detail` benefits tab:**

```
chain omy3i9,0cyt4v,z76fvu,d29ipo   parent jgdhrc   flex/row
  copy 1: n=4   omy3i9, 0cyt4v, z76fvu, d29ipo
  copy 2: n=3   omy3i9, 0cyt4v,         d29ipo     ← z76fvu, an INTERIOR member, unrendered
```

`z76fvu` is `src/app/shop/member-detail/page.tsx#{b.value > 0 && (` at source index 2, and `INITIAL_BENEFITS`'s `b002` has `value: 0`. The edit map reads `0cyt4v canMoveUp: true, canMoveDown: true, reasons {}` — E1 clean, E2 flex/row, E3 passes at 3 ≥ 2. Drag `0cyt4v` to leading-of-`d29ipo`: source index 1 → 2, so the **source-space no-op check does not fire**, and the render is unchanged.

Controls in the same session: `pk9pwr`, `scroot`, `srroot`, `smroot` → `block/row`; `grpeul` → `table/row`; `smroww`, `xufjus` → `flex/row`. **The plan's own cited counter-subject `ww57qb` reproduces as `block/row`** — the reading is not in dispute, the sweep was.

⚠ **How it was missed is the finding's real content, and it belongs in the text:** the r4 lane went *into tab space* to read `pk9pwr` on the memo tab and did not check the benefits tab one click away. **Pre-mortem 4's shape, recurring inside the edit that documents pre-mortem 4** — validated against the population it was derived from.

**Fix:** state the truth and the actual containment. One flex-parented subject constructs it — `omy3i9,0cyt4v,z76fvu,d29ipo` under `jgdhrc` — and what keeps it off the design view is that the benefits tab is a plain `useState` an in-page click cannot drive there (§5/M10, §9.6).

⚠ **And say the consequence plainly: §9.6's KI ruling is now LOAD-BEARING for this residual, not a note.** The only thing containing it is a defect the plan itself calls *"not phase-47's to fix"* — i.e. one anyone may fix at any time, silently re-opening the residual. **A containment that a future bugfix removes has to be named as such**, or the next lane inherits a resolved-looking gap.

## 2. `3/3/3/3/3/2` is wrong in ORDER, and the same sentence contradicts itself

Measured in document order, with a control that distinguishes first-short from last-short:

```
/shop/order-detail  parent 4jpxin
  column 0: n=2   hjo7s4, 5s41w1        ← the SHORT one is the FIRST
  columns 1–5: n=3
CONTROL /lab/tests/shared-oid  parent d7c2h9
  columns 0–3: n=2 ; column 4: n=1      ← short one is the LAST — G47-11d's "instance 4" is correct
```

Source: `src/app/shop/order-detail/page.tsx#                {i > 0 && (` — the connector is emitted only for `i > 0`, so **column 0** lacks it.

The sentence writes `3/3/3/3/3/2` (positional-looking, wrong in order) and then says *"in column 0, `5s41w1` reads `2 / 2`"* — which is right. **A lane building the U9 material looks at the sixth column, sees `n/3`, and concludes the effect does not exist.** This repo has already paid for exactly that shape once this round.

**Fix, three sites:** `2/3/3/3/3/3`; *"the **first** missing `rpb6hb`"*; U9's *"`n / 2` in the **first**"*. Keep *"in column 0"* — it is the only one already correct. Also: `5s41w1` is source index **3 of 3** on a 1-based reading, and §4.4 defines `n` as the 1-based position — the current *"index 2 of 3"* mixes bases inside the sentence whose whole job is an off-by-meaning argument.

## 3. §12's owner-live enumeration omits U9

`U1–U5, U7 and U8` — U9 was minted at r4 and is a readout-semantics question S47-4 ships. §12 is the layer-by-layer contract a story brief is written from, so **a U-item that exists only in §8 is a deliverable with no carrier.** Fix: `U1–U5, U7, U8 and U9`.

## 4. The new key's second clause promises what the refusal cannot verify — and drops the clause that is always true

**First, the good news the lane checked and the brief was wrong to worry about:** in `이 복사본에는 … 형제 요소가 렌더되지 않았습니다`, `이 복사본` is a **locative topic** (`-에는`); the grammatical subject is `형제 요소`, the same subject as the shipped `no-reorderable-sibling` row. **It is not an unprecedented construction and it satisfies wording rule 1.** Keep it.

**The defect is the second clause.** Every other refusal in this map that refuses a *gesture* over a source-legal move ends by naming the working alternative — `layout-not-modelled` and `chain-member-not-locatable` both say `패널의 ↑ / ↓ 로는 바꿀 수 있습니다`. **`no-sibling-in-this-copy` is the only member of that class that does not.** And the panel is available here **by construction**: sub-floor implies the chain has ≥2 source members because E1 already passed, so `canMoveUp || canMoveDown` is true — confirmed on the shipped subject (`d4b6s3`: `canMoveUp:false, canMoveDown:true`).

In its place it makes an **existential claim about other rendered copies that the refusal cannot check at paint time.** True on today's only subject (a 5-copy `.map()`), false the first time it fires on a **single-copy** conditional sibling — which is the ordinary shape in real code. `shop/member-detail`'s `jbtzr7,xpy5eu` under `ejll90` is already that shape: measured **1 instance, flex/row, resolved 2** at default, with `{nextThreshold && …}` as its sibling and `getNextThreshold` returning `undefined` once points pass the top threshold.

⚠ **No gate watches the truth of any refusal sentence's second clause.** G47-11 checks bilinguality and the element-as-subject rule; G47-11b/c/d check *which key* fires. Nothing checks that a promised alternative exists. This is the first sentence in the map where that gap has teeth — **worth naming as a gap even though this fix closes today's instance.**

**LEAD RULING — replace the prediction with the invariant.** `… 렌더되지 않았습니다 — 패널의 ↑ / ↓ 로는 바꿀 수 있습니다.` / `… to trade places with. The panel's ↑ / ↓ still work here.` If you want to keep a copy-prediction it must be a **second variant gated on the instance count the client already has** (`#dsh-ring-instance-hint`, §4.1(h)), never an unconditional promise.

**Register, while you are in the row:** `렌더되지` is dev jargon among neighbours that use plain Korean (`편집할 수 있는 단위`, `흐름 축`, `위치를 확정할 수 없어`). `그려지지 않았습니다` matches the register **and matches `spec.ts`'s own vocabulary for this very element** (`다섯 번 그려지는`).

## 5. §4.7's component-instance row is wrong in both sub-cases — and the sweep list was a proper subset again

A whole-file grep for `chain-member-not-locatable` finds 8 sites; seven are correctly re-scoped to ambiguity-only. This one is not:

> **component instance** | SHIPS WHERE THE OID REACHES THE DOM; refused as `chain-member-not-locatable` otherwise.

Under the r4 rule that key is wrong **both ways**: as a **subject**, the plan's own text says it *"cannot be pressed at all"* — term 4 never makes it a candidate, so nothing is painted; as a **member**, ruling (iii) **drops** it, and only where that leaves fewer than two survivors does the copy refuse, as `no-sibling-in-this-copy`.

⚠ **This ships a false sentence into `.omc/specs/interaction-ontology.md`, a durable register §4.7 itself says NO GATE WATCHES.** And it is the fifth round running that a sweep list has turned out to be a proper subset — **the two clean rounds were the exception, not the turn.** Say that where the sweep discipline is recorded; the honest lesson is that the by-cause grep is the instrument and the list never is.

## 6. Two one-word Minors

- **The process note states a count its own list refutes.** *"KEPT BECAUSE IT HAS COST THIS PHASE TWICE"* then enumerates **three** (r0's §0 claim, r1's oid reasons, r2's ontology sentence). By P47-5's own standard — *"a count that omits its own freshest instance is the failure it describes"* — this is that failure, one screen into the document. → **THREE TIMES** (four, if you count §1 above; use whichever the list then holds).
- **U9 misquotes the owner's delegation.** It says the readout is *"ground the owner personally ruled … not the lead's or this lane's to settle silently."* The ruling record says the content is *"the drop position (`3 / 7` **or whatever form the plan settles**)"* — **the owner delegated the form.** Routing U9 is still right, but reframe it: *you delegated the form; here is a consequence of the form that was not visible when you did.* Asking them to re-decide something they handed over is the one way this reads badly.

---

## 7. One question the plan cannot currently answer, and it underwrites four SYNTHETIC declarations

§8 carries r3's *"exactly 1 of 235 was never reachable in any observed state"* (a multi-state sweep). The r4 delta lane swept **default state only** and said so; the pre-codex lane's own sweep found **112 of 235 chains render zero instances in default state**. Those sentences sit in one document and **no reader can tell which states were actually driven.** It is the seam §1's finding crawled out of, and it is the basis for four SYNTHETIC gate-subject declarations.

**Do not guess.** Either state precisely which states each figure was measured under — naming the sweep and its scope beside the number, as §E requires — or mark the reachability bound as scope-qualified. **A bound whose scope is unstated is the shape this phase has been paying for all week.**
