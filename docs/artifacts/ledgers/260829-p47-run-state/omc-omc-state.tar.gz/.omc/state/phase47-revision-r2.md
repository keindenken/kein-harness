# phase-47 ralplan — CONSOLIDATED REVISION BRIEF (after review round 2)

Three lanes reviewed r1: a **primed closure audit**, a **fresh unprimed probe lane**, and **codex, unprimed**. All three returned REVISE.

**First, the good news, because it changes what this round is about.**

- **NOT ONE ITEM FROM ROUND 1 CAME BACK REWORDED-ONLY.** The closure audit looked hardest at the seven the brief named as most exposed and found that in every one the *argument* moved, checkable at source. Twenty of twenty are CLOSED or PARTIAL-with-the-half-named.
- **All three round-1 sweeps landed in full** — the first time in four attempts in this repo that a sweep list was not a proper subset.
- **The measured layer reproduced a third and fourth time.** Two independent lanes re-derived the census by different routes, digit for digit, including the 578 = 578 control; one re-derived the refusal tally and the 133/83/19 split; one positive-controlled the `unequal-indent = 0` by re-indenting a real line and watching it become 4.
- **M14 was adjudicated against the lead's own lean and the lead accepts it.** `directionToken` is assigned only inside the `orderedBases` loop, so it is silent on exactly the variant/computed population M3 proved broken; and `flexDirection` comes off the same `CSSStyleDeclaration` the mandatory `display` read already creates, so there is no widening to justify. **DR47-6 stands as r1 wrote it. Do not re-open it.**

**Do not re-open M1–M20 or the round-1 lead rulings.** They are closed. This round is about (a) the new text nobody had reviewed, (b) claims about shipped code that turned out false when driven, and (c) the owner ruling.

**The recurring class, named because it is now the phase's signature and it has hit the lead twice and this plan twice:** *a claim carried into the text without being re-opened at source.* §0 keeps that lesson in the plan **because it already cost this phase a revision**, and MF-6 below is the same error committed inside the correction for the first one. **New standing requirement: every population claim and every timing number in the plan names the probe that produced it.** The probes now exist and are reproducible — `.omc/state/scratch-r2/` (census, singletons, tally, split, noclass, the `unequal-indent` control, the JSX-comment cause, three timing probes) and the round-1 lanes' equivalents. Cite them.

---

## A. THE OWNER RULING — apply it first

`.omc/state/phase47-owner-ruling-drag-readout.md`. **DR47-8 is DECIDED: reading (b).** The closure audit enumerated the thirteen sites; take that list as authoritative and sweep beyond it.

Falsified outright: DR47-8's header cell and chosen cell; **its entire rationale** — including *"the CONTENT points at (a)"*, *"the backlog's B-Q4 row settles provenance toward (a)"*, and the sentence that existed **only** to keep both readings open (*"Both readings share the node, the style writer, the placement and the z"*); §4.4's content paragraph and its branch-specific-id note; S47-4's conditional rider; §8's preamble; **§9.1 in its entirety, including `Recommendation: (a)`**; §12's closing line.

Weakened in authority: §2's *"the owner's v3 CLOSE ruling, quoted verbatim"*. **Keep the block quote byte-identical** — the tracker record is not edited — but the phase does (b) **because the owner ruled (b) on 2026-08-27**, not because the sentence was correctly parsed. The owner does not remember making the v3 CLOSE ruling. Do **not** repeat their own recollection (*"what went into phase-46 was (b) too"*) as fact; phase-46 touched the readout family and shipped no size readout, which is consistent but is not the same claim.

New obligations the ruling creates:
1. **Route reading (a) back to B-Q4's row** in `docs/post-loop-backlog.md` with the ruling recorded on it. The owner did not cancel it — *"it'd be useful to have."* **Do not invent a phase number.** §11's follow-ups currently name only B-Q4's auto-scroll half.
2. **The `n / N` readout now needs a gate and has none.** While (b) was open no gate could pin the content; now one is owed. RED-when: read `N` from the DOM sibling count instead of from the chain → the row fires on the `.map()` subject and on `swallowed-oid` (see MF-5/MF-6 below, where the two populations differ in **both** directions).
3. **The readout node now carries two mutually exclusive contents** — the neutral `n / N` on an eligible drag and §4.5's **red** refusal sentence on a refusing arm — while C47-4 parameterises `tone` once. Say whether it is re-styled per paint or whether these are two nodes.
4. **§8's U-list keeps U1–U5, U7 with U6 removed.** Add one clause saying the hole is deliberate so a later lane does not "restore" it.

---

## B. CRITICAL — claims about shipped code that failed when driven

### B1. The CSS model is not total, and it was falsified in a browser *(codex, sole — measured in headless Chromium with positive controls)*

r1 claims ONE `getComputedStyle(parentEl)` answers flow-container, axis and reversal, and calls the result a TOTAL algorithm. **Driven, it is not:**

- **`direction: rtl`** reverses visual order with `flexDirection` still reading `row` — reversal without `-reverse`.
- **`writing-mode: vertical-rl`** makes the same `row` advance on **y**.
- **Unequal child `order`** makes a source reorder **visually ineffective** — DOM order changed, every child stayed where it was.

Positive control in the same run: plain LTR flex, moving C to the first DOM position moved it x=48 → x=8. **The instrument could produce a non-zero result before it reported the zeros.**

**LEAD RULING — take codex's option 1: scope admissibility to the subset actually modelled.** Admit only `direction: ltr`, `writingMode: horizontal-tb`, and sibling chains whose computed `order` values are all equal; anything else paints a typed client refusal. Each of the three gets its **own** RED-when — they fail differently and a single row cannot discriminate them. This reaches DR47-5, DR47-6, C47-2, G47-5, the risks, the ADR and the ontology wording. **Modelling full logical-flow is the alternative and it loses on scope; state it as a considered option with that rationale, not as an omission.**

### B2. `no-reorderable-sibling` is FALSE for 108 of the 130 subjects it is assigned to *(fresh lane, sole — measured, with a causal control)*

The 192 singletons split by refusal **pair**, not by admissibility. Of the 130 "admissible singletons", only **22** have no adjacent sibling in both directions. For the other **108** a sibling exists — it is simply not an editable op-unit (57 `unsupported-sibling`/`unsupported-sibling`, 39 mixed, 12 the other way).

**The cause was driven, not reasoned.** In `src/app/lab/tests/style-edit/page.tsx`, `v002k2`/`5pznp9`/`sms60s`/`hakgqo` are four *visibly adjacent* children of a `flex flex-col` parent, each reporting `unsupported-sibling` with `prev=null next=null`. Strip the intervening `{/* … */}` JSX comments and re-run `buildEditMap`: `v002k2 prev=5n09bh next=5pznp9`, fully eligible. **A JSX comment severs the chain.**

**This is r1's own M18 argument, one layer down** — r1 says a sentence claiming "there is no sibling" is TRUE for the 130 and FALSE for the 62; it is also false for 108 of the 130. **G47-11b leg (i) is green on the defect and on the correct behaviour alike** — the vacuity P47-5 forbids.

**Say instead:** E1's failure splits **three** ways — 22 → `no-reorderable-sibling`; **108 → a sentence naming what the user cannot see**; 62 → the engine's own reason. Adopt the fresh lane's wording direction: *"사이에 편집할 수 없는 요소가 있어 순서를 바꿀 수 없습니다"* / *"something between them is not an editable unit"* — true, actionable, and it satisfies wording rule 1 where the generic arm does not. `unsupported-sibling`'s row must stop being scoped to *"a step of the fold"* and stop saying *"지나가야 하는"* / *"a sibling it must pass"*: at arm time nothing is being passed. G47-11b gains a fourth leg whose mutation is "fold the 108 into `no-reorderable-sibling`".

### B3. R47-4's in-lock bound is 2.2× wrong *(fresh lane, sole — measured on the real call shape)*

r1 publishes *"2.741 ms/parse … k ≤ 6 ⇒ ≈16 ms in-lock worst case"*. But `moveAdjacent` is `moduleContext` + `resolveJsxChildOp` + `swapSpans`, **not a parse**. Measured on the largest page: `moduleContext` alone **2.664 ms** (reproducing r1's number), one `moveAdjacent` **5.77 ms**, the full **k = 6** fold on the corpus's longest chain **35.18 ms**. Controls: `k=7` refuses `no-adjacent-sibling` (so 6 is the real maximum and the fold really moved six), and 6-down-then-6-up is byte-identical.

r1 is honest that S47-2 owes the real call shape — **but it publishes 16 ms as R47-4's mechanism, and 35 ms under a write lock is a different conversation.**

**LEAD RULING: promote the already-named fallback to the design.** A k-step composer over ONE parse stops being a contingency and becomes what S47-2 builds. This is the fresh lane's synthesis (ii) and it does three things at once: it answers B3, it removes the strongest half of the k = 1 steelman, and it leaves the destination receipt, G47-8/9/10 and the one-Cmd+Z guarantee intact. Re-price R47-4 against the composer, measured.

### B4. `StructureSection` cannot construct the destination receipt — and there is a better shape *(closure audit C-3 + codex M2, two lanes, converged)*

**This is the lead's own M15 candidate and it is unbuildable as named.** The panel receives only the selected oid's `StructureEditInfo` — one link, not a chain. Moving B up in `[A,B,C,D]` needs `{prevOid: prev(A), nextOid: A}`; B's record gives A and C and **not `prev(A)`**, which lives in A's own entry. The panel receives neither the edit-map nor a sibling lookup. So the moment S47-2 makes the field REQUIRED on moves, **every shipped ↑/↓ click is a 400**, and G47-10b's leg has a subject that cannot satisfy it.

**LEAD RULING — adopt codex's shape: an ANCHOR receipt, `{anchorOid, side}`.** It dissolves the problem rather than plumbing around it:
- **The panel can construct it from what it already holds** — for `move-up` of X the anchor is `prevOid` with `side: "leading"`; for `move-down` it is `nextOid` with `side: "trailing"`. No new prop, no edit-map in the panel, no widening of §2's "does NOT touch" list.
- **It is exactly what the hit-test already produces** — §4.2(4) resolves the pointer to *(sibling `S`, side)*. r1 then converts that to a `{prevOid, nextOid}` pair; under the anchor shape the conversion disappears.
- **It keeps every property DR47-4 won on.** It is a COORDINATE, not a count, so a stale chain still 409s — G47-10's argument is unchanged and still executable.

Re-derive DR47-4 against it with the losers restated, and re-check M15's endpoint-discipline answer under the new shape: with both producers able to construct it, `expectDestination` can be **REQUIRED on `move-up`/`move-down` and FORBIDDEN elsewhere**, which preserves the REQUIRED-or-FORBIDDEN rule instead of minting this endpoint's first optional field.

### B5. DR47-10's term 5 is the predicate this repo filed KI-46 against *(closure audit, sole)*

r1's §4.1(a) term 5 arms on `hasPendingEdits()` being false and §4.1(c) says *"term 5 **guarantees** nothing is dirty"*. `use-classname-commit.ts` says the opposite in terms: *"the sync arm used to be taken on 'nothing dirty', and **that predicate is FALSE inside a commit's in-flight window** — `commit()` clears the draft before awaiting."* The shipped repair is **two** synchronous readers, and `isSettled` exists precisely so a caller can spell it — forwarded with the comment *"the two synchronous controller readers, forwarded so the panel can spell §3.7(b)'s guarded predicate."*

**`isSettled` and `settleForResize` appear nowhere in the plan (grep: zero hits).** Inside the KI-46 window a reorder press reads clean, arms, switches selection synchronously — and the in-flight className commit's R1 identity guard sees `identityRef` moved and **drops the write. A committed token disappears silently.**

Note also that the sibling gesture does **not** arm synchronously: the resize machine has an `armed-pending` state, *"pointerdown taken, the settlement barrier is still awaited"*. DR47-10 never compares against it.

**Say instead:** term 5 becomes the two-reader predicate. Delete "guarantees" and say what the predicate actually buys. Add a gate row: **arm attempted inside a commit's in-flight window → does not arm**, RED-when "use `hasPendingEdits()` alone" — KI-46, executable. State whether a settlement barrier is owed and, if not, why this gesture differs from resize.

**And route the silence.** Term 5 makes the phase's headline gesture silently do nothing whenever a draft is dirty, on a canvas where 578 of 770 elements are reorderable — while DR47-7 rejects option (c) precisely because *"a silent no-op teaches the user the feature is broken"*. **Two lanes raised this independently.** The excluded N > 1 case gets U5; this gets nothing. Give it a U-item beside U5, or measure the dirty-press rate.

---

## C. MUST-FIX — the rest

### C1. The generic refusal arm violates the plan's own wording rule 1 *(codex M3 + fresh lane MF-7, two lanes)*

Rule 1: *"the subject of the sentence is the RELATIONSHIP that refused, **never the element**."* The generic arm: *"**이 요소는** 여기서 순서를 바꿀 수 없습니다 / **This element** cannot be reordered here"* — the element is the subject, differing from the named counterexample by one word. **G47-11 leg (ii) fires on the plan's own text.** And it is measured at 118 refusals, so it is populated, not defensive. **A single generic arm cannot satisfy rule 1 across four causes — rule 1's own argument says so.** Name the relationship per cause.

### C2. The refusal map is total over the ENGINE's vocabulary, not the DESIGN's *(closure audit C-2 + fresh lane MF-5, two routes)*

Two holes:
- **Absence.** The producer's type is `StructuralRefusalReason | undefined` — `reasons?: Partial<Record<...>>`, and the emitter omits the field entirely when empty. A `Record` over the union has no arm for `undefined`. The shipped panel already carries the missing arm (`fallbackReason`, partitioned by op). Say which class the 62 fall in, measured.
- **§4.2(2)'s uniqueness refusal has no key, no words and no gate leg** — a **third** client-only condition where §4.5 says there are two. It is populated, not defensive: in `swallowed-oid`, `Field({label, value})` takes no `...rest`, so `wcall1..4` reach **zero** DOM nodes while the artifact records them as a fully eligible four-member chain — and `wflbl3`/`wfval7` reach the DOM **four times each**. **The two populations differ in both directions.**

This is pre-mortem 3 entering through the design rather than through the fix for it. State the client-only set as three.

### C3. `focusStageIfOrphaned` is sited where its own predicate is false *(fresh lane, sole — two measured docblocks)*

That function's synchronous-call safety is a property of **its one call site**, and the file calls that *"a MUST-NOT-BREAK invariant this function's correctness depends on."* Its sibling `focusStageIfOwned` carries a **measured three-row table** whose ordering note reads: *"the remount lands on a LATER flush than this callback. At restore time the ticket element is connected and focused on EVERY path."* So at the panel value-commit callback `orphaned` is **false** and the call returns without focusing.

Three further things that table settles and the plan does not mention: the three panel controls behave **differently** (the chip add-input remounts; `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever); a text-entry guard **was built on this path and rejected**, with two rows measured STICKY — and DR47-9 evaluates five options without ever naming `focusStageIfOwned` or KI-31; and the backlog row names `document.body` as the mechanism for **both** dead windows, so **C47-6b alone already restores Cmd+Z here**.

**Say instead:** name the control, name the flush the call must land on, and state that C47-6a's value is focus *placement*, not undo restoration — §4.6's "two edits, two dead windows" over-claims it. **G47-12 row (a) must assert `#dsh-stage` is focused, not "Cmd+Z undoes"** — otherwise it passes on C47-6b alone.

### C4. Three factual corrections, each carried without re-opening at source

- **The oid reconciliation's arithmetic is right and BOTH of its reasons are false** *(fresh lane MF-6)*. The corpus has exactly **one** duplicated oid string — `wcall1`, in `swallowed-oid`, and it is one real element plus one docblock mention. **`insert-scratch` carries no duplicate oids at all**; its three occurrences are `data-oid="…"` **ellipses in a file-header comment**. ⚠ **This claim entered in the M18 correction the lead ordered, and it was not re-opened at source. It is the same error as §0's, inside the fix for §0's.** The honest population for R47-7 is `.map()` bodies for **under**-counting and swallowed oids for **over**-counting — which the plan does not mention at all.
- **DR47-4 mis-describes the union it splits** *(fresh lane MF-8)*. `BaselinedWireVerb = Exclude<StructuralWireVerb, 'insert-child'>`, so the first arm carries **all five** ops, `insert-after` included; the split is by **baseline**, not by payload. An executor implementing §4.3 literally produces a union that does not cover `insert-after`. Say `{delete, duplicate, insert-after}`.
- **C47-1's "the ONLY change to the shield is ONE call" contradicts DR47-11 and S47-3** *(fresh lane MF-4)*. The shield is one of the seven guard-consulting boundaries and S47-3 migrates all seven. That file takes at least two edits plus an import. **P47-4 and R47-1 rest the phase's highest-risk edit on it being one auditable call**, so state both edits and say which one the predicate-breadth obligation attaches to.

### C5. D47-2's VERIFIED label is not earned *(codex M4 + fresh lane WC-4, two lanes)*

*"THE NO-FLOW-AXIS REFUSAL IS THE MAJORITY CASE (MEASURED)"* rests on an **authored-class proxy**, not a live computed-layout census — and §4.2(3) exists precisely because authored tokens are not the truth. **Relabel it an authored-base proxy, mark live prevalence UNVERIFIED, and ground the refusal requirement in the ontology contract rather than in an unproved majority.** Note also that the 54 `no-class` parents are classified by exactly the proxy §4.2(3) calls broken; it survives empirically here (`src/app/globals.css` has no `display` or `flex` rule) — **write the empirical form**. And the softness runs the same direction as the 83 lower bound, so 57% is an **upper** bound on non-flex.

### C6. Internal section references drifted ~18 sites *(closure audit J-2 + codex M5, two lanes)*

The §0/§3/§4 restructure shifted every section by one. The closure audit enumerated them; take that table. `check-citation-anchors.mjs` is GREEN because it validates **code anchors into other files** and treats `.md` targets as unchecked section links — **this drift is inside the gate's declared blind spot**, and per-commit briefs cite this plan verbatim. S47-4 currently sends an executor to a section that does not exist. Fix in the same revision as the DR47-8 edit, which touches four of them anyway.

---

## D. WORTH-CONSIDERING — adopt or reject with a reason

- **`REORDER_INDICATOR_Z`'s 44 → 41 retraction rests on a false premise and an unratified mechanism** *(closure audit J-1)*. "The readout family's own 41" is false for the family's **drag** member: the second `styleReadout` copy — the one serving a pointer-following drag — sets **44**, with the popup at 45. And the mechanism that replaced the z privilege (§4.1(h)'s furniture hiding) is **U4, an open owner question settled after S47-4** — the story that ships the indicator. If the owner rules against hiding, the complaint collapses to **zero** mechanisms on shipped code. Either keep 41 with a named S47-4 acceptance criterion that it is conditional on U4, or take 44 matching the shipped drag precedent.
- **`styleReadout`: three call sites, not two** *(all three lanes)*. C47-4(1) and the ADR say "two existing callers"; §3.8 correctly says "two **other**"; G47-7b says "three existing readouts". Compiler-forced, so it cannot ship missed — but it is the same off-by-one class the brief raised twice already.
- **`READOUT_ACCENT_PX` is module-private, and importing it makes a cycle** *(codex W1 + fresh lane WC-2)*. Parameterise `accentPx`, or keep a resize-local wrapper that supplies it. Note `spacing-readout-accent.test.ts` row (3) requires the declaration in **both** files and requires the spacing copy to survive — which the ADR's follow-up says it does and C47-4(1) says it does not.
- **§4.1(h) does not say HOW the furniture is hidden, and F46-D turns on exactly that** *(fresh lane WC-3)*. `readScene`'s never-fired fallback fires precisely when `#dsh-handle-layer` is **absent from the DOM**. If §4.1(h)'s hiding is an unmount, **phase-47 ships the first runtime mechanism that removes that node** and G42-7's completeness leg goes vacuous. §9.5 disposes of F46-D on *role* and misses the mechanism. Specify `visibility`/`display` hiding — or take F46-D.
- **The drop table's refresh policy is unstated and G47-4's RED-when presupposes one** *(closure audit J-3)*. §4.2 builds it *"once"*; G47-4 says *"the drop table's last reading is stale"*. A table built once has no last reading. **Scroll and window-resize are in neither the terminal set nor a re-measure rule.**
- **G47-12(b-ii)'s RED-when has a green reading** *(closure audit J-4)*. Hoisting the `document.body` term alone does nothing to a focused `<input>`. Say *"hoist the **ownership check, with its new term**"*.
- **G47-1's fourth press needs a fixture S47-0 does not list**, and its *"every reorder behaviour stays green"* is wrong — an early return above `beginTravelRecording(e)` also kills travel recording *(fresh lane WC-11)*.
- **Four things now sit at z 41** under the ring layer, two of which overlap at gesture start, with no ordering rule *(closure audit MINOR 2 + fresh lane WC-10)*. The repo's own precedent says DOM order decides.
- **The §3.F preamble C47-7 amends carries two banned line pins, both now dead** *(fresh lane WC-7)* — they land on unrelated code. `AGENTS.md`'s anchor rule is binding and the gate cannot see them. Convert in the same amendment.
- **`adjacentOpUnit` is not exported** *(fresh lane WC-8)*. Name what S47-2 will actually call.
- **DR47-10(ii) is rejected on a defect the tracker records as FIXED** *(fresh lane WC-9)*. The shape argument survives; the framing presents it as live.
- **`display: contents` parents are refused** by §4.2(3)'s predicate *(closure audit MINOR 3)*. Correct and conservative — one clause so it reads as ruled rather than missed.
- **§4.5's table mixes entry counts with refusal counts** without saying so *(fresh lane WC-6)*.
- **A direct-child predicate may be owed** *(closure audit, Open Question)*. §4.2(2) refuses on non-unique resolution, but uniqueness is not sibling-hood: a chain member wrapped by a component renders as a *grandchild*, resolves uniquely, and hands the hit-test a box that is not a flex item of the parent whose axis was just read. Unmeasured — say so or measure it.

---

## E. Standing requirement, from this round's recurring class

**Every population claim and every timing number names the probe that produced it.** Not "measured" — the file, and what its control was. This round found three numbers wrong (16 ms → 35 ms; 130 → 22 + 108; both reasons of the oid reconciliation) and every one of them was a claim written from a previous claim rather than re-opened. `.omc/state/scratch-r2/` holds reproducible probes for the census, the singleton split by refusal pair, the refusal tally, the parent-layout split, the `unequal-indent` control, the JSX-comment cause and three timing runs. **Cite them where the numbers live, and keep each number in exactly ONE home.**

**Then re-read §0's own process note and check it against your own revision.** It is in the plan because it cost this phase a revision, and it was broken again inside the correction it describes.
