# phase-47 — drag-to-reorder — SHARED PLANNING CONTEXT

This file is the single channel that reaches every lane, including codex (whose runtime reads only `AGENTS.md` and never `.claude/CLAUDE.md`). Everything a lane must know is here or it does not reach that lane.

Repo: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc` (a git worktree; branch `phase-47-drag-reorder-in-omc`, base `main` @ `a7007ff`). **Run every command from this directory. Do NOT `cd` to the parent checkout.** A sibling worktree `phase-47-drag-reorder-in-kein` exists and belongs to a DIFFERENT harness — never read, write or reason about it.

## 0. The rules that bind you

- **`AGENTS.md` at the repo root is binding.** Read it before anything else. Its verification-gates and workflow sections are not background.
- **`docs/prompt/worker-brief.md` is binding** — you are a worker: you own your brief and nothing else, you never own git, you do not spawn anything that writes or judges your work, and you check your own instruments before reporting a number.
- **Cite code by ANCHOR, never by line number.** Write `` `path/to/file.ts#<exact source text>` `` where the quoted text occurs EXACTLY ONCE in that file. `file.ts:NNN` is banned outright and `node scripts/check-citation-anchors.mjs` (inside `pnpm gates`) enforces it. An anchor cannot contain a backtick. A `.md` target is a section link and is not uniqueness-checked.
- **Everything written into `.omc/` is English.** The user is Korean-speaking; the artifacts are not.
- **A measured number has exactly ONE home.** Point at it; do not restate it.
- **Report only numbers you can re-derive, with the command beside them.** A zero result is evidence only after you have shown the instrument can produce a non-zero one.

## 1. What phase-47 IS — the owner's written ruling

The authority is `docs/e3/tracker.md` §"v3 CLOSE (2026-08-24, owner rulings recorded the same day)". Read that section; do not work from this summary alone. It says:

> **Drag-to-reorder → IN, as phase-47 of a v3.5 follow-up pair.** The gesture rides v2's existing `move-up`/`move-down` verbs (no new write class) with the blue insertion indicator, and carries the cheap B-Q4 mitigation (a W×H readout during drag) since this gesture is where dragging blind bites.

and, in the v3.5 scope line:

> The QoL items (undo-focus-ownership, field-focus-ring, link-toggle-tooltip) distribute across the two — **undo-focus-ownership belongs with 47**, which touches focus anyway.

So phase-47 = **three things**:

1. **The drag-to-reorder gesture**, riding the existing `move-up` / `move-down` structural verbs — **no new write class** — with a **blue insertion indicator**.
2. **The cheap B-Q4 mitigation**: a **W×H readout during drag**. (B-Q4's own row is `docs/post-loop-backlog.md`, and the auto-scroll half is NOT this phase — read the row for the owner's 2026-08-19 ruling on what is and is not confirmed.)
3. **`undo-focus-ownership`** — the QoL rider. Its full statement, mechanism and the owner's own sketch are in the `undo-focus-ownership` row of `docs/post-loop-backlog.md`. **Read that row; the mechanism is already diagnosed there and the two guards it names are each individually correct.**

## 2. What phase-47 is NOT — lead rulings, stated so no lane re-opens them

These are LEAD rulings for this planning round. A lane may CONTEST any of them with evidence — that is what a review lane is for — but must do so explicitly rather than silently planning past them.

- **B-Q5 (small-element handle admission) is PHASE-48**, by owner ruling 2026-08-25. Out. What 48 inherits, including what is now known to be FALSE, is on the B-Q5 row of `docs/post-loop-backlog.md` and in `.omc/plans/ralplan-phase-46-ring-furniture-restyle.md` §8.
- **Marquee stays deferred-v4.** The stage-background drag slot is contested by v4's absolute insert-on-drop. ⚠ **This matters to THIS phase**: if the reorder gesture claims any stage-background press, it pre-empts a v4 decision the owner deliberately deferred. Say so if your design touches it.
- **KI-10 stays inherited.**
- **The three unrouted live-pass items are NOT picked up**: `selection-ring-treatment`, `spacing-affordance-mark`, and **KI-54** (padding popup outside-click wipes the screen, MED, cause unknown, destination is an owner ruling). Picking one up would WIDEN the owner's own written scope line. Basis: the owner's scope ruling names three things and these are not among them.
- **Multi-select drag is OUT by default** — recorded as an explicit exclusion rather than left to silence, which is the pattern `.omc/plans/ralplan-phase-45-multi-select.md` §1 used for drag-to-reorder itself. ⚠ **This is the ruling most worth contesting** if the design cannot cleanly refuse it — see §4(b).

## 3. What already exists — verified against source in this worktree

Re-verify anything you lean on; these are pointers, not findings.

- **The structural verbs are shipped.** `packages/descvi/src/extractor/structural-edit.ts#export const STRUCTURAL_OPS: readonly StructuralOp[] = ['delete', 'move-up', 'move-down', 'duplicate', 'insert-after'];`. They are **single-target and one-step**.
- **The panel already drives them** — `packages/descvi/src/react/overlay/panel/StructureSection.tsx` renders `"위로 이동"` / `"아래로 이동"` buttons gated on `canMoveUp` / `canMoveDown`, with **typed refusal reasons already rendered as Korean tooltips**. Read `disabledReason` and the typed-reason mapping: the refusal vocabulary this phase needs may already exist.
- **Drag machinery exists** from phase-42 (resize) and phase-44 (spacing): a drag machine, `setPointerCapture`, and a measured finding that the pointer stream and `pointerup` survive past the frame edge.
- **A travel guard exists** from phase-45: `packages/descvi/src/react/overlay/canvas/pointer-thresholds.ts#export const POINTER_DRAG_THRESHOLD_PX = 4;`. It records the **greatest distance the pointer reached from its press point** — travel, NOT click-time displacement, because Chromium's click for an out-and-back drag is byte-indistinguishable from a plain click. Its full contract is the docblock in `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts`.
- **NO insertion indicator exists.** Nothing in the overlay renders a drop/insertion line today. That render, and the drop-index computation behind it, are entirely new.

## 4. The four hard points — the plan must answer all four

These are the lead's reading of where this phase gets hard. They are a starting point, not a checklist to fill: a lane that finds a fifth has done its job.

**(a) The selection shield structurally suppresses drag, and its arm table has been broken before.** `packages/descvi/src/react/overlay/canvas/use-canvas-selection-shield.ts` calls `preventDefault()` on `pointerdown` in its ordinary arm.

⚠ **CORRECTED 2026-08-27 AFTER REVIEW ROUND 1, AND THE CORRECTION IS THE LEAD'S OWN ERROR.** The first version of this paragraph said the docblock records *"three separate occasions on which this table was got wrong"*, all of them *"order-of-arms failures"*, and that *"phase-47 opens a new arm in that table"*. **All three claims are false, and the r0 draft inherited them verbatim into P47-4, D47-3, R47-1 and its pre-mortem.** Re-read at source:

- The file records **ONE** occasion on which the arm table itself was wrong: `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, so `#dsh-stage`'s own `tabIndex={-1}` made every handle, strip and apron take ROW P and retired phase-42's entire ROW D as unreachable code. Both review lanes measured it independently.
- **That failure is PREDICATE-BREADTH, not order-of-arms.** The arm-order rule is stated in the file as a rule with a reason, never as a recorded failure. **A mechanism that makes the implementer quote the arm order back would not have caught the one failure that happened.**
- The other two recorded items are a different class: a **falsified gate prediction** about what ROW P protects (§3.9's RED-when, measured twice and found FALSE), and an **overstatement** at `pointerIdOf`. Both are wrong claims *about* the table, not the table being wrong.
- **Phase-47 does NOT open a new arm.** The r0 draft reversed this and the reversal is correct: a reorder press must keep every ordinary-arm behaviour, so reorderability is a gesture state on an ordinary target, not a target-ownership class. See DR47-1.

**What remains true is the risk, not the story about it.** This is still the highest-risk edit in the phase, and the plan must state what the new call's predicate must NOT match, which target class each existing arm claims, and how the gate for it can go RED — with the gate aimed at predicate breadth, which is the class the record actually contains.

**(b) The travel guard is already spoken for, and the reorder gesture wants the same signal.** Today a click whose travel ≥ `POINTER_DRAG_THRESHOLD_PX` is SWALLOWED when the click carries Shift or the selection already holds more than one member. The two Shift meanings are disambiguated **by TARGET first, by TRAVEL second**. A reorder drag's target is an **ordinary element**, so the target-first leg does not separate it from a multi-select gesture. **How the reorder gesture arms without colliding with the phase-45 contract is a first-class design question**, and it is the reason §2's multi-select-drag exclusion is the one most worth contesting.

**(c) `move-up`/`move-down` are single-step; a drag is an n-step move.** Folding n steps onto a one-step verb has consequences the plan must price — **n undo entries** being the obvious one, and whether n sequential writes can interleave with the preview/commit session at all being the less obvious one. The owner's "no new write class" ruling constrains this. Whatever you choose, state what the user sees when they press Cmd+Z once after a 4-position drag.

**(d) Non-flex parents have no defined reorder semantics, and the spec already says so.** `.omc/specs/interaction-ontology.md` §3.F-1 carries the rows: a flex/auto-layout parent gets *"Reorder sibling; blue insertion indicator"*, while a block/grid parent is *"Reorder ambiguous (no flow axis) — may require 'add auto-layout' first"* with gate *"undefined blue-line; clarify at gate"*. **The refusal policy and its Korean wording are a deliverable of this phase.** KI-17 is the standing lesson: a refusal that names the WRONG relationship is itself a defect that shipped and got filed.

## 5. Inherited debt this phase is likely to touch

- **F46-D — remove the `readScene` fallback.** phase-46's landing audit (`docs/e3/tracker.md`, phase-46 section) left exactly one item routed to "whoever owns this file next", with the reason recorded: `e2e/resize-handles.spec.ts`'s `readScene` collects roots from a `getElementById(...) ?? layerEl` fallback that has never fired, and with G46-11's glyph legs deleted the corner/strip legs are now the WHOLE of that checker — under the fallback it would collect the spacing family and mis-fire. **If phase-47 touches that file, this is phase-47's.** Read the audit paragraph, not this summary.
- **KI-47** — theme toggle leaves the selection ring and resize chips painted in the previous theme's colours. It was found to be an **unrouted fourth member** of a family the owner excluded as three, so it stands OPEN with no destination. `docs/known-issues.md` carries the mechanism AND a stated fix direction (thread the `dark` prop the two hooks already receive into the effect deps, so the class sniff disappears). **It is cheap and it touches the ring.** Whether phase-47 should take it is a real question for the plan to raise — it is NOT currently in scope and the lead has not ruled it in.

## 6. Deliverable and bar

The plan file is `.omc/plans/ralplan-phase-47-drag-reorder.md`.

Structure and bar, from `AGENTS.md` and the 2plan contract:

- **A RALPLAN-DR summary FIRST**: 3–5 principles; the top 3 decision drivers; and for every real decision **≥2 viable options with bounded pros/cons**, or an explicit invalidation rationale when only one survives.
- **Numbered contract ids** (the `C47-n` / `DR47-n` / `G47-n` convention the sibling plans use) that per-commit briefs can cite verbatim. An ambiguous contract becomes an executor's guess.
- **Acceptance criteria concrete enough to FAIL.** No vague term without a metric.
- **Every risk paired with a MECHANISM**, not a restatement of intent.
- **Per-phase gates, each able to go RED, each with a stated RED-when.** A gate that cannot fail is scaffolding. `AGENTS.md`: *"Make it fail before you believe it green."*
- **An ADR**: decision, drivers, alternatives considered, why chosen, consequences, follow-ups.
- **Stories sized for `implement → independent verification → atomic commit`**, in ship order.
- **A UI change needs a real `descvi:dev` smoke or Playwright** — say which, per story. ⚠ **This phase CANNOT be verified by unit tests alone**: an insertion indicator's position and a drag's arming threshold are things only a running server shows. Phase-46's plan straddled the live session and that was recorded as a cost; say plainly where phase-47 needs the owner's eyes and what it can settle without them.

## 7. Two failure modes this project has paid for, stated because they apply here

- **A conclusion can be RIGHT while its REASON is FALSE, and the reason is what builds the gate.** Five of phase-21's seven falsified facts were this shape. When you approve a decision, approve the REASONING.
- **A fact checked against an ARTIFACT is not verified until it is checked against the RUNNING APP.** Phase-21 shipped two facts confirmed only against `edit-map.json`; both survived five consensus rounds and died to the first live click. Mark anything not yet driven live as UNVERIFIED, in the text.
