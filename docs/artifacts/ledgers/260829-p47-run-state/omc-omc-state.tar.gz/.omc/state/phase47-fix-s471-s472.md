# phase-47 — CONSOLIDATED FIX BRIEF for S47-1 + S47-2

The joint verification lane returned **REJECT**. One consolidated brief, as the round's contract requires — do not treat these as separate errands.

**First, what it settled POSITIVELY, so you do not re-defend it.** Your travelled-range equivalence is **correct and load-bearing**, proven by differential execution rather than argument:

- **Corpus sweep:** 234 chains, 1,078 subject×destination cases — zero byte divergences, zero reason divergences, zero admit/refuse divergences.
- **Hazard sweep:** 600 synthetic cases — zero byte divergences, zero outcome divergences.
- **Positive control** (`for (const member of touched)` → `for (const member of [])`, applied once and verified): failures went 6 → 46, with the composer **writing bytes where the fold refuses** on every deep/shallow crossing. **Your travelled-member proof is the only thing standing between this design and a silent correctness hole.**

And the two lanes' index spaces are **genuinely independently derived** — S47-1 computes `removed.indexOf(anchorOid)` over a filtered array, you compute `anchorIndex < sourceIndex ? anchorIndex : anchorIndex - 1` — agreeing on all 224 receipts, with a control firing 133 disagreements including exactly the `leading(next)` half. The panel's `↑ → leading(prevOid)` / `↓ → trailing(nextOid)` is arithmetically correct.

⚠ **Your ownership is extended for this round to cover S47-1's two touches** (M4's test row and M2's map). S47-1's lane is finished and idle, so there is no conflict — but touch only what is named here.

---

## C1 — BLOCKING. `pnpm gates` is RED at step 4/13, and the cause is a habit rather than a bug

```
✗ GATE FAILED at step 4/13: 'Test (repo root)'
 Test Files  5 failed | 226 passed (231)      Tests  15 failed | 4817 passed (4832)
```

Failing: `test/gate/insert-wire-contract.test.ts`, `test/sidecar/c3-real-bridge-roundtrip.test.ts` (2), `test/sidecar/handle-structure-edit.test.ts` (9), `test/sidecar/insert-corpus-seed.test.ts`, `test/sidecar/m1-response-payload-matrix.test.ts` (2) — **none of them the three you repaired.** Every one carries the same cause: `400 expectDestination must carry { anchorOid: string, side: "leading"|"trailing" }`.

⚠ **You repaired what the COMPILER reported and stopped. `pnpm test` was the missing step, and it is one command.** Typecheck is clean; these are runtime-broken, not compile-broken, so nothing told you. **This is the phase's own "a prose list is not the gate set" failure one level over** — the enumeration you trusted was the type checker's, and its silence is not the suite's.

**Fix:** repair the rows by deriving a **semantically correct** `expectDestination` from each fixture's live `prevOid`/`nextOid` — `c9-ac12-oracle.test.ts` already does this and is the pattern to copy. ⚠ **Do not paper a row with any receipt that merely parses**; a fixture that 400s later for an unrelated reason is worse than a red one now. **Two rows are exempt and are C2's, not test repairs.**

## C2 — BLOCKING, and it is a LEAD RULING, not a test edit

`handle-structure-edit.test.ts:401` — *"`move-up` at the FIRST sibling → 422 `no-adjacent-sibling`"* now returns **400**. Proven by arithmetic over `resolveMoveDestination`, not by the test: for `sourceIndex = 0` and any `anchorIndex = a > 0`, `anchorAfterRemoval = a − 1`, so `destinationIndex` is `a − 1` or `a` — both `≥ 0`. `direction` is `'none'` or `'down'`, **never `'up'`**. **There is no receipt a client can construct that reaches the engine's `no-adjacent-sibling` refusal on a `move-up`.**

### THE RULING: accept it, and the reason is that the 400 is the truer answer

A `move-up` receipt naming a destination that is not up is a **client contradiction** — the client asserted a direction and named a coordinate disagreeing with it. That is precisely what the direction-disagreement 400 exists to catch, and it is a better answer than a 422, which says *"your source cannot do this"* when the truth is *"your request contradicts itself."* The engine's `no-adjacent-sibling` arm for the moves belonged to the **old wire**, where the verb carried no destination and the server derived one. It has no client that can reach it, and that is correct rather than lost.

⚠ **And the finding's sharper half, which goes in the plan and which I am ruling as a gap in §4.3's argument SHAPE:** §4.3's *"why this is not a new write class"* enumerates what is **unchanged** — no new op, verb, journal arm, `reselectTargetFor` arm, `REASON_TEXT` key — and **never asks what became UNREACHABLE.** A reason silently leaving the wire is the same class of defect as one silently arriving, and the shipped gate that watched this one is the gate now failing. **I am adding that to the plan; you rewrite the row** to assert the 400 with the contradiction as its stated reason, and add its mirror — **a `move-down` at the tail** — which the suite has nowhere.

## M1 — the stated rationale for where `parseDestinationForOp` runs is falsified by a shipped gate

`server.ts` says it *"runs THIRD — after the receipt, before the payload — so a request malformed on several axes reports the older contract first."* But `snippetId` is an **older** contract than `expectDestination` and is now reported second (`insert-wire-contract.test.ts:364` flipped from the snippet message to the destination message).

**Fix — and take the first option unless you find it wrong:** move the destination parse **after** `parseSnippetForOp`, which makes the comment true and restores the shipped gate without editing its assertion. If you instead keep the order, **delete the claim** — a reasoned sentence nobody drove is this plan's own §0 base rate, and it has now produced three findings in one round (M1, M2, M5).

## M2 — JOINT. The "total map" compile mechanism is blind to the vocabulary you added

`reorder-refusal-messages.ts` promises *"an engine reason added upstream is a COMPILE error here rather than a raw kebab-case identifier painted at a user."* It is keyed on `StructuralRefusalReason`, but the **wire's** reason space is `EngineRefusalReason`, which you widened with `| MoveDestinationRefusalReason`. Driven with a paired control: a member added to `StructuralRefusalReason` → **RED**; a member added to `MoveDestinationRefusalReason` → **GREEN**.

**No raw kebab reaches a user today** — both surfaces have total fallbacks (`REORDER_GENERIC_REFUSAL_MESSAGE`, `UNKNOWN_REASON_TEXT`) — so this is a mechanism that cannot fire rather than a live defect. **It is still exactly the P47-5 class this phase made a principle of.**

**Fix:** key the totality proof on the union the wire actually carries. Either give the destination reasons their own `Record<MoveDestinationRefusalReason, BilingualMessage>` with real words, or state in the docblock that they are deliberately excluded **because they are client bugs and not verdicts about the user's source**, with a `never`-style alias proving the exclusion is complete. ⚠ **`test/gate/no-reasoned-reasons.test.ts`'s `ALL_REASONS` has the same blind spot — decide both in one edit**, and while you are there add `test/reorder` to its scanned `dirs` (it scans `test/gate` and `test/helpers` only, so S47-1's reason strings are unwitnessed).

## M3 — §4.3(4)'s "the SHIPPED refusal surface, not a second implementation of it" is FALSE, measured

600 hazard cases: bytes identical everywhere, admit/refuse partition identical everywhere, and **6 label divergences**. `resolveAtLocation` wraps the partner's `boundaryOf` in a try/catch and substitutes `unsupported-sibling`; your travelled-member loop keeps `non-canonical-separator` as an own reason. **Same source, same obstruction, a different sentence depending on how far the user dragged.**

**RULING: accept the divergence, correct the claim.** Your label is the more truthful one under wording rule 1 — the obstruction genuinely is the separator — and both keys render bilingually, so no user meets a raw code. **I am correcting §4.3(4) in the plan to say what is true:** the k = 1 pair uses the shipped ladder; travelled members are proven on the same axes but keep their own separator reason. **You add the 6-case row as a gate**, because the reason axis is currently unwatched — `move-to-destination.test.ts` asserts byte-equality on five hand-picked moves and nothing compares reasons.

## M4 — S47-1's tie-break half that the lead sustained is ungated, and the mutation is green

`reorder-model.ts` documents *"`move-up` breaks a tie between two informative ones"*. Plant `[up, down]` → `[down, up]`, applied exactly once: **86 tests, all pass.** The `no-adjacent-sibling`-yields half **is** gated and does go RED; the tie-between-two-informative half has no row, because every fixture in that file has at most one informative reason.

**Fix:** one row — `{ "move-up": "unsupported-parent", "move-down": "unequal-indent" }` must yield `{ source: "engine", reason: "unsupported-parent" }` — and **drive the `[down, up]` mutation to prove it RED before you believe it.**

## M5 — R47-4's pre-commitment is unenforced in CI, and the line is drawn backwards

`expect(composerMs).toBeLessThan(12)` is behind `DESCVI_BENCH=1` on the ground that a wall-clock threshold in CI goes red for the machine's reasons. But `expect(foldMs).toBeGreaterThan(THRESHOLD_MS)` is **also** wall-clock and is **not** gated — **and it is the one a faster machine breaks.**

**Fix — draw the line honestly, either way:** gate both wall-clock rows behind `DESCVI_BENCH` and say plainly in the test's docblock that R47-4 is a **bench criterion, not a CI gate**; or assert the composer always with generous CI headroom and the tight bound under bench. What must not stand is the current split, which enforces the discriminator and not the pre-commitment. (G47-20's parse count covers algorithmic regressions either way, so the uncovered case is a constant-factor slowdown only — say that where you draw the line.)

## Minors

- **m1.** `test/react/sidecar-bridge.test.ts:715` — the repaired `structReq` builds `move-down` as `{anchorOid: 'itemaa', side: 'trailing'}`, but `itemaa` is the fixture's **prev**. That is `trailing(prev)` — **one of the 42 zero-displacement receipts you mint a 400 for.** Dormant today, but it is a fixture that will 400 for a reason unrelated to whatever the next author is testing. Use `nextOid: 'itemcc'`.
- **m2.** `c3-bridge-finalized.test.ts`'s `anchorOid: 'p'` against all-`null` neighbours is harmless and genuinely mechanical. No action.
- **m3.** `c9-ac12-oracle.test.ts` now `throw`s when the oracle subject has no neighbour — correct for today's fixture, but it converts a future fixture change from a refusal-path test into a harness crash. Worth one guard or one comment.

---

## How this round is judged

- **Every fix that ADDS an assertion must be made to FAIL before it is believed** — same standard the findings were raised under. A fix round is a revision, and this project has shipped a lead-ordered assertion that resolved to a different request's response, vacuous and deterministic, inside the very commit whose subject was closing vacuous gates.
- **Every RED probe proves it landed** — assert the mutation applied exactly once. A probe that missed comes back green and reads as an inert gate.
- **Restore by `cp` from a snapshot taken AFTER you start — never `git checkout --`.** Everything here is uncommitted.
- **Run `pnpm test` before you report, not just your own files and not just typecheck.** That is C1's whole lesson and the tree is quiescent, so it is available to you.
