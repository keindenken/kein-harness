import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const cases = [
  ['sandbox/resize-flex-col', 'scstck'],
  ['sandbox/resize-flex-row', 'srstrp'],
  ['sandbox/resize-repeat-list', 'smlist'],
];
const BASE = 'http://localhost:3000';
for (const [screen, oid] of cases) {
  await page.goto([BASE, screen].join('/'));
  await page.waitForTimeout(450);
  const r = await page.evaluate((o) => {
    const el = document.querySelector('[data-oid="' + o + '"]');
    if (!el) return 'member-not-in-dom';
    const cs = getComputedStyle(el.parentElement);
    return cs.display + ' / ' + cs.flexDirection + ' / parentTag=' + el.parentElement.tagName;
  }, oid);
  console.log(screen, 'chain-parent computed:', r);
}
await browser.close();
