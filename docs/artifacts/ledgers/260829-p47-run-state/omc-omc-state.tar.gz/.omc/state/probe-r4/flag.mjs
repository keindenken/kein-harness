import { readFileSync } from 'node:fs';
import * as SE from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/packages/descvi/src/extractor/structural-edit.ts';
const src = readFileSync('src/app/lab/tests/shared-oid/page.tsx', 'utf8');
const ctx = SE.moduleContext(src);
const SCR = 'lab/tests/shared-oid';
for (const oid of ['d4b6s3', 'd8m1w7']) {
  const up = SE.classifyStructuralEligibility(ctx, SCR, oid, 'move-up');
  const dn = SE.classifyStructuralEligibility(ctx, SCR, oid, 'move-down');
  console.log(oid, 'canMoveUp=' + up.eligible, 'canMoveDown=' + dn.eligible, up.reason || '', dn.reason || '');
}
