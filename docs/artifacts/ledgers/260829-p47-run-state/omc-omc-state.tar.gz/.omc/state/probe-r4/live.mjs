import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const HOST = 'http://localhost:3000';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const detector = (oids) => {
  const groups = new Map();
  for (const oid of oids) {
    for (const el of document.querySelectorAll('[data-oid="' + oid + '"]')) {
      const p = el.parentElement;
      if (!p) continue;
      if (!groups.has(p)) groups.set(p, new Set());
      groups.get(p).add(oid);
    }
  }
  const out = [];
  for (const [p, set] of groups) {
    const cs = getComputedStyle(p);
    const mem = [...set].join('+');
    out.push({ n: set.size, members: mem, display: cs.display, dir: cs.flexDirection });
  }
  return out;
};
async function probe(route, label, oids) {
  await page.goto(HOST + route);
  await page.waitForTimeout(700);
  const res = await page.evaluate(detector, oids);
  const counts = res.map((r) => r.n).sort();
  console.log(label, 'instances=' + res.length, 'resolvedCounts=[' + counts.join(',') + ']');
  for (const r of res) console.log('   parent', r.display, r.dir, 'n=' + r.n, r.members);
  return res;
}
console.log('=== CONTROL A: a chain the plan says is uniform (4 map instances, all 3) ===');
await probe('/sandbox/resize-repeat-list', 'smcell,smname,smtagg', ['smcell', 'smname', 'smtagg']);
console.log('=== TARGET 1: order-detail step columns (plan: 6 columns, 5 complete, 1 missing rpb6hb) ===');
await probe('/shop/order-detail', 'rpb6hb,hjo7s4,5s41w1', ['rpb6hb', 'hjo7s4', '5s41w1']);
console.log('=== TARGET 2: member-detail benefit meta chain (2 conditional of 3) ===');
await probe('/shop/member-detail', '2dtotc,jvbbn7,cmsa36', ['2dtotc', 'jvbbn7', 'cmsa36']);
console.log('=== TARGET 3: the 5-member conditional chain the plan names ===');
await probe('/sandbox/resize-repeat-list', 'smlist,smndaa,smndbb,smndcc,smlnkk', ['smlist', 'smndaa', 'smndbb', 'smndcc', 'smlnkk']);
await browser.close();
