import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const read = (o) => {
  const sel = '[data-oid="' + o + '"]';
  const el = document.querySelector(sel);
  if (!el) return o + ': absent';
  const cs = getComputedStyle(el.parentElement);
  return o + ': parent ' + cs.display + ' ' + cs.flexDirection;
};
await page.goto('http://localhost:3000/shop/order-detail');
await page.waitForTimeout(500);
console.log('order-detail R47-4 subject head:', await page.evaluate(read, 'kh1mfx'));
console.log('order-detail CONTROL (known flex parent):', await page.evaluate(read, '4jpxin'));
await page.goto('http://localhost:3000/shop/member-list');
await page.waitForTimeout(500);
console.log('member-list chain A head:', await page.evaluate(read, 'ohpkna'));
console.log('member-list chain B head:', await page.evaluate(read, 'xaro3n'));
await browser.close();
