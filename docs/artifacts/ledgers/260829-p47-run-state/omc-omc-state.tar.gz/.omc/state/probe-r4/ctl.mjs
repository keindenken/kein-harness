import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto('http://localhost:3000/lab/tests/shared-oid');
await page.waitForTimeout(600);
const read = () => page.evaluate(() => {
  const sel = '[data-oid="d7c2h9"]';
  const lis = [...document.querySelectorAll(sel)];
  return lis.map((li) => {
    const kids = [...li.children];
    const oidsHere = kids.map((c) => c.getAttribute('data-oid'));
    const isMem = (k) => k === 'd4b6s3' || k === 'd8m1w7';
    return oidsHere.filter(isMem).length;
  });
});
console.log('BASELINE per-instance resolved member counts:', (await read()).join(','));
await page.evaluate(() => {
  const lis = [...document.querySelectorAll('[data-oid="d7c2h9"]')];
  const sep = lis[0].querySelector('[data-oid="d8m1w7"]');
  sep.remove();
});
console.log('CONTROL 1 (removed the separator from instance 0):', (await read()).join(','));
await page.evaluate(() => {
  const lis = [...document.querySelectorAll('[data-oid="d7c2h9"]')];
  const last = lis[lis.length - 1];
  const s = document.createElement('span');
  s.setAttribute('data-oid', 'd8m1w7');
  last.appendChild(s);
});
console.log('CONTROL 2 (planted a separator into the LAST instance):', (await read()).join(','));
await browser.close();
