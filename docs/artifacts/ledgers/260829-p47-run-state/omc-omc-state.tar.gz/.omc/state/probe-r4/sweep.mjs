import { readFileSync } from 'node:fs';
import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const rows = JSON.parse(readFileSync('.omc/state/probe-r4/chains.json', 'utf8'));
const HOST = 'http://localhost:3000';
const detector = (oids) => {
  const groups = new Map();
  for (const oid of oids) {
    for (const el of document.querySelectorAll('[data-oid="' + oid + '"]')) {
      const p = el.parentElement;
      if (!p) continue;
      if (!groups.has(p)) groups.set(p, new Set());
      groups.get(p).add(oid);
    }
  }
  const out = [];
  for (const [p, set] of groups) {
    const cs = getComputedStyle(p);
    const isFlex = cs.display === 'flex' || cs.display === 'inline-flex';
    out.push({ n: set.size, flex: isFlex, disp: cs.display });
  }
  return out;
};
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const screens = [...new Set(rows.map((r) => r.screen))];
const findings = [];
for (const s of screens) {
  const u = [HOST, s].join('/');
  await page.goto(u);
  await page.waitForTimeout(450);
  const mine = rows.filter((x) => x.screen === s);
  for (const r of mine) {
    const oids = r.chain.split(',');
    const res = await page.evaluate(detector, oids);
    const ns = res.map((x) => x.n);
    const uniqueN = [...new Set(ns)];
    findings.push({ screen: s, chain: r.chain, len: r.len, cond: r.cond, ns, uniqueN, flex: res.map((x) => x.flex) });
  }
}
await browser.close();
const { writeFileSync } = await import('node:fs');
writeFileSync('.omc/state/probe-r4/sweep.json', JSON.stringify(findings));
console.log('chains probed:', findings.length);
const anyFlex = findings.filter((f) => f.flex.some(Boolean));
console.log('chains with at least one FLEX parent instance:', anyFlex.length);
const nonUniform = findings.filter((f) => f.uniqueN.length !== 1 && f.ns.length !== 0);
console.log('CHAINS WHOSE RESOLVED COUNT DIFFERS BETWEEN INSTANCES:', nonUniform.length);
for (const f of nonUniform) console.log('  NONUNIFORM', f.screen, f.chain, 'len=' + f.len, 'per-instance n=' + f.ns.join('/'), 'flex=' + f.flex.join('/'));
const under2 = findings.filter((f) => f.ns.some((n) => n === 1));
console.log('CHAINS WITH AN INSTANCE RESOLVING EXACTLY ONE MEMBER (E3 fewer-than-two REFUSES):', under2.length);
for (const f of under2) console.log('  FEWER-THAN-TWO', f.screen, f.chain, 'len=' + f.len, 'n=' + f.ns.join('/'), 'flex=' + f.flex.join('/'));
