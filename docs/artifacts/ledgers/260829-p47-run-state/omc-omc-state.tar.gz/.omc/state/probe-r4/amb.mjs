import { readFileSync } from 'node:fs';
import { chromium } from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/node_modules/.pnpm/playwright@1.60.0/node_modules/playwright/index.mjs';
const rows = JSON.parse(readFileSync('.omc/state/probe-r4/chains.json', 'utf8'));
const HOST = 'http://localhost:3000';
const det = (oids) => {
  const parents = new Set();
  for (const oid of oids) {
    const sel = '[data-oid="' + oid + '"]';
    const els = document.querySelectorAll(sel);
    for (const el of els) if (el.parentElement) parents.add(el.parentElement);
  }
  let many = 0;
  let deep = 0;
  for (const p of parents) {
    for (const oid of oids) {
      const sel = '[data-oid="' + oid + '"]';
      const all = [...p.querySelectorAll(sel)];
      const direct = all.filter((e) => e.parentElement === p);
      if (direct.length > 1) many++;
      if (all.length !== direct.length) deep++;
    }
  }
  return { many, deep };
};
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const screens = [...new Set(rows.map((r) => r.screen))];
let MANY = 0;
let DEEP = 0;
for (const s of screens) {
  await page.goto([HOST, s].join('/'));
  await page.waitForTimeout(400);
  const mine = rows.filter((x) => x.screen === s);
  for (const r of mine) {
    const res = await page.evaluate(det, r.chain.split(','));
    MANY += res.many;
    DEEP += res.deep;
  }
}
console.log('SEVERAL-MATCHES readings at PARENT scope across all chains:', MANY);
console.log('DEEPER-DESCENDANT readings at PARENT scope across all chains:', DEEP);
await page.goto([HOST, 'sandbox/resize-repeat-list'].join('/'));
await page.waitForTimeout(400);
await page.evaluate(() => {
  const el = document.querySelector('[data-oid="smname"]');
  const w = document.createElement('div');
  el.parentElement.insertBefore(w, el);
  w.appendChild(el);
});
const c = await page.evaluate(det, ['smcell', 'smname', 'smtagg']);
console.log('CONTROL (wrapped smname in a fresh div): many=' + c.many, 'deep=' + c.deep);
await browser.close();
