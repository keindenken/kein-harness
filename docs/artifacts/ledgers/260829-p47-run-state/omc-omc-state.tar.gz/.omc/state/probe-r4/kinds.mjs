import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import * as SE from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/packages/descvi/src/extractor/structural-edit.ts';
const ROOT = 'src/app';
const pages = [];
function walkDir(d) {
  for (const e of readdirSync(d)) {
    const p = join(d, e);
    if (statSync(p).isDirectory()) walkDir(p);
    else if (e === 'page.tsx') pages.push(p);
  }
}
walkDir(ROOT);
const rows = [];
for (const p of pages) {
  if (p === 'src/app/page.tsx') continue;
  const dir = p.replace('src/app/', '').replace('/page.tsx', '');
  const src = readFileSync(p, 'utf8');
  const ctx = SE.moduleContext(src);
  const uniq = [...new Set([...src.matchAll(/data-oid="([a-z0-9]+)"/g)].map((m) => m[1]))];
  const base = new Map();
  const kind = new Map();
  for (const o of uniq) {
    const b = SE.deriveStructuralBaseline(ctx, dir, o);
    if (!b) continue;
    base.set(o, b);
    let r = SE.resolveJsxChildOp(ctx, dir, o, 'move-down');
    if (!r.ok) r = SE.resolveJsxChildOp(ctx, dir, o, 'move-up');
    kind.set(o, r.ok ? r.opUnitKind : 'unresolved');
  }
  const seen = new Set();
  for (const o of base.keys()) {
    if (seen.has(o)) continue;
    let head = o;
    while (base.get(head)?.prevOid && base.has(base.get(head).prevOid)) head = base.get(head).prevOid;
    const c = [head];
    seen.add(head);
    let cur = head;
    while (base.get(cur)?.nextOid && base.has(base.get(cur).nextOid)) {
      cur = base.get(cur).nextOid;
      c.push(cur);
      seen.add(cur);
    }
    if (c.length === 1) continue;
    const kinds = c.map((x) => kind.get(x));
    const nCond = kinds.filter((k) => k === 'conditional-container').length;
    const uncond = c.length - nCond;
    const chainStr = c.join(',');
    rows.push({ screen: dir, chain: chainStr, len: c.length, cond: nCond, uncond });
  }
}
console.log('total multi-member chains:', rows.length);
const withCond = rows.filter((r) => r.cond !== 0);
console.log('chains containing at least one conditional-container member:', withCond.length);
const risky = withCond.filter((r) => r.uncond !== r.len && Math.max(2 - r.uncond, 0) !== 0);
console.log('chains whose UNCONDITIONAL member count is under 2 (E3 fewer-than-two risk):', risky.length);
for (const r of risky) console.log('  RISK', r.screen, r.chain, 'len=' + r.len, 'cond=' + r.cond, 'uncond=' + r.uncond);
for (const r of withCond) console.log('  COND', r.screen, r.chain, 'len=' + r.len, 'cond=' + r.cond, 'uncond=' + r.uncond);
const { writeFileSync } = await import('node:fs');
writeFileSync('.omc/state/probe-r4/chains.json', JSON.stringify(rows));
