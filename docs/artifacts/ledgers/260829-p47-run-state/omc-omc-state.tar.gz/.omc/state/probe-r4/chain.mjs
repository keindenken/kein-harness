import { readFileSync } from 'node:fs';
import * as SE from '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/packages/descvi/src/extractor/structural-edit.ts';
const FILE = process.argv[2];
const SCREEN = process.argv[3];
const src = readFileSync(FILE, 'utf8');
const ctx = SE.moduleContext(src);
const oids = [...src.matchAll(/data-oid="([a-z0-9]+)"/g)].map(m => m[1]);
const uniq = [...new Set(oids)];
const base = new Map();
for (const o of uniq) {
  const b = SE.deriveStructuralBaseline(ctx, SCREEN, o);
  if (b) base.set(o, b);
}
const seen = new Set();
const chains = [];
for (const o of base.keys()) {
  if (seen.has(o)) continue;
  let head = o;
  while (base.get(head)?.prevOid && base.has(base.get(head).prevOid)) head = base.get(head).prevOid;
  const c = [head]; seen.add(head);
  let cur = head;
  while (base.get(cur)?.nextOid && base.has(base.get(cur).nextOid)) {
    cur = base.get(cur).nextOid;
    c.push(cur);
    seen.add(cur);
  }
  if (c.length >= 2) chains.push(c);
}
const out = chains.map(c => c.join(','));
console.log(JSON.stringify({ f: FILE, bytes: Buffer.byteLength(src), out }));
