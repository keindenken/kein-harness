import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const swc = require('/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/packages/descvi/node_modules/@swc/core');
const realParse = swc.parseSync;
globalThis.__PARSES = 0;
swc.parseSync = function (...a) { globalThis.__PARSES++; return realParse.apply(this, a); };
const SE = await import('/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc/packages/descvi/src/extractor/structural-edit.ts');
const FILE = process.argv[2];
const SCREEN = process.argv[3];
const CHAIN = process.argv[4].split(',');
const src = readFileSync(FILE, 'utf8');
function spansOf(source, chain) {
  const ctx = SE.moduleContext(source);
  const spans = [];
  for (const oid of chain) {
    let r = SE.resolveJsxChildOp(ctx, SCREEN, oid, 'move-down');
    if (!r.ok) r = SE.resolveJsxChildOp(ctx, SCREEN, oid, 'move-up');
    if (!r.ok) throw new Error(oid + ' unresolved ' + r.fail);
    spans.push({ oid, start: r.opUnitSpan.start, end: r.opUnitSpan.end });
  }
  return spans;
}
function oneSplice(source, chain, from, to) {
  const spans = spansOf(source, chain);
  const asc = [...spans].sort((a, b) => a.start - b.start);
  const buf = Buffer.from(source, 'utf8');
  const contents = asc.map((s) => buf.subarray(s.start, s.end));
  const order = asc.map((_, i) => i);
  const moved = order.splice(from, 1)[0];
  order.splice(to, 0, moved);
  const parts = [buf.subarray(0, asc[0].start)];
  asc.forEach((s, i) => {
    parts.push(contents[order[i]]);
    const nxt = asc[i + 1];
    parts.push(buf.subarray(s.end, nxt ? nxt.start : s.end));
  });
  parts.push(buf.subarray(asc[asc.length - 1].end));
  const out = Buffer.concat(parts).toString('utf8');
  SE.moduleContext(out);
  return out;
}
function naive(k) {
  let b = src;
  for (let i = 0; i !== k; i++) {
    b = SE.moveAdjacent(b, SCREEN, CHAIN[0], 'down');
  }
  return b;
}
function spelledKswap(k) {
  const ctx = SE.moduleContext(src);
  let b = src;
  for (let i = 0; i !== k; i++) {
    const r = SE.resolveJsxChildOp(ctx, SCREEN, CHAIN[0], 'move-down');
    if (!r.ok) throw new Error('step ' + i + ' refused ' + r.fail);
    const sp = r.opUnitSpan;
    const sib = r.siblingSpan;
    const pair = Math.min(sp.start, sib.start) === sp.start ? [sp, sib] : [sib, sp];
    b = SE.swapSpans(b, pair[0], pair[1]);
  }
  return b;
}
function tryIt(label, fn) {
  const p0 = globalThis.__PARSES;
  try {
    const v = fn();
    const np = globalThis.__PARSES - p0;
    console.log(label, 'OK parses=' + np, 'bytes=' + Buffer.byteLength(v));
    return v;
  } catch (e) {
    console.log(label, 'THREW', e.reason || e.message);
    return null;
  }
}
console.log('chain', CHAIN.join(','), 'bytes', Buffer.byteLength(src), 'strlen', src.length);
const K = CHAIN.length - 1;
const nv = tryIt('naive fold k=' + K, () => naive(K));
tryIt('r2 spelled k-swap k=1', () => spelledKswap(1));
tryIt('r2 spelled k-swap k=2', () => spelledKswap(2));
tryIt('r2 spelled k-swap k=' + K, () => spelledKswap(K));
const os = tryIt('ONE-SPLICE 0 to ' + K, () => oneSplice(src, CHAIN, 0, K));
console.log('  one-splice EQUALS naive fold byte-for-byte:', os === nv);
const c1 = tryIt('CONTROL no-move 0 to 0', () => oneSplice(src, CHAIN, 0, 0));
console.log('  CONTROL no-move identical to source:', c1 === src);
const c2 = tryIt('CONTROL wrong dest 0 to ' + (K - 1), () => oneSplice(src, CHAIN, 0, K - 1));
console.log('  CONTROL wrong-dest differs from naive:', c2 !== nv);
function naiveUp(oid, k) {
  let b = src;
  for (let i = 0; i !== k; i++) {
    b = SE.moveAdjacent(b, SCREEN, oid, 'up');
  }
  return b;
}
const nu = tryIt('naive UP fold member3 k=2', () => naiveUp(CHAIN[3], 2));
const ou = tryIt('ONE-SPLICE 3 to 1', () => oneSplice(src, CHAIN, 3, 1));
console.log('  interior up-move EQUALS naive:', ou === nu);
function med(fn, n) {
  const ts = [];
  for (let i = 0; i !== n; i++) {
    const t = process.hrtime.bigint();
    fn();
    ts.push(Number(process.hrtime.bigint() - t) / 1e6);
  }
  ts.sort((a, b) => a - b);
  return ts[Math.floor(n / 2)].toFixed(3);
}
console.log('TIMING median of 15');
console.log('  naive fold k=' + K + ':', med(() => naive(K), 15), 'ms');
console.log('  one-splice k=' + K + ' (incl verify reparse):', med(() => oneSplice(src, CHAIN, 0, K), 15), 'ms');
