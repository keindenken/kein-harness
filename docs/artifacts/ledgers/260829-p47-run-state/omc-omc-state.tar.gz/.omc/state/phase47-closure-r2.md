# phase-47 ralplan — CLOSURE AUDIT (round 2, PRIMED)

You are the CLOSURE AUDIT lane. You are **deliberately primed**: you are handed the required-changes list from round 1 and you judge, per item, whether the current text closes it. A fresh unprimed lane is reviewing the same text in parallel for what a new reader would find — that is not your job. **Yours is the one thing only a primed lane can do: see a finding RESTATED rather than FIXED.**

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout, and never touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read

1. **`.omc/state/phase47-revision-r1.md`** — the required-changes list you audit against (§1 M1–M20, §2 worth-considering, §3 the lead's rulings).
2. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the CURRENT text (revision 1, 492 lines).
3. **`.omc/state/phase47-context.md`** — the planning context, including the lead's own corrected §4(a).
4. `AGENTS.md` and `docs/prompt/worker-brief.md` — the project rules and the rules you work under.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch goes under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE** — printed text reaches nobody.

## The verdict vocabulary — use exactly these

For **every** item in §1 (M1–M20), every bullet in §2, and every ruling in §3:

- **CLOSED** — the text now says the right thing, for the right reason, and where a mechanism was owed one exists.
- **PARTIAL** — some of the item landed; name precisely which half did not.
- **NOT CLOSED** — the text still says the thing the finding falsified.
- ⚠ **REWORDED-ONLY** — the sentence changed and the REASON did not. **This is the verdict this lane exists to produce.** A finding whose conclusion survives while its justification moves is the phase-21 shape: five of seven falsified facts there were a right conclusion resting on a false reason, and the reason is what builds the gate. If a fix repairs the prose while the underlying argument, mechanism, or gate is unchanged, say REWORDED-ONLY and show both texts.

The revision brief's §4 names seven items as most exposed to REWORDED-ONLY — **M1, M3, M5, M12, M14, M15, M19**. Treat that as a hint about where to look hardest, not as the boundary: an item not on that list can be reworded-only too, and saying so is worth more than confirming the seven.

## Beyond per-item verdicts — four things to check that no item names

1. **The sweeps.** The brief's §4 says three fixes reach further than their own sections: §0's correction reaches P47-4, D47-3, R47-1 and the pre-mortem; M3's reaches P47-1, D47-2, §3.2(3) and §3.5; M18's reaches D47-1, D47-2, §2.1, §8.6 and S47-0. **Verify each sweep landed everywhere, by grepping the whole file rather than by reading the section that changed.** A claim a fix falsifies does not care whether it sits in the section that was edited — this repo has shipped a sweep list that was a proper subset four times running.
2. **New text is unreviewed text.** r1 grew by 132 lines and introduced at least two new DR-level decisions (DR47-10, DR47-11), retracted one constant, and re-derived DR47-6 to a different answer. **None of that has been reviewed by anyone.** Hold it to the same bar as r0: ≥2 options with a stated loser rationale, mechanisms not intentions, gates with constructible RED-whens.
3. **Whether a fix broke something that was fine.** A revision this size can falsify a claim that passed round 1. Check that the gates, principles and contracts round 1 accepted still hold against the new text.
4. **The planner's own flags.** Its report names four places it is least confident: DR47-10(iv)'s silent dirty-refusal; §4.2(4)'s tie-breaks being reasoned rather than observed; M15's "↑/↓ buttons become a second producer" and its blast radius into `StructureSection`; and that nothing is driven live. **A lane that only audits the list misses what the author already suspects.** Judge these too.

⚠ **One item needs your explicit adjudication.** M14 told the planner to add option (d) — `readLayoutContext(parentEl).directionToken` — and re-derive. It did, and **(d) LOSES**; DR47-6 instead collapsed to a single `getComputedStyle` call answering flow, axis and reversal together, on the ground that M3 makes a live `display` read mandatory anyway. The planner flags this as the item most worth a second look because the lead's phrasing leaned toward (d). **Rule on it: is (d)'s rejection honest, and is the collapse sound, or did a mandatory read get used to justify a wider one?**

## ⚠ A NEW OWNER RULING LANDED AFTER THIS TEXT WAS WRITTEN — read `.omc/state/phase47-owner-ruling-drag-readout.md`

DR47-8 is **DECIDED: reading (b)** — the readout goes on the reorder drag and shows the drop position; the resize W×H readout is not built in this phase and routes back to B-Q4's backlog row. The owner also does **not remember** making the v3 CLOSE ruling the plan quotes as its authority, which makes today's input the strong authority and that sentence the weak one.

**The current text does not reflect any of this, and its absence is NOT a finding — do not report it.** What IS your finding: **every sentence this ruling falsifies.** Sweep for the claims whose CAUSE it moves, not only the ones that name DR47-8 — the two-readings framing, "both are cheap and neither blocks the other", the shared node/style argument that existed to keep both open, S47-4's conditional rider, §7's U-item list and count, §8.1, and any ADR consequence. Report them as a list the revision must carry.

## Report format

A table of every item with its verdict, then the detail for everything that is not CLOSED. For each: quote the r0 text, quote the r1 text, and say what is still owed. Cite by anchor or by file + function, never by line number.

End with an explicit verdict on the text as a whole: **APPROVE** (it clears the bar as it now stands) or **REVISE** (with the must-fix list). A conditional approve is a REVISE.
