# phase-47 ralplan — CLOSURE AUDIT (round 3, PRIMED)

You are the CLOSURE AUDIT lane. You are **deliberately primed**: you are handed the required-changes list from round 2 and you judge, per item, whether the current text closes it. Two other lanes work the same text in parallel — one fresh and unprimed, one measuring live in a browser. Neither of those is your job. **Yours is the one thing only a primed lane can do: see a finding RESTATED rather than FIXED.**

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout, and never touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read

1. **`.omc/state/phase47-revision-r2.md`** — the required-changes list you audit against: §A the owner ruling, §B (B1–B5, the critical items), §C (C1–C6), §D worth-considering, §E the standing probe-citation requirement.
2. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the CURRENT text (revision 2, 525 lines).
3. **`.omc/state/phase47-owner-ruling-drag-readout.md`** — the owner ruling §A applies. Unlike last round, it is now **supposed to be reflected in the text**; judging whether it landed in full is part of your audit.
4. **`.omc/state/phase47-context.md`** — the planning context, including the lead's own corrected §4(a).
5. `AGENTS.md` and `docs/prompt/worker-brief.md`.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch goes under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE** — printed text reaches nobody.

## The verdict vocabulary — use exactly these

For **every** item in §A, §B, §C, every bullet in §D, and §E:

- **CLOSED** — the text now says the right thing, for the right reason, and where a mechanism was owed one exists.
- **PARTIAL** — some of the item landed; name precisely which half did not.
- **NOT CLOSED** — the text still says the thing the finding falsified.
- ⚠ **REWORDED-ONLY** — the sentence changed and the REASON did not. **This is the verdict this lane exists to produce.** A finding whose conclusion survives while its justification moves is the shape that has cost this project most: a right conclusion resting on a false reason, and the reason is what builds the gate. If a fix repairs the prose while the underlying argument, mechanism, or gate is unchanged, say REWORDED-ONLY and show both texts.

⚠ **Round 2's audit found ZERO reworded-only fixes.** That is the bar this revision has to match, and it also means you should not assume you will find one — a clean negative is a real result. What it does mean is that the author has been fixing reasons rather than sentences, so the places to look hardest are the ones where the *conclusion was already right and only the justification moved*: B1 (the CSS scope narrowing, where the choice stands and the scope changed), B3 (the composer promoted from fallback to design), B5 (the two-reader predicate), C3 (`focusStageIfOrphaned`'s siting), C5 (a relabel from VERIFIED to proxy).

## Beyond per-item verdicts — five checks no item names

1. **The sweeps.** §A's ruling was to reach thirteen enumerated sites *plus everything whose CAUSE it moves*. B2's three-way split reaches §4.1, §4.5, G47-11b and every population sentence that said 130. B4's anchor receipt reaches DR47-4, §4.2, §4.3, the panel's standing in §2, G47-10 and the ADR. **Verify each by grepping the whole file, never by reading the section that changed.** This repo shipped a sweep list that was a proper subset four times running; round 2 was the first clean one. Check whether that held.
2. **New text is unreviewed text.** r2 grew by 33 lines but rewrote far more than that, and it introduced new keys (`layout-not-modelled`, `sibling-not-editable`), new gates (G47-5d's three legs, G47-11c, G47-12(a) restated, G47-13 leg (ii), G47-18b, G47-20), a **pre-committed numeric threshold** (R47-4's <19 ms), and a reversal back to z = 44. **None of it has been read by anyone.** Hold it to the full bar: ≥2 options with a stated loser rationale, mechanisms not intentions, gates with constructible RED-whens and a subject the corpus can supply.
3. **Whether a fix broke something that was fine.** Two revisions of this size can falsify a claim an earlier round accepted. Round 2's own closure audit closed twenty round-1 items; check that they are still closed.
4. **The threshold in R47-4.** The plan now pre-commits a `<19 ms` composer budget derived from two measured endpoints, with **no composer number measured**. A pre-committed threshold that can fail is good practice; a threshold picked so that it will not fail is not. Judge which this is, and whether the plan says what happens if the composer lands above it.
5. **The planner's own flags.** Its report names four: R47-4's threshold being a judgement; §4.2(2)'s direct-child rule having an unmeasured population; R47-11's refusal population being uncounted; and nothing driven live. **Three of those four are being measured right now by the live lane** — so for those, judge whether the plan states its uncertainty honestly and names what would settle it, not whether it knows the answer.

## Report format

A table of every item with its verdict, then the detail for everything that is not CLOSED. For each: quote the r1 text, quote the r2 text, and say what is still owed. Cite by anchor or by file + function, never by line number.

End with an explicit verdict on the text as a whole: **APPROVE** (it clears the bar as it now stands) or **REVISE** (with the must-fix list). A conditional approve is a REVISE.

⚠ **Say plainly if you think the text is close enough that further text rounds are worth less than execution.** The lead is weighing exactly that, and a primed lane that has watched three revisions is the best-placed judge of whether the findings are still getting smaller and different in kind.
