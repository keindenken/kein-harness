# phase-47 ralplan — FOUR SENTENCES, THEN DONE

The final check drove the one clause nobody had driven and **falsified it**. Four sentences close this; the verifier's own words are *"four sentences away, not a round away."* **This is the last edit of the planning round.**

⚠ **The sharpest finding first, because it is the shape this phase keeps producing: the fix for codex's blocker 2 RE-CREATED codex's blocker 2, on a larger population than the original.**

---

## 1. The diagnostic carve-out tests grammatical MOOD, not verifiability — and it is falsified on shipped subjects

**The carve-out:** *a diagnostic second clause offers a possible **cause** and promises no **outcome**, so there is nothing for the refusal to be wrong about.*

**Falsified three ways, all driven:**

**(a) The reason code is shared across causes the refusal cannot tell apart.** `unsupported-sibling` has two emission sites in `packages/descvi/src/extractor/structural-edit.ts`; all 189 corpus refusals come from `refuse('unsupported-sibling', 'the adjacent sibling is not an oid-bearing admissible op-unit');`. Driven through the classifier, that one site fires identically on a JSX comment between siblings (clause **true**), **a visible oid-less sibling element with nothing between them** (clause **false**), and a JSX expression sibling (false). The middle case is the repo's own shipped test — `packages/descvi/test/extractor/structural-edit.test.ts#refuses a swap partner that bears no oid`.

**(b) Measured on the population that actually paints the sentence.** Of the 96 singletons whose `move-up` refuses `unsupported-sibling`: **31 comment-caused, ≥26 with a visible unmarked element directly above and nothing between them**, 38 first-inside a `{cond && (` wrapper the detector cannot classify (so 26 is a **floor**), 1 expression. Verified by eye at `src/app/lab/tests/spacing-nesting/page.tsx` (`snpbed`, preceded by a visible Korean `<h2>` bearing no oid) and `src/app/lab/tests/align-wrap/page.tsx` (`awf1cn`). **On ≥26 shipped default-state subjects the user is told something invisible may sit between two elements, and what is there is a visible heading with nothing between them.**

**(c) The rule is not decidable by a later author, and the counterexample is constructive.** Restate the blocked clause in the indicative: *"This parent may not be an auto-layout container."* It names a cause, promises no outcome, **passes the rule as written**, and carries the identical necessary-not-sufficient falsehood codex blocked. **A rule that admits a re-mooded copy of the sentence it was written to exclude is not the rule the section thinks it wrote.**

⚠ **What is actually load-bearing is the hedge, and the rule never mentions it.** The two rows survive because *"may"* makes them unfalsifiable, not because "diagnostic" is a safe category.

**Fix:** replace the carve-out with the verifiability test — **a second clause may name a cause only if the refusal can establish it at paint time; otherwise it names the class, not one member of it.** ⚠ **The client cannot establish it:** the artifact publishes reason **codes only**, so the client holds one bit and cannot separate comment from oid-less-sibling from expression. **Reword both clauses off "invisible"**, which is false for the ≥26.

## 2. The blocker-2 fix re-created blocker 2 — the panel invariant is false on ≥87 shipped subjects

*"The panel's ↑ / ↓ still work here"* holds **only if E1 gates E2**. §4.1(a) lists E1/E2/E3 and **never states an evaluation order or first-failure-wins**; §4.5 leans on the order twice (*"which E1 already guarantees"*, *"sub-floor implies E1 already passed"*) without ever making it a rule, and *"E1, E2 and E3 are known at arm time"* if anything reads as parallel.

Measured: **192 singletons** fail E1, so `canMoveUp` and `canMoveDown` are both false and **both panel buttons are disabled.** Of those, **≥87 also have an authored non-flex parent** (E2 fails too); 93 more have an oid-less parent and are statically unresolvable. **On any of them an E2-first implementation paints "the panel's ↑ / ↓ still work here" where neither works.**

`snpbed` is the convergence subject and **both r6-touched clauses are false on it**: `canMoveUp: false, canMoveDown: false`, reasons `{move-up: unsupported-sibling, move-down: no-adjacent-sibling}`, a visible `<h2>` above it with nothing between, inside a non-flex `<section className="mb-8">`. **Which sentence it paints is undetermined by the plan**, and G47-11b does not pin it — its leg-2 subject is "a 108-class subject", and whether that gate goes RED depends on a subject property nobody has named.

**Fix — one sentence:** evaluation is **E1 → E2 → E3, first failure paints**, stated at §4.1(a) as a rule rather than left to be inferred from two places that assume it. Then check G47-11b's leg-2 subject names a property that decides the row.

## 3. `destinationIndex`'s index space is unpinned, and the two readings differ on half of G47-10b's new legs

Reproducing the enumeration exactly (224 / 42 / 112 / 182 — **all four of codex's figures reproduce**) pins the intended semantics: `destinationIndex` is **the subject's final index after remove-then-insert.** No other definition yields 42. §4.3(3) says only *"computed before any splice"* and never names the space. Under the other natural reading — the anchor's pre-removal index adjusted by side — **21 of the 42 non-self no-ops are missed, exactly the whole `leading(next)` half**, which is one of the two legs G47-10b adds.

**Fix:** name it — *"the subject's index in the resulting order."* G47-10b names both legs so the gate is a real backstop; this costs an executor a round-trip rather than shipping a defect, but it is a contract an executor would have to guess at.

**Secondary, worth one clause:** if `direction` is `sign(destinationIndex − sourceIndex)`, a zero-displacement receipt has no sign, so the direction-disagreement 400 **already subsumes** the zero-displacement 400 — the "two 400s read off it" are one. Nothing breaks (G47-10b's mutation removes both together), but the plan presents them as independent.

## 4. The zero-displacement 400 has no carrier

S47-2 (§5) and §12's sidecar layer both enumerate *"its self-anchor 400"* and *"the direction-disagreement 400"* and stop. The new 400 exists only in §4.3 and §6. **By the plan's own standard at §12** — *"a U-item that exists only in §8 is a deliverable with no carrier"* — this is the same defect. Add it to both.

---

## 5. Four mechanical corrections

- **Two live hits of codex's blocked phrase survive**, both citing the now-scoped §4.2(3) while stating the absolute themselves: DR47-6's *"measured all three exclusions at ZERO SUBJECTS IN THIS CORPUS"* and §2 exclusion 9's *"Zero subjects in this corpus … nothing is lost today"* — the second repeating codex's blocked *"nothing is lost today"* verbatim. ⚠ **Sixth consecutive round in which a sweep list is a proper subset of what the by-cause grep returns.** Bind both like the other five, and let the sweep-discipline note carry the sixth instance.
- **A count contradiction eight lines apart** in §4.5: *"Two of these name the panel as the working alternative"* against *"Four now carry the panel invariant"* — and the first sentence's justification is *about* the flow-axis row r6 changed. C47-5's own rule is that the count sites agree.
- **The sweep partition does not cover its table:** 4 + 7 + 2 = 13 against **14** data rows. The missing row is `no-reorderable-sibling`, the one client-only row with no second clause — benign in outcome (it correctly carries no panel clause, since E1-failed is exactly when the panel does *not* work), but **the sweep whose purpose was exhaustiveness is not exhaustive.**
- **§5's unreviewed-surface enumeration omits the new wording rule.** The diagnostic-vs-promissory distinction is **contract governing every future refusal row**, minted last edit and driven by nobody. It is the item that most belongs in that list and the only one missing — and after item 1 replaces it, the replacement is the thing that has now been driven, which is worth saying.

---

## 6. What the check confirmed, so it is not re-opened

- **All four of codex's receipt figures reproduce exactly** (224 / 42 / 112 / 182), by an independent enumeration.
- §3.1's corpus figures reproduce a sixth time — 854 refusals, 541/189/52/48/18/6, 192 singletons — driven through `classifyStructuralEligibility` over all 24 screens including `::` sub-screens.
- **Both status-section corrections verify.** codex's r0/r1 findings (M14, M15, B1, C1) each map to closed plan text, and *"r6 is the only text it has not read"* is true in the sense that matters, since r5 is cumulative.
- The base-rate sentence is in its stronger form, the two counts are labelled, and the only two occurrences of "unanim" both negate it.
- `appliedK` (item 4 of the last round) is **CLOSED** — named, with its reason and both carriers.
