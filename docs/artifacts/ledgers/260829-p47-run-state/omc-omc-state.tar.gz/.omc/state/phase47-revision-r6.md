# phase-47 ralplan — CODEX'S THREE BLOCKERS + ONE RIDER

The vendor-independent gate returned **REVISE**. Three blockers, ranked by codex, all low-effort, **none reopening a design ruling**. It confirmed the anchor receipt's direction and distance arithmetic holds, and that `k` is recoverable from the result in all 182 non-zero receipts it enumerated.

⚠ **This is the last edit. codex has no second call**, so after this the plan's status line must record exactly which text each lane read — see §5.

---

## 1. BLOCKER — the anchor receipt has a non-self no-op hole

**Claim:** *"`anchorOid === the subject's own oid` is a 400"* and *"a direction disagreeing with the wire verb is a 400."*

**Actually true:** a receipt that is not self-anchored can still name the subject's current position. In `[A,B,C]` with subject `B`, both `trailing(A)` and `leading(C)` give **displacement 0**, and neither `move-up` nor `move-down` is valid for it.

**How established — exhaustive, with a control:** every subject × anchor × side combination over every chain of length 2–7. Of **224 non-self receipts, 42 are non-self no-ops.** A planted positive control (a wrong pre-removal anchor-index formula) fired **112 times**. On the remaining **182** non-no-op receipts, the pre-splice direction verdict and the `k` recovered from the resulting order **agreed in every case**.

**The root cause is worth stating in the text:** the validation forbids an input *shape* (self-anchor) rather than the normalized destination's *meaning* (zero displacement). That is the same shape as §4.2(6)'s client-side no-op detection — the client has the check and the server does not.

**LEAD RULING — 400, not a 200 no-op.** codex offers both; 400 is right and the reason is this endpoint's own discipline: it 400s on contradictions rather than accepting-and-ignoring them (`parseExpectForOp`'s REQUIRED-or-FORBIDDEN rule, both directions). A 200 no-op would blur the verb contract and the one-request/one-undo semantics that DR47-4 exists to protect.

**Fix:** §4.3 states `destinationIndex === sourceIndex ⇒ 400`. `resolveMoveDestination` produces a normalized `{sourceIndex, destinationIndex, direction, appliedK}` **before the splice**, and rejects both zero displacement and verb-sign disagreement from it. **G47-10b gains the two adjacent-anchor no-op forms** (`trailing(prev)` and `leading(next)`) as named mutations.

## 2. BLOCKER — `parent-has-no-flow-axis` promises an alternative the refusal cannot verify

**Claim:** *"부모를 auto-layout(flex)으로 바꾸면 가능합니다 / make the parent an auto-layout (flex) container first."*

**Actually true:** flex is **necessary, not sufficient.** The same parent with `rtl`, a vertical writing mode, or unequal child `order` still refuses at `layout-not-modelled` after being made flex.

**How established:** in headless Chromium, a `display:block; direction:rtl` parent was changed to `display:flex` **only**, and the plan's admissibility conjunction stayed **false**; the same probe's LTR / horizontal / equal-order positive control returned **true**.

⚠ **This is the same class the last edit just fixed on the NEW key — and this row has carried it for four rounds.** The pre-codex lane asked whether any row promises an unverifiable alternative; codex answered yes, on a row nobody had re-read. **Say that in §4.5's wording rules**: the gap the last edit named ("no gate watches the truth of a second clause") had a second live instance at the moment it was written.

**Fix — codex's exact replacement, which is the class invariant E1 already guarantees:**

> `부모에 끌기 순서를 정할 흐름 축이 없습니다. 패널의 ↑ / ↓ 로는 바꿀 수 있습니다.`
> `This parent has no flow axis for drag-to-reorder. The panel's ↑ / ↓ still work here.`

**And sweep by cause, not by row:** any other refusal sentence whose second clause names a fix rather than the panel invariant is the same defect. Check every row, including ones that predate this round.

## 3. BLOCKER — scoped zeros become absolute corpus claims downstream

**Claim:** R47-11's *"MEASURED AT ZERO in this corpus … nothing is lost today"* and the ADR's *"all with zero subjects in this corpus."*

**Actually true:** the **status block is correct** — it says no sweep has enumerated the state space. **§4.2, R47-11, S47-0 and Consequences then revert to unscoped absolutes.** The qualification landed in one place and did not propagate.

**codex's own sweep, stated with its scope:** default state reproduces **112/235 chains zero-render**, 123 non-zero, with a positive control. Over the 10 routes carrying a `conditional-container`, it drove default plus **24 single-button states and actually clicked 23**. It re-detected **only** the plan's own `omy3i9,0cyt4v,z76fvu,d29ipo` — **an independent second confirmation of that chain**, and codex says plainly it is *"a re-confirmation within the scope investigated, not a proof of absence over unreached compound states."*

**Fix:** by-cause grep for `zero`, `0/930`, `zero subjects in this corpus`, and bind every one to its probe's scope — e.g. *"zero among the 930 elements observed by round 3"*, *"no additional subject in the default and single-button states driven by the final vendor sweep."* ⚠ **R47-11's unmeasured range must name the CURRENT corpus's unobserved states, not only future corpus growth** — that is the half it omits, and it is the half that is true today.

## 4. RIDER — name the applied `k`'s home in the result type

codex confirmed `k` is recoverable from the resulting order on all 182 non-no-op receipts, so the calculation is sound. What the plan does not say is **what "the RESULT" is as a type.** Put `appliedK` explicitly on the normalized object §1 mints (or on the one-splice composer's result), and fix the 200 payload and the sidecar log suffix to read **that field only**. This makes G47-20's gate concrete instead of leaving an executor to invent the seam.

---

## 5. THE STATUS LINE — record what actually happened, because it is not unanimity

The planning contract wants unanimous Claude + vendor approval **of the text as it now stands**. That is no longer reachable: codex had one call and it is spent. **Do not write anything that reads as unanimous.**

Write the truth, and write it as a first-class part of the plan rather than a footnote:

- Five review rounds ran: three parallel lanes at rounds 1–3, a delta re-check, a pre-codex check, and the vendor gate.
- **codex reviewed the 555-line text and returned REVISE with three blockers, ranked.** All three are corrected here.
- **No vendor-independent lane has read the corrected text.** One Claude lane will verify these four items and nothing else.
- The gap is bounded and should be stated as such: codex's three findings were a missing server arm, one refusal sentence, and a scope-qualification sweep — **none of them touching a design ruling**, and codex explicitly confirmed the anchor receipt's arithmetic and `k` recovery.

**And keep the base-rate sentence honest.** It now reads four-for-four on unreviewed additions carrying a defect. codex found a fifth instance in prose that had stood four rounds (§2 above) — so the rule is not merely about *new* additions but about *anything nobody re-drove*, which is the stronger and more useful form.
