# phase-47 ralplan — FINAL CHECK

**Narrowest scope of the whole round: four applied fixes, one newly-minted distinction, and one status section.** Everything else in this plan is closed by five review rounds and a vendor gate. Do not re-open any of it, do not re-derive numbers, do not re-litigate rulings. If you write a finding outside the list below, say explicitly that you know it is outside scope and why it could not wait.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Never `cd` to the parent checkout; never touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read

1. **`.omc/state/phase47-revision-r6.md`** — the four items required.
2. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the current text (570 lines).
3. `AGENTS.md`, `docs/prompt/worker-brief.md`.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE.**

---

## §1 — The one thing minted in this edit and driven by nobody

To let two refusal rows pass the rule written one edit earlier, the author minted a **diagnostic-vs-promissory distinction**:

> a *diagnostic* second clause offers a possible **cause** and promises no **outcome**, so there is nothing for the refusal to be wrong about; *"make the parent flex"* failed precisely because it promised an outcome.

Two rows pass on it — `unsupported-sibling` and `sibling-not-editable`. Four rows carry the panel invariant; seven have no second clause.

**The author flags this as its own top uncertainty, and the reason is the phase's signature: it is a reasoned clause nobody drove.** Every defect worth having in six rounds was found by running something, and codex's last catch was a promissory clause that had stood four rounds and been read a dozen times.

**Test the distinction, not the rows' current wording:**
- Read the two rows' actual Korean and English. **Does a reader experience a diagnostic clause as a promise?** A sentence that names a cause implies a fix; if the named cause is not the whole cause, the implication is false in the same way `"make the parent flex"` was.
- Is the distinction **decidable by a later author** writing a fifth row, or does it require the judgement of the person who minted it? A rule that only its author can apply is not a rule.
- **Can the refusal verify the cause it names at paint time?** That is the actual test the earlier rule imposes. If a diagnostic clause names a cause the client has not established, it is promissory in the only sense that matters.

## §2 — The four fixes, per item: CLOSED / PARTIAL / NOT CLOSED / REWORDED-ONLY

1. **The non-self no-op 400.** `resolveMoveDestination` returns `{sourceIndex, destinationIndex, direction, appliedK}` **pre-splice**; both 400s read off it (zero displacement, verb-sign disagreement). G47-10b gains the two non-self forms (`trailing(prev)`, `leading(next)`) with the 42/224 and 112-control figures. **Check the two 400s are derivable from the normalized object *before* any splice**, and that G47-10b's mutations can actually go RED.
2. **`parent-has-no-flow-axis`'s replacement wording**, plus the necessary-not-sufficient argument and the `display:block; direction:rtl → display:flex` probe with its LTR control.
3. **Five scoped-zero sites bound to their probes** (§4.2(3), R47-11, S47-0 ×2, ADR Consequences), with R47-11 naming **both** halves of its unmeasured range — future corpus growth **and** the current corpus's unobserved states, the latter carrying 112/235.
4. **`appliedK` on the normalized object**, with the 200 payload and the log suffix reading that field and no other.

## §3 — The status section, which must not overstate in either direction

The author corrected two things in the lead's own framing and both corrections look right — **verify them, because they are the record this phase leaves behind.**

- **codex reviewed r0, r1 and r5, not only the final text.** It was one of the three parallel lanes at rounds 1 and 2, and several of its findings are closed in the plan (M14, M15, B1, C1). The status line says r6 is the only text it has not read. **Check that against the plan's own round record.**
- **"What is unreviewed is only prose" was wrong and is now narrower.** Fixing blockers 1 and 3 **adds contract text** — a second 400 arm, a new result type, a replaced user-facing string. The line now names the unreviewed surface as exactly those plus this revision's scope sweep. **Check that enumeration is complete** — if the sweep touched anything else that is contract rather than prose, it belongs in that list.

Also check: the base-rate sentence is in its **stronger** form (anything nobody re-drove, not only new additions), the two different counts are labelled so neither reads as an error, and **nothing anywhere reads as unanimity**, because it is not.

## §4 — Two checks

1. **Did these four fixes break a neighbour?** A 15-line growth after six rounds can falsify something verified clean.
2. **Sweep by cause.** The refusal-clause sweep was done by cause and its result recorded (4 invariant / 7 none / 2 diagnostic). **Verify that partition against the actual table** rather than trusting the count — sweep lists in this repo were proper subsets in five of seven rounds.

## §5 — Verdict

**APPROVE** or **REVISE**, explicitly.

⚠ And answer this directly: **is the plan ready to hand to execution?** Not "is it perfect" — six rounds have established it will not be. The question is whether an executor can build S47-0 through S47-6 from this text without having to guess at a contract, and whether every gate it names can go RED. If something would make an executor stop and ask, name it; if nothing would, say so plainly.
