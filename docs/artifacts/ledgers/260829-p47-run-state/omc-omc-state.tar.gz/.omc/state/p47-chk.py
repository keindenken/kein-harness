import sys
pairs = [l.rstrip('\n') for l in open(sys.argv[1], encoding='utf8') if l.strip()]
for p in pairs:
    f, _, a = p.partition('#')
    try:
        s = open(f, encoding='utf8').read()
    except Exception as e:
        print('ERR ', f, e)
        continue
    n = s.count(a)
    print(('OK  ' if n == 1 else 'BAD%d' % n), f + '#' + a[:75])
