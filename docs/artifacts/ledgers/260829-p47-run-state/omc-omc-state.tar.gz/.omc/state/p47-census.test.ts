// EPHEMERAL probe (phase-47 planning). Not a gate. Delete after reading.
import { describe, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { buildEditMap } from '../../packages/descvi/src/extractor/edit-map.ts';

function walkPages(dir: string, out: string[] = []): string[] {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkPages(p, out);
    else if (e.name === 'page.tsx') out.push(p);
  }
  return out;
}

describe('p47 census', () => {
  it('counts sibling runs', () => {
    const repoRoot = path.resolve(__dirname, '../..');
    const appRoot = path.join(repoRoot, 'src', 'app');
    const inputs = walkPages(appRoot).map((pagePath) => {
      const dir = path.dirname(pagePath);
      const specPath = path.join(dir, 'spec.ts');
      return {
        id: path.relative(appRoot, dir).split(path.sep).join('/'),
        pageSource: fs.readFileSync(pagePath, 'utf8'),
        specSource: fs.existsSync(specPath) ? fs.readFileSync(specPath, 'utf8') : '',
        relPagePath: path.relative(repoRoot, pagePath).split(path.sep).join('/'),
      };
    }).filter((i) => i.specSource !== '');
    const map = buildEditMap(inputs as never);
    const oidsByScreen = (map as unknown as { oids: Record<string, Record<string, { structure?: { parentOid: string | null; prevOid: string | null; nextOid: string | null; canMoveUp: boolean; canMoveDown: boolean } }>> }).oids;
    let total = 0, movable = 0;
    const lens: number[] = [];
    for (const [, entries] of Object.entries(oidsByScreen)) {
      const byOid = new Map<string, { prev: string | null; next: string | null }>();
      for (const [oid, e] of Object.entries(entries)) {
        total++;
        const s = e.structure;
        if (!s) continue;
        if (s.canMoveUp || s.canMoveDown) movable++;
        byOid.set(oid, { prev: s.prevOid, next: s.nextOid });
      }
      for (const [oid, l] of byOid) {
        if (l.prev !== null) continue;
        let n = 1;
        let cur = l.next;
        const seen = new Set([oid]);
        while (cur !== null && byOid.has(cur) && !seen.has(cur)) { seen.add(cur); n++; cur = byOid.get(cur)!.next; }
        lens.push(n);
      }
    }
    const hist = new Map<number, number>();
    for (const n of lens) hist.set(n, (hist.get(n) ?? 0) + 1);
    console.log('P47CENSUS', JSON.stringify({
      screens: Object.keys(oidsByScreen).length,
      totalOids: total,
      movable,
      runs: lens.length,
      runsGE2: lens.filter((n) => n >= 2).length,
      runsGE3: lens.filter((n) => n >= 3).length,
      runsGE4: lens.filter((n) => n >= 4).length,
      maxRun: lens.length ? Math.max(...lens) : 0,
      hist: [...hist.entries()].sort((a, b) => a[0] - b[0]),
    }));
  });
});
