# phase-47 ralplan — DELTA RE-CHECK (round 4, final Claude gate)

You are the **last Claude lane before the plan goes to codex for its single remaining vendor-independent call.** Three review rounds have run; the design layer has stopped moving; round 3's closure audit recommended stopping the text rounds after one targeted edit. This is that check.

**Your scope is the deltas, not the plan.** Do not re-open decisions, do not re-litigate closed items, do not re-derive the census (it has been reproduced independently five times). If you find yourself writing a finding about something not in §1 or §2 below, ask whether it is genuinely new — and if it is, say so loudly, because everything else has had three passes.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout; never touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read

1. **`.omc/state/phase47-revision-r3.md`** — the required-changes list this revision answers.
2. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the current text (530 lines).
3. `AGENTS.md`, `docs/prompt/worker-brief.md`.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE.**

---

## §1 — THE ONE THING THAT MATTERS MOST: a new design ruling arrived at the last revision with no review pass

The revision introduced a ruling **nobody asked for and nobody has read**. The planner flags it as its own top uncertainty. Judge it as new text held to the full bar, not as a delta.

**The ruling:** a chain member that resolves to **zero** DOM elements is **DROPPED from the drop table**, not refused. Its stated justification is that the anchor receipt never computes an index, so dropping costs nothing — and its stated dividend is that all 15 previously-affected chains now admit in every rendered instance, dissolving the per-instance inconsistency the live lane measured (6 chains refused always, 9 refused only in some instances). It carries one consequence the planner ruled with it: **`N` in the `n / N` readout becomes the RESOLVED member count, not the source chain length.**

**Test it, hard, in at least these directions:**

- **Does the anchor stay meaningful across a dropped member?** The anchor is a SOURCE coordinate resolved server-side against the live source chain, which still contains the unrendered member. So the user aims at a rendered sibling and the element may land on the far side of something invisible. Is that what the plan says happens? Is it what should happen? Is it *stated*?
- **What now triggers `chain-member-not-locatable` at all?** The live lane measured `n>1` at **0 of 636** readings under the parent scope, and `n=0` is now dropped rather than refused. If both arms are unreachable from the corpus, the clause is purely defensive — which is acceptable and honest, but the plan must say it plainly rather than implying a live trigger.
- **Does dropping interact with the arming predicate?** If a chain has 5 source members and 2 render, the subject may now sit in an effective run of 2. Check whether `canMoveUp || canMoveDown` (an artifact-derived flag over the SOURCE chain) can now disagree with what the drop table can offer — i.e. can the gesture arm on a subject whose resolved run has length 1?
- **The `N` consequence.** Is a readout whose denominator is the rendered count the right answer, or does it now lie about the element's position in the file it is about to edit? The planner argues showing a total the user cannot count would be the readout's own KI-17. Test the counter-argument.
- **Does the ruling survive the six shipped conditional-sibling chains?** The live lane named them: `sandbox/resize-repeat-list` (`smndaa`/`smndbb`/`smndcc`, three `{queueState === 'x' && <p/>}` blocks in a 5-member chain), `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`. **Drive one.**

## §2 — The deltas to verify closed

Per item: **CLOSED / PARTIAL / NOT CLOSED / REWORDED-ONLY**. The last verdict is the one worth most — two rounds running have produced zero of them, so a clean negative is a real result and a positive one is a real catch.

**From §0 of the brief (the live results):**
- The status blockquote no longer claims nothing was driven; it names browser, version, hosts, controls, **the lane's own self-catch (wrap detector 37 → 3)**, and precisely what stays unmeasured.
- §4.1(e) states this phase's own stage-host capture measurement with the paired no-capture control and both limitations (CDP is not an OS pointer hand-off; Chromium only).
- §3.1 carries the live 91/144 (61.3 %) as its ONE home with the proxy beside it; D47-2 points rather than restates.
- §4.2(2)'s `.map()` attribution withdrawn; the `wflbl3` grandchild claim deleted; the real cause named.
- Every zero-population clause keeps its clause and loses its claim to a shipped subject, on `unequal-indent`'s rider model — G47-5c, G47-5d, G47-11c, the `reversed` branch. **§6 reportedly gained a SUBJECT column: check that every row has one and that no row claims a subject the corpus does not hold.**

**From §1–§3 of the brief:**
- **M1** — the one-splice composer replaces the k-swap fold; `cutSpans`'s docblock named as the lesson reached past; the span-rearrangement primitive is an S47-2 obligation. ⚠ **Do not take this on faith: the previous two revisions each specified a composer that did not run, and both were caught by building it. Build this one.**
- **M2** — R47-4's threshold re-derived to 12 ms on a NAMED subject and chain. Is 12 both meetable and falsifiable against the measured ~7.5 ms floor?
- **M3** — G47-20 pins 2 vs 2k parses with an instrumented counter S47-2 ships. Does the counter exist as a named deliverable, and can the gate observe it?
- **M4** — the instance hint's explicit `visibility: visible`.
- **M7** — both ontology preamble sentences rewritten (a `mousemove` listener ships at HEAD in `use-canvas-hover-ring.ts`).
- **M8** — R47-3 now states the mechanism (`adjacentOpUnit` does not check indent equality; it is a move-only precondition).
- **M9's list** — 165 vs 189; three-conditions/five-keys; the qualified component-instance row; G47-14's wrapper module; the guard teardown; G47-12(a)'s named control; the clamped readout; S47-0's fixture list split into shipped vs owed; the C47-6a/b swap note; the one-home fixes; the two unruled wire cases (`anchorOid === subject` → 400; `parentOid: null` chains); the readout on a refusing arm.
- **M10** — the design-view click constraint recorded where S47-6 reads it, with the known-issue question routed to the lead.

## §3 — Three checks no item names

1. **Sweep by cause.** M1 reaches §4.3, R47-4, G47-20, S47-2, the ADR. The live results reach §3.1, D47-2, §4.1(e), §4.2(2)–(5), §8's UNVERIFIED list, R47-11, the status block. **The new drop-on-absence ruling reaches further than its own clause — find everywhere.** Grep the whole file, never the changed section. Round 3 completed both its sweeps; this would make three.
2. **Pre-mortem 3 was rewritten** around the "gate green on its own defect" class, which this plan has produced **four times in its own text**. Judge whether the rewrite is honest about that count and whether the countermeasure is a mechanism or a resolution.
3. **Is anything now over-claimed in the other direction?** Three revisions of tightening can produce a plan that hedges what it actually knows. The live lane CONFIRMED eight things; check they are stated with the confidence they earned, not less.

## §4 — Your verdict

**APPROVE** or **REVISE**, explicitly. A conditional approve is a REVISE.

⚠ **Say plainly whether this text is ready to be the one codex reads.** That call has exactly one shot left — there is no second vendor-independent pass after it — so if you would want one more Claude edit before spending it, say so and name what.
