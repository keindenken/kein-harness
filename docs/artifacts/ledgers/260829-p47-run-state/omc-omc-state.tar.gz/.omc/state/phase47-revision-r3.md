# phase-47 ralplan — FINAL TARGETED REVISION (after review round 3)

⚠ **THIS IS THE LAST FULL REVISION.** After it, one lane re-checks only the deltas below, then codex gets its single remaining call on the final text. **Do not re-open anything not named here.** Round 3 closed every round-2 item, found zero reworded-only fixes for the second round running, and completed both of its sweeps — the design layer has stopped moving. What is left is mechanism, gate subjects, and honest labels.

Three lanes ran: a **primed closure audit**, a **fresh unprimed reviewer**, and a **live probe lane** that drove a real browser. The first two converged on four defects without seeing each other. The third measured what all three revisions had been unable to.

---

## §0 — What the live lane settles, and it changes more than it breaks

**Browser: Chromium 148.0.7778.96, headless and headed. Hosts: `descvi:dev` :3001 + sidecar :7331, and the plain view :3000.** Both were free; nothing was killed; both stopped. Tree clean, `.descvi/screens.json` byte-identical.

Every number below has a planted positive control named in the lane's report. **Where a control caught the lane's own instrument, that is recorded too** — its first wrap detector counted distinct cross-axis offsets and reported 37 wrapped parents; an `items-center` row with unequal-height children produces that without wrapping. The corrected count is 3. **Take the corrected numbers and cite the control.**

### CONFIRMED — and two of these upgrade a label the plan has carried as UNVERIFIED for three revisions

1. **§4.1(e)'s capture on `#dsh-stage` is MEASURED, not inherited.** 500 px past all four edges and the corner: `pointermove` keeps arriving, `pointerup` arrives at the off-frame coordinate with `pointerId 1`, `target === #dsh-stage`, capture still held, `pointercancel` **0 in 15 drags**. **The paired control is what makes it evidence**: same host, same listeners, capture removed → `outsideViewport=0`, **`pointerup=0`**. Headed reproduces headless exactly. **Stop declining phase-42's measurement and state your own**, with the browser and version, and carry both limitations verbatim: CDP input always targets the page, so this is the browser honouring off-viewport coordinates and **not** the OS handing the pointer to another application; and **only Chromium was measured** — Firefox/WebKit are not in this repo's Playwright cache and the repo's own e2e is Chromium-only.
2. **A free finding that touches §4.2(4): under capture, `e.target` is `#dsh-stage` for every event from the first move onward**, while `document.elementFromPoint` keeps resolving the real element and `null` off-frame. A hit-test reading `e.target` mid-drag gets the stage and nothing else. §4.2(4)'s coordinate-and-rect algorithm is unaffected — **say so, because the wrong implementation is the obvious one.**
3. **D47-2 IS NOW VERIFIED, and it holds.** Live: **91 flex / 144 non-flex of 235 — the no-flow-axis refusal is the majority case at 61.3 %.** Cross-tabulated against the authored proxy: **zero misclassifications in either direction**; all movement is the 19 unknowns resolving 8 flex / 11 block. **Both of the proxy's stated edges held** — 83 was a lower bound on flex, 133+19 an upper bound on non-flex. **Retire the UNVERIFIED label C5 made you attach, and put the live number in §3.1 as its one home** with the proxy kept beside it as the corroborating reading.
4. The census reproduces a **fifth** time, independently.

### FALSIFIED — five, and the first one is a design-level discovery

5. ⚠ **§4.2(2)'s "several matches" arm has NO SUBJECT once the rule is parent-scoped — 0 of 636 member readings.** The plan names `.map()` bodies as the many-node population. **They are, at *partition* scope: 52 many-node readings across 20 chains, 26 of 234 chains refused. At the *parent* scope §4.2(2) itself specifies, every one of them disappears**, because each repeat renders under its own parent. `smcell/smname/smtagg` resolve once per `<li>`, all direct children, under a `flex flex-row` parent.

   **The refusal has a real population, and it is a cause the plan never names: mutually-exclusive `{cond && <el/>}` siblings linked into one chain.** `adjacentOpUnit` admits a `{expr && <el/>}` container (§3.2 says so), so the artifact links alternatives the DOM can never show together. Measured:

   | class | chains | of 235 |
   |---|---|---|
   | refused in **every** observed state | **6** | 2.6 % |
   | refused **only in some** observations | **9** | 3.8 % |
   | never renders at all | **1** | 0.4 % |
   | never refused | **219** | 93.2 % |

   The clearest is `sandbox/resize-repeat-list`: `smndaa`/`smndbb`/`smndcc` are three `{queueState === 'x' && <p/>}` blocks inside a 5-member chain, so exactly one renders per state. Same shape in `lab/tests/shared-oid`, `lab/tests/single-screen`, `sandbox/resize-flex-col`, `sandbox/resize-flex-row`, `shop/member-detail`.

   ⚠ **The 9 "sometimes" chains are the more interesting half and the plan has no concept for them: the same chain refuses or admits depending on WHICH RENDERED INSTANCE the user pressed.** `shop/order-detail`'s `rpb6hb,hjo7s4,5s41w1` renders 6 step columns, five complete and the sixth missing `rpb6hb` — 55 passing scopes, 11 refusing. **A per-instance verdict on a per-chain contract. Rule on it: is that acceptable, and does the refusal wording survive a user who just did the same drag successfully one column over?**

   **The one chain that never renders anywhere, in any state, is exactly the one the plan named** — `swallowed-oid`'s `wcall1…wcall4`. It is the only one.

6. **§4.2(2)'s direct-child clause has ZERO subjects.** 0 of 251 observations, 0 of 235 chains, 0 of 601 uniquely-resolved members — with a planted control (`C-B` wrapped a member in a fresh `<div>`; the analyzer reported it immediately). **The one prop-swallowing component in the repo produces the OPPOSITE failure**: `Field`'s interior oids resolve once *and are direct children of their own wrapper*, so they pass both clauses; its exterior oids reach no node and are caught by the zero-match clause.
7. **§4.2(3)'s three CSS exclusions have ZERO subjects.** `direction: rtl` 0/930 elements; non-`horizontal-tb` 0/930; computed `order` is `"0"` on **930 of 930** reads. Each with a planted control that returned the planted value. **The exclusions stay correct about the browser — codex's round-2 falsification is untouched — they are simply unreachable from this corpus.**
8. **§4.2(5)'s `reversed` branch has ZERO subjects.** Three reverse flex containers exist in `lab/tests/align-enablement` and the corpus scan sees them (`row-reverse` 2, `column-reverse` 1) — **but none of their children carries a `data-oid`**, so none can be a chain member.
9. **The tie-breaks are not zero, but they are small: wrap has 2 subjects (both `lab/tests/align-wrap`, both genuinely 2-line), overlap has 1** (`shop/order-detail`'s `4jpxin`, a 2 px step-connector over a step marker — the only one of three overlaps whose parent is flex; the other two are `position:absolute` under `display:block` parents).

### What this means, ruled

**Every one of these zero-population findings is a LABEL problem, not a design problem. Do not delete the clauses.** They are correct, they are cheap, and each prevents a real failure the browser can produce. **What must change is that the plan stops claiming a shipped subject where there is none**, and routes every such gate's subject to S47-0 as authored-and-declared-synthetic — which is exactly what it already does for `unequal-indent`, and that rider is the model to copy.

---

## §1 — The four defects two lanes found independently

### M1. §4.3(4)'s one-parse composer does not run. **Both lanes built it and both watched it throw.**

```
spelled composer k=1: equals naive? true
spelled composer k=2 THREW: span-sentinel-failed
spelled composer k=3, k=6 THREW: span-sentinel-failed
```
(on `shop/member-list` the same code throws `reparse-failed` at k=2.)

`resolveJsxChildOp(ctx, …)` derives spans from `ctx.mod`, whose offsets address the buffer `moduleContext` parsed. `swapSpans` swaps spans of unequal length, so every later offset shifts and step 2 hands stale spans to a buffer they no longer describe. **The parse is not per-step overhead to be hoisted — it is what makes each step's spans valid.** And the failure is `span-sentinel-failed`, an internal error, so §4.3(5)'s *"any step's typed refusal aborts `prepare`"* does not catch it.

⚠ **This repo already wrote the lesson down, in the same file.** `cutSpans`'s docblock: *"All spans address the ORIGINAL buffer… N sequential `cutSpan` calls are the wrong tool: each re-parses, and every span after the first is stale."* Name it as the precedent and say the plan reached past it.

**The correct shape is ONE-SPLICE, not a k-swap loop** — read every member's span from one `moduleContext`, permute the slot contents, rebuild the buffer once, reparse once. **A lane built it and measured it with controls in both directions:**

```
one-splice k=6 equals the naive 6-step fold, byte for byte: true
CONTROL no move (0→0) is byte-identical to source:            true
CONTROL wrong destination (0→5) differs from naive k=6:       true

naive k=6 fold                                median 34.436 ms
one-parse one-splice k=6 (no verify reparse)  median  4.538 ms
```

**S47-2 gains one obligation the plan does not state: the composer needs a span-rearrangement primitive beside `swapSpans`, because `swapSpans` swaps exactly two spans and a k-step move is not k swaps of one pair.** The *"`expect` consulted on the first step only"* clause dies with the steps.

### M2. R47-4's pre-committed threshold is unreachable by a *correct* implementation of the design it was written to accept

Measured: `moduleContext` 2.628 · `resolveJsxChildOp` warm 0.233 · `swapSpans` **incl. its own reparse** 2.911. So a correct k-swap fold's **best case is 21.49 ms** — above the 19 ms threshold. The criterion would fire on a correct implementation and return the k = 1 clamp for a reason that has nothing to do with the design's merit.

(Also: *"closer to the floor than to the ceiling"* is `< 18.92`, not `< 19`. A 18.95 ms result satisfies the number and violates the sentence.)

**Re-derive the threshold against a floor an implementation can occupy.** Under M1's one-splice shape, k = 6 is ≈4.5 ms plus one verify reparse ≈2.9 ms ≈ **7.5 ms**. A threshold near 12 ms is both meetable and falsifiable. **Name the subject file and chain in R47-4** — these numbers are page-size-dependent (`member-list`, 9 656 B: 0.662 / 1.490 / 9.041).

### M3. G47-20 pins a parse count no implementation produces, correct or mutated

`swapSpans` ends on `reparseOrThrow`, so **one `moveAdjacent` is TWO parses**: naive k = 6 is **12**, not 6, and the correct composer's floor is **2**, not 1 — a structural edit that skipped the defensive reparse would write unvalidated bytes. The timings confirm it arithmetically: `5.616 ≈ 2.628 + 0.233 + 2.911`. **State the two counts the gate actually discriminates (2 for a correct one-splice request of any k; 2k for the naive fold) and say where the instrumented `parse` that observes them lives** — the plan currently provides for neither.

### M4. §4.1(h) hides the very node it says it keeps visible

`#dsh-ring-instance-hint` is created with `ensureReadout(host, INSTANCE_HINT_ID)` where `host = handleLayerRef.current` — **it is a child of `#dsh-handle-layer`**, as are `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint`. `visibility` inherits, so hiding the layer hides the hint. R47-8's only mechanism is inoperative, and **G47-16 leg (ii) is green on the defect and on the correct behaviour alike** — P47-5's own named failure.

**Fix:** either an explicit `visibility: visible` re-declaration on the hint (named in C47-1), or hide the layer's `[data-dsh-handle]` children rather than the layer node. Re-aim G47-16(ii) at a mutation that can fail — *"delete the hint's `visibility: visible` override"*.

---

## §2 — The two gates with no satisfiable subject, now settled by measurement

Both lanes reasoned these out; the live lane confirmed them with numbers.

### M5. G47-11c — `chain-member-not-locatable`'s two "shipped subjects" do not fire

- `wcall1…wcall4` **cannot be pressed** — zero DOM nodes in every state (measured, and it is the only such chain in the corpus). §4.1(a) term 4 requires the press to resolve to a `[data-oid]` element. Independently, its parent `wgrid1` is `grid`, so E2 would refuse first.
- `wflbl3`/`wfval7` **do not refuse** — the join is parent-scoped, and within one `Field` wrapper each resolves exactly once as a direct child. The four-nodes-each fact is a document-wide property this join never queries. Both stated mutations change nothing on this subject.
- **The "grandchild" attribution to `wflbl3` is factually wrong** — it is a direct child of its wrapper.

**Fix:** the gate keeps its clause but its subject is **synthetic and owed by S47-0** — and now you know exactly what to author, because the live lane found the real cause: a chain containing mutually-exclusive `{cond && <el/>}` siblings. **Six such chains already ship.** Use one of them; the subject stops being synthetic. Delete the grandchild attribution, and correct R47-7 and §12, which repeat the false claim a second and third time.

### M6. G47-19 — the `n / N` gate the owner ruling created cannot go RED on either named subject

`N` is a **sibling** count; the artifact-vs-DOM asymmetry is a **document-wide** property. Scoped to the subject's own parent — the only scope this design uses — both named populations **agree** with the artifact: the `.map()` subject is 3 chain members in an `<li>` with exactly 3 element children; the `swallowed-oid` two-member chain is 2 and 2. The "four rendered rows" belongs to `smroww`, which is a **singleton** (`canMoveUp: false, canMoveDown: false`) and can never be a drag subject — **the gate read a row count and called it a chain length**.

**Fix:** name a mutation that discriminates at the scope the design uses. A document-wide `querySelectorAll` count over the chain's oids *is* discriminating (12 vs 3 on the `.map()` subject) — or give the row a subject whose DOM sibling count genuinely differs from its chain length (a flex parent with one element child that is not a chain member), and route it to S47-0. Drop the "opposite directions" argument.

---

## §3 — The rest

### M7. §4.7's *"still literally true"* is false at HEAD, independently of this phase

`use-canvas-hover-ring.ts` registers `stage.addEventListener("mousemove", onMouseMove)`. The ontology preamble's grep-confirmed sentence is already wrong. **Keeping a false sentence and calling it verified is precisely the process failure §0 records** — rewrite **both** preamble sentences in the same amendment, describing the shipped listener set rather than asserting an absence whose terms have drifted.

### M8. R47-3's conclusion survived an attempt to break it — record the mechanism that makes it true

A lane tried to defeat it with `unsupported-sibling` and `non-canonical-separator` mid-chain and could not. The reason is in `adjacentOpUnit`'s own docblock: *"Indent equality is NOT checked here — it is a move-only precondition, not a property of the neighbour."* Because the chain is built only across links `adjacentOpUnit` already admitted, **indent is the only move-only precondition a chain-derived destination can trip.** The conclusion and the reason both hold — **state the mechanism, since the plan currently asserts the conclusion without it.**

### M9. Smaller, each with its fix named

- **§4.5's "189 ARM-TIME refusals" is 165.** Measured: `unsupported-sibling` on singletons (arm-time) 165; on multi-member chain members (a fold-step side) 24. **The 24 genuinely are the "a sibling it must pass" case** — so the wording must work at *both* moments rather than replacing one wrong scope with another.
- **§4.5's "THREE conditions" heads a FIVE-row table**, while the rest of the plan says "five client-only keys". Say "three conditions, five keys" or fix the count.
- **§4.7's component-instance row ships unqualified and is false for the class this repo keeps a fixture of.** An oid-bearing instance is an admissible op-unit for the *write*; the *drag* needs a DOM node and `<Field data-oid="wcall1"/>` has none. The row should say: ships where the oid reaches the DOM, refused as `chain-member-not-locatable` otherwise. **This is the exact shape §4.7 flags one row above.**
- **G47-14's caller-scan leg can invert.** `callerSites` **excludes the definition file by name**, so if `terminateActiveCanvasGesture()` lives in `resize-gesture-guard.ts` — the natural home — the scan returns **zero** callers, not "exactly ONE outside its own module". S47-3's brief must name the wrapper's module.
- **The second guard needs a teardown, and DR47-11's migration does not cover it.** `resetResizeGestureGuard()` is a separate obligation from the 7 boundary calls: it drops the registration and clears the latch after an unmount mid-gesture, and its docblock says why `terminate()` cannot be it. §4.1(f) lists "unmount" as a terminal trigger; say what the reorder machine's teardown is.
- **G47-12 row (a) does not name its control, and only one of three can satisfy it.** `EditableDescription` and `#dsh-name-input` re-seed in place and keep focus, so `orphaned` is false forever there; the row is reachable only on the **chip add-input**. Name it. And §4.6 calls `focusStageIfOwned`'s table "the control" for a claim about the *panel value-commit* flush, while that table measured the *canvas-click ticket-restore* path — the physics generalises, the word "control" over-claims by one call path.
- **`#dsh-ring-layer` carries `overflow-hidden`.** A pointer-following readout is clipped at the frame edge. DR47-3 counts clipping as a cost of the ghost; it is a cost of the readout too. **Rule it rather than letting U1 discover it.**
- **S47-0's fixture list does not say which halves already exist.** Measured: the corpus already carries **three flex-row chains of 7** (`shop/member-list` ×2, `shop/order-detail`), so that half is not authoring work. Genuinely absent: a **flex-col ≥5** chain, a `flex-row-reverse` chain with oid-bearing children, and a variant (`md:flex-*`) chain with oid-bearing children. **Say which is which**, or S47-0 re-authors what ships.
- **C47-6a and C47-6b swapped meanings between r1 and r2.** Internally consistent now — but the plan insists per-commit briefs cite contract ids verbatim, and a brief drafted against r1 would build the other thing. One line at §4.6 recording the swap.
- **The one-home rule is bent**: 235/62/21/7 live in §3.1 and are restated in D47-1 and the ADR's Drivers; 578-of-770 is restated in §8 U8. Point at them.
- **Two unruled cases on the wire:** `anchorOid === the subject's own oid` (§4.2(4) hit-tests over all members *including the subject*, §4.2(6) catches it client-side, the server has no arm — make it a **400**); and `parentOid: null` chains (`wflbl3`/`wfval7` carry it, and they are pressable, admissible, flex-parented subjects).
- **What the readout shows on a refusing arm** is unstated — §4.4 rules two nodes and §4.5 rules no indicator, but nothing says the readout is absent.

### M10. One incidental measurement worth a home

**On the design view, an in-page control cannot be activated by a click.** `shop/member-detail`'s three tab buttons drive a plain React `useState`; on :3001 three consecutive clicks produced no state change (oid counts 84/84/84), while the byte-identical script on :3000 produced 84/69/35. **The canvas selection shield claims the press.** This is why 10 of 235 chains had to be measured on the plain host, and the lane ran a cross-host control first (20/20 screens identical at default state).

This is not phase-47's defect and not phase-47's to fix — **but it constrains how any Playwright spec drives in-page state on the design view, which S47-6 needs.** Record it where S47-6 will read it, and say whether it deserves a `docs/known-issues.md` entry; the lead will rule.

---

## §4 — What this revision is judged on

**A single lane will re-check exactly these deltas, then codex gets its one remaining call on the final text.** So:

- **Sweep by cause, not by section.** M1 reaches §4.3, R47-4, G47-20, S47-2 and the ADR. §0's live results reach §3.1, D47-2, §4.1(e), §4.2(2)-(5), §8's UNVERIFIED list, R47-11 and the status blockquote. Round 3 completed both its sweeps; make it three.
- **Every zero-population clause keeps its clause and loses its claim to a shipped subject.** Copy `unequal-indent`'s SYNTHETIC-and-UNCONDITIONAL rider, which is the model already in the plan.
- **The status blockquote changes.** Three revisions of *"nothing has been driven against a running `descvi:dev`"* is no longer true. State what was driven, on which browser and version, with which controls — and state precisely what remains unmeasured: other browser engines, a real cross-application pointer drag-out, viewport-dependence of the wrap and overlap counts, and any chain hidden behind an in-page control the sweep did not find (bounded: exactly 1 of 235 was never reachable, and its cause is independently known).
