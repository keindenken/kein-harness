# OWNER RULING — the drag readout (DR47-8), 2026-08-27

**The ruling: reading (b). The readout goes on the REORDER drag and shows the DROP POSITION.** The resize W×H readout — reading (a) — is **not built in phase-47**.

The owner's words, translated: *"I have no memory of deciding this… from the context it must be (b), since what went into phase-46 was (b) too. (a) I had forgotten about entirely — even that Figma has it. It'd be useful to have, but if it isn't a subject of this phase it can pass."*

## ⚠ The provenance, stated because the plan currently rests on the weaker half

The plan quotes `docs/e3/tracker.md`'s v3 CLOSE sentence — *"carries the cheap B-Q4 mitigation (a W×H readout during drag) since this gesture is where dragging blind bites"* — as a binding owner ruling, and DR47-8 was built as two readings of it.

**The owner does not remember making that ruling.** So the v3 CLOSE sentence is a weaker authority than the plan treats it as, and the strong authority is now **this fresh input of 2026-08-27**. Say so where DR47-8 is decided: the phase does (b) because the owner ruled (b) today, **not** because the v3 CLOSE sentence was correctly parsed. This is the same provenance discipline phase-46's P46-3 applied to a fresh input the plan's round 0 went looking for in the wrong place.

⚠ **Do NOT rewrite the v3 CLOSE sentence.** It is a dated record of what was written; the tracker's convention is that such records are not edited. The correction is carried where the decision now lives.

⚠ **One half of the owner's reasoning is not load-bearing and must not be repeated as fact.** They offered *"what went into phase-46 was (b) too"* as their own reasoning from context. Phase-46 touched the readout FAMILY (the accent on the refusal marker, the instance hint and the refusal hint) and shipped no size readout — which is consistent with the ruling but is not the same claim. **Record the ruling, not the recollection.** The ruling stands on the owner having made it.

## What this changes

1. **DR47-8 is DECIDED, not routed.** §8.1 stops being an open question. §7's U6 is removed from the owner's live-pass list — it is answered.
2. **The readout's content is the drop position** (`3 / 7` or whatever form the plan settles), on the reorder gesture, hosted by the new reorder hook. The branch-specific id `#dsh-reorder-readout` is now correct rather than presumptuous.
3. **Reading (a) — the resize W×H readout — leaves this phase and needs a destination.** The owner did not cancel it: *"it'd be useful to have."* It is the cheap half of **B-Q4**, whose row in `docs/post-loop-backlog.md` already records the owner's 2026-08-19 direction (auto-scroll confirmed as the expensive half; a W×H readout during drag as the cheaper mitigation that may be taken first), and S42-5's measurement that no numeric size readout exists anywhere is the evidence that row rests on. **Route it back to the B-Q4 row with this ruling recorded on it**, so the next lane that opens B-Q4 finds a live item rather than a deleted one. Do not invent a phase number for it.
4. **The ordering problem M17 raised is dissolved**, not deferred: the decision now precedes S47-4 as it had to.

## Sweep obligation

**This ruling falsifies prose, and not only the sentences that name DR47-8.** Sweep the whole plan for every claim whose CAUSE this moves — the two-readings framing, "both are cheap and neither blocks the other", the shared-node/shared-style argument that existed to keep both readings open, S47-4's conditional rider, §7's U-item list and its count, §8.1, and any consequence in the ADR. A sentence that stays true while its reason dies is the half that survives a sweep and should not.
