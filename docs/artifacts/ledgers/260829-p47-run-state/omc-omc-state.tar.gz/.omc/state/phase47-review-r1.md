# phase-47 ralplan — REVIEW ROUND 1

You are a REVIEW lane in a consensus planning round. Two other lanes are reviewing the SAME text in parallel right now; none of you has reported, so none of you can be primed by another. Overlap between you is corroboration, not waste.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run every command there. Do NOT `cd` to the parent checkout `/Users/kein/Documents/workspace/dev/descvi/repo`, and never read, write or reason about the sibling worktree `phase-47-drag-reorder-in-kein` — a different harness owns it.

## What to read

1. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the text under review (DRAFT r0, 360 lines).
2. **`.omc/state/phase47-context.md`** — the planning context the draft was written against: the owner's ruling, the lead's rulings, the four hard points, the bar.
3. **`docs/prompt/worker-brief.md`** — the rules you work under.
4. **`AGENTS.md`** — binding project rules.

## What you must NOT do

- **Do not edit the plan or any other file.** Your deliverable is a report, and it must be your FINAL MESSAGE — text you merely print reaches nobody.
- **Do not spawn anything that writes or that judges your work.** A read-only lookup is fine.
- **Never own git.** No commit, add, stash, checkout, branch, reset. If you create scratch files, put them under `.omc/state/` (gitignored) and leave the tree otherwise untouched.

## The bar you are reviewing against

From `AGENTS.md` and the 2plan contract:

- Acceptance criteria concrete enough to FAIL; no vague term without a metric.
- Every risk paired with a MECHANISM, not a restatement of intent.
- Per-phase gates each able to go RED, each with a stated RED-when naming the mutation.
- An ADR: decision, drivers, alternatives, why chosen, consequences, follow-ups.
- Code cited by ANCHOR (`path#exact source text`, occurring exactly once in that file), never by line number.
- **A decision closed for a WEAK reason is a defect** — if a stronger unstated reason exists, say so; a reviewer who defeats the weak reason reopens a decision that was actually closed.
- **A conclusion can be RIGHT while its REASON is FALSE, and the reason is what builds the gate.** Five of phase-21's seven falsified facts were this shape. When you accept a decision, accept the REASONING — not just the outcome.
- **A fact checked against an ARTIFACT is not verified until it is checked against the RUNNING APP.** The draft tags claims VERIFIED / UNVERIFIED; check that the tags are honest, and flag any VERIFIED that is really artifact-only.

## Report format — required

Separate **MUST-FIX** from **WORTH-CONSIDERING**. For every finding give: the claim in the plan (quote it), what is actually true, **how you established that** (the command you ran or the anchor you read), and what the plan should say instead. Cite by file + function or by anchor, never by line number alone — this plan's own contracts have moved twice.

End with an explicit verdict: **APPROVE** (the text as it now stands clears the bar) or **REVISE** (with the must-fix list). A conditional approve is a REVISE.

## Specific claims this round should test

These are the lead's picks, not a checklist — a lane that finds something not on this list has done its job. Do not treat the list as the scope.

1. **§3.1 / DR47-1 — the draft REVERSES the lead's own framing.** The context file said phase-47 "opens a new arm in that table"; the draft says the arm table gains NO row and adds one call inside the existing ordinary arm. **Test the reversal, both directions.** Is a reorder press really required to keep every ordinary-arm behaviour? Does the claim that `suppressShieldPointer` uses `stopPropagation` and never `stopImmediatePropagation` hold at source, and does that actually make option (b) spec-legal as claimed? Is the phase-45 C45-5 precedent quoted accurately and is it really the same shape?
2. **§2.1 — the census.** The draft reports 427 runs / 192 singletons / 235 multi / 62 ≥3 / 21 ≥4 / longest 7, with an internal control (578 = 578 by two paths) and a stated discrepancy (770 vs 798 vs ~1096–1107). Numbers produced by a bespoke probe are exactly where this project has been burned. Re-derive what you can, or state precisely why you could not.
3. **D47-2 — "the non-flex refusal is plausibly the majority case", from an 83/235 source-token proxy.** This drives §3.5 being a first-class deliverable. Is the proxy's stated direction (upper bound on refusals) actually the right direction? `readLayoutContext` / `deriveParentContext` fall back to computed display — does that make the proxy an upper or a LOWER bound on the flex population?
4. **§3.3 / DR47-4 — one request, one journal entry, one Cmd+Z.** The load-bearing claims: `moveAdjacent` is a pure `string → string`; the structural handler computes inside `commitWrite`'s `prepare` under the write lock; one request is exactly one journal push; k applications inside one `prepare` therefore give one undo. **Each is a source claim and each is checkable.** Also test the atomicity claim in step 5 and the "before bytes are the whole file" claim.
5. **§3.2 — identity-based drop resolution.** Is `ParentDirection` really unable to see `-reverse` (§2.4)? Is `directionSource === "unresolved"` really the non-flex predicate, and does it really fail to separate grid from block? Does the `.map()` claim in §2.2 (a `.map()` container terminates the run and can never be a reorder subject) hold against `adjacentOpUnit`?
6. **§3.4 — `styleReadout` is claimed module-private, so "adopt" means EXTRACT.** Check it, and check the z-ordering claim (`REORDER_INDICATOR_Z = 44` above `RESIZE_CORNER_Z = 43`) against what is actually in the file.
7. **§3.7 — "`node scripts/check-v3-registers.mjs` does NOT gate these rows".** A claim that no gate watches an edit is exactly the claim that must be true or the phase ships an unwatched amendment believing it watched. Verify it by running the script and by reading its census scope.
8. **§4 S47-0 — "`src/app/lab/tests/align-enablement/` looks like the reverse fixture and is NOT one"** because its children carry no `data-oid`. If this is wrong, S47-0's fixture authoring is wrong.
9. **§5 G47-1 — "This is the gate that would have caught the `closest`-vs-`matches` regression the shield's docblock records".** A historical attribution. If the regression was actually caught by something else, the gate's justification is a weak reason standing in for a real one.
10. **§8.3 — is `expectDestination` a "new write class"?** The draft argues the narrow reading (a write class is a mutation kind) and states the wider one. The owner's words are *"rides v2's existing `move-up`/`move-down` verbs (no new write class)"*. Attack the argument, not the conclusion.
11. **§1 exclusion 5 / §3.1(a) — the multi-select exclusion.** The draft says it "survives contact cleanly" because arming keys on the same two axes phase-45's consumption condition keys on. Is that actually true of the shipped condition, and does the trailing-click latch really leave phase-45's gated condition unmoved?
12. **§7 — the owner-eyes boundary.** Is the story boundary (after S47-4, before S47-6) actually the right cut? Is anything in the U1–U7 list in fact test-decidable, and is anything in §5's "settles without the owner" list actually a matter of taste?
