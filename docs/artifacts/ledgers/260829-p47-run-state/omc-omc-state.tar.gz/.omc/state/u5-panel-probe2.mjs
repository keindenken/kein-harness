import { chromium } from '@playwright/test';

/** U5 rider probe, leg 2 — a multi-selection whose HEAD has both panel verbs dead. */
const browser = await chromium.launch();
const page = await browser.newPage();

const readPanel = async () =>
  page.evaluate(() => {
    const sec = document.getElementById('dsh-structure-edit');
    const btn = (label) => {
      const b = sec === null ? null : sec.querySelector(`button[aria-label="${label}"]`);
      return b === null ? 'ABSENT' : b.disabled ? 'DISABLED' : 'ENABLED';
    };
    return {
      describedOid: document.getElementById('dsh-name-oid')?.textContent ?? null,
      up: btn('위로 이동'),
      down: btn('아래로 이동'),
    };
  });

await page.goto('http://localhost:3001/lab/tests/spacing-nesting');
await page.waitForSelector('#dsh-ring-layer');

const oids = await page.evaluate(() =>
  Array.from(document.querySelectorAll('#dsh-screen [data-oid]')).map((n) => n.getAttribute('data-oid')));
console.log('oids:', oids.join(','));

// snpbed is the plan's own convergence subject: canMoveUp:false, canMoveDown:false.
const other = oids.find((o) => o !== 'snpbed');
await page.locator(`[data-oid="${other}"]`).click();
console.log(`click ${other}         =>`, JSON.stringify(await readPanel()));
await page.locator('[data-oid="snpbed"]').click({ modifiers: ['Shift'] });
console.log('shift-click snpbed (N=2) =>', JSON.stringify(await readPanel()));

await browser.close();
