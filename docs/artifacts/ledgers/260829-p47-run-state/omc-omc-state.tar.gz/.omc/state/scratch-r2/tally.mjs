import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
const tally={};
let n=0;
for (const [screen,e] of Object.entries(m.oids)) {
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue;
    const r=st.reasons||{};
    for (const op of ['move-up','move-down']) { if (r[op]) { tally[r[op]]=(tally[r[op]]||0)+1; n++; } }
  }
}
console.log('total move refusals:',n);
for(const p of Object.entries(tally).sort((a,b)=>b[1]-a[1])) console.log('  ',p[1],p[0]);
