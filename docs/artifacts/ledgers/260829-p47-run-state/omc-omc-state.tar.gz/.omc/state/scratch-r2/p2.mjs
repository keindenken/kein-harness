const base = em.buildEditMap([{ id: 'x', pageSource: page, specSource: spec }]);
console.log('BASE', JSON.stringify(tally(base)));
const bad = page.split('\n').map((l) => (l.includes('smname') ? '  ' + l : l)).join('\n');
const mut = em.buildEditMap([{ id: 'x', pageSource: bad, specSource: spec }]);
console.log('PLANTED', JSON.stringify(tally(mut)));
