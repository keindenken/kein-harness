import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const em = await import(ROOT + '/packages/descvi/src/extractor/edit-map.ts');
const dir = ROOT + '/src/app/lab/tests/style-edit/';
const page = readFileSync(dir + 'page.tsx', 'utf8');
const spec = readFileSync(dir + 'spec.ts', 'utf8');
function show(src, label) {
  const m = em.buildEditMap([{ id: 'x', pageSource: src, specSource: spec }]);
  for (const [s,e] of Object.entries(m.oids)) for (const [oid,v] of Object.entries(e)) {
    const st = v.structure; if (!st) continue;
    if (['v002k2','5pznp9','sms60s','hakgqo'].includes(oid)) console.log(label, oid, 'prev=' + st.prevOid, 'next=' + st.nextOid, JSON.stringify(st.reasons));
  }
}
show(page, 'BASE');
const stripped = page.split('\n').filter((l) => !l.trim().startsWith('{/*')).join('\n');
show(stripped, 'NOCOMMENT');
