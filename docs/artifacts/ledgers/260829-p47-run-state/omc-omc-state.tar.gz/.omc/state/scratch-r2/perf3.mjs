import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const se = await import(ROOT + '/packages/descvi/src/extractor/structural-edit.ts');
const big = readFileSync(ROOT + '/src/app/shop/order-detail/page.tsx', 'utf8');
const SID = 'shop/order-detail';
function fold(src, oid, k) { let s = src; for (let i = 0; i < k; i++) s = se.moveAdjacent(s, SID, oid, 'down'); return s; }
try { fold(big, 'kh1mfx', 7); console.log('k=7 SUCCEEDED (unexpected)'); } catch (e) { console.log('k=7 refused:', e.reason || e.message); }
const back = fold(fold(big, 'kh1mfx', 6), 'kh1mfx', 0);
let s = fold(big, 'kh1mfx', 6);
for (let i = 0; i < 6; i++) s = se.moveAdjacent(s, SID, 'kh1mfx', 'up');
console.log('round-trip byte-identical:', s === big);
