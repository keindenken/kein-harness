import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
for (const [s,e] of Object.entries(m.oids)) {
  if (!s.includes('order-detail')) continue;
  let best = null, bestLen = 0;
  for (const [oid,v] of Object.entries(e)) { const st=v.structure; if(!st) continue; if (st.prevOid===null && st.nextOid!==null) { let n=1, cur=st.nextOid; while(cur){ n++; cur = e[cur].structure.nextOid; } if(n>bestLen){bestLen=n;best=oid;} } }
  console.log(s, 'headOid', best, 'len', bestLen);
}
