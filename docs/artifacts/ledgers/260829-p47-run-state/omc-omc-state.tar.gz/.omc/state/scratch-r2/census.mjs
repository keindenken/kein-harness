import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync(process.argv[2] ?? '.descvi/edit-map.json','utf8'));
let comps=[], movable=0, entries=0, isolatedIneligible=0;
const hist={};
for (const [screen, e] of Object.entries(m.oids)) {
  entries += Object.keys(e).length;
  const seen=new Set();
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue;
    if (st.canMoveUp||st.canMoveDown) movable++;
  }
  // walk chains: heads are entries whose prevOid === null, grouped by parentOid
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue;
    if (seen.has(oid)) continue;
    if (st.prevOid !== null) continue; // not a head
    // head: walk nextOid
    const members=[]; let cur=oid;
    while(cur!==null && cur!==undefined && !seen.has(cur)){ seen.add(cur); members.push(cur); const c=e[cur]; cur = c?.structure?.nextOid ?? null; }
    comps.push({screen, members});
  }
  // any entry never seen (prevOid non-null but unreachable) — report
  for (const [oid,v] of Object.entries(e)) { if(!seen.has(oid)) { comps.push({screen, members:[oid], orphan:true}); seen.add(oid);} }
}
for (const c of comps) hist[c.members.length]=(hist[c.members.length]||0)+1;
const multi = comps.filter(c=>c.members.length>=2);
const membersInMulti = multi.reduce((a,c)=>a+c.members.length,0);
const singles = comps.filter(c=>c.members.length===1);
// classify singletons: admissible (has a resolving op-unit) vs structurally ineligible
let admSingle=0, inelig=0;
for (const c of singles) {
  const v = m.oids[c.screen][c.members[0]].structure;
  const r = v.reasons||{};
  const noSib = (r['move-up']==='no-adjacent-sibling'||r['move-up']===undefined) && (r['move-down']==='no-adjacent-sibling'||r['move-down']===undefined);
  if (noSib) admSingle++; else inelig++;
}
console.log('entries',entries,'movable',movable);
console.log('components',comps.length,'orphans',comps.filter(c=>c.orphan).length);
console.log('multi',multi.length,'membersInMulti',membersInMulti);
console.log('singletons',singles.length,'admissibleSingletons',admSingle,'structurallyIneligible',inelig);
console.log('>=3',comps.filter(c=>c.members.length>=3).length,'>=4',comps.filter(c=>c.members.length>=4).length,'longest',Math.max(...comps.map(c=>c.members.length)));
console.log('hist',JSON.stringify(hist));
