import { readFileSync } from 'node:fs';
const dir = '/Users/kein/y/';
const page = readFileSync(dir + 'page.tsx', 'utf8');
console.log(page.length);
