import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const em = await import(ROOT + '/packages/descvi/src/extractor/edit-map.ts');
const dir = ROOT + '/src/app/sandbox/resize-repeat-list/';
const page = readFileSync(dir + 'page.tsx', 'utf8');
const spec = readFileSync(dir + 'spec.ts', 'utf8');
function tally(map) {
  const t = {};
  for (const e of Object.values(map.oids)) for (const v of Object.values(e)) {
    const r = (v.structure && v.structure.reasons) || {};
    for (const op of ['move-up', 'move-down']) if (r[op]) t[r[op]] = (t[r[op]] || 0) + 1;
  }
  return t;
}
const base = em.buildEditMap([{ id: 'x', pageSource: page, specSource: spec }]);
console.log('BASE', JSON.stringify(tally(base)));
const bad = page.split('\n').map((l) => (l.includes('smname') ? '  ' + l : l)).join('\n');
const mut = em.buildEditMap([{ id: 'x', pageSource: bad, specSource: spec }]);
console.log('PLANTED', JSON.stringify(tally(mut)));
