import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const se = await import(ROOT + '/packages/descvi/src/extractor/structural-edit.ts');
const big = readFileSync(ROOT + '/src/app/shop/order-detail/page.tsx', 'utf8');
console.log('bytes', Buffer.byteLength(big), 'chars', big.length);
for (let w = 0; w < 20; w++) se.moduleContext(big);
let t0 = performance.now();
for (let i = 0; i < 50; i++) se.moduleContext(big);
console.log('moduleContext ms', ((performance.now() - t0) / 50).toFixed(3));
