import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const se = await import(ROOT + '/packages/descvi/src/extractor/structural-edit.ts');
const big = readFileSync(ROOT + '/src/app/shop/order-detail/page.tsx', 'utf8');
const SID = 'shop/order-detail';
function fold(src, oid, k) { let s = src; for (let i = 0; i < k; i++) s = se.moveAdjacent(s, SID, oid, 'down'); return s; }
let out = fold(big, 'kh1mfx', 6);
console.log('changed', out !== big, 'len', out.length);
for (let w = 0; w < 5; w++) fold(big, 'kh1mfx', 6);
let t0 = performance.now();
for (let i = 0; i < 20; i++) fold(big, 'kh1mfx', 6);
console.log('k=6 fold ms', ((performance.now() - t0) / 20).toFixed(3));
t0 = performance.now();
for (let i = 0; i < 20; i++) fold(big, 'kh1mfx', 1);
console.log('k=1 ms', ((performance.now() - t0) / 20).toFixed(3));
