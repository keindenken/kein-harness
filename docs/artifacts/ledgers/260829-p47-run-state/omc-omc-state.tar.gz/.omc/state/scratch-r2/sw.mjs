import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
const sw = m.oids['lab/challenge/swallowed-oid'];
for (const k of ['wcall1','wcall2','wcall3','wcall4','wflbl3','wfval7','wgrid1']) { const st=sw[k].structure; console.log(k,'parent='+st.parentOid,'prev='+st.prevOid,'next='+st.nextOid,'up='+st.canMoveUp,'dn='+st.canMoveDown, JSON.stringify(st.reasons||{})); }
