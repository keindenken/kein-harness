import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
const t={};
for (const [s,e] of Object.entries(m.oids)) {
  const seen=new Set();
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue; if(seen.has(oid)) continue; if(st.prevOid!==null) continue;
    let n=0, cur=oid; while(cur){ seen.add(cur); n++; cur = e[cur].structure.nextOid; }
    if (n<2) continue; const p=st.parentOid; if(p===null||!e[p]) continue;
    if (e[p].className===null||e[p].className===undefined) { const r=e[p].reason||'(none)'; t[r]=(t[r]||0)+1; }
  }
}
console.log(t);
