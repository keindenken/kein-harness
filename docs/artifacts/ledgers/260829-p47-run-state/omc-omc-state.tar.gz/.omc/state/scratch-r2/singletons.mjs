import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
const tally={};
const pairTally={};
let singles=0;
for (const [screen,e] of Object.entries(m.oids)) {
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue;
    if (st.prevOid===null && st.nextOid===null) {
      singles++;
      const r=st.reasons||{};
      const up = r['move-up'] || 'ELIGIBLE';
      const dn = r['move-down'] || 'ELIGIBLE';
      const key = up + ' | ' + dn;
      pairTally[key]=(pairTally[key]||0)+1;
      tally[up]=(tally[up]||0)+1; tally[dn]=(tally[dn]||0)+1;
    }
  }
}
console.log('singleton entries:',singles);
console.log('per-op reason tally:',tally);
console.log('pair tally:');
for(const p of Object.entries(pairTally).sort((a,b)=>b[1]-a[1])) console.log('  ',p[1],p[0]);
