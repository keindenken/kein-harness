import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
for (const [s,e] of Object.entries(m.oids)) { if (e['wcall1']) console.log('wcall1 present in', s); }
const sw = m.oids['lab/challenge/swallowed-oid'];
console.log('swallowed-oid entries:', sw ? Object.keys(sw).length : 'MISSING');
console.log(sw ? Object.keys(sw).join(' ') : '');
