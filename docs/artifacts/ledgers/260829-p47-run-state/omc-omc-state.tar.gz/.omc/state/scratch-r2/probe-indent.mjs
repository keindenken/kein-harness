import { readFileSync } from 'node:fs';
const dir = '/Users/kein/y/';
const page = readFileSync(dir + 'page.tsx', 'utf8');
console.log(page.length);
function tally(map) {
  const t = {};
  for (const e of Object.values(map.oids)) for (const v of Object.values(e)) {
    const r = (v.structure && v.structure.reasons) || {};
    for (const op of ['move-up', 'move-down']) if (r[op]) t[r[op]] = (t[r[op]] || 0) + 1;
  }
  return t;
}
console.log(typeof tally);
