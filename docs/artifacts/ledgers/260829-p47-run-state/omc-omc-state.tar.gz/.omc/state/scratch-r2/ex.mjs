import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
let n=0;
for (const [s,e] of Object.entries(m.oids)) for (const [oid,v] of Object.entries(e)) {
  const st=v.structure; if(!st) continue;
  if (st.prevOid===null && st.nextOid===null) {
    const r=st.reasons||{};
    const up=r['move-up']||'E', dn=r['move-down']||'E';
    if (up==='unsupported-sibling' && dn==='unsupported-sibling' && n<8) { console.log(s, oid, JSON.stringify(st.parentOid)); n++; }
  }
}
