const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
console.log(ROOT);
