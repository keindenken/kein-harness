const ROOT = '/Users/kein/x';
const m = await import(ROOT + '/packages/descvi/src/extractor/edit-map.ts');
console.log(Object.keys(m));
