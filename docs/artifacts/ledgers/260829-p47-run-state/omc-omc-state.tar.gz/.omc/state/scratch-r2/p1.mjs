import { readFileSync } from 'node:fs';
const ROOT = '/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc';
const em = await import(ROOT + '/packages/descvi/src/extractor/edit-map.ts');
const dir = ROOT + '/src/app/sandbox/resize-repeat-list/';
const page = readFileSync(dir + 'page.tsx', 'utf8');
const spec = readFileSync(dir + 'spec.ts', 'utf8');
