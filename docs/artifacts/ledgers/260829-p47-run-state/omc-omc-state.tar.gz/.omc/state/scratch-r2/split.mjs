import { readFileSync } from 'node:fs';
const m = JSON.parse(readFileSync('.descvi/edit-map.json','utf8'));
let unknown=0, flex=0, nonflex=0, noclass=0, realNonFlex=0, grid=0;
for (const [s,e] of Object.entries(m.oids)) {
  const seen=new Set();
  for (const [oid,v] of Object.entries(e)) {
    const st=v.structure; if(!st) continue; if(seen.has(oid)) continue; if(st.prevOid!==null) continue;
    const members=[]; let cur=oid;
    while(cur){ seen.add(cur); members.push(cur); cur = e[cur].structure.nextOid; }
    if (members.length < 2) continue;
    const p = st.parentOid;
    if (p===null || !e[p]) { unknown++; continue; }
    const cn = e[p].className;
    if (cn===null || cn===undefined) { nonflex++; noclass++; continue; }
    const toks = String(cn).split(" ");
    if (toks.includes('flex') || toks.includes('inline-flex')) { flex++; continue; }
    nonflex++; realNonFlex++;
    if (toks.includes('grid') || toks.includes('inline-grid')) grid++;
  }
}
console.log('nonflex',nonflex,'flex',flex,'unknown',unknown);
console.log('of nonflex: noclass',noclass,'realNonFlex',realNonFlex,'grid',grid);
