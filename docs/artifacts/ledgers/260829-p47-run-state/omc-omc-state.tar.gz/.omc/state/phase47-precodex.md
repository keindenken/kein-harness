# phase-47 ralplan — PRE-CODEX CHECK

**Narrow scope. Seven applied edits and three unreviewed additions. Nothing else.**

The plan has had four review rounds. Every item from every round is closed and re-verified; the design layer has stopped moving; three independent lanes have reproduced its census, its timings and its live measurements. **Do not re-open any of that**, do not re-derive numbers, do not re-litigate decisions. If you find yourself writing a finding about something not listed below, it is almost certainly settled — check that it is genuinely new before reporting it, and say so explicitly if it is.

**Why this check exists, stated because it is the whole justification for spending a lane on it:** every unreviewed addition this planner has made has carried a defect. Three for three — r1's composer threw, r2's respelled composer threw, and r3's drop-on-absence ruling was false on a shipped subject. Each was caught by *building or driving it*, never by reading. **The next thing the plan goes to is codex, which has exactly one call left and no second pass after it.** Your job is to make sure that call lands on text worth it.

Working directory: `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-omc`. Run everything there. Never `cd` to the parent checkout or touch the sibling worktree `phase-47-drag-reorder-in-kein`.

## Read

1. **`.omc/state/phase47-revision-r4.md`** — the seven edits that were required.
2. **`.omc/plans/ralplan-phase-47-drag-reorder.md`** — the current text (551 lines).
3. `AGENTS.md`, `docs/prompt/worker-brief.md`.

## Do not

Edit any file. Own git. Spawn anything that writes or judges your work. Scratch under `.omc/state/` (gitignored). **Your report is your FINAL MESSAGE.**

## §1 — Verify the seven, per item: CLOSED / PARTIAL / NOT CLOSED / REWORDED-ONLY

1. **The sub-floor ruling.** A new key `no-sibling-in-this-copy` whose subject is the rendered COPY, with `lab/tests/shared-oid`'s `d4b6s3,d8m1w7` as a SHIPPED subject and a new G47-11d with three mutations; the false dividend sentence replaced by the measurement; G47-11c's cell corrected to ambiguity-only-and-synthetic. **Check the ruling holds where it now claims to** — the measured reading is five instances at `2/2/2/2/1`, all flex-parented, `canMoveUp=false canMoveDown=true`.
2. **`n / N` is instance-local**, the relocation into the readout stated, routed to U9.
3. **No-op detection over SOURCE position**, residual stated, plus the unrendered-first edge.
4. **§5's fixture inventory** corrected to the live read: two flex-row 7-chains not three (`order-detail`'s parent computes `table`); the three sandbox 5-chains disqualified by **E2**, not by conditionals; §4.2(2)'s example qualified; R47-4's subject flagged as a composer benchmark; `40,979 bytes`.
5. **The conditions count** — now "three conditions, six keys". Check all dependent sites agree, and that six is right after item 1 minted a key.
6. **Pre-mortem 3 → five, split by class**, with r3's own G47-16(ii) named, and the mechanism-vs-resolution asymmetry stated.
7. **The four unreached places closed** (§4.2(6), §6, §8, §11) and re-swept by cause for the new key.

## §2 — The three things nobody has read. Hold these to the full bar.

The planner named these itself. Given the 3-for-3 base rate above, they are the likeliest place a defect is sitting.

- **The new key's Korean wording.** It is the fourth per-cause sentence and **the first whose grammatical subject is a rendered copy rather than a source relationship** — a construction the existing bilingual vocabulary has no precedent for. Check it against wording rule 1 (the subject is the relationship that refused, never the element), against KI-17's lesson, and against the practical test: does it survive a user who succeeded one column over? Its second clause actively predicts that success — is that a promise the code can keep?
- **U9.** The owner ruled the readout's existence; this asks about its denominator. **Is that a legitimately new question or does it read as relitigating a settled ruling?** Say which, plainly.
- **Pre-mortem 4's four-level claim** — assembled by the planner from four separately-recorded failures and never reviewed as a single claim. Does the composite hold, or is it four things standing next to each other?

## §3 — Two checks

1. **Did the seven edits break anything that was verified clean?** The prior lane confirmed M1's composer, R47-4's 12 ms, G47-20's 2-vs-2k, M4, M7, M8, M10, the §6 subject column and the citation gate. A 21-line growth can falsify a neighbour.
2. **Sweep by cause for the new key.** The planner lists where it swept. Grep the whole file rather than trusting the list — this repo's sweep lists were proper subsets four rounds running before the last two came out clean.

## §4 — Your verdict

**APPROVE** or **REVISE**, explicitly, and then the question that actually matters:

⚠ **Is this text worth codex's single remaining call?** If you would still want an edit first, name it in one line. If you would send it, say so — and if there is something you would want codex to look at *specifically*, name that too, because I am writing its brief from your answer.
