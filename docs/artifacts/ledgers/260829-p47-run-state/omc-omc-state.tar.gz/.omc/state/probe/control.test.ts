import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

it('positive control: planting a signature moves the census', () => {
  const r = collectInputs('src/app');
  const base = census(r.inputs);
  const baseHist: Record<number, number> = {};
  for (const n of base.runs) baseHist[n] = (baseHist[n] ?? 0) + 1;
  // find the input holding the longest run's page by brute force: strip ONE data-oid from each input in turn
  let moved = 0;
  const deltas: any[] = [];
  for (let i = 0; i < r.inputs.length; i++) {
    const mutated = r.inputs.map((x, j) => j === i ? { ...x, pageSource: x.pageSource.replace(/ data-oid="[a-z0-9]+"/, '') } : x);
    if (mutated[i].pageSource === r.inputs[i].pageSource) continue;
    const c = census(mutated);
    if (c.oidEntries !== base.oidEntries || c.movable !== base.movable || c.runs.length !== base.runs.length) {
      moved++;
      deltas.push({ file: r.inputs[i].relPagePath, oidEntries: c.oidEntries, movable: c.movable, runs: c.runs.length, longest: Math.max(...c.runs) });
    }
  }
  console.log(JSON.stringify({ baseline: { oidEntries: base.oidEntries, movable: base.movable, runs: base.runs.length }, mutatedInputsThatMoved: moved, of: r.inputs.length, sample: deltas.slice(0, 6) }, null, 2));
  expect(moved).toBeGreaterThan(0);
});
