import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

it('map-rendered subjects', () => {
  const r = collectInputs('src/app');
  const targets = r.inputs.filter((i) => /repeat-list|shared-oid|dynamic-shapes/.test(i.relPagePath));
  for (const input of targets) {
    const c = census([input]);
    const rows: any[] = [];
    for (const sid of Object.keys(c.map.oids)) {
      for (const oid of Object.keys(c.map.oids[sid])) {
        const s = c.map.oids[sid][oid].structure;
        if (s && (s.canMoveUp || s.canMoveDown)) rows.push([sid, oid, s.prevOid, s.nextOid, s.parentOid]);
      }
    }
    console.log(input.relPagePath, JSON.stringify(rows));
  }
  expect(true).toBe(true);
});
