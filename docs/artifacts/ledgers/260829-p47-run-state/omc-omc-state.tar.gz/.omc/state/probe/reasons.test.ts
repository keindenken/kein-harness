import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

it('refusal reason census over move verbs', () => {
  const r = collectInputs('src/app');
  const c = census(r.inputs);
  const tally: Record<string, number> = {};
  const samples: string[] = [];
  for (const sid of Object.keys(c.map.oids)) {
    for (const oid of Object.keys(c.map.oids[sid])) {
      const s = c.map.oids[sid][oid].structure;
      if (!s || !s.reasons) continue;
      for (const op of Object.keys(s.reasons)) {
        if (op !== 'move-up' && op !== 'move-down') continue;
        const k = op + ':' + s.reasons[op];
        tally[k] = (tally[k] ?? 0) + 1;
        if (s.reasons[op] === 'unequal-indent' && samples.length < 10) samples.push(sid + '/' + oid + '/' + op);
      }
    }
  }
  console.log(JSON.stringify({ tally, unequalIndentSamples: samples }, null, 2));
  expect(true).toBe(true);
});
