import type { ScreenMeta } from '@descvi/core';
import { useScreenState } from 'descvi/react';
import Link from 'descvi/vite/Link';

// A `sandbox/` screen (track 3, phase-42 §3.6) — see the sibling `resize-flex-row` for what the set is
// for. Nothing under `e2e/` may name this id and no G42 gate reads it.
//
// THE SHAPE THIS SCREEN OWNS: a `.map()` region. `smroww` and its three cells are written ONCE in this
// source and rendered four times, so all four DOM instances share one `data-oid` and
// `computeInstanceMeta` reports `instanceCount: 4` on any of them. That is the dogfood home for §3.2's
// shared-oid handle ruling: a handle drawn on one instance writes the single source span and therefore
// moves all four at once, and this is the only screen in the sandbox set where that is observable.
// Four rows rather than two, so a mis-indexed instance readout ("2/2" for every instance) cannot look
// plausible.
export const screenMeta = {
  id: 'sandbox/resize-repeat-list',
  title: '반복 리스트',
  states: {
    queueState: {
      label: '동기화 상태',
      values: ['idle', 'syncing', 'failed'],
      default: 'idle',
    },
  },
} as const satisfies ScreenMeta;

const TASKS = [
  { no: 'TS-1041', name: '상품 이미지 재업로드', owner: '이도현' },
  { no: 'TS-1042', name: '카테고리 매핑 정리', owner: '박서윤' },
  { no: 'TS-1043', name: '반품 사유 코드 통합', owner: '최민재' },
  { no: 'TS-1044', name: '배송비 정책 반영', owner: '정유나' },
] as const;

export default function Screen() {
  const [queueState] = useScreenState<'idle' | 'syncing' | 'failed'>('queueState', 'idle');

  return (
    <div data-oid="smroot" data-screen="sandbox/resize-repeat-list" className="space-y-6 mx-auto p-6 max-w-3xl">
      <header data-oid="smhead" className="flex flex-col gap-1">
        <h1 data-oid="smttll" className="font-bold text-2xl tracking-tight">반복 리스트</h1>
        <p data-oid="smsubb" className="text-neutral-500 text-sm">
          네 건의 작업이 한 벌의 소스에서 그려집니다 — 한 행을 편집하면 네 행이 함께 바뀝니다.
        </p>
      </header>

      {/* THE SUBJECT — one source row, four DOM instances sharing `smroww`. The row is itself a
          `[data-oid]` child of a flex parent with a static className, so it is a valid drag subject AND
          a shared-oid one at the same time; that combination is what this screen exists to provide. */}
      {queueState === 'idle' && (
        <p data-oid="smndaa" className="bg-neutral-50 px-4 py-3 border border-neutral-200 rounded-lg text-neutral-700 text-sm">
          대기 중입니다. 다음 동기화는 정시에 시작됩니다.
        </p>
      )}

      {queueState === 'syncing' && (
        <p data-oid="smndbb" className="bg-blue-50 px-4 py-3 border border-blue-200 rounded-lg text-blue-800 text-sm">
          동기화 중입니다. 진행 중에는 작업 순서를 바꿀 수 없습니다.
        </p>
      )}

      {queueState === 'failed' && (
        <p data-oid="smndcc" className="bg-rose-50 px-4 py-3 border border-rose-200 rounded-lg text-rose-800 text-sm">
          동기화가 실패했습니다. 마지막 성공 시점 이후의 변경은 아직 반영되지 않았습니다.
        </p>
      )}

      <ul data-oid="smlist" className="flex flex-col gap-2">
        {TASKS.map((task) => (
          <li data-oid="smroww" key={task.no} className="flex flex-row items-center gap-3 bg-white p-3 border border-neutral-200 rounded-lg">
            <span data-oid="smcell" className="w-24 font-medium text-sm tabular-nums">{task.no}</span>
            <span data-oid="smname" className="flex-1 text-sm">{task.name}</span>
            <span data-oid="smtagg" className="w-20 text-neutral-500 text-xs text-right">{task.owner}</span>
          </li>
        ))}
      </ul>

      <Link data-oid="smlnkk" href="/sandbox/resize-flex-row" className="inline-block text-neutral-500 text-sm underline">
        가로 스트립 화면으로
      </Link>
    </div>
  );
}
