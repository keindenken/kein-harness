import { defineConfig } from 'vitest/config';
import path from 'node:path';
const repoRoot = process.cwd();
export default defineConfig({
  root: repoRoot,
  esbuild: { jsx: 'automatic', jsxImportSource: 'react' },
  test: { name: 'probe', include: ['.omc/state/probe/**/*.test.ts'], environment: 'node', globals: true, testTimeout: 600000 },
  resolve: { alias: [
    { find: '@descvi/core/validate', replacement: path.resolve(repoRoot, 'packages/core/src/validate.ts') },
    { find: '@descvi/core/schema', replacement: path.resolve(repoRoot, 'packages/core/src/schema/index.ts') },
    { find: '@descvi/core', replacement: path.resolve(repoRoot, 'packages/core/src/index.ts') },
    { find: '@', replacement: path.resolve(repoRoot, 'src') },
  ] },
});
