import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

it('gap', () => {
  const r = collectInputs('src/app');
  const rows: any[] = [];
  for (const input of r.inputs) {
    const c = census([input]);
    const statics = (input.pageSource.match(/data-oid=/g) ?? []).length;
    const uniq = new Set((input.pageSource.match(/data-oid="([a-z0-9]+)"/g) ?? [])).size;
    if (statics !== c.oidEntries) rows.push({ file: input.relPagePath, statics, uniqStatic: uniq, mapEntries: c.oidEntries });
  }
  console.log(JSON.stringify(rows, null, 2));
  expect(true).toBe(true);
});
