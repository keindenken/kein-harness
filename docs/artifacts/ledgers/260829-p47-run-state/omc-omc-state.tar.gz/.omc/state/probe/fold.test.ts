import { it, expect } from 'vitest';
import fs from 'node:fs';
import { moveAdjacent, deriveStructuralBaseline, moduleContext } from '../../../packages/descvi/src/extractor/structural-edit.ts';

const PAGE = 'src/app/sandbox/resize-repeat-list/page.tsx';
const SCREEN = 'sandbox/resize-repeat-list';

it('k-step fold', () => {
  const src0 = fs.readFileSync(PAGE, 'utf8');
  const base = deriveStructuralBaseline(moduleContext(src0), SCREEN, 'smlist');
  console.log('baseline smlist', JSON.stringify(base));
  let s = src0;
  const k = 3;
  for (let i = 0; i < k; i++) {
    s = moveAdjacent(s, SCREEN, 'smlist', 'down', i === 0 ? base : undefined);
    const b = deriveStructuralBaseline(moduleContext(s), SCREEN, 'smlist');
    console.log('after step', i + 1, JSON.stringify(b));
  }
  expect(s).not.toBe(src0);
  fs.writeFileSync('.omc/state/probe/out-fold.tsx', s);
});
