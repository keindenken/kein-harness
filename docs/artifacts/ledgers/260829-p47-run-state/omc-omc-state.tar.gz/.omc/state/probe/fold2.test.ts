import { it, expect } from 'vitest';
import fs from 'node:fs';
import { moveAdjacent, deriveStructuralBaseline, moduleContext } from '../../../packages/descvi/src/extractor/structural-edit.ts';

const PAGE = 'src/app/sandbox/resize-repeat-list/page.tsx';
const SCREEN = 'sandbox/resize-repeat-list';

it('control: a stale expect on step 2 must throw', () => {
  const src0 = fs.readFileSync(PAGE, 'utf8');
  const base = deriveStructuralBaseline(moduleContext(src0), SCREEN, 'smlist');
  const s1 = moveAdjacent(src0, SCREEN, 'smlist', 'down', base);
  let threw = '';
  try { moveAdjacent(s1, SCREEN, 'smlist', 'down', base); } catch (e: any) { threw = String(e?.reason ?? e?.message ?? e); }
  console.log('stale-expect on step 2 =>', threw);
  expect(threw).not.toBe('');
});

it('control: overshoot k must throw', () => {
  const src0 = fs.readFileSync(PAGE, 'utf8');
  let s = src0;
  let threw = '';
  try { for (let i = 0; i < 12; i++) s = moveAdjacent(s, SCREEN, 'smlist', 'down', undefined); } catch (e: any) { threw = String(e?.reason ?? e?.message ?? e); }
  console.log('overshoot =>', threw);
  expect(threw).not.toBe('');
});

it('parse cost on the largest page', () => {
  const files = ['src/app/sandbox/resize-repeat-list/page.tsx', 'src/app/shop/order-detail/page.tsx', 'src/app/shop/member-detail/page.tsx', 'src/app/lab/tests/align-enablement/page.tsx'];
  for (const f of files) {
    const src = fs.readFileSync(f, 'utf8');
    for (let i = 0; i < 5; i++) moduleContext(src);
    const t0 = performance.now();
    const N = 40;
    for (let i = 0; i < N; i++) moduleContext(src);
    const ms = (performance.now() - t0) / N;
    console.log(f, 'bytes', src.length, 'ms/parse', ms.toFixed(3));
  }
  expect(true).toBe(true);
});
