import fs from 'node:fs';
import path from 'node:path';
import { buildEditMap } from '../../../packages/descvi/src/extractor/edit-map.ts';

function walkPages(dir: string, out: string[]): void {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkPages(p, out);
    else if (e.name === 'page.tsx') out.push(p);
  }
}

export function collectInputs(root: string) {
  const pages: string[] = [];
  walkPages(root, pages);
  pages.sort();
  const inputs = [] as { id: string; pageSource: string; specSource: string; relPagePath: string }[];
  const skipped: string[] = [];
  for (const p of pages) {
    const spec = path.join(path.dirname(p), 'spec.ts');
    if (!fs.existsSync(spec)) { skipped.push(p); continue; }
    inputs.push({ id: path.relative(root, path.dirname(p)).split(path.sep).join('-') || 'root', pageSource: fs.readFileSync(p, 'utf8'), specSource: fs.readFileSync(spec, 'utf8'), relPagePath: path.relative(process.cwd(), p) });
  }
  return { inputs, pages, skipped };
}

export function census(inputs: any[]) {
  const map: any = buildEditMap(inputs as any);
  let oidEntries = 0;
  let movable = 0;
  const runs: number[] = [];
  for (const screenId of Object.keys(map.oids)) {
    const entries = map.oids[screenId];
    const ids = Object.keys(entries);
    oidEntries += ids.length;
    for (const oid of ids) {
      const s = entries[oid].structure;
      if (s && (s.canMoveUp || s.canMoveDown)) movable++;
    }
    const seen = new Set<string>();
    for (const oid of ids) {
      const s = entries[oid].structure;
      if (!s) continue;
      if (s.prevOid !== null) continue;
      let len = 0;
      let cur: string | null = oid;
      while (cur !== null && !seen.has(cur)) {
        seen.add(cur);
        len++;
        const st = entries[cur]?.structure;
        cur = st ? st.nextOid : null;
      }
      runs.push(len);
    }
  }
  return { map, oidEntries, movable, runs };
}
