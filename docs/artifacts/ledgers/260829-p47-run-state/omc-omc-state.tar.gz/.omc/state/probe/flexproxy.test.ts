import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

const isFlex = (c: string) => c.split(/ +/).some((t) => t === 'flex' || t === 'inline-flex');
const isGrid = (c: string) => c.split(/ +/).some((t) => t === 'grid' || t === 'inline-grid');

it('flex proxy re-derivation', () => {
  const r = collectInputs('src/app');
  const c = census(r.inputs);
  const nullReasons: Record<string, number> = {};
  let flexParent = 0, noOidParent = 0, nullClass = 0, nonFlexClass = 0, gridClass = 0;
  const nonFlexSamples: string[] = [];
  for (const sid of Object.keys(c.map.oids)) {
    const entries = c.map.oids[sid];
    const seen = new Set<string>();
    for (const oid of Object.keys(entries)) {
      const s = entries[oid].structure;
      if (!s || s.prevOid !== null) continue;
      const members: string[] = [];
      let cur: string | null = oid;
      while (cur !== null && !seen.has(cur)) { seen.add(cur); members.push(cur); const st = entries[cur]?.structure; cur = st ? st.nextOid : null; }
      if (members.length < 2) continue;
      const pOid = entries[members[0]].structure.parentOid;
      if (pOid === null) { noOidParent++; continue; }
      const pc = entries[pOid]?.className ?? null;
      if (pc === null) { nullClass++; const rr = entries[pOid]?.reason ?? 'absent-entry'; nullReasons[rr] = (nullReasons[rr] ?? 0) + 1; continue; }
      if (isFlex(pc)) { flexParent++; continue; }
      nonFlexClass++;
      if (isGrid(pc)) gridClass++;
      if (nonFlexSamples.length < 8) nonFlexSamples.push(sid + '/' + pOid + ' :: ' + pc);
    }
  }
  console.log(JSON.stringify({ total: flexParent + noOidParent + nullClass + nonFlexClass, flexParent, noOidParent, nullClass, nonFlexClass, gridClass, nullReasons, nonFlexSamples }, null, 2));
  expect(true).toBe(true);
});
