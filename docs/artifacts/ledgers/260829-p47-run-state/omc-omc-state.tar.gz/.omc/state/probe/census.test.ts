import { it, expect } from 'vitest';
import { collectInputs, census } from './census-lib.ts';

it('census', () => {
  const r = collectInputs('src/app');
  const c = census(r.inputs);
  const hist: Record<number, number> = {};
  for (const n of c.runs) hist[n] = (hist[n] ?? 0) + 1;
  const multi = c.runs.filter((n) => n >= 2);
  const membersInMulti = multi.reduce((a, b) => a + b, 0);
  console.log(JSON.stringify({
    pagesOnDisk: r.pages.length,
    withSpec: r.inputs.length,
    skipped: r.skipped,
    partitions: Object.keys(c.map.oids).length,
    oidEntries: c.oidEntries,
    movable: c.movable,
    runsTotal: c.runs.length,
    singletons: c.runs.filter((n) => n === 1).length,
    ge2: multi.length,
    membersInMulti,
    ge3: c.runs.filter((n) => n >= 3).length,
    ge4: c.runs.filter((n) => n >= 4).length,
    longest: Math.max(...c.runs),
    hist,
  }, null, 2));
  expect(c.runs.length).toBeGreaterThan(0);
});
