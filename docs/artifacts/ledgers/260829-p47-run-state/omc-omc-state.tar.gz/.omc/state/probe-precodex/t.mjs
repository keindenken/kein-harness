const groups = new Map();
for (const [p, hits] of groups) {
  console.log(p, hits);
}
