# phase-47 ralplan — CONSOLIDATED REVISION BRIEF (after review round 1)

Three lanes reviewed r0 in parallel — architect, critic, codex — and **all three returned REVISE**. This is the single consolidated brief: findings are deduplicated, conflicts are adjudicated by the lead with the ruling stated, and each item says what the plan must SAY, not just that it is wrong.

**Do not treat this as a list to tick.** Several items falsify a REASON behind a conclusion the lanes otherwise accept — the phase-21 shape the bar names — and a fix that repairs the sentence while leaving the reason intact is a REWORDED-ONLY fix, which round 2 will be primed to detect.

**Where the lanes agreed by different routes, that is corroboration and the item is closed against re-argument.** Where they disagreed, the lead's ruling is stated and you may contest it with evidence, loudly, as you correctly did with the arm-table framing in r0.

---

## 0. FIRST — the lead's own error, and everything downstream of it

⚠ **`.omc/state/phase47-context.md` §4(a) has been CORRECTED. Re-read it before you touch §3.1.**

The context file told you the shield's docblock records *"three separate occasions on which this table was got wrong"*, all *"order-of-arms failures"*, and that *"phase-47 opens a new arm in that table"*. The architect lane re-read the file end to end and found all three false; the lead re-verified at source and confirms:

- **ONE** recorded arm-table failure: `isFocusableHandleEvent`'s first draft used `closest` where it needed `matches`, retiring ROW D entirely. Both review lanes measured it independently.
- It is a **PREDICATE-BREADTH** failure, not order-of-arms. The arm-order rule appears in the file as a rule with a reason, never as a recorded failure.
- The other two items are a **falsified gate prediction** about ROW P and an **overstatement** at `pointerIdOf` — wrong claims *about* the table, not the table being wrong.

**R0 inherited the false claim verbatim into P47-4, D47-3, R47-1 and pre-mortem 1.** Correct all four. The consequence that matters most: **R47-1's mechanism — "the brief requires the implementer to quote the arm order back" — is aimed at a failure class the record does not contain, and would not have caught the one that happened.** Replace it with a mechanism aimed at predicate breadth: the S47-3 brief requires the implementer to state, for the new call, what its predicate must NOT match and which target class each existing arm claims.

⚠ **`AGENTS.md` requires that every citation be re-opened at the moment of writing. This claim came from the lead and was not re-opened. That is the rule the error cost, and it is worth one sentence in the plan.**

**Your r0 reversal of the "new arm" framing was CORRECT and is SUSTAINED** — but codex found its stated reason weak, and the lead agrees. *"A fourth row is by construction a row that does something ELSE, so it would have to re-implement the ordinary arm"* is not a necessity: a fourth arm could call a shared helper. **The strong reason is that reorderability is not a target-ownership class at all — it is a gesture state on an ordinary target, and a sub-threshold press must retain ordinary click semantics.** The arm table partitions by TARGET; this partitions by what happens after. Rewrite DR47-1's rationale on that ground and keep C45-5 as a topology precedent only.

---

## 1. MUST-FIX — design contradictions and contract gaps

### M1. §3.1(a) term 5 and §3.5 contradict each other, silencing 45% of the corpus *(critic, sole)*

Term 5 makes `canMoveUp || canMoveDown` a **conjunct of arming**, so a singleton subject never becomes a candidate — while §3.5 says singletons *"arm into a refusing state"* and paints `no-reorderable-sibling`. Both cannot hold, and under term 5 that key is unreachable code covering **192 of 427 runs**, receiving exactly the silent no-op DR47-7 rules against. **`no-reorderable-sibling` also has no gate**: G47-11 asserts only `parent-has-no-flow-axis`.

**Say instead:** split arming into *candidate* (terms 1–4) and *eligible* (term 5), with term 5's failure routing to the refusing state rather than to non-arming. Give `no-reorderable-sibling` its own gate leg.

### M2. The drag subject and `selectedTarget` are not the same element, and the post-write handoff reads the wrong one *(codex, sole)*

With A selected, the user can press and drag B. A successful terminal arms the trailing-click latch, so the release click returns **before** selection resolution — and `handleStructureSaved` in `use-preview-session.ts` reads `screenId`/`oid` from `selectedTarget`, not from an explicit drag subject. **B moves while the selection stays on A**, and if A carried a dirty draft the gesture bypasses the pending-edit seam entirely.

The lead re-checked the second half: `use-preview-session.ts` uses `selectedTarget` as the sole subject throughout. This is a real seam and r0 has no term for it.

**Say instead:** rule between (i) arm only when the pressed oid equals the selected oid; (ii) resolve the pending edit at threshold and switch selection to the drag subject; (iii) pass an explicit drag-subject identity through the structural post-save handoff. **This is a DR-level decision with ≥2 options and a stated loser rationale, not a sentence.** Gates must cover no-selection→B, selected-A→B, dirty-A→B, and correct subject retention after 200 / 409 / 422.

### M3. The non-flex predicate is wrong AND it violates P47-1 *(codex + architect, two routes, composed)*

Two findings that meet:

- **codex:** `deriveParentContext` checks `variantControlsDirection` **before** `baseIsFlex` and `computedIsFlex` — the lead verified the branch order at source. So a parent carrying `md:flex-row` below the `md` breakpoint yields `directionSource === "variant"` and **never reaches `"unresolved"`**, even though its computed `display` is `block`. §3.5 admits it, and §3.2(3) then takes an axis from a non-flex element.
- **architect:** §3.5's arm-time refusal computes an **admissibility verdict client-side from a computed-style read**, on a property the edit-map does not publish per oid. **P47-1 as written ("no verdict is computed client-side") is broken by the design's own §3.5.**

**Say instead:** narrow P47-1 to ORDER and MEMBERSHIP, stating explicitly that *live layout admissibility* is the DOM's and why that is not the classifier-divergence class the `StructureSection` prohibition is about — or drop the arm-time half in favour of the server's answer. Then fix the predicate: it must consult live computed `display`, and the inactive-variant case gets its own RED-when (a `md:flex-row` parent below `md` must REFUSE; the same parent above `md` must ADMIT).

⚠ **The two findings compose into a third:** the population where D47-2's authored-token proxy is weakest — variant-controlled and computed-flex parents — is **exactly** the population where the shipped predicate is broken. Say that once, where the proxy is stated.

### M4. `.map()`-body elements ARE reorder subjects, and one drag rewrites N rows *(architect, sole, measured)*

§2.2's *"a `.map()`-rendered list is therefore not a reorder subject and cannot become one by accident"* is false. The **container** claim is right (a CallExpression terminates the run), but elements **inside** the map body are ordinary admissible op-units. Measured: `src/app/sandbox/resize-repeat-list/page.tsx` has `smcell`/`smname`/`smtagg` under `parentOid: smroww`, a `flex flex-row` parent, all three movable — a run of 3 rendered as **four DOM instances**.

Three consequences r0 does not price:
1. §3.2(2)'s `parentElement`-scoped lookup happens to work here, so the conclusion survives — **its stated reason does not.** Re-argue the uniqueness refusal from this population rather than from its absence.
2. **One drag rewrites the template, so N rendered rows reorder at once.** Nothing in §3.2–§3.4 mentions it.
3. §3.1(e) hides the ring layer — which holds `#dsh-ring-instance-hint`, the one affordance that says "4 instances". **The affordance explaining the multi-instance write is suppressed exactly when it is load-bearing.** Rule on it explicitly.

### M5. An armed-but-no-op drag now eats a selection click — an unstated live regression *(architect, sole)*

Compose §3.1(d) (arm the latch on *any* armed drag) with §3.2(6) (a no-op destination issues no request): press a reorderable element, travel 5 px, return, release. The gesture armed, resolved to a no-op, armed the latch — and the shield's click arm returns before resolution. **No selection happens.** Today that gesture selects. Phase-42 measured 2-of-20 tremor misclassifications at this threshold, and 235 of 427 runs are reorderable, so this is a click-selection regression across a majority of the canvas.

**U3 does not name this.** It asks whether 4 px *feels* right, not what a sub-intent arm costs.

**Say instead:** arm the latch on a terminal that **issued a request** (or that moved the destination), not on every armed drag — or state the swallow as an accepted cost with its frequency. Either way §5 gains the row, and U3 gains this as its concrete harm.

### M6. The shared active-drag guard is a singleton with replace-semantics, and the plan never mentions it *(critic MUST-FIX + architect WORTH-CONSIDERING — LEAD RULES: MUST-FIX)*

Lead-verified: `terminateActiveResizeGesture()` is called at **7 production sites across 4 files** (`use-canvas-selection-shield.ts`, `use-classname-commit.ts`, `DescviOverlay.tsx`, `use-preview-session.ts` ×4), and `registerTerminal` has exactly one real caller, `resize-drag-machine.ts`. The guard's header rules it *"A MODULE SINGLETON, deliberately"* and *"registering replaces"*.

- Not registering ⇒ a live reorder drag is invisible to all 7 boundaries — including the shield's own `switchSelection`, whose comment names the worst path: *"reachable exactly when pointer CAPTURE FAILS … the shield would resolve a selection mid-gesture and produce a second POST for one drag."* §3.1(c) lists "selection change" as a terminal trigger but never says what delivers it.
- Registering ⇒ it **replaces** the resize gesture's terminal.

**Say instead:** a DR-level ruling on whether the reorder machine joins `resizeGestureGuard` or stands beside it, with the replace-semantics residual recorded the way DR47-2 records the latch's.

### M7. No idempotence contract over the `mousedown`/`pointerdown` pair *(codex + architect, converged)*

`onPointerSuppress` is registered for **both** events. `beginTravelRecording` needed a whole mechanism for this (§3.5(d)'s `pointerIdOf` comparison). A reorder call placed after it inherits none of it: in jsdom it fires twice per press, and the `mousedown` half **carries no `pointerId`**, so §3.1(b)'s `setPointerCapture(e.pointerId)` is not expressible from it.

**Say instead:** C47-1 states the reorder call's one-per-press rule and its `pointerId` precondition in the same shape §3.5(d) uses; §5 gains a RED-when that dispatches the pair and asserts one arming.

### M8. The hit-test is not a total algorithm *(codex, sole)*

*"which sibling's box contains it (or is nearest, when the pointer is in a gap)"* leaves undefined: the distance function, equal-distance tie-break, overlapping boxes, gaps between wrap lines, and whether the subject's own box participates. Two implementers produce two different destinations and G47-5 cannot tell them apart.

**Say instead:** write the total algorithm (e.g. minimise point-to-rect squared distance; ties resolve by source-chain order; a point inside multiple rects resolves by a named rule), with RED-whens for the line gap, the exact midpoint, equal distance, and overlapping rects.

### M9. §3.2(3) handles three of `ParentDirection`'s four members *(critic, sole)*

The union is `"row" | "col" | "unset" | "unsupported"`. `"unsupported"` is reachable **without** `directionSource === "unresolved"` — both the `variantControlsDirection` and `computedIsFlex` branches do `directionFromComputed(...) ?? "unsupported"`. So such a parent arms (the refusal predicate is false there) and hands the drop table an axis with no case. **An executor guesses.**

**Say instead:** name the fourth member and its disposition — most cheaply by widening the refusal predicate to `directionSource === "unresolved" || direction === "unsupported"`.

### M10. The refusal set is not total over the engine, which is pre-mortem #3 re-entering *(architect, sole, measured)*

`StructuralRefusalReason` has ~20 members. §3.5 defines a **new** four-key union with a `never` tail and **no total map from the engine union onto it, and no fallback arm**. G47-11's own justification quotes the phase-46 record that an unlisted reason once put raw kebab-case into a Korean panel.

Architect's measured refusal tally over `move-up`/`move-down` across `src/app` (positive-controlled): `no-adjacent-sibling` 541 · `unsupported-sibling` 189 · `unsupported-parent` 52 · `target-bears-data-screen` 48 · `unsupported-container` 18 · `non-canonical-separator` 6 · **`unequal-indent` 0**.

⚠ **`unequal-indent` is ZERO across the corpus**, which firms two things r0 left conditional: **R47-3's trade is safe today** (its re-rate condition is answered, so stop hedging it), and **G47-9's fixture obligation is unconditional** — the atomicity gate has no natural subject and can only ever run against an authored one. Move it from a footnote to an S47-0 acceptance criterion, and say plainly that its subject is synthetic.

**Say instead:** C47-5 defines the mapping over the ENGINE union with the `never` tail there, plus a named generic arm for reasons with no reorder-specific sentence. §3.3(5) drops its four-item enumeration (which is a subset masquerading as the set).

### M11. C47-6's `null` half cannot be implemented where the plan says *(critic + architect, converged)*

The shipped Cmd+Z handler runs `if (!(active instanceof Element)) return;` → text-entry return → `if (!stage?.isConnected) return;` → the ownership disjunction. **A `null` `activeElement` bails at the FIRST guard**, two guards above the ownership check and **above** the text-entry guard. So "the disjunction gains one term" leaves `null` dead, and the correct edit moves an early return that precedes the text-entry guard — the exact shape G47-12's leg (ii) exists to police, now inside the fix. **G47-12(ii) is therefore vacuous for the `null` half**: a focused `<input>` is an Element, so that branch cannot fire on it.

Also: `stage?.isConnected` is already proven one line above, so C47-6's *"while `stageRef.current?.isConnected` is true"* is a redundant re-check an executor will write anyway.

**Say instead:** state the two edits and their order separately, each with its own RED-when — or drop the `null` half and say why.

### M12. G47-1 already ships, its RED-when is not constructible, and §11 files it where half of it cannot run *(critic + architect + codex, THREE-WAY)*

- **It ships.** `e2e/spacing-gesture.spec.ts`'s *"§3.9's THREE-ARM TABLE"* test already presses a strip, a `data-dsh-handle="se"` corner and the popup input and reads `defaultPrevented`. The shield's docblock names it: *"THE GATES THAT PIN THIS TABLE, both in `e2e/spacing-gesture.spec.ts`."*
- **The mutation cannot be built.** RED-when says *"make the reorder call return early before `suppressShieldPointer(e)`"* — but C47-1 places the call **after** `beginTravelRecording(e)`, which is itself after `suppressShieldPointer(e)`. No mutation there can flip `defaultPrevented`. **The leg is green on the implementation and on its negation.**
- **Wrong layer.** §11 files G47-1 under jsdom; the ROW P leg needs the spacing popup and a real pointer gesture, and jsdom has no `PointerEvent` and no pointer capture.
- **Mis-credited history** (all three lanes): the `closest`/`matches` regression was found by two review lanes; the `defaultPrevented` gate was added afterwards to reproduce and pin it.

**Say instead:** G47-1 **extends** the shipped Playwright row with a fourth press (an ordinary reorderable element), stays in e2e, and its RED-when names a mutation the contract can express — e.g. build DR47-1(a): move the reorder call above `suppressShieldPointer(e)` and early-return, and show the ordinary row flip. Restate the history as "reproduces and pins the regression the review lanes found".

### M13. "Adopt `styleReadout`" is four unpriced costs *(critic + architect, union)*

1. **Its base tone is the REFUSAL's palette** — red text, red border, red left accent — under a comment saying the other two callers override three colour lines *in a specific order*, because the `border` shorthand resets all four sides. A W×H or `n / N` readout adopted without the override ships **red**.
2. **It hard-codes `zIndex = "41"`** — below `RESIZE_STRIP_Z = 42` and `RESIZE_CORNER_Z = 43`, equal to `SPACING_STRIP_Z = 41` — while §3.4 specifies `REORDER_INDICATOR_Z = 44` and says nothing about the readout's z.
3. **The extraction breaks a shipped source-text gate.** `spacing-readout-accent.test.ts` row (3) reads `use-resize-handles.ts` as TEXT for `/const READOUT_ACCENT_PX = (\d+);/` and asserts cross-file agreement. Moving the function orphans the constant or mints a third declaration — and F46-B already priced this exact revision at *"TWO production constants plus the hand-written literals … never one constant"*.
4. **`layoutReadouts` places that family as a selection-anchored stack**, which a pointer-following drag readout cannot join.

**Say instead:** the extraction parameterises z and role-colour (or C47-4 names the override lines and their order as the caller's obligation); §3.4 states where `READOUT_ACCENT_PX` lives afterwards and what happens to row (3); the drag readout gets an explicit z and an explicit statement that its placement is not `layoutReadouts`'.

### M14. DR47-6 strawmans its loser, states a false cost, and omits the option that wins *(critic + architect, converged; architect's synthesis adopted)*

- **The missing option.** `deriveParentContext` projects `readLayoutContext`, which returns **`directionToken`** — documented as *"The exact unprefixed base-layer direction token … `direction` alone cannot tell an authored `flex-row` from a `flex-row-reverse`."* It is exported and deliberately re-exported by `panel/index.ts` with a comment ruling it the family's one home for outside consumers, and `LayoutSection` already decides its reverse refusal on it. So base-layer reversal is available **today**, with no new field and no computed read.
- **The false cost.** *"the second place in the overlay that reads computed flex direction"* — there are **four** sites in three files (`parent-context.ts` ×2, `use-spacing-drag.ts`, `use-spacing-affordances.ts`). It would be the fifth.
- **The omitted strongest argument FOR (b):** `use-spacing-drag.ts` is a shipped **canvas gesture module reading computed flex direction for orientation, not admissibility** — a verbatim precedent for what (b) proposes.

**LEAD RULING:** add **option (d)** — read `readLayoutContext(parentEl).directionToken` for the base layer, fall back to computed `flexDirection` only when `directionSource` is `variant` or `computed` — and re-derive the choice against it. Correct the site count. Give (a) its honest rejection (`directionToken` is base-layer only, so it misses variant/computed parents — which is a real argument and the one to make).

### M15. `expectDestination` needs a forbidden-elsewhere arm, and this endpoint has NO optional fields *(architect + codex + critic, THREE-WAY)*

The structural endpoint enforces strict per-op **REQUIRED-or-FORBIDDEN** in both directions, 400 either way, with an explicit rule that *"absent means ABSENT: an explicit `null` is a value the client chose to send and is refused with the rest."* `parseExpectForOp` is a total switch for exactly this reason, and `snippetId`'s docblock says *"accepting-and-ignoring it would hide that."*

**So `expectDestination` would be this endpoint's first genuinely optional field** — necessarily, because the shipped `StructureSection` ↑/↓ buttons send `move-up`/`move-down` without it. codex adds that the payload-free union arm also carries `delete`/`duplicate`, so an optional field there is reachable from verbs that have no destination.

⚠ **This is a materially stronger objection than §8.3's stated wider reading (*"any wire-shape change violates the ruling"*), which is a strawman the plan then defeats.** Replace it.

**LEAD RULING — the narrow reading of "no new write class" STANDS**, on the enumeration r0 already gives (no `StructuralOp` member, no wire verb, no journal arm, no `reselectTargetFor` arm, no `REASON_TEXT` key, no composer) and **not** on the appeal to `structural-edit.ts`'s header sentence, which names one class contrasted with literal replacement and does not carry a taxonomy — drop that appeal. **But the optionality objection must be answered by DESIGN, not by argument.** One candidate worth evaluating rather than adopting: make `expectDestination` **REQUIRED for `move-up`/`move-down` and FORBIDDEN elsewhere**, with the panel's ↑/↓ buttons becoming a second producer that computes it from the chain they already read — which preserves the endpoint's discipline exactly instead of minting an exception to it. Split the union's move arm from the delete/duplicate arm either way.

### M16. The observability line cannot see the defect it exists to catch *(critic, sole)*

§11: *"S47-2 adds `k` to it, so a fold that silently became k = 1 is visible in the sidecar log."* The suffix is built **from `body`**, in the HTTP layer, with no handle on what the fold computed. A `k` read from the request body is the *requested* k — **identical under a correct fold and under one that applied a single step.** Green on the exact mutation it is justified by.

**Say instead:** echo the **applied** `k` in the 200 payload and read the suffix from the result.

### M17. DR47-8's decision point contradicts S47-4's ordering *(codex, sole)*

§7 puts the owner boundary *after* S47-4 and answers DR47-8 there as U6; §8.1 says it blocks S47-4. Both cannot hold — S47-4 cannot implement a host hook and content function chosen after it ships. `#dsh-reorder-readout` is also a branch-specific id under the recommended reading.

**Say instead:** DR47-8 is answered **before** S47-4. The lead is putting it to the owner now (§3 below). The post-S47-4 owner pass keeps U1–U5 and U7 only.

### M18. Census labels overstate what was measured *(codex + architect, both refine; both adopted)*

Every raw figure **reproduced three times independently** — the critic re-derived through the extractor's own CLI and the architect through a separate probe with its own positive control, and both match r0 digit for digit, including the 578 = 578 control. **The numbers are not in question; the labels are.**

- **codex:** of the 192 singletons, **62 are structurally ineligible OIDs**; admissible singletons are **130**. So `427` is "chain components", not "admissible runs". Relabel: *427 chain components: 235 admissible multi-member chains, 130 admissible singletons, 62 ineligible isolated entries.*
- **architect:** all 54 `null`-className parents carry `reason: 'no-class'`, none `'dynamic-class'` — an element with no className cannot be Tailwind-flex. Corrected split: **133 measured non-flex (57%) · 83 flex (35%) · 19 unknown (8%)**. Also **15 of the 79** non-flex parents are `grid` (6%), which prices wording rule 2 rather than only forbidding the word.
- **§8.6 is CLOSED, not open** — both lanes resolved it identically: `798 − 24` (`src/app/page.tsx`, no sibling `spec.ts`) `− 3` (`insert-scratch` duplicate oid strings) `− 1` (`swallowed-oid`) `= 770`. **Delete §8.6.** Move the duplicate-oid observation into §3.2(2)'s uniqueness argument, where it does work: the census under-counts the DOM population exactly in R47-7's own population.
- **S47-0's re-derivation obligation is DISCHARGED** by the critic's CLI run. Replace it with the fixture-authoring obligation.

⚠ **Where codex and the architect appear to conflict on D47-2's direction, they do not:** codex is right that authored-flex 83 is a *lower* bound on the flex population, and the architect is right that the 54 `no-class` parents are near-certain refusals. Both hold, and the residual uncertainty concentrates in the **variant/computed** parents — which is M3's broken predicate. State the bound honestly and say where it is soft.

### M19. The multi-select exclusion's stated reason is one phase-45 explicitly ruled false *(critic, sole)*

§3.1(a) term 2 reads modifiers **at the press**. The shipped condition reads `shiftKey` **at the click**, and both the code and C45-5 rule the press-time read out in terms: *"THE MODIFIER IS READ HERE, AT THE CLICK, NEVER AT THE PRESS. A user can press without Shift and be holding it by release, or the reverse."* Same axes, opposite moment — and the moment is the whole content of phase-45's ruling.

**LEAD RULING: the exclusion is SUSTAINED, the reason is REBUILT.** The conclusion likely survives (an armed reorder drag arms the trailing latch, and the latch branch precedes the travel check, so a Shift-at-release click is swallowed either way) — **but r0 does not make that argument, and it is the argument that makes the exclusion clean.** Make it.

Two riders in the same place: (i) §1 exclusion 4's *"every modifier+drag remains exactly as inert as it is today"* is **false** for a modifier acquired mid-gesture — press plain, hold Cmd, drag, drop, and you get a reorder; codex's phrasing is the accurate one (*"does not arm reorder; existing click behaviour is unchanged"*). (ii) `selection.length` is ambiguous between the PINNED array and the RAW cell, and the shield's docblock records the residual — say which the reorder module reads.

### M20. S47-0's fixture contract is one shorter than G47-8 needs *(codex, sole)*

S47-0 requires runs of **≥4**; G47-8 specifies a run of **5** with a 3-position drag. Raise the contract to ≥5 or name a dedicated run-of-5 fixture. **Pre-mortem item 2 is about exactly this**, so the mismatch is the pre-mortem's own scenario sitting in the plan.

---

## 2. WORTH-CONSIDERING — adopt or reject with a reason

- **`POINTER_DRAG_THRESHOLD_PX` count is off by one, twice.** Four importers ship today (`spacing-affordance-geometry.ts`, `use-canvas-selection-shield.ts`, `use-resize-drag.ts`, `use-spacing-drag.ts`); reorder is the **fifth importer / fourth drag classifier**. The module's own header (*"ONE SYMBOL, THREE CONSUMERS"*) is already stale — correcting it is a free rider on a file this phase reads anyway.
- **§3.7's amendment list is incomplete.** §3.F-1 has six rows; r0 flips two. Row 4 (component instance) **also ships** under this design — an oid-bearing instance is a `JSXElement` and therefore an admissible op-unit — and row 5 (dragging the selection box) is directly about this gesture. Given §3.7's own argument that no gate watches these rows, an incomplete enumeration is the whole hazard.
- **`REORDER_INDICATOR_Z = 44` claims a discipline §5 does not deliver**, and its justification contradicts §3.1(e): the stated reason is *"must never be occluded by furniture"* while §3.1(e) hides the furniture. Two mechanisms for one problem, each justified by the other's absence — pick one. Also mint the inequality gate or drop the claim; the pin lives in `spacing-affordance-geometry.test.ts`, not in `use-resize-handles.ts`.
- **§3.1(e) is ambiguous over five nodes.** The ring layer holds the hover ring, the selection ring, three readouts, the handle layer and the spacing layer. Naming three leaves the rest to an executor's guess — and M4(3) makes the instance hint load-bearing.
- **§3.2(2)'s DOM subject and D47-2's artifact subject are different elements** (`el.parentElement` vs the artifact's `parentOid`). Where a component boundary sits between them they disagree, and the 19 no-oid-parent runs are guaranteed mis-attributed. Say the subject identity once.
- **§2.1's proxy sentence says "comprising" and means "of which"** — 19 + 54 = 73, not 152; the remaining 79 have a real non-flex authored className.
- **§3.1(a) term 5 mixes units** — an element-level predicate citing a run-level figure. The element figure is 578 of 770.
- **§2.3's *"on both file sources"* is imprecise and the fold's home is unnamed.** `computeStructuralEdit` receives both but `moveAdjacent` touches only `pageSource`; the loop belongs inside `computeStructuralEdit`, not around it in `server.ts`. S47-2 should say which.
- **`armTrailingClickSuppression`'s docstring contract widens too** — it reads *"when a gesture ended with the primary button still down"*, and the sole shipped producer gates on `primaryDown`. A reorder terminal arms it on an ordinary `pointerup`. Apply the keep-the-name/correct-the-docstring precedent here as r0 does for `isResizeHandleEvent`.
- **G47-3's mutation is broadly RED** — setting the constant to 40 also moves two render floors, the travel guard and two classifiers. Say the reorder assertion is the *discriminating* leg, not the only RED.
- **§3.F preamble sentence 1 is already false** (since phase-42's resize drag), while the grep-shaped sentence 2 is still literally true — the shipped gestures use `pointermove`, not `mousemove`. R47-8's mechanism is right; the framing overstates.
- **§3.3's byte-exact-undo reason can be cited harder:** `JournalEntry` stores whole-file `before` bytes for **both** declared files, and the structural handler is the only two-file writer — r0's "the whole file" reads as one.
- **Parse cost re-measured** at 2.741 ms on the largest page (39.8 KB), 0.198 ms on the smallest; k ≤ 6 ⇒ ≈16 ms in-lock. Consistent with phase-45. S47-2 still owes the real call shape, but the order of magnitude is settled — say so.
- **DR47-6's grep is 6 hits but 3 code instances** (3 are Korean prose in a `spec.ts`), of which only two are pure direction-reverse. Small, but it is the number S47-0 authors against.
- **§7 claims *"every gate in §5"* settles without the owner while G47-4 is flagged browser-only.** One clarifying sentence that Playwright **is** the running app for that purpose.

---

## 3. LEAD RULINGS on the routed questions

**3.1 — The k = 1 clamp steelman: REJECTED, and the reason is a cost the steelman did not price.** Both the architect and codex independently proposed reducing phase-47 to a one-step drag, deleting `expectDestination`, the fold, G47-8/9/10, R47-4 and §8.3 — roughly a third of the plan and all of its server surface — on the ground that 173 of 235 runs can only produce k = 1 anyway. **The argument is good and it is still wrong here**, because the phase's most expensive instrument is the owner's live pass, and **a clamped gesture measures a crippled one**: a drag across the 62 runs that can produce k ≥ 2 would either refuse or land one position, and the owner would be judging the feel of something the phase does not intend to ship. The saving is real; it is smaller than one wasted live pass. **Keep the fold in S47-2.** Record the steelman and this rejection in the ADR's alternatives — it is the strongest argument against the design's centre of gravity and deserves to be on the record rather than absorbed.

**3.2 — §8.2, KI-47: NOT TAKEN.** It is cheap and it touches the ring, but phase-46's S46-5 records that correcting every routing site was the owner's **stated condition** for excluding the KI-19/49/50 family, and KI-47 was then found to be an unrouted fourth member of it. Adding it back by lead inference reverses an owner condition. **It needs a fresh owner input, not an inference.** Keep §8.2 as a routed question with this ruling recorded and the destination still open.

**3.3 — §8.5, F46-D: LEFT STANDING, unrouted — but r0's ground is not good enough.** The conclusion (phase-47 does not touch `e2e/resize-handles.spec.ts`) is plausible, but it was asserted from ROLE and the plan does not record having read `readScene`'s predicate — which is the thing F46-D is actually about. **Make that grep an S47-6 deliverable**, so the disposition rests on a reading rather than on an inference, and say that F46-D remains unrouted either way.

**3.4 — §8.3: ruled at M15.** Narrow reading stands on the enumeration; the header appeal is dropped; the optionality objection is answered by design.

**3.5 — §8.6: closed and deleted** (M18).

**3.6 — DR47-8 goes to the OWNER, before S47-4** (M17). The lead is asking now. Write §8.1 so that the answer lands as a one-line edit to the plan, and keep both readings cheap as r0 already does.

---

## 4. What round 2 will be

A **primed CLOSURE AUDIT** against this list — per-item verdicts of CLOSED / PARTIAL / NOT CLOSED / **REWORDED-ONLY** — plus an **UNPRIMED re-review** of the current text by a fresh lane. So:

- **A finding closed by rewriting the sentence while leaving the reason intact will be caught and reported as REWORDED-ONLY.** M1, M3, M5, M12, M14, M15 and M19 are the items most exposed to this, because in each the conclusion may survive and only the reason moves.
- **Where a fix changes a decision, sweep for every other claim that decision's REASON supported** — not only the sentences that now contradict it. §0's correction alone reaches P47-4, D47-3, R47-1 and the pre-mortem; M3's reaches P47-1, D47-2, §3.2(3) and §3.5; M18's reaches D47-1, D47-2, §2.1, §8.6 and S47-0.
- Keep the r0 status block's VERIFIED / UNVERIFIED discipline and update it: three lanes independently reproduced §2.1, one re-measured the parse cost, and one drove the k-step fold to completion with controls. **Those move to VERIFIED with the lane named. Nothing has been driven against a running `descvi:dev`, and that stays UNVERIFIED.**
