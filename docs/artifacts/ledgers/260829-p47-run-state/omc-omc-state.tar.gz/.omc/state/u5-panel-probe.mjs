import { chromium } from '@playwright/test';

/**
 * U5 rider probe — is the panel's ↑ / ↓ actually LIVE for a member of a multi-member selection?
 * Driven against the already-running `descvi:dev` on :3001.
 */
const browser = await chromium.launch();
const page = await browser.newPage();

const readPanel = async () =>
  page.evaluate(() => {
    const sec = document.getElementById('dsh-structure-edit');
    const btn = (label) => {
      const b = sec === null ? null : sec.querySelector(`button[aria-label="${label}"]`);
      return b === null ? 'ABSENT' : b.disabled ? 'DISABLED' : 'ENABLED';
    };
    return {
      describedOid: document.getElementById('dsh-name-oid')?.textContent ?? null,
      structureSection: sec === null ? 'ABSENT' : 'PRESENT',
      up: btn('위로 이동'),
      down: btn('아래로 이동'),
    };
  });

const routes = [
  ['/lab/tests/reorder-flow', [['rfcol1', 'rfcol2'], ['rfcol2', 'rfcol1'], ['rfcol3', 'rfcol5']]],
  ['/lab/tests/reorder-refusal', [['rrrtl2', 'rrrtl3'], ['rrltr2', 'rrltr3']]],
];

for (const [route, pairs] of routes) {
  await page.goto('http://localhost:3001' + route);
  await page.waitForSelector('#dsh-ring-layer');
  console.log('\n=== ' + route);
  for (const [a, b] of pairs) {
    await page.locator(`[data-oid="${a}"]`).click();
    const single = await readPanel();
    await page.locator(`[data-oid="${b}"]`).click({ modifiers: ['Shift'] });
    const multi = await readPanel();
    console.log(`  click ${a}            => ${JSON.stringify(single)}`);
    console.log(`  shift-click ${b} (N=2) => ${JSON.stringify(multi)}`);
    await page.keyboard.press('Escape');
  }
}

await browser.close();
