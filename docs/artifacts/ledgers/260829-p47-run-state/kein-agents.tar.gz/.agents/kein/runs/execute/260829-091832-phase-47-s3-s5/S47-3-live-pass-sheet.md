# S47-3 live pass — the sheet

**Assembled by the lead from the plan, 2026-08-29.** ⚠ The list an executor assembled in its round-1 report is **stale** and must not be used: it counts four Korean sentences where there are five, carries the old wording of the fifth, and predates three items added by later review. This sheet is the current one.

**EG-1 has run and decided what this pass leads with.** Eligible **360 / 748 = 48.13 %** → **pass path**: lead with the working gesture; the refusal strings are secondary furniture. Full census at `.agents/kein/reports/260829-eg1-eligible-parent-population.md`.

**DR47-10 binds the shape of this pass: your readings are RECORDED, not silently applied.** Nothing here is a request for approval to ship — S47-3 is landed and the gesture works. Two of the rows are **write-behaviour** questions rather than look questions, marked ⚠**W**, and they are flagged because answering them ratifies what S47-4 will *do*, not what you are looking at.

## Exact targets, taken from EG-1's per-parent dump — no hunting

Every oid below is a measured verdict from the census, not a guess. Start `pnpm descvi:dev` (:3001).

**The working gesture — this is what the pass leads with.**

| Screen | Parent | Drag these | Why this one |
|---|---|---|---|
| `/sandbox/resize-flex-row` | `#P3`, `display: flex` | **`srcdaa` · `srcdbb` · `srcdcc`** | Three siblings, one row, eligible. Every look question below is answerable here. |
| `/sandbox/resize-flex-col` | `#P3`, `display: flex` | **`scrwaa` · `scrwbb` · `scrwcc`** | The column axis. ⚠ Use this screen, **not** `seroot` — every direct child of `seroot` refuses `chain-disagrees`. |

**All five refusal sentences, each with a real target.**

| Sentence | Where | Drag | Gate status |
|---|---|---|---|
| `multi-select` | either sandbox screen | select `srcdaa` **and** `srcdbb`, then drag one of them | driven in e2e |
| `not-flow-order` | `shop/member-detail` `#P16` (`grid`) | `2ww0ca` / `adaq8c` / `jw5z9l` / `39ln4d` | driven in e2e |
| **`no-adjacent-sibling`** | `/sandbox/resize-flex-row` `#P0` | **`srroot`** (an only child) | ⚠ **never rendered by any test** — and its wording changed during this story |
| **`not-one-line`** | `shop/member-list` `#P4` | **`hsq00f`** or **`5g5e8c`** | ⚠ **never rendered by any test** |
| **`chain-disagrees`** | `/sandbox/resize-flex-row` `#P1` | **`srstrp`** or **`srndbb`** (geo 4 slots vs chain 1) | ⚠ **never rendered by any test** |

**Density, if you want to feel what 48 % means.**

| For | Screen |
|---|---|
| Refusals wall-to-wall | `lab/tests/align-enablement` — the corpus's **only 0 %-eligible screen** (0 of 15) |
| Nearly so | `lab/tests/spacing-nesting` — 10.5 % (2 of 19) |
| The friendly end | `lab/challenge/insert-scratch` — 92.3 % (12 of 13) |
| A real HTML table | `shop/order-list` — 97 of the corpus's 125 part-1 refusals live here alone |

## The look questions

| # | Question | What a change costs |
|---|---|---|
| **1** | ⚠ **THE ONE MOST LIKELY TO CHANGE YOUR MIND, and a lane found it by LOOKING rather than reasoning: on a downward drag the insertion line sits A FULL ROW PAST THE POINTER.** Swept in 20 px steps and mapped. It is self-consistent with the shipped rule and nothing was changed on the strength of it — but it is the difference between *"the line shows where this will land"* and *"the line is a row ahead of my finger"*, and **no artifact in this phase ever decided it was the right picture.** It fell out of a rule chosen for correctness. | The rule is one ternary. ⚠ But line-position legs (a) and (b) sample at the exact flip point of this mapping, so they move first — their tolerance gets **re-derived, not widened** |
| **2** | The line's **colour, thickness and inset**. ⚠ Nothing in the suite reads the line's `backgroundColor` — **it is nowhere gated as blue.** You are the first and only check on this. | Constants in `use-reorder-affordances.ts`; S47-5 owes the missing colour gates either way |
| **3** | Does the line sit **between the two neighbours**, or flush against one? Both arms ship: flush at the ends, midpoint in the interior. Drag to the **first slot** specifically — that arm had no gate at all until round 4. | Same ternary as #1 |
| **4** | The readout's **position and content — and whether W×H is the right pair at all.** The owner's own earlier ruling named W×H, so the plan ships it; but W×H is the quantity a RESIZE changes. A reorder changes a **position**. A slot index, or a neighbour's name, may be the better answer. | Content is one function; the pair is a spec question (§3.8) |
| **5** | **The five Korean refusal sentences, read as Korean.** ⚠ Five, not four — and the fifth was **reworded during this story**: it is now `"이 요소에는 순서를 바꿀 형제 요소가 없습니다."`, not the panel's `"이 방향에 형제 요소가 없습니다."` (the panel's version labels per-direction buttons, where "이 방향에" is correct; a drag has no direction). ⚠ **Three of the five have never been rendered in a browser by any test** — `not-one-line`, `chain-disagrees`, and the reworded one. You are the first reader of two of them. | A wording change is a literal. A *sixth* sentence is a scope change and comes to the lead |
| **6** | The **refusal readout's behaviour**: dwell, dismissal, and whether it re-fires on every small drag. At 48 % eligible you will meet refusals about half the time. | Behaviour, not wording — a timer or a suppression rule |
| **7** | **`REORDER_ENGAGE_THRESHOLD_PX = 12`** — is 12 px where your hand expects a drag to begin? The plan rules this a **judgement, not a measurement**; nothing derives it. | One constant, three citations |
| **8** | **A no-op drop** — you drag and come back to where you started. Today it paints a line marking the slot the element is already in, and the release then selects. Defensible, and never decided. | A branch in the paint guard |
| **9** | Dragging an element that is **NOT currently selected** — what should be selected afterwards? Today: nothing changes. A movement gesture is not a selection gesture, which is defensible, and is exactly the kind of thing a plan should not settle alone. | The forward write has no reselect; adding one is S47-4's |

## The write-behaviour questions ⚠**W**

These ratify what S47-4 will **do**. At S47-3 all you can see is a picture; at S47-4 the same gesture writes.

| # | Question | If the answer is "refuse" |
|---|---|---|
| **W1** | **A release OUTSIDE the parent's box.** Open Questions rules it clamps to the nearest end slot. Today a clamped release paints a line and commits nothing; at S47-4 the same gesture commits a `move-up`/`move-down` from a drop you made off-canvas. **Should a release outside the parent commit the clamped move, or refuse?** | A new refusal arm and a **sixth** Korean sentence — a scope change, routed to the lead, not taken inside a story |
| **W2** | **The right-button chord.** Measured, not theorised: press with the RIGHT button on an eligible element, chord the left in, drag past 12 px — **a blue line and a readout paint.** The ordinary seeding site is not button-gated. At S47-3 it is a stray picture; **at S47-4 it is a structural write begun by a right-click.** | Either way, S47-4 **pins your answer** with a row that goes RED under the opposite behaviour. It ships ungated in both directions today precisely so the gate is not written to be reversed |

## How readings come back

Any answer is a reading, including "fine" and "I did not meet this one". ⚠ **A row you could not reach is recorded as unreached with its reason** — phase-46's live pass filed two rows under one reason that belonged to only one of them, and the false half had to be deleted later. If you did not meet something, that is the useful fact; a plausible reason invented after the fact is worse than a blank.

S47-5 lands the readings in `docs/e3/tracker.md`'s phase-47 section, whether or not they are acted on.
