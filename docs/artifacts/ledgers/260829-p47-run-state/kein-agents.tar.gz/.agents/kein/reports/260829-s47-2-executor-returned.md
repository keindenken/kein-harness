# S47-2 — the Executor's returned report, transcribed by the lead

⚠ **PROVENANCE, STATED BECAUSE IT CHANGES HOW THIS FILE SHOULD BE READ.** The S47-2 Executor was a
native `kein:executor` and returned its report as its final message rather than writing one to
`.agents/kein/reports/`, which is where the codex lanes' reports land by their own output contract.
A review lane correctly reported the absence: it could not verify any S47-2 RED-when claim because
no by-number table existed in the tree. This file is the lead transcribing that returned report so
the record is complete. **It is a transcription, not a fresh measurement**, and the review lane's
point stands: a source reading of a Path and a driven mutation are different things, and only the
second is evidence.

## RED-when table as the Executor reported it

| # | Driven? | Reported result |
|---|---|---|
| **2** (Leg A) | yes | Moving the seeding call above ROW D: tracker flips null → non-null. The Executor also reports its FIRST implementation could not discriminate this — conditional seeding made the assertion structurally blind — found by driving, not by reading, and fixed. |
| **3** (Leg B) | yes | Seeding above ROW P: same flip, plus 3 incidental rows. |
| **4** (Leg C) | **NO — "time-boxed out"** | Control verified green under ruled code; the compound mutation (`preventDefault` + move above ROW P) was never applied. |
| **5** | yes | A separate unconditional seed statement outside the closure lets the `mousedown` half re-seed; reference-identity check flips. |
| **6, 7** | **no** | Claimed inherited unchanged from phase-45's own `activeTravelGestureRef` mechanism, already driven by `canvas-selection-shield-travel.test.tsx`. |
| **8** (must-show) | yes | A PERSISTING `maxTravelRef.current = 0` inside the reorder consumer flips the Shift-drag swallow 0 → 1. |
| **10** | yes | Via the combined "seed gated on modifier" mutation; flips with 49, 53, 56. |
| **11** | **no** | Claimed no RED-when distinct from 10's stated in the plan. |
| **12, 15(b)** | **not run** | e2e-only; the ports were held by a sibling worktree's `descvi:dev` at the time. The lead ran them later: both PASS. |
| **13** | yes | Swallow keyed on `armed && thresholdCrossed` instead of `engaged && dropIndex ≠ sourceIndex`: a refused gesture's click is wrongly swallowed. |
| **14** | yes | `REORDER_ENGAGE_THRESHOLD_PX` lowered to 4: an 8 px eligible drag wrongly swallows. |
| **15(a)** | yes | Click-time read left unconditional: a second click wrongly stays swallowed. |
| **49, 53, 56** | yes | Same combined modifier mutation as 10. |
| **54** (must-show) | yes | COMPOUND — revert clause 1 AND remove clause 5 → reported subject reads A, not B. Half (i) alone produces a **dead press** (`tracker() === null`), which is the plan's own stated second failure shape and not this row's RED. |
| **55** (must-show) | yes | Clause 2's button condition dropped: a buttonless traverse wrongly accumulates. |
| **57** | yes | Subject from `selectionRef.current[0]` instead of the press target; flips, plus 4 incidental rows. |
| **58** (must-show) | yes | Clause 5's listener removed alone: all three legs (ROW D, ROW P, off-stage `#dsh-panel`) flip, and the ordinary-element control stays green — which is what proves the mutation did not simply kill every tracker. |

**None was reported `NONE — non-discriminating`.**

⚠ **The Executor also states it confirmed §3.2's consumer-ordering ruling by READING `onTravel` back
after its edit rather than by a green suite** — which is what the brief asked for, because the
ordering is exactly the thing a green suite cannot distinguish.

## The departures it reported, with its own reasons

- **`ReorderTrackerState.subject` is `Element | null`, not `Element`.** §3.1's Legs A and B need
  seeding to be unconditional — a press with no resolvable `[data-oid]` target still seeds, with a
  null subject that can never reach `engaged`. Its first draft made seeding conditional on subject
  resolution, and that made Legs A and B **structurally unable to discriminate their own mutation**,
  because subject resolution's container check refused before the arm-order bug could be observed.
- **jsdom returns `""` for an unset `getComputedStyle(el).order`, not the CSS-spec `"0"`.** Every
  eligible fixture in the jsdom rig sets `style.order = "0"` explicitly for that reason. This
  package's suite had not previously exercised that reader.
- **The hook's return type changed from `void` to `RefObject<ReorderTrackerState | null>`** — a seam
  S47-3 and S47-4 consume, not yet read in production.

## What it routed to the lead rather than deciding

The citation-anchor gate went RED on 7 plan citations, because this story is *ruled* to split the two
shipped lines the plan pins. It identified unique replacement anchors but **did not edit the plan**,
on the ground that a shared RALPLAN-governed artifact is not an Executor's to rewrite. The lead
re-anchored them per line — the same stale string meant three different things across its five uses,
so a blanket substitution would have been wrong — and the gate returned GREEN at 1079 citations.
