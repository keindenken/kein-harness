# EG-1 — per-parent sequence dump (306 candidate parents, all 24 screens)

Companion to `.agents/kein/reports/260829-eg1-eligible-parent-population.md`. Generated 2026-08-29T11:54:57.965Z by the EG-1 walk — descvi:dev :3001, chromium 1440x900, the DEFAULT state of every screen. One row per UNIQUE candidate parent, eligible or not, per plan §6 EG-1's round-1 correction.

Columns:

- **n** — the parent's rendered element-child count (the sibling count the maximum reading is taken over).
- **verdict** — the SHIPPED module's own return value. Nothing in this file re-implements the predicate.
- **geo** — the geometric slot list: rendered element children in DOM order, each shown as the oid `SourceResolver.resolve()` answers for it. An oid-LESS child resolves UP to its nearest oid-bearing ancestor, so it shows that ancestor's oid rather than a hole — see the **stamp** column.
- **stamp** — one character per slot in the same order: `o` = the slot carries its own `data-oid`, `-` = it does not (an unstamped host wrapper). A `-` is what makes a geo entry a resolved-up ancestor rather than the slot's own identity.
- **chain** — the engine chain in source order, built by walking `prevOid`/`nextOid` through `editMap.oids[screenId]` from the dragged element's entry (plan §3.7's definition). DIAGNOSTIC ONLY — the shipped predicate reconciles by pairwise adjacency over rendered siblings instead. This column exists so the divergence is readable.
- **diff** — first index at which geo and chain differ; `-1` = identical as sequences.

The STOP condition is the conjunction `verdict = eligible` AND `diff != -1`. It occurs on zero rows in this file.

## lab/challenge/dynamic-shapes  (9 candidate parents, 22 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/dynamic-shapes#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["dxroot"]` | `o` | `["dxroot"]` |
| lab/challenge/dynamic-shapes#P1 | flex | 2 | eligible | 2 | 2 | -1 | `["dxhead","dxintr"]` | `oo` | `["dxhead","dxintr"]` |
| lab/challenge/dynamic-shapes#P2 | flex | 5 | chain-disagrees | 5 | 3 | 0 | `["dxroot","dxlgsc","dxncsc","dxstep","dxcont"]` | `-oooo` | `["dxlgsc","dxncsc","dxstep"]` |
| lab/challenge/dynamic-shapes#P3 | flex | 2 | eligible | 2 | 2 | -1 | `["dxlghd","dxlgbx"]` | `oo` | `["dxlghd","dxlgbx"]` |
| lab/challenge/dynamic-shapes#P4 | flex | 3 | chain-disagrees | 3 | 1 | 1 | `["dxlgnd","dxlgnd","dxlgnd"]` | `ooo` | `["dxlgnd"]` |
| lab/challenge/dynamic-shapes#P5 | flex | 2 | eligible | 2 | 2 | -1 | `["dxnchd","dxncsp"]` | `oo` | `["dxnchd","dxncsp"]` |
| lab/challenge/dynamic-shapes#P6 | flex | 3 | chain-disagrees | 3 | 1 | 1 | `["dxncit","dxncit","dxncit"]` | `ooo` | `["dxncit"]` |
| lab/challenge/dynamic-shapes#P7 | flex | 2 | eligible | 2 | 2 | -1 | `["dxsthd","dxstls"]` | `oo` | `["dxsthd","dxstls"]` |
| lab/challenge/dynamic-shapes#P8 | flex | 3 | chain-disagrees | 3 | 1 | 1 | `["dxmrow","dxmrow","dxmrow"]` | `ooo` | `["dxmrow"]` |

## lab/challenge/focus-steal  (5 candidate parents, 11 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/focus-steal#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["fsroot"]` | `o` | `["fsroot"]` |
| lab/challenge/focus-steal#P1 | flex | 2 | eligible | 2 | 2 | -1 | `["fshead","fsintr"]` | `oo` | `["fshead","fsintr"]` |
| lab/challenge/focus-steal#P2 | flex | 4 | chain-disagrees | 4 | 2 | 0 | `["fsroot","fsplay","fsstep","fshint"]` | `-ooo` | `["fsplay","fsstep"]` |
| lab/challenge/focus-steal#P3 | flex | 3 | eligible | 3 | 3 | -1 | `["fsplhd","fspla1","fspla2"]` | `ooo` | `["fsplhd","fspla1","fspla2"]` |
| lab/challenge/focus-steal#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["fssthd","fsstls"]` | `oo` | `["fssthd","fsstls"]` |

## lab/challenge/insert-scratch  (6 candidate parents, 13 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/insert-scratch#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["gkmcvp"]` | `o` | `["gkmcvp"]` |
| lab/challenge/insert-scratch#P1 | flex | 4 | eligible | 4 | 4 | -1 | `["f5n1lq","2tpfwo","gkuwxr","2zsycz"]` | `oooo` | `["f5n1lq","2tpfwo","gkuwxr","2zsycz"]` |
| lab/challenge/insert-scratch#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["m6zvjh","d3fgri"]` | `oo` | `["m6zvjh","d3fgri"]` |
| lab/challenge/insert-scratch#P3 | flex | 2 | eligible | 2 | 2 | -1 | `["scvae1","2m6bqb"]` | `oo` | `["scvae1","2m6bqb"]` |
| lab/challenge/insert-scratch#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["fhdz0o","e7ngbk"]` | `oo` | `["fhdz0o","e7ngbk"]` |
| lab/challenge/insert-scratch#P5 | flex | 2 | eligible | 2 | 2 | -1 | `["fgx3d9","vk2ebz"]` | `oo` | `["fgx3d9","vk2ebz"]` |

## lab/challenge/nested-scroll  (7 candidate parents, 18 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/nested-scroll#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["nsroot"]` | `o` | `["nsroot"]` |
| lab/challenge/nested-scroll#P1 | flex | 2 | eligible | 2 | 2 | -1 | `["nhead1","nintro"]` | `oo` | `["nhead1","nintro"]` |
| lab/challenge/nested-scroll#P2 | flex | 4 | chain-disagrees | 4 | 3 | 0 | `["nsroot","nctl01","nsclsc","nsteps"]` | `-ooo` | `["nctl01","nsclsc","nsteps"]` |
| lab/challenge/nested-scroll#P3 | flex | 2 | eligible | 2 | 2 | -1 | `["nctlhd","ndirct"]` | `oo` | `["nctlhd","ndirct"]` |
| lab/challenge/nested-scroll#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["nschhd","nscrlr"]` | `oo` | `["nschhd","nscrlr"]` |
| lab/challenge/nested-scroll#P5 | block | 6 | eligible | 6 | 6 | -1 | `["nrow01","nrow02","nrow03","nrow04","nrow05","nrow06"]` | `oooooo` | `["nrow01","nrow02","nrow03","nrow04","nrow05","nrow06"]` |
| lab/challenge/nested-scroll#P6 | flex | 2 | eligible | 2 | 2 | -1 | `["nsthdg","nstlst"]` | `oo` | `["nsthdg","nstlst"]` |

## lab/challenge/relocation  (5 candidate parents, 10 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/relocation#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["c7v2md"]` | `o` | `["c7v2md"]` |
| lab/challenge/relocation#P1 | flex | 2 | eligible | 2 | 2 | -1 | `["c4pn1s","cq83fe"]` | `oo` | `["c4pn1s","cq83fe"]` |
| lab/challenge/relocation#P2 | flex | 3 | chain-disagrees | 3 | 2 | 0 | `["c7v2md","cm5rt0","cb9sqt"]` | `-oo` | `["cm5rt0","cb9sqt"]` |
| lab/challenge/relocation#P3 | flex | 3 | eligible | 3 | 3 | -1 | `["ck1zwb","c6dhx9","cz0ju4"]` | `ooo` | `["ck1zwb","c6dhx9","cz0ju4"]` |
| lab/challenge/relocation#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["cn2elr","cw6ka3"]` | `oo` | `["cn2elr","cw6ka3"]` |

## lab/challenge/swallowed-oid  (10 candidate parents, 20 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/challenge/swallowed-oid#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["wsroot"]` | `o` | `["wsroot"]` |
| lab/challenge/swallowed-oid#P1 | flex | 2 | eligible | 2 | 2 | -1 | `["whead1","wintro"]` | `oo` | `["whead1","wintro"]` |
| lab/challenge/swallowed-oid#P2 | flex | 4 | chain-disagrees | 4 | 3 | 0 | `["wsroot","wctl01","wgrsec","wsteps"]` | `-ooo` | `["wctl01","wgrsec","wsteps"]` |
| lab/challenge/swallowed-oid#P3 | flex | 2 | eligible | 2 | 2 | -1 | `["wctlhd","wdirct"]` | `oo` | `["wctlhd","wdirct"]` |
| lab/challenge/swallowed-oid#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["wgrshd","wgrid1"]` | `oo` | `["wgrshd","wgrid1"]` |
| lab/challenge/swallowed-oid#P5 | flex | 2 | eligible | 2 | 2 | -1 | `["wflbl3","wfval7"]` | `oo` | `["wflbl3","wfval7"]` |
| lab/challenge/swallowed-oid#P6 | flex | 2 | eligible | 2 | 2 | -1 | `["wflbl3","wfval7"]` | `oo` | `["wflbl3","wfval7"]` |
| lab/challenge/swallowed-oid#P7 | flex | 2 | eligible | 2 | 2 | -1 | `["wflbl3","wfval7"]` | `oo` | `["wflbl3","wfval7"]` |
| lab/challenge/swallowed-oid#P8 | flex | 2 | eligible | 2 | 2 | -1 | `["wflbl3","wfval7"]` | `oo` | `["wflbl3","wfval7"]` |
| lab/challenge/swallowed-oid#P9 | flex | 2 | eligible | 2 | 2 | -1 | `["wsthdg","wstlst"]` | `oo` | `["wsthdg","wstlst"]` |

## lab/tests/align-enablement  (7 candidate parents, 15 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/align-enablement#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["aeroot"]` | `o` | `["aeroot"]` |
| lab/tests/align-enablement#P1 | block | 5 | chain-disagrees | 5 | 3 | 0 | `["aeroot","aerrev","aecrev","aewrev","aebrev"]` | `-oooo` | `["aerrev","aecrev","aewrev"]` |
| lab/tests/align-enablement#P2 | block | 3 | chain-disagrees | 3 | 2 | 0 | `["aeroot","aerowa","aenowr"]` | `-oo` | `["aerowa","aenowr"]` |
| lab/tests/align-enablement#P3 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["aeroot","aeinlf"]` | `-o` | `["aeinlf"]` |
| lab/tests/align-enablement#P4 | block | 6 | chain-disagrees | 6 | 5 | 0 | `["aeroot","aevdir","aevitm","aevwrp","aeiwrp","aevcnt"]` | `-ooooo` | `["aevdir","aevitm","aevwrp","aeiwrp","aevcnt"]` |
| lab/tests/align-enablement#P5 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["aeroot","aediag"]` | `-o` | `["aediag"]` |
| lab/tests/align-enablement#P6 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["aeroot","aeleaf"]` | `-o` | `["aeleaf"]` |

## lab/tests/align-wrap  (8 candidate parents, 11 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/align-wrap#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["awroot"]` | `o` | `["awroot"]` |
| lab/tests/align-wrap#P1 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["awroot","awf1cn"]` | `-o` | `["awf1cn"]` |
| lab/tests/align-wrap#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["awf1ca","awf1cb"]` | `oo` | `["awf1ca","awf1cb"]` |
| lab/tests/align-wrap#P3 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["awroot","awf2cn"]` | `-o` | `["awf2cn"]` |
| lab/tests/align-wrap#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["awf2ca","awf2cb"]` | `oo` | `["awf2ca","awf2cb"]` |
| lab/tests/align-wrap#P5 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["awf2cc"]` | `o` | `["awf2cc"]` |
| lab/tests/align-wrap#P6 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["awroot","awhgcn"]` | `-o` | `["awhgcn"]` |
| lab/tests/align-wrap#P7 | flex | 2 | eligible | 2 | 2 | -1 | `["awhgca","awhgcb"]` | `oo` | `["awhgca","awhgcb"]` |

## lab/tests/shared-oid  (11 candidate parents, 28 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/shared-oid#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["d5w9j4"]` | `o` | `["d5w9j4"]` |
| lab/tests/shared-oid#P1 | block | 6 | chain-disagrees | 6 | 1 | 1 | `["d2k7q8","d3v8n5","d1z5g6","dn6y1c","dbr0p9","dl8j2r"]` | `oooooo` | `["d2k7q8"]` |
| lab/tests/shared-oid#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["d6r3m1","d9x4t2"]` | `oo` | `["d6r3m1","d9x4t2"]` |
| lab/tests/shared-oid#P3 | flex | 5 | chain-disagrees | 5 | 1 | 1 | `["d7c2h9","d7c2h9","d7c2h9","d7c2h9","d7c2h9"]` | `ooooo` | `["d7c2h9"]` |
| lab/tests/shared-oid#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["d4b6s3","d8m1w7"]` | `oo` | `["d4b6s3","d8m1w7"]` |
| lab/tests/shared-oid#P5 | flex | 2 | eligible | 2 | 2 | -1 | `["d4b6s3","d8m1w7"]` | `oo` | `["d4b6s3","d8m1w7"]` |
| lab/tests/shared-oid#P6 | flex | 2 | eligible | 2 | 2 | -1 | `["d4b6s3","d8m1w7"]` | `oo` | `["d4b6s3","d8m1w7"]` |
| lab/tests/shared-oid#P7 | flex | 2 | eligible | 2 | 2 | -1 | `["d4b6s3","d8m1w7"]` | `oo` | `["d4b6s3","d8m1w7"]` |
| lab/tests/shared-oid#P8 | flex | 1 | no-adjacent-sibling | 1 | 2 | 1 | `["d4b6s3"]` | `o` | `["d4b6s3","d8m1w7"]` |
| lab/tests/shared-oid#P9 | block | 3 | eligible | 3 | 3 | -1 | `["d0p4k8","dg5w4p","dp3n8v"]` | `ooo` | `["d0p4k8","dg5w4p","dp3n8v"]` |
| lab/tests/shared-oid#P10 | block | 2 | eligible | 2 | 2 | -1 | `["dbrs01","dbrs02"]` | `oo` | `["dbrs01","dbrs02"]` |

## lab/tests/single-screen  (10 candidate parents, 26 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/single-screen#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["b4k9p2"]` | `o` | `["b4k9p2"]` |
| lab/tests/single-screen#P1 | block | 3 | chain-disagrees | 3 | 1 | 1 | `["b7h2qw","binf05","bbdy3p"]` | `ooo` | `["b7h2qw"]` |
| lab/tests/single-screen#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["btl3xk","bpg1zv"]` | `oo` | `["btl3xk","bpg1zv"]` |
| lab/tests/single-screen#P3 | block | 2 | eligible | 2 | 2 | -1 | `["blbfar","bath4c"]` | `oo` | `["blbfar","bath4c"]` |
| lab/tests/single-screen#P4 | block | 2 | eligible | 2 | 2 | -1 | `["blbfda","bdat2m"]` | `oo` | `["blbfda","bdat2m"]` |
| lab/tests/single-screen#P5 | block | 2 | eligible | 2 | 2 | -1 | `["blbfst","bsts7n"]` | `oo` | `["blbfst","bsts7n"]` |
| lab/tests/single-screen#P6 | block | 2 | eligible | 2 | 2 | -1 | `["blbftl","btin6x"]` | `oo` | `["blbftl","btin6x"]` |
| lab/tests/single-screen#P7 | block | 6 | chain-disagrees | 6 | 3 | 2 | `["blbfbd","bbta9r","bsvst9","btag4h","bcda7v","bbdy3p"]` | `ooooo-` | `["blbfbd","bbta9r","bwrn5t"]` |
| lab/tests/single-screen#P8 | flex | 6 | chain-disagrees | 6 | 1 | 1 | `["btagit","btagit","btagit","btagpm","btagpm","btagpm"]` | `oooooo` | `["btagit"]` |
| lab/tests/single-screen#P9 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["bsav8k"]` | `o` | `["bsav8k"]` |

## lab/tests/spacing-nesting  (18 candidate parents, 19 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/spacing-nesting#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["snroot"]` | `o` | `["snroot"]` |
| lab/tests/spacing-nesting#P1 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpbed"]` | `-o` | `["snpbed"]` |
| lab/tests/spacing-nesting#P2 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpaxe"]` | `-o` | `["snpaxe"]` |
| lab/tests/spacing-nesting#P3 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngapn"]` | `-o` | `["sngapn"]` |
| lab/tests/spacing-nesting#P4 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpcol"]` | `-o` | `["snpcol"]` |
| lab/tests/spacing-nesting#P5 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngaco"]` | `-o` | `["sngaco"]` |
| lab/tests/spacing-nesting#P6 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpzer"]` | `-o` | `["snpzer"]` |
| lab/tests/spacing-nesting#P7 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngaut"]` | `-o` | `["sngaut"]` |
| lab/tests/spacing-nesting#P8 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngzro"]` | `-o` | `["sngzro"]` |
| lab/tests/spacing-nesting#P9 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngthn"]` | `-o` | `["sngthn"]` |
| lab/tests/spacing-nesting#P10 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpthn"]` | `-o` | `["snpthn"]` |
| lab/tests/spacing-nesting#P11 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpflu"]` | `-o` | `["snpflu"]` |
| lab/tests/spacing-nesting#P12 | flex | 2 | eligible | 2 | 2 | -1 | `["snpfla","snpflb"]` | `oo` | `["snpfla","snpflb"]` |
| lab/tests/spacing-nesting#P13 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snglrg"]` | `-o` | `["snglrg"]` |
| lab/tests/spacing-nesting#P14 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snpvar"]` | `-o` | `["snpvar"]` |
| lab/tests/spacing-nesting#P15 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snnflx"]` | `-o` | `["snnflx"]` |
| lab/tests/spacing-nesting#P16 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","snbflr"]` | `-o` | `["snbflr"]` |
| lab/tests/spacing-nesting#P17 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["snroot","sngwrp"]` | `-o` | `["sngwrp"]` |

## lab/tests/style-edit  (7 candidate parents, 14 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/style-edit#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["seroot"]` | `o` | `["seroot"]` |
| lab/tests/style-edit#P1 | flex | 6 | chain-disagrees | 6 | 1 | 1 | `["5n09bh","v002k2","5pznp9","sms60s","hakgqo","gvxwrq"]` | `oooooo` | `["5n09bh"]` |
| lab/tests/style-edit#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["ymjg9i","jy3px6"]` | `oo` | `["ymjg9i","jy3px6"]` |
| lab/tests/style-edit#P3 | flex | 2 | eligible | 2 | 2 | -1 | `["xnf2ei","pezi4o"]` | `oo` | `["xnf2ei","pezi4o"]` |
| lab/tests/style-edit#P4 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["syp8pf"]` | `o` | `["syp8pf"]` |
| lab/tests/style-edit#P5 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["5heefd"]` | `o` | `["5heefd"]` |
| lab/tests/style-edit#P6 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["xrnk7s"]` | `o` | `["xrnk7s"]` |

## lab/tests/three-screen  (10 candidate parents, 20 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/three-screen#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["a0zk3r"]` | `o` | `["a0zk3r"]` |
| lab/tests/three-screen#P1 | block | 5 | chain-disagrees | 5 | 1 | 1 | `["asf1p9","a8jd5w","a4gs7u","ayl9d3","axe5g7"]` | `ooooo` | `["asf1p9"]` |
| lab/tests/three-screen#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["a7pf2q","a2vc9m"]` | `oo` | `["a7pf2q","a2vc9m"]` |
| lab/tests/three-screen#P3 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["a8jd5w","a1rb6y"]` | `-o` | `["a1rb6y"]` |
| lab/tests/three-screen#P4 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["a8jd5w","a5tn0x"]` | `-o` | `["a5tn0x"]` |
| lab/tests/three-screen#P5 | block | 3 | chain-disagrees | 3 | 2 | 0 | `["a8jd5w","abr0p7","a3ndlk"]` | `-oo` | `["abr0p7","a3ndlk"]` |
| lab/tests/three-screen#P6 | block | 2 | eligible | 2 | 2 | -1 | `["abrs01","abrs02"]` | `oo` | `["abrs01","abrs02"]` |
| lab/tests/three-screen#P7 | inline | 1 | not-flow-order | 1 | 1 | -1 | `["a6hq3e"]` | `o` | `["a6hq3e"]` |
| lab/tests/three-screen#P8 | block | 4 | chain-disagrees | 4 | 3 | 0 | `["a4gs7u","a9kx1p","a0mw8f","azb4c2"]` | `-ooo` | `["a9kx1p","a0mw8f","azb4c2"]` |
| lab/tests/three-screen#P9 | flex | 2 | eligible | 2 | 2 | -1 | `["awn2h4","a9wt4c"]` | `oo` | `["awn2h4","a9wt4c"]` |

## lab/tests/three-screen::approve-modal  (5 candidate parents, 7 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/three-screen::approve-modal#P0 | block | 2 | not-one-line | 2 | 1 | 0 | `["a0zk3r","aq4z2b"]` | `-o` | `["aq4z2b"]` |
| lab/tests/three-screen::approve-modal#P1 | block | 2 | eligible | 2 | 2 | -1 | `["apc9m3","aok5w7"]` | `oo` | `["apc9m3","aok5w7"]` |
| lab/tests/three-screen::approve-modal#P2 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["aq4z2b","anj1t8"]` | `-o` | `["anj1t8"]` |
| lab/tests/three-screen::approve-modal#P3 | block | 3 | chain-disagrees | 3 | 1 | 0 | `["aq4z2b","aq4z2b","apbtn7"]` | `--o` | `["apbtn7"]` |
| lab/tests/three-screen::approve-modal#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["amv6y2","alx3q9"]` | `oo` | `["amv6y2","alx3q9"]` |

## lab/tests/three-screen::reject-modal  (5 candidate parents, 7 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| lab/tests/three-screen::reject-modal#P0 | block | 2 | not-one-line | 2 | 1 | 0 | `["a0zk3r","akb8r4"]` | `-o` | `["akb8r4"]` |
| lab/tests/three-screen::reject-modal#P1 | block | 2 | eligible | 2 | 2 | -1 | `["ajd2n6","aih7c1"]` | `oo` | `["ajd2n6","aih7c1"]` |
| lab/tests/three-screen::reject-modal#P2 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["akb8r4","ahz5v3"]` | `-o` | `["ahz5v3"]` |
| lab/tests/three-screen::reject-modal#P3 | block | 2 | chain-disagrees | 2 | 1 | 0 | `["akb8r4","agt9f2"]` | `-o` | `["agt9f2"]` |
| lab/tests/three-screen::reject-modal#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["afp4l8","aem1s5"]` | `oo` | `["afp4l8","aem1s5"]` |

## sandbox/resize-flex-col  (7 candidate parents, 16 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| sandbox/resize-flex-col#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["scroot"]` | `o` | `["scroot"]` |
| sandbox/resize-flex-col#P1 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["schead","scstck","scndaa","sclnkk"]` | `oooo` | `["schead"]` |
| sandbox/resize-flex-col#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["scttll","scsubb"]` | `oo` | `["scttll","scsubb"]` |
| sandbox/resize-flex-col#P3 | flex | 3 | eligible | 3 | 3 | -1 | `["scrwaa","scrwbb","scrwcc"]` | `ooo` | `["scrwaa","scrwbb","scrwcc"]` |
| sandbox/resize-flex-col#P4 | block | 2 | eligible | 2 | 2 | -1 | `["scrwal","scrwav"]` | `oo` | `["scrwal","scrwav"]` |
| sandbox/resize-flex-col#P5 | block | 2 | eligible | 2 | 2 | -1 | `["scrwbl","scrwbv"]` | `oo` | `["scrwbl","scrwbv"]` |
| sandbox/resize-flex-col#P6 | block | 2 | eligible | 2 | 2 | -1 | `["scrwcl","scrwcv"]` | `oo` | `["scrwcl","scrwcv"]` |

## sandbox/resize-flex-row  (7 candidate parents, 16 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| sandbox/resize-flex-row#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["srroot"]` | `o` | `["srroot"]` |
| sandbox/resize-flex-row#P1 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["srhead","srstrp","srndbb","srlnkk"]` | `oooo` | `["srhead"]` |
| sandbox/resize-flex-row#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["srttll","srsubb"]` | `oo` | `["srttll","srsubb"]` |
| sandbox/resize-flex-row#P3 | flex | 3 | eligible | 3 | 3 | -1 | `["srcdaa","srcdbb","srcdcc"]` | `ooo` | `["srcdaa","srcdbb","srcdcc"]` |
| sandbox/resize-flex-row#P4 | block | 2 | eligible | 2 | 2 | -1 | `["srcdal","srcdav"]` | `oo` | `["srcdal","srcdav"]` |
| sandbox/resize-flex-row#P5 | block | 2 | eligible | 2 | 2 | -1 | `["srcdbl","srcdbv"]` | `oo` | `["srcdbl","srcdbv"]` |
| sandbox/resize-flex-row#P6 | block | 2 | eligible | 2 | 2 | -1 | `["srcdcl","srcdcv"]` | `oo` | `["srcdcl","srcdcv"]` |

## sandbox/resize-repeat-list  (8 candidate parents, 23 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| sandbox/resize-repeat-list#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["smroot"]` | `o` | `["smroot"]` |
| sandbox/resize-repeat-list#P1 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["smhead","smlist","smndaa","smlnkk"]` | `oooo` | `["smhead"]` |
| sandbox/resize-repeat-list#P2 | flex | 2 | eligible | 2 | 2 | -1 | `["smttll","smsubb"]` | `oo` | `["smttll","smsubb"]` |
| sandbox/resize-repeat-list#P3 | flex | 4 | chain-disagrees | 4 | 1 | 1 | `["smroww","smroww","smroww","smroww"]` | `oooo` | `["smroww"]` |
| sandbox/resize-repeat-list#P4 | flex | 3 | eligible | 3 | 3 | -1 | `["smcell","smname","smtagg"]` | `ooo` | `["smcell","smname","smtagg"]` |
| sandbox/resize-repeat-list#P5 | flex | 3 | eligible | 3 | 3 | -1 | `["smcell","smname","smtagg"]` | `ooo` | `["smcell","smname","smtagg"]` |
| sandbox/resize-repeat-list#P6 | flex | 3 | eligible | 3 | 3 | -1 | `["smcell","smname","smtagg"]` | `ooo` | `["smcell","smname","smtagg"]` |
| sandbox/resize-repeat-list#P7 | flex | 3 | eligible | 3 | 3 | -1 | `["smcell","smname","smtagg"]` | `ooo` | `["smcell","smname","smtagg"]` |

## shop/member-detail  (37 candidate parents, 84 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/member-detail#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["5chpob"]` | `o` | `["5chpob"]` |
| shop/member-detail#P1 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["xttsu7"]` | `o` | `["xttsu7"]` |
| shop/member-detail#P2 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["ok9do5","n72jou","i2q127","y3ngs5"]` | `oooo` | `["ok9do5"]` |
| shop/member-detail#P3 | flex | 3 | eligible | 3 | 3 | -1 | `["q3ce6o","h1wgib","0mfpz4"]` | `ooo` | `["q3ce6o","h1wgib","0mfpz4"]` |
| shop/member-detail#P4 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["zpdi86"]` | `o` | `["zpdi86"]` |
| shop/member-detail#P5 | flex | 2 | eligible | 2 | 2 | -1 | `["iiopjf","t1enbb"]` | `oo` | `["iiopjf","t1enbb"]` |
| shop/member-detail#P6 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["mtusgi"]` | `o` | `["mtusgi"]` |
| shop/member-detail#P7 | block | 2 | eligible | 2 | 2 | -1 | `["nll7kl","yf1y6t"]` | `oo` | `["nll7kl","yf1y6t"]` |
| shop/member-detail#P8 | grid | 4 | not-flow-order | 4 | 1 | 1 | `["htv5mk","htv5mk","htv5mk","htv5mk"]` | `oooo` | `["htv5mk"]` |
| shop/member-detail#P9 | block | 2 | eligible | 2 | 2 | -1 | `["2rd6lb","0bl54n"]` | `oo` | `["2rd6lb","0bl54n"]` |
| shop/member-detail#P10 | block | 2 | eligible | 2 | 2 | -1 | `["2rd6lb","0bl54n"]` | `oo` | `["2rd6lb","0bl54n"]` |
| shop/member-detail#P11 | block | 2 | eligible | 2 | 2 | -1 | `["2rd6lb","0bl54n"]` | `oo` | `["2rd6lb","0bl54n"]` |
| shop/member-detail#P12 | block | 2 | eligible | 2 | 2 | -1 | `["2rd6lb","0bl54n"]` | `oo` | `["2rd6lb","0bl54n"]` |
| shop/member-detail#P13 | flex | 3 | chain-disagrees | 3 | 1 | 1 | `["x5hoyo","x5hoyo","x5hoyo"]` | `ooo` | `["x5hoyo"]` |
| shop/member-detail#P14 | block | 2 | chain-disagrees | 2 | 1 | 1 | `["7wzm5j","7xtale"]` | `oo` | `["7wzm5j"]` |
| shop/member-detail#P15 | block | 3 | eligible | 3 | 3 | -1 | `["i12r2q","rd7gp2","j5q8xv"]` | `ooo` | `["i12r2q","rd7gp2","j5q8xv"]` |
| shop/member-detail#P16 | grid | 4 | not-flow-order | 4 | 4 | -1 | `["2ww0ca","adaq8c","jw5z9l","39ln4d"]` | `oooo` | `["2ww0ca","adaq8c","jw5z9l","39ln4d"]` |
| shop/member-detail#P17 | block | 2 | eligible | 2 | 2 | -1 | `["djtskk","76mxpy"]` | `oo` | `["djtskk","76mxpy"]` |
| shop/member-detail#P18 | block | 2 | eligible | 2 | 2 | -1 | `["yktmif","t9t540"]` | `oo` | `["yktmif","t9t540"]` |
| shop/member-detail#P19 | block | 2 | eligible | 2 | 2 | -1 | `["291s5n","li432p"]` | `oo` | `["291s5n","li432p"]` |
| shop/member-detail#P20 | block | 2 | eligible | 2 | 2 | -1 | `["89rhup","uj2td0"]` | `oo` | `["89rhup","uj2td0"]` |
| shop/member-detail#P21 | block | 3 | eligible | 3 | 3 | -1 | `["kobuo6","np09eb","lias41"]` | `ooo` | `["kobuo6","np09eb","lias41"]` |
| shop/member-detail#P22 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["xmfe8u"]` | `o` | `["xmfe8u"]` |
| shop/member-detail#P23 | block | 3 | eligible | 3 | 3 | -1 | `["ejll90","nuxbli","f5pwkq"]` | `ooo` | `["ejll90","nuxbli","f5pwkq"]` |
| shop/member-detail#P24 | flex | 2 | eligible | 2 | 2 | -1 | `["jbtzr7","xpy5eu"]` | `oo` | `["jbtzr7","xpy5eu"]` |
| shop/member-detail#P25 | flex | 3 | eligible | 3 | 3 | -1 | `["pje5wb","yuct1c","w2qz8a"]` | `ooo` | `["pje5wb","yuct1c","w2qz8a"]` |
| shop/member-detail#P26 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["morsj0"]` | `o` | `["morsj0"]` |
| shop/member-detail#P27 | flex | 4 | chain-disagrees | 4 | 1 | 1 | `["nml1bd","nml1bd","nml1bd","nml1bd"]` | `oooo` | `["nml1bd"]` |
| shop/member-detail#P28 | block | 2 | chain-disagrees | 2 | 1 | 1 | `["qhcya7","8qgfwe"]` | `oo` | `["qhcya7"]` |
| shop/member-detail#P29 | flex | 2 | eligible | 2 | 2 | -1 | `["tmoh8r","7ozvu2"]` | `oo` | `["tmoh8r","7ozvu2"]` |
| shop/member-detail#P30 | block | 2 | chain-disagrees | 2 | 1 | 1 | `["zngxtd","zngxtd"]` | `oo` | `["zngxtd"]` |
| shop/member-detail#P31 | flex | 3 | eligible | 3 | 3 | -1 | `["kveehi","rquq0n","qprajq"]` | `ooo` | `["kveehi","rquq0n","qprajq"]` |
| shop/member-detail#P32 | block | 2 | eligible | 2 | 2 | -1 | `["lgzfvx","iotiyx"]` | `oo` | `["lgzfvx","iotiyx"]` |
| shop/member-detail#P33 | block | 2 | eligible | 2 | 2 | -1 | `["3k0oqe","yqwgrw"]` | `oo` | `["3k0oqe","yqwgrw"]` |
| shop/member-detail#P34 | flex | 3 | eligible | 3 | 3 | -1 | `["kveehi","rquq0n","qprajq"]` | `ooo` | `["kveehi","rquq0n","qprajq"]` |
| shop/member-detail#P35 | block | 2 | eligible | 2 | 2 | -1 | `["lgzfvx","iotiyx"]` | `oo` | `["lgzfvx","iotiyx"]` |
| shop/member-detail#P36 | block | 2 | eligible | 2 | 2 | -1 | `["3k0oqe","yqwgrw"]` | `oo` | `["3k0oqe","yqwgrw"]` |

## shop/member-detail::point-adjust-modal  (7 candidate parents, 14 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/member-detail::point-adjust-modal#P0 | block | 2 | not-one-line | 2 | 1 | 0 | `["xttsu7","rnnmnf"]` | `oo` | `["rnnmnf"]` |
| shop/member-detail::point-adjust-modal#P1 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["wob7jr"]` | `o` | `["wob7jr"]` |
| shop/member-detail::point-adjust-modal#P2 | block | 4 | eligible | 4 | 4 | -1 | `["0tg5gz","n7cbq4","3g40mt","6i7vnd"]` | `oooo` | `["0tg5gz","n7cbq4","3g40mt","6i7vnd"]` |
| shop/member-detail::point-adjust-modal#P3 | block | 2 | eligible | 2 | 2 | -1 | `["s9j8hy","g1osey"]` | `oo` | `["s9j8hy","g1osey"]` |
| shop/member-detail::point-adjust-modal#P4 | grid | 2 | not-flow-order | 2 | 2 | -1 | `["wwvfd9","7gkn3g"]` | `oo` | `["wwvfd9","7gkn3g"]` |
| shop/member-detail::point-adjust-modal#P5 | block | 2 | eligible | 2 | 2 | -1 | `["dx5kys","sxhnew"]` | `oo` | `["dx5kys","sxhnew"]` |
| shop/member-detail::point-adjust-modal#P6 | flex | 2 | eligible | 2 | 2 | -1 | `["bvb8qz","bzmb2u"]` | `oo` | `["bvb8qz","bzmb2u"]` |

## shop/member-detail::benefit-add-modal  (13 candidate parents, 30 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/member-detail::benefit-add-modal#P0 | block | 2 | not-one-line | 2 | 1 | 0 | `["xttsu7","2ltq1c"]` | `oo` | `["2ltq1c"]` |
| shop/member-detail::benefit-add-modal#P1 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["vgg4ao"]` | `o` | `["vgg4ao"]` |
| shop/member-detail::benefit-add-modal#P2 | block | 3 | eligible | 3 | 3 | -1 | `["r2bb79","32qqsi","1wsexn"]` | `ooo` | `["r2bb79","32qqsi","1wsexn"]` |
| shop/member-detail::benefit-add-modal#P3 | block | 2 | eligible | 2 | 2 | -1 | `["xhlya4","lcn6x5"]` | `oo` | `["xhlya4","lcn6x5"]` |
| shop/member-detail::benefit-add-modal#P4 | grid | 6 | not-flow-order | 6 | 6 | -1 | `["xep6ty","ajyxpg","a6gr7v","u1eng0","cqnjch","3grnce"]` | `oooooo` | `["xep6ty","ajyxpg","a6gr7v","u1eng0","cqnjch","3grnce"]` |
| shop/member-detail::benefit-add-modal#P5 | block | 2 | eligible | 2 | 2 | -1 | `["ulxmrs","726nvi"]` | `oo` | `["ulxmrs","726nvi"]` |
| shop/member-detail::benefit-add-modal#P6 | inline-block | 3 | not-one-line | 3 | 3 | -1 | `["we86ok","e4impr","s32f9i"]` | `ooo` | `["we86ok","e4impr","s32f9i"]` |
| shop/member-detail::benefit-add-modal#P7 | block | 2 | eligible | 2 | 2 | -1 | `["mln584","k9bgjw"]` | `oo` | `["mln584","k9bgjw"]` |
| shop/member-detail::benefit-add-modal#P8 | block | 2 | eligible | 2 | 2 | -1 | `["88fma7","e34ddc"]` | `oo` | `["88fma7","e34ddc"]` |
| shop/member-detail::benefit-add-modal#P9 | block | 2 | eligible | 2 | 2 | -1 | `["j7m3vs","mr28pw"]` | `oo` | `["j7m3vs","mr28pw"]` |
| shop/member-detail::benefit-add-modal#P10 | block | 2 | eligible | 2 | 2 | -1 | `["su5id8","lvreu9"]` | `oo` | `["su5id8","lvreu9"]` |
| shop/member-detail::benefit-add-modal#P11 | block | 2 | eligible | 2 | 2 | -1 | `["dksej1","rll2op"]` | `oo` | `["dksej1","rll2op"]` |
| shop/member-detail::benefit-add-modal#P12 | flex | 2 | eligible | 2 | 2 | -1 | `["nbgnqa","jm7rm4"]` | `oo` | `["nbgnqa","jm7rm4"]` |

## shop/member-list  (34 candidate parents, 113 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/member-list#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["nc5v2e"]` | `o` | `["nc5v2e"]` |
| shop/member-list#P1 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["pcyo3f","t9n1yu","nbxeq0","vf4lm7"]` | `oooo` | `["pcyo3f"]` |
| shop/member-list#P2 | block | 2 | eligible | 2 | 2 | -1 | `["tfiuby","an3i8p"]` | `oo` | `["tfiuby","an3i8p"]` |
| shop/member-list#P3 | flex | 5 | chain-disagrees | 5 | 1 | 1 | `["4379il","4379il","4379il","4379il","4379il"]` | `ooooo` | `["4379il"]` |
| shop/member-list#P4 | block | 2 | not-one-line | 2 | 2 | -1 | `["hsq00f","5g5e8c"]` | `oo` | `["hsq00f","5g5e8c"]` |
| shop/member-list#P5 | block | 2 | chain-disagrees | 2 | 1 | 1 | `["xufjus","t3hr3g"]` | `oo` | `["xufjus"]` |
| shop/member-list#P6 | flex | 7 | eligible | 7 | 7 | -1 | `["ohpkna","tiomab","fb1n2z","f87b8y","t5ug66","vp9e97","lqaxc2"]` | `ooooooo` | `["ohpkna","tiomab","fb1n2z","f87b8y","t5ug66","vp9e97","lqaxc2"]` |
| shop/member-list#P7 | block | 8 | chain-disagrees | 8 | 1 | 1 | `["wy08ay","wy08ay","wy08ay","wy08ay","wy08ay","wy08ay","wy08ay","wy08ay"]` | `oooooooo` | `["wy08ay"]` |
| shop/member-list#P8 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P9 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P10 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P11 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P12 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P13 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P14 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["salutd"]` | `o` | `["salutd"]` |
| shop/member-list#P15 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P16 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P17 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P18 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P19 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P20 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P21 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P22 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P23 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P24 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P25 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P26 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P27 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P28 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P29 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |
| shop/member-list#P30 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["salutd"]` | `o` | `["salutd"]` |
| shop/member-list#P31 | flex | 7 | eligible | 7 | 7 | -1 | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` | `ooooooo` | `["xaro3n","k777qm","3vry5r","qip4gp","tb5xkm","82yxbh","1hzfxp"]` |
| shop/member-list#P32 | flex | 2 | eligible | 2 | 2 | -1 | `["qx3hu0","x8fhoz"]` | `oo` | `["qx3hu0","x8fhoz"]` |
| shop/member-list#P33 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["q175qy"]` | `o` | `["q175qy"]` |

## shop/order-detail  (38 candidate parents, 95 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/order-detail#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["6tvqoa"]` | `o` | `["6tvqoa"]` |
| shop/order-detail#P1 | block | 7 | chain-disagrees | 7 | 1 | 1 | `["x4922k","grpeul","aau1w5","4sj549","vj31pb","7kngp3","nprnz5"]` | `ooooooo` | `["x4922k"]` |
| shop/order-detail#P2 | flex | 3 | eligible | 3 | 3 | -1 | `["vstl1b","irfkn8","5pd01r"]` | `ooo` | `["vstl1b","irfkn8","5pd01r"]` |
| shop/order-detail#P3 | block | 2 | eligible | 2 | 2 | -1 | `["15yc0k","1jodul"]` | `oo` | `["15yc0k","1jodul"]` |
| shop/order-detail#P4 | flex | 2 | eligible | 2 | 2 | -1 | `["9ez5l6","kvv41c"]` | `oo` | `["9ez5l6","kvv41c"]` |
| shop/order-detail#P5 | table | 7 | not-flow-order | 7 | 7 | -1 | `["kh1mfx","6xrrnu","gwdd53","288qqj","lj8bsm","mdpmc1","thbzev"]` | `ooooooo` | `["kh1mfx","6xrrnu","gwdd53","288qqj","lj8bsm","mdpmc1","thbzev"]` |
| shop/order-detail#P6 | block | 2 | chain-disagrees | 2 | 1 | 1 | `["5o7kmi","yaf3wl"]` | `oo` | `["5o7kmi"]` |
| shop/order-detail#P7 | flex | 6 | chain-disagrees | 6 | 1 | 1 | `["4jpxin","4jpxin","4jpxin","4jpxin","4jpxin","4jpxin"]` | `oooooo` | `["4jpxin"]` |
| shop/order-detail#P8 | flex | 2 | chain-disagrees | 2 | 3 | 0 | `["hjo7s4","5s41w1"]` | `oo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P9 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["792cco"]` | `o` | `["792cco"]` |
| shop/order-detail#P10 | flex | 3 | not-one-line | 3 | 3 | -1 | `["rpb6hb","hjo7s4","5s41w1"]` | `ooo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P11 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["lbw6u1"]` | `o` | `["lbw6u1"]` |
| shop/order-detail#P12 | flex | 3 | not-one-line | 3 | 3 | -1 | `["rpb6hb","hjo7s4","5s41w1"]` | `ooo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P13 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["lbw6u1"]` | `o` | `["lbw6u1"]` |
| shop/order-detail#P14 | flex | 3 | not-one-line | 3 | 3 | -1 | `["rpb6hb","hjo7s4","5s41w1"]` | `ooo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P15 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["lbw6u1"]` | `o` | `["lbw6u1"]` |
| shop/order-detail#P16 | flex | 3 | not-one-line | 3 | 3 | -1 | `["rpb6hb","hjo7s4","5s41w1"]` | `ooo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P17 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["lbw6u1"]` | `o` | `["lbw6u1"]` |
| shop/order-detail#P18 | flex | 3 | not-one-line | 3 | 3 | -1 | `["rpb6hb","hjo7s4","5s41w1"]` | `ooo` | `["rpb6hb","hjo7s4","5s41w1"]` |
| shop/order-detail#P19 | flex | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["lbw6u1"]` | `o` | `["lbw6u1"]` |
| shop/order-detail#P20 | block | 3 | eligible | 3 | 3 | -1 | `["9qe7wo","5f9zmt","vhbzil"]` | `ooo` | `["9qe7wo","5f9zmt","vhbzil"]` |
| shop/order-detail#P21 | grid | 4 | not-flow-order | 4 | 4 | -1 | `["p57k6f","8uuk6o","r5eoke","qgsmgt"]` | `oooo` | `["p57k6f","8uuk6o","r5eoke","qgsmgt"]` |
| shop/order-detail#P22 | block | 2 | eligible | 2 | 2 | -1 | `["tjrdl9","kk1bgn"]` | `oo` | `["tjrdl9","kk1bgn"]` |
| shop/order-detail#P23 | block | 2 | eligible | 2 | 2 | -1 | `["fjmts3","c43pc1"]` | `oo` | `["fjmts3","c43pc1"]` |
| shop/order-detail#P24 | block | 2 | eligible | 2 | 2 | -1 | `["6rmx6j","k9p4p0"]` | `oo` | `["6rmx6j","k9p4p0"]` |
| shop/order-detail#P25 | block | 2 | eligible | 2 | 2 | -1 | `["wx8r1d","w6hep8"]` | `oo` | `["wx8r1d","w6hep8"]` |
| shop/order-detail#P26 | flex | 2 | eligible | 2 | 2 | -1 | `["yq61na","dppx5g"]` | `oo` | `["yq61na","dppx5g"]` |
| shop/order-detail#P27 | block | 3 | eligible | 3 | 3 | -1 | `["dq4i7j","uy301v","zzajcn"]` | `ooo` | `["dq4i7j","uy301v","zzajcn"]` |
| shop/order-detail#P28 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["ekp8ld"]` | `o` | `["ekp8ld"]` |
| shop/order-detail#P29 | flex | 2 | eligible | 2 | 2 | -1 | `["ilpnz8","htcg06"]` | `oo` | `["ilpnz8","htcg06"]` |
| shop/order-detail#P30 | block | 3 | eligible | 3 | 3 | -1 | `["5qybv7","2fh9tq","kxn4ty"]` | `ooo` | `["5qybv7","2fh9tq","kxn4ty"]` |
| shop/order-detail#P31 | block | 3 | eligible | 3 | 3 | -1 | `["3mhjx3","1gjj7z","vtjdhv"]` | `ooo` | `["3mhjx3","1gjj7z","vtjdhv"]` |
| shop/order-detail#P32 | flex | 2 | eligible | 2 | 2 | -1 | `["ym39mx","dwi6mv"]` | `oo` | `["ym39mx","dwi6mv"]` |
| shop/order-detail#P33 | flex | 2 | eligible | 2 | 2 | -1 | `["krv3jy","oajcct"]` | `oo` | `["krv3jy","oajcct"]` |
| shop/order-detail#P34 | flex | 2 | eligible | 2 | 2 | -1 | `["4o7pte","s0bw1n"]` | `oo` | `["4o7pte","s0bw1n"]` |
| shop/order-detail#P35 | block | 2 | eligible | 2 | 2 | -1 | `["jp43jq","r8shtg"]` | `oo` | `["jp43jq","r8shtg"]` |
| shop/order-detail#P36 | block | 3 | eligible | 3 | 3 | -1 | `["c30iu7","5khf9o","i3mmvm"]` | `ooo` | `["c30iu7","5khf9o","i3mmvm"]` |
| shop/order-detail#P37 | flex | 2 | eligible | 2 | 2 | -1 | `["qe9onb","kkaakf"]` | `oo` | `["qe9onb","kkaakf"]` |

## shop/order-list  (32 candidate parents, 116 oid-bearing elements)

| parent | display | n | verdict | geo len | chain len | diff | geo | stamp | chain |
|---|---|---|---|---|---|---|---|---|---|
| shop/order-list#P0 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["u8j60k"]` | `o` | `["u8j60k"]` |
| shop/order-list#P1 | block | 4 | chain-disagrees | 4 | 1 | 1 | `["adzf6v","0hlrjh","ahzi35","ntqtdg"]` | `oooo` | `["adzf6v"]` |
| shop/order-list#P2 | block | 2 | eligible | 2 | 2 | -1 | `["cuuamv","15farj"]` | `oo` | `["cuuamv","15farj"]` |
| shop/order-list#P3 | flex | 9 | chain-disagrees | 9 | 1 | 1 | `["e80nw8","e80nw8","e80nw8","e80nw8","e80nw8","e80nw8","e80nw8","e80nw8","e80nw8"]` | `ooooooooo` | `["e80nw8"]` |
| shop/order-list#P4 | block | 2 | not-one-line | 2 | 2 | -1 | `["9e22ia","ww8r6f"]` | `oo` | `["9e22ia","ww8r6f"]` |
| shop/order-list#P5 | block | 1 | no-adjacent-sibling | 1 | 1 | -1 | `["svdgx6"]` | `o` | `["svdgx6"]` |
| shop/order-list#P6 | table | 2 | not-flow-order | 2 | 2 | -1 | `["2mpe0o","um0wtr"]` | `oo` | `["2mpe0o","um0wtr"]` |
| shop/order-list#P7 | table-header-group | 1 | not-flow-order | 1 | 1 | -1 | `["aq6vfn"]` | `o` | `["aq6vfn"]` |
| shop/order-list#P8 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["sbqa40","h1c0xq","v9aonm","ut05qx","vdjddn","u54qo5"]` | `oooooo` | `["sbqa40","h1c0xq","v9aonm","ut05qx","vdjddn","u54qo5"]` |
| shop/order-list#P9 | table-row-group | 11 | not-flow-order | 11 | 1 | 1 | `["2knggo","2knggo","2knggo","2knggo","2knggo","2knggo","2knggo","2knggo","2knggo","2knggo","2knggo"]` | `ooooooooooo` | `["2knggo"]` |
| shop/order-list#P10 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P11 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P12 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P13 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P14 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P15 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P16 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P17 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P18 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P19 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P20 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P21 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P22 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P23 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P24 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P25 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P26 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P27 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P28 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P29 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
| shop/order-list#P30 | table-row | 6 | not-flow-order | 6 | 6 | -1 | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` | `oooooo` | `["lnjbea","ow09nm","w7a895","i9vut2","rddd65","mg749d"]` |
| shop/order-list#P31 | table-cell | 1 | not-flow-order | 1 | 1 | -1 | `["eclnar"]` | `o` | `["eclnar"]` |
