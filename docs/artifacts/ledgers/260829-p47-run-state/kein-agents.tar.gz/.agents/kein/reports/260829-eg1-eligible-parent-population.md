# EG-1 — the eligible-parent population (phase-47)

**Lane:** QA / Evidence Gate. **Date:** 2026-08-29. **Worktree:** `/Users/kein/Documents/workspace/dev/descvi/repo/phase-47-drag-reorder-in-kein`.
**Spec:** `.omc/plans/ralplan-phase-47-drag-reorder.md` §6 "EG-1: the eligible-parent population", with §2.10 and §3.7/DR47-11.

## Verdicts, up front

| Question | Answer |
|---|---|
| **STOP condition** (two populations differ on a parent the predicate calls ELIGIBLE) | **NOT TRIGGERED.** 0 of 142 eligible parents. |
| **Eligible fraction** | **360 / 748 = 48.13 %** → **PASS PATH** (≥ 40 %). S47-3's live pass leads with the working gesture. |
| **Maximum candidate-parent sibling count** | **11** → **≤ 33**, so `MAX_REORDER_STEPS = 32` is **unreachable in this corpus**. Record the number; nothing changes; no second client bound, no fifth Korean sentence. |
| **Instrument check** | **PASSED, both legs**, and both were shown able to print before any zero was believed. |

Nothing here is an acceptance of the phase. It is a measurement returned for the lead's judgement.

## Method — what was actually driven

- `pnpm descvi:dev` started by this lane (Vite :3001 + sidecar :7331). `lsof -nP -iTCP:7331,3001,3000 -sTCP:LISTEN` returned **no listeners** before the start, so no sibling worktree was touched and nothing was killed.
- A scratch Playwright harness (chromium 1.60.0, viewport 1440×900) navigated to each of the manifest's 24 screens — the 21 routable ids directly, the three `::` sub-screens via `/{owner}?open={id}` — and, **in the page**, imported the SHIPPED modules through Vite's `/@fs/` transform and called them:
  - `packages/descvi/src/react/overlay/canvas/reorder-eligibility.ts#export function assessReorderEligibility<Parent, Child>(input: ReorderEligibilityInput<Parent, Child>): ReorderEligibility<Child> {` — the verdict, unmodified.
  - `packages/descvi/src/react/overlay/canvas/reorder-tracker.ts#export const REORDER_LIVE_DOM_READER: ReorderDomReader<Element, Element> = {` — the shipped live-DOM reader (`getComputedStyle` + `getBoundingClientRect`).
  - `packages/descvi/src/react/overlay/canvas/reorder-tracker.ts#export function resolveReorderStructure(resolver: SourceResolver, element: Element): ReorderStructure | null {` — the shipped element-keyed engine reader.
  - `packages/descvi/src/react/overlay/engine/source-resolver.ts#export function createSourceResolver(editMap: EditMapData): SourceResolver {` over the edit map fetched from `/@descvi/edit-map`.
  **The predicate was not re-implemented.** Every bucket below is the shipped module's own return value.
- **Walk unit.** Every `[data-oid]` element whose nearest enclosing `[data-screen]` is the screen under test, with `dragged = el` and `parent = el.parentElement`.
- **Which version of the module was measured.** The **working-tree** version. `reorder-eligibility.ts`, `reorder-tracker.ts` and `use-canvas-selection-shield.ts` all carry uncommitted modifications from the in-flight S47-1/S47-2 work at the time of this run; that is the code EG-1 is a fact about, since it is the code S47-3's live pass will run. If those files move before S47-3, this gate's numbers are about a version that no longer exists and the walk should be re-run — the harness is one file and the re-run is minutes.
- **Run stability.** The full walk was executed **three times**; the per-screen bucket vectors were byte-identical across all three. (Run 1 and 2 differed only in that Vite optimized two dependencies during run 1; the identical run 2 rules that out as a confounder.)

### One deliberate deviation from the production wiring, stated

The production `SourceResolver` instance is built inside `DescviOverlay` and is not reachable from page script. The harness therefore built **a second instance from the same shipped factory over the same fetched edit map**. It is the same code over the same data; it is not the same object. **Measured, not inferred:** the module and both readers are the shipped ones. **Inferred:** that the overlay's own instance would answer identically — it is a pure function of the edit map it closes over.

## Buckets — per screen and in total

`p3-chain` = `part-3-chain-disagrees`; `p3-absent` = `part-3-entry-absent`. **The two are never summed.**

| screen | oid elements | eligible | refused-part-1 | refused-part-2 | p3-chain | p3-absent | refused-single-child | eligible % |
|---|---|---|---|---|---|---|---|---|
| lab/challenge/dynamic-shapes | 22 | 8 | 0 | 0 | 13 | 0 | 1 | 36.4 |
| lab/challenge/focus-steal | 11 | 7 | 0 | 0 | 3 | 0 | 1 | 63.6 |
| lab/challenge/insert-scratch | 13 | 12 | 0 | 0 | 0 | 0 | 1 | 92.3 |
| lab/challenge/nested-scroll | 18 | 14 | 0 | 0 | 3 | 0 | 1 | 77.8 |
| lab/challenge/relocation | 10 | 7 | 0 | 0 | 2 | 0 | 1 | 70.0 |
| lab/challenge/swallowed-oid | 20 | 16 | 0 | 0 | 3 | 0 | 1 | 80.0 |
| lab/tests/align-enablement | 15 | 0 | 0 | 0 | 14 | 0 | 1 | 0.0 |
| lab/tests/align-wrap | 11 | 6 | 0 | 0 | 3 | 0 | 2 | 54.5 |
| lab/tests/shared-oid | 28 | 15 | 0 | 0 | 11 | 0 | 2 | 53.6 |
| lab/tests/single-screen | 26 | 10 | 0 | 0 | 14 | 0 | 2 | 38.5 |
| lab/tests/spacing-nesting | 19 | 2 | 0 | 0 | 16 | 0 | 1 | 10.5 |
| lab/tests/style-edit | 14 | 4 | 0 | 0 | 6 | 0 | 4 | 28.6 |
| lab/tests/three-screen | 20 | 6 | 1 | 0 | 12 | 0 | 1 | 30.0 |
| lab/tests/three-screen::approve-modal | 7 | 4 | 0 | 1 | 2 | 0 | 0 | 57.1 |
| lab/tests/three-screen::reject-modal | 7 | 4 | 0 | 1 | 2 | 0 | 0 | 57.1 |
| sandbox/resize-flex-col | 16 | 11 | 0 | 0 | 4 | 0 | 1 | 68.8 |
| sandbox/resize-flex-row | 16 | 11 | 0 | 0 | 4 | 0 | 1 | 68.8 |
| sandbox/resize-repeat-list | 23 | 14 | 0 | 0 | 8 | 0 | 1 | 60.9 |
| shop/member-detail | 84 | 53 | 8 | 0 | 17 | 0 | 6 | 63.1 |
| shop/member-detail::point-adjust-modal | 14 | 10 | 2 | 1 | 0 | 0 | 1 | 71.4 |
| shop/member-detail::benefit-add-modal | 30 | 19 | 6 | 4 | 0 | 0 | 1 | 63.3 |
| shop/member-list | 113 | 81 | 0 | 2 | 19 | 0 | 11 | 71.7 |
| shop/order-detail | 95 | 44 | 11 | 15 | 17 | 0 | 8 | 46.3 |
| shop/order-list | 116 | 2 | 97 | 2 | 13 | 0 | 2 | 1.7 |
| **TOTAL (24 screens)** | **748** | **360** | **125** | **26** | **186** | **0** | **51** | **48.13** |

**No screen failed to be walked.** All 24 produced a full record; `no-parent` was 0 everywhere.

By unique candidate parent (306 total): eligible 142, `chain-disagrees` 68, `no-adjacent-sibling` 51, `not-flow-order` 33, `not-one-line` 12.

### The split, and which population the owner question is about

- **`part-3-chain-disagrees` = 186 elements / 68 parents.**
- **`part-3-entry-absent` = 0 elements / 0 parents.**

These are reported separately and are not summed. §6's alternate-path owner question (b) is about the first population — and the pass path means it is not asked. **See "What the walk showed that the plan did not anticipate" below: the zero in the second bucket is not the absence of oid-less slots. It is a mechanism finding.**

Cause breakdown of the 186 `chain-disagrees` elements, attributed by their parent's two sequences (**measured** from the dump, **classified** by this lane):

| shape | elements | parents |
|---|---|---|
| geometric list LONGER — a slot the engine cannot address on its own (an unstamped host child) | 122 | 53 |
| shared-oid parent — one `.map()` op-unit rendering k DOM siblings | 62 | 14 |
| engine chain LONGER — an op-unit that renders nothing (`{cond && <El/>}`) | 2 | 1 |
| equal length, permuted order | 0 | 0 |

The single chain-LONGER parent is `shop/order-detail#P8`: geometric `["hjo7s4","5s41w1"]` vs engine chain `["rpb6hb","hjo7s4","5s41w1"]`, diverging at index 0 — `rpb6hb` is an op-unit that renders nothing at the screen's default `orderStatus`. That is §2.10's `&& <` shape, observed live.

## The per-parent sequence dump

All **306** candidate parents, eligible or not, with the geometric slot oids in DOM order, the engine chain oids in source order, both lengths, and the first diverging index:

**`.agents/kein/reports/260829-eg1-per-parent-sequence-dump.md`**

Two things about that dump, so it is read correctly:

- The `geo` column shows, per DOM slot, the oid `SourceResolver.resolve()` answers for it. **An oid-less slot resolves UP** to its nearest oid-bearing ancestor, so it appears as that ancestor's oid — never as a hole. The dump's **`stamp`** column carries that distinction per slot (`o` = the slot has its own `data-oid`, `-` = it does not), so an unstamped host wrapper is readable directly from the row.
- The `chain` column is built by walking `prevOid`/`nextOid` through `editMap.oids[screenId]` — the plan §3.7 definition. **It is a diagnostic, not the verdict.** The shipped predicate reconciles by asserting pairwise adjacency over rendered siblings instead. The two agree on every row measured here; where they could disagree is the STOP condition, checked below.

## The STOP condition — checked and not triggered

Definition: *the two populations differ on a parent the predicate nonetheless calls ELIGIBLE.*

Driven over all **142 eligible parents**: for each, the geometric slot oid sequence was compared element-by-element against the engine chain built independently from the edit map. **0 mismatches.** Every eligible parent had `firstDivergingIndex = -1` and equal lengths. Part 3 is doing what DR47-11 rules it does, on this corpus, at this viewport.

## Maximum sibling count — and the pre-decided reading it triggers

| population | max sibling count | where |
|---|---|---|
| all 306 candidate parents | **11** | `shop/order-list#P9`, `display: table-row-group` (refused at part 1) |
| parents that reached part 3 (passed parts 1 and 2) | 9 | `shop/order-list#P3`, `display: flex` (refused `chain-disagrees`) |
| ELIGIBLE parents only | 7 | `shop/member-list#P6`, `display: flex` |

Full histogram of sibling counts over candidate parents: `1:64, 2:148, 3:38, 4:17, 5:5, 6:20, 7:11, 8:1, 9:1, 11:1`.

**Reading triggered: "≤ 33 → the cap is unreachable."** The largest parent in the corpus holds 11 children, admitting a longest drag of 10 steps against a cap of 32. Recorded, named, and **nothing changes**: `MAX_REORDER_STEPS` stays a lock guard, the client clamp takes no second bound, no fifth Korean sentence is minted. This is the pass reading — reported, not decided by this lane.

## The instrument check — mandatory, and run in two legs

Neither zero in this report is believed on silence.

**Leg 1 — can the walk report a mismatch at all?** Required by §6: run against a page containing a `.map()`. Screen `lab/challenge/dynamic-shapes` (the corpus's dedicated `.map()` screen). **Output — NON-EMPTY, 13 elements across 5 mismatching parents:**

```
lab/challenge/dynamic-shapes: 22 oid-elements
  {"eligible":8,"refused-part-1":0,"refused-part-2":0,
   "part-3-chain-disagrees":13,"part-3-entry-absent":0,"refused-single-child":1}

P2 chain-disagrees flex n=5  geo=["dxroot","dxlgsc","dxncsc","dxstep","dxcont"]  chain=["dxlgsc","dxncsc","dxstep"]  diff=0
P4 chain-disagrees flex n=3  geo=["dxlgnd","dxlgnd","dxlgnd"]                     chain=["dxlgnd"]                    diff=1
P6 chain-disagrees flex n=3  geo=["dxncit","dxncit","dxncit"]                     chain=["dxncit"]                    diff=1
P8 chain-disagrees flex n=3  geo=["dxmrow","dxmrow","dxmrow"]                     chain=["dxmrow"]                    diff=1
P1/P3/P5/P7 eligible flex n=2  geo == chain  diff=-1
```

P4/P6/P8 are the KI-10 shared-oid shape exactly as §2.10 predicts: three rendered siblings under one op-unit, geometric length 3 against chain length 1, first divergence at index 1. The controls (P1/P3/P5/P7) stay eligible with identical sequences, so the instrument is discriminating and not merely loud.

**Leg 2 — can the `part-3-entry-absent` bucket fire?** Added by this lane, because `part-3-entry-absent = 0` across the whole corpus is exactly the kind of zero the brief says must not be believed on an instrument never shown able to print it. A negative control was driven in-page: a synthetic flex parent appended outside any `[data-screen]`, whose three children therefore have no oid-bearing ancestor. **Output:**

```json
{ "moduleVerdict": { "eligible": false, "reason": "chain-disagrees" },
  "resolvedChildStructures": [null, null, null],
  "harnessBucket": "part-3-entry-absent" }
```

The shipped module refused, every child resolved to `null`, and the harness's split classified it `part-3-entry-absent`. **The bucket can fire. The corpus zero is a measurement.**

**On the split itself — measured vs. classified.** The shipped module returns ONE reason, `chain-disagrees`, for both populations (`reorder-eligibility.ts#  if (dragged === null || structures.some((structure) => structure === null)) return { eligible: false, reason: "chain-disagrees" };`). The split is therefore **this lane's diagnostic**, computed by re-reading the same injected reader in the module's own branch order (null-resolution first). The verdict is the module's; the label on the refusal is the harness's, and leg 2 is what proves the label can take either value.

## What the walk showed that the plan did not anticipate

1. **`part-3-entry-absent` is structurally unreachable in this corpus, and not for the reason the zero suggests.** §3.7 grounds that bucket in `structure` being optional on the client mirror. Measured: **all 770 edit-map entries across all 24 screens carry a `structure` field** — the optional path has no instance. And the oid-less slot, which one would expect to produce a `null`, does not: `resolve()` walks UP to the nearest oid-bearing ancestor, so an unstamped `<header>` inside a parent stamped `dxroot` resolves to `dxroot` — the parent's own oid — and the refusal arrives through the pairwise adjacency assertion, landing in `chain-disagrees`. **122 of the 186 part-3 elements are exactly this shape.** So the plan's DR47-11 table row "*a slot is an oid-less host wrapper the engine cannot address*" is real and is the LARGEST part-3 population, but it is filed under "the geometric list is LONGER", not under `entry-absent`. If the alternate path ever fires, the owner question must be asked about **unstamped host slots**, not about `.map()`: `.map()` is 62 elements / 14 parents, roughly a third of the part-3 population.
2. **`shop/order-list` is a table, and it costs 97 of the 125 part-1 refusals.** Its parent census is `table` ×2, `table-header-group`, `table-row-group`, `table-row` ×12, `table-cell` ×11 — a listing rendered as a real HTML table, refused at part 1 by ruling, before any geometry is read. It alone drops the corpus eligible rate by roughly 6 points (1.7 % eligible on that screen against 48 % overall). Not a defect; worth the lead knowing that "the reorder gesture is dead on the order list" is a shape of this corpus and not a bug report waiting to happen.
3. **A single-child parent inside a table reports `not-flow-order`, not `no-adjacent-sibling`.** Eleven `table-cell` parents with exactly one child land in the part-1 bucket because part 1 runs first. The bucket counts are correct per the module's ruled ordering; the note is only that "refused-single-child = 51" undercounts elements a user would describe that way.
4. **`lab/tests/align-enablement` is 0 % eligible** (0 of 15, 14 `chain-disagrees` + 1 single-child) — the only screen with no eligible element at all. If S47-3's live pass wants a screen on which to demonstrate a refusal string, that is the one.
5. **Coverage boundary, stated rather than buried.** The walk measures **the default state of every screen**. 494 distinct oids were rendered out of **770** authored — the gap is state-axis-gated content, concentrated in `shop/order-detail` (72 rendered of 274 authored, behind an 11-value `orderStatus` axis) and `shop/member-detail` (62 of 103). The plan's claim line names "the 798 oid-bearing corpus elements"; what this gate measured is **748 rendered DOM instances of 494 distinct oids at the default state**. The 48.13 % is a fraction of what is on screen by default, which is what the predicate is a fact about — but it is **not** a fraction of the whole authored corpus, and a status-axis sweep would be a different measurement. Nothing in EG-1 asks for one; this is named so nobody reads the number as wider than it is.
6. **Part 2 refuses 12 parents, and 5 of them are one repeated shape.** `shop/order-detail#P10/12/14/16/18` are five `display: flex` parents of 3 children each — a repeated row that is monotonic on neither axis at 1440×900. Per §3.7's stated residual, that verdict is viewport-dependent; it was stable across three runs at this one viewport and was not re-measured at another.

## Cleanup and baseline

- The `descvi:dev` process pair started by this lane was stopped; `lsof -nP -iTCP:7331,3001,3000 -sTCP:LISTEN` is clean again (evidence in the returning message).
- **No git command that writes was run.** No `add`, no `stash`, no `commit`.
- **No shipped code was changed.** The harness lived entirely outside the repo, in the session scratchpad, and was deleted: `eg1-walk.mjs`, `eg1-entry-absent-probe.mjs`, and the raw JSON captures (`eg1-raw.json`, `eg1-raw-2.json`, `eg1-raw-3.json`, `eg1-instrument.json`, `em.json`, `dev.log`).
- The only files this lane added to the worktree are this report and its companion dump, both under the already-untracked `.agents/kein/reports/`. The tracked-file modifications present in `git status` are pre-existing from other lanes and were not touched.
