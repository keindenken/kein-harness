import { defineConfig, devices, type ReporterDescription } from '@playwright/test';
import { randomBytes } from 'node:crypto';

/**
 * KI-12 — mints the sidecar's CSRF write-gate token ONCE per `playwright test` invocation and shares it, via the environment, with every process this run touches: both `webServer` entries below, the ambient sidecar `globalSetup` spawns, the solo project's own spawns, and the spec files that talk to the sidecar directly.
 *
 * `??=` rather than an unconditional mint, because this module is evaluated in MORE than one process — the runner loads it once, but a test WORKER is a separate Node process that reloads the config independently, and an unconditional mint would hand each worker a DIFFERENT value instead of the one the runner already placed in the environment. Every spawn below (`webServer`, `globalSetup`'s sidecar, a worker's own children) inherits `process.env` by default, so setting it here, before anything is spawned, is sufficient on its own.
 */
process.env.DESCVI_DEV_TOKEN ??= randomBytes(32).toString('hex');
// Same value under a second name, unconditionally kept in sync: Vite only inlines
// `VITE_`-prefixed env vars into client code, so the design-view bundle needs this name
// to see what `DESCVI_DEV_TOKEN` above already settled.
process.env.VITE_DESCVI_DEV_TOKEN = process.env.DESCVI_DEV_TOKEN;

/**
 * ⚠ EDITING A COMMENT IN THIS FILE CAN TURN THE CITATION GATE RED, AND THE SENTENCE THAT DOES IT WILL NOT LOOK LIKE A CITATION.
 *
 * `scripts/check-citation-anchors.mjs` leg (b) proves every anchor citation resolves to EXACTLY ONE occurrence in the file it names. Three of them point into this file today — the solo project's name line, its dependencies line, and one sentence of prose in the testMatch note below. (Re-count by grepping this file's path followed by a hash across the gate's scan roots: docs, packages/descvi/src/vite, e2e, scripts, .omc/plans, .omc/specs.) Repeat any of that text anywhere in this file and the anchor resolves TWICE, and the gate reports the CITING DOCUMENT rather than the edit that caused it.
 * Measured at phase-27 P3: an ordinary new sentence added to the comment below happened to reuse five words of the prose anchor, and the gate went RED naming `.omc/plans/ralplan-phase27-ki32-liveness.md`. The plan's A12 records this hazard for ROW TITLES pasted into their own suite; prose in a config comment is the same hazard with nothing at all to warn you. **The prose anchor is the dangerous one** — a code line is hard to retype by accident and an English sentence is not. So run the gate after editing this file's COMMENTS, not only after editing its code.
 */

/**
 * W5's two oracles, appended to whatever human-readable reporter the environment wants.
 *
 * They are what makes a green run mean something: `identity-oracle` pins WHICH tests ran and with WHICH status against a read-only golden (G3/G6), and `artifact-oracle` proves the run restored every path it touched (G4/C-R1). Both run in `onEnd`, after teardown — see `e2e/reporters/oracle-support.ts` for the ordering that makes that correct.
 * ⚠ Both return `{status:'failed'}` or `undefined` and NEVER `{status:'passed'}`. Playwright applies each reporter's returned status SEQUENTIALLY, so a successful oracle answering `passed` would overwrite a real test failure that a reporter earlier in this array had already recorded.
 * ⚠ THAT MAKES ORDER IRRELEVANT TO THE EXIT STATUS, AND ORDER IS STILL LOAD-BEARING HERE — an earlier comment claimed otherwise and the claim was measured false. `artifact-oracle` compares a tree snapshot taken in `onBegin` against `onEnd`, so ANY reporter that writes a repo file from its own `onEnd` is seen or not seen purely by where it sits relative to this one. Measured with a probe reporter standing in for `IdentityOracle.update()`'s write to the golden: `[list, artifact, probe, identity]` → exit 0 with a tracked file left modified and UNSEEN; `[list, probe, artifact, identity]` → exit 1. **The dependency is removed rather than documented**: `harnessWritten` in `e2e/fixtures/mutable-paths.json` excludes the golden's path from that delta, so reordering this array cannot arm it. Keep the exclusion, not the ordering, as the thing you rely on.
 */
const reporters: ReporterDescription[] = [
  ['list'],
  ...(process.env.CI ? ([['html', { open: 'never' }]] as ReporterDescription[]) : []),
  ['./e2e/reporters/artifact-oracle.ts'],
  ['./e2e/reporters/identity-oracle.ts'],
];

/**
 * Playwright e2e config — descvi single-stack Vite (two views, ONE author surface).
 *
 * THREE projects over two webServers (phase-23 W2; the matrix is measured, see `.omc/plans/ralplan-phase23-e2e-harness.md` § "The project matrix"):
 *   - `plain`       → `vite` on :3000                                — the prototype, NO overlay. Collects `overlay-shell` only.
 *   - `design-view` → `vite --config descvi.vite.config.mts` on :3001 — the overlay editor. Collects the AMBIENT specs (each needs a sidecar on :7331) plus the NEUTRAL ones. ⚠ Both sets are ENUMERATED in `e2e/fixtures/spec-classes.json` and audited against the `*.spec.ts` set on disk by `pnpm test:e2e:gate-cx1` — read the membership and the counts THERE, never off a sentence here. This clause used to say "the ten AMBIENT specs … plus the three neutral ones" and name the three; it was hand-counted, it drifted (13 / 5 as of 2026-08-20, and the drift pre-dates phase-43), and no gate could see that it had. A count a gate reads cannot go stale silently; a count in prose does nothing else.
 *   - `solo`        → :3001 as well, but collects only the two specs whose subject IS the sidecar's own lifecycle and which therefore require :7331 to be absent when they start.
 * Both views render the SAME `src/app/**​/page.tsx` over the real routes (`/` portal + `{claude,gemini,gpt}/order-{list,detail}`). There is no Next host.
 *
 * ⚠ W4 CLOSED THE WINDOW IN WHICH THIS SUITE COULD NOT BE GREEN, and the paragraph that used to stand here saying otherwise is superseded rather than deleted, because its measurements are the argument for the `globalSetup` below. Under W2/W3 the config started no sidecar, and the two classes wanted opposite things from :7331 — measured with the port free, `9 failed / 33 did not run / 9 skipped / 11 passed`; measured with an ambient sidecar up, `2 failed / 9 skipped / 51 passed`. Those were never two bugs and one fix: the same process simultaneously produced the 51 passes and the 2 failures, so **no state of :7331 made that configuration green.** `globalSetup` now claims the port for the ambient class and the solo project's fixture takes it away again for its own two specs, which is what arranges both preconditions inside one invocation. Measured after W4 from a clean tree with 3000/3001/7331 free: `9 skipped / 53 passed`, exit 0. ⚠ THAT IS A DATED FIGURE, NOT THE CURRENT ONE, and it is kept because it is the W4 argument rather than a description of today: phase-27 added `liveness-wake`'s six rows, so the same command now reports `9 skipped / 59 passed` over 68 collected tests. ⚠ That 59 is Playwright's own EXPECTED-vs-ACTUAL axis and the golden's `passed` is 58; they differ by the one held `test.fail` pin and are not two readings of the same number. Reconcile a surprise against `e2e/fixtures/expected-identities.json`, which is the pin, not against any number here.
 *
 * `testMatch`, not a runtime guard, is what puts a spec in a project — preconditions are arranged by the harness rather than asserted by the spec. Ten of the twelve guards removed alongside this cutover were tautologies afterwards: the file sits in exactly one project and the predicate always passes there, so removal was a semantic no-op.
 * ⚠ **The two solo specs are the opposite case, and theirs is the consequential removal.** Their guard was `project.name !== "design-view"`, which inside `solo` is a CONTRADICTION rather than a tautology — it fires and skips. Measured with the guards left in place: `2 skipped, exit 0`, a suite that reports green having run neither. `overlay-shell` keeps its two guards because it is the one file collected by two projects, so its predicate is not a tautology in either one.
 * ⚠ A `testMatch` entry must match the actual FILENAME, **extension included**. Measured on this config by varying one entry: `'**​/undo-toast.spec.ts'`, `'undo-toast.spec.ts'` and `'e2e/undo-toast.spec.ts'` all match; `'**​/undo-toast'` and `'undo-toast'` both match NOTHING. The `**​/` prefix is irrelevant in both directions — dropping `.spec.ts` is what kills the match. The `**​/…spec.ts` form used below is a convention, not a requirement. **The failure is silent**: `collectFilesForProject` filters non-matches without throwing and a run errors only when the TOTAL collected set is empty, so a typo drops a whole file and even `--list` exits 0.
 *
 * `solo` runs last by declaration rather than by emergent ordering: per-project `workers` bounds concurrency only WITHIN a project, so the solo fixture would otherwise stop the sidecar underneath concurrently-running ambient tests. ⚠ Its measured cost is that ONE failing `plain`/`design-view` test suppresses the entire solo project as "did not run".
 * ⚠ **THE `dependencies` EDGE DECIDES WHETHER A TITLE FILTER HOLDS, AND WHICH WAY IT GOES DEPENDS ENTIRELY ON WHETHER THE FILTER LEAVES `solo` NON-EMPTY.** The filter IS applied to every project — including these two. What the edge adds is that a `solo` test surviving the filter drags `plain` and `design-view` in as DEPENDENCIES, and a dependency runs in FULL, unfiltered. Measured on this config at phase-27 P3, `--list` collected per project:
 *   - no filter                                    → 9 plain / 57 design-view / 2 solo  (68)
 *   - `-g '<a design-view row title> '`            → 0 plain /  1 design-view / 0 solo  (1)   ← solo matched nothing, no expansion, the filter HELD
 *   - `-g 'a sidecar-only restart'` (a SOLO title) → 9 plain / 57 design-view / 1 solo  (67)  ← one solo survivor, both dependencies back in FULL
 *   - `--grep-invert '<a design-view row title> '` → 9 plain / 57 design-view / 2 solo  (68)  ← the excluded row is COLLECTED again
 * So a positive `-g` naming a `plain`/`design-view` row is trustworthy on a bare `playwright test`; `--grep-invert` is effectively never trustworthy, because solo's two titles survive almost any exclusion. It goes wrong quietly, and in the direction that matters — the run reports `59 passed` over a set the reader believes was narrowed to one. Pass `--project=<name>` or `--no-deps` whenever the filter is load-bearing rather than reasoning about which case you are in.
 * ⚠ Quote Playwright's own summary line (`4 failed`, `59 passed`, `9 skipped`) as the evidence, never an exit code — and note the format is Playwright's, not vitest's `Tests N passed|failed`; a note about how to quote evidence that names the wrong runner's format teaches the wrong grep.
 *
 * `fullyParallel`, `workers` and `retries` are pinned PER PROJECT rather than at the top level, because top-level exclusivity rests on the `projects` array order — reorder the array and it breaks silently, so a declared constraint beats an emergent one.
 * ⚠ **AND `workers: 1` HAS A SECOND CONSEQUENCE NOBODY MEETS UNTIL THEY READ A RED TAIL: FAILURES CASCADE, so the count at the bottom of a run is NOT the number of independent defects.** Every mutating spec restores its fixture and then re-derives `.descvi/` through `scripts/check-extract-outcome.mjs` — and that script rewrites `edit-map.json`, which is the map the SIDECAR resolves the next spec's write against. So a spec whose `afterEach` is truncated (it threw, or a mid-row restore failed) leaves a stale map behind, and every LATER spec's write lands nowhere: they fail as `waitForResponse` timeouts, naming a symptom that has nothing to do with them and pointing at the wrong file. Measured on this repo at phase-44 S44-3: a single upstream cause produced 23 failing rows, of which **8 carried only `waitForResponse` timeouts** and one carried a `toContain` — none of them named the real cause.
 *
 * **HOW TO READ A RED TAIL, THEN.** Do not classify by grepping the aggregate output for an error string — that is what the S44-3 lane did, and it reported "all failures cite one cause" against a log where a third of them cited something else entirely. **Isolation-run the suspect specs one at a time** (`--project=design-view <file>`); a spec that passes alone was a downstream victim, and a spec that fails alone is a real defect. The membership conclusion is only as good as the per-spec runs behind it.
 *
 * ⚠ **`workers: 1` is not tidiness; it is the difference between a suite that runs and one that does not.** Measured on identical bytes with no `--workers` flag: `12 failed / 27 did not run / 14 passed` in 17.4 s. The same bytes at `--workers=1`: `2 failed / 51 passed`. Which also means any baseline quoted without a worker count is a property of the measuring machine's core count rather than of the commit.
 * ⚠ The top-level `workers` below is only the global cap, and in CI it is `1` — so CI does run the top-level shape this paragraph rejects for local use. That is not a defect: `dependencies` still orders `solo` last under it.
 */
export default defineConfig({
  testDir: './e2e',
  // W4: the harness claims :7331 or hard-fails naming the port, records the owned pid + nonce + the sidecar's own `/status.journal.sessionId` in a file-backed registry under `test-results/`, and bootstraps the gitignored `.descvi/edit-map.json` that a fresh clone does not have. The solo project's fixture (`e2e/fixtures/solo-sidecar.ts`) stops and restarts that sidecar around its two specs, which is the half `globalSetup` cannot arrange.
  globalSetup: './e2e/global-setup.ts',
  forbidOnly: !!process.env.CI,
  workers: process.env.CI ? 1 : undefined,
  reporter: reporters,
  use: {
    // `retain-on-failure`, NOT `on-first-retry`: `retries: 0` on all three projects makes `on-first-retry` unreachable, so it would collect nothing anywhere. CI runs `pnpm test:e2e` and uploads `playwright-report/` with 7-day retention (`.github/workflows/ci.yml`), so the archived report would carry no trace at all, on every run.
    // The two settings pull the same way on purpose: a retry HIDES a flake, a retained trace SHOWS it. It was worth most in the W2/W3-to-W4 window, when the suite could not be green from a clean checkout and CI was red throughout with nothing in the report to say why; W4 closed that window, and what the trace now buys is the first genuine flake in a suite that is expected to be green.
    trace: 'retain-on-failure',
  },
  projects: [
    {
      name: 'plain',
      testMatch: ['**/overlay-shell.spec.ts'],
      fullyParallel: false,
      // Explicit even though this project collects only a non-mutating file: without it the next spec added here inherits unbounded parallelism silently.
      workers: 1,
      // `0` here is deliberate rather than inherited. A retry on a fast non-mutating file would be cheap, but uniformity across the three projects is worth more than that — and with `trace: 'retain-on-failure'` above, a flake in this project is now something you SEE rather than something a retry papers over.
      retries: 0,
      use: { ...devices['Desktop Chrome'], baseURL: 'http://localhost:3000' },
    },
    {
      name: 'design-view',
      testMatch: [
        // The AMBIENT specs — each fails without a sidecar on :7331. The criterion is "fails without a sidecar", NOT "greps for 7331": `binding-follow` has eight `waitForResponse` on `/edit` and zero occurrences of the port. ⚠ The MEMBERSHIP below is the `testMatch`; the CLASSIFICATION lives in `e2e/fixtures/spec-classes.json` and is what `pnpm test:e2e:gate-cx1` audits. No count is stated here on purpose — the one that used to be ("the ten AMBIENT specs") had drifted, and the second copy of a hand count is the one nobody corrects.
        '**/binding-follow.spec.ts',
        '**/insert-live.spec.ts',
        '**/late-remeasure.spec.ts',
        '**/panel-focus.spec.ts',
        '**/selection-consistency.spec.ts',
        '**/structural-editing.spec.ts',
        '**/undo-cmdz.spec.ts',
        '**/undo-cross-screen.spec.ts',
        '**/undo-toast.spec.ts',
        '**/unresolved-banner.spec.ts',
        // AMBIENT, and unambiguously so: phase-42 S42-3's rows drive a real resize gesture whose
        // release POSTs through the sidecar and splices `page.tsx` on disk, which is the criterion
        // this list uses. Its non-committing rows (the two mid-drag ring-truth ones) cancel with
        // Escape and write nothing, but the file as a whole cannot run without :7331.
        '**/resize-write.spec.ts',
        // AMBIENT — phase-43 S43-4. Every row clicks a control in the shipped Layout section, which commits
        // through the shared className path and awaits `POST /edit`, then reads the geometry the browser
        // produces from the re-served source. Nothing in it survives a suppressed :7331.
        '**/alignment-write.spec.ts',
        // AMBIENT — phase-44 S44-3. The committing rows drive a real spacing gesture whose release POSTs
        // through the sidecar and splices `page.tsx` on disk, which is the criterion this list uses. Its
        // resting-DOM rows (the floor counts, the clamp, universe B) touch no network and would survive a
        // suppression on their own; the file as a whole cannot.
        '**/spacing-gesture.spec.ts',
        // Neutral — passes with or without a sidecar, but the axis panel is overlay-only chrome, so this view is where it belongs.
        '**/state-axis-reconcile.spec.ts',
        // Neutral, and the classification is about ONE of its two row families rather than about the
        // file: the `setContent` calibration rows touch no network at all and pass suppressed by
        // construction, while the fixture-validation rows load `lab/tests/align-*` through this server.
        // `docs/e3/tracker.md` carries the per-ROW suppressed statuses, because a file-level verdict
        // reports the same green whether one row survived the suppression or all of them did.
        // Design-view rather than plain: the phase's own write rows drive the overlay panel over these
        // same screens, and one collection project for the pair is what keeps them comparable.
        '**/alignment-layout.spec.ts',
        // Neutral, and MEASURED so rather than assumed — RE-measured at P3, because the file grew a row that reads :7331 traffic and the earlier reason for the classification stopped covering it. All six rows passed under `DESCVI_E2E_NO_SIDECAR=1` on this project. ALL SIX read the overlay's component list — the spec routes every row through one helper that asserts the unedited description is findable before the row does anything else — and ONE of them additionally counts sidecar `/status` requests. That one survives the suppression because its observable is the request the PAGE ISSUES, not the response: a connection refused on :7331 is still a request Playwright reports. Design-view all the same: the observable IS the overlay panel, so there is no plain-view form of this file.
        '**/liveness-wake.spec.ts',
        // Neutral, and measured rather than argued: all eight rows passed under
        // `DESCVI_E2E_NO_SIDECAR=1`, which follows from what the file does — it reads the edit map
        // the page already loaded and issues no write at all. It belongs to this project because
        // its whole subject is the overlay's ring layer, which the prototype view does not render.
        '**/resize-handles.spec.ts',
        // Neutral — phase-48 B-Q5, plan §8.1. The §8.1 region-set instrument: every row reads a target's own measured box and one live selection, and issues no write of any kind.
        '**/region-set-instrument.spec.ts',
        // ⚠ AMBIENT — CORRECTED at the S42-5 audit, and the wording it replaces was measured FALSE.
        // The retired comment called this file neutral on the grounds that "the gesture it drives
        // writes no className and issues no `/edit` at all". That is true of only PART of the file.
        // Re-measured under `DESCVI_E2E_NO_SIDECAR=1` on this project: 4 of its 10 rows TIME OUT and
        // 6 pass. The four are precisely the ones that let the drag COMPLETE — acceptance 1–3, plus
        // the three `Escape not pressed` legs of the Escape matrix — and each of them awaits a
        // `waitForResponse` on `POST /edit` that never arrives with :7331 suppressed. The six that
        // pass are the Escape-CANCELLED legs and the two controls, which really do write nothing.
        // So the file's own byte-identity assertions are scoped to its cancelled rows and never
        // covered its completed ones. `e2e/fixtures/spec-classes.json` carries the same verdict, and
        // the phase-42 plan's G42-2 row called it ambient all along — this comment was the outlier.
        // Design-view regardless: its subject is the ring furniture and the overlay's selection
        // shield, neither of which the prototype view renders.
        '**/resize-handle-shield.spec.ts',
        // Neutral — phase-44 S44-0. Two row families in one file: `setContent` calibration rows over a
        // stylesheet this spec compiles itself (no descvi code runs on them at all, so their RED-when is
        // a Tailwind or Chromium change), and fixture-VALIDATION rows that load `lab/tests/spacing-nesting`
        // through this server and measure the rendered boxes jsdom cannot lay out. Per-ROW suppressed
        // statuses live in `docs/e3/tracker.md`; a file-level verdict would report the same green whether
        // one row survived the suppression or all of them did.
        '**/spacing-cascade.spec.ts',
        // Neutral — phase-45 S45-3b. Every row resolves a selection through the overlay's own shield and
        // issues no write at all: no `POST /edit`, no `page.tsx` splice, nothing for a sidecar to answer.
        // Design-view is the only project that can collect it, because the shield and the selection ring
        // are overlay chrome the prototype view does not render.
        '**/multi-select-shield.spec.ts',
        '**/multi-select-write.spec.ts',
        // AMBIENT — phase-47 S47-6, and argued in the spec's own header rather than here. Its subject (c)
        // drags a chain member three positions, awaits `POST /edit` and asserts the resulting bytes of
        // `src/app/lab/tests/reorder-flow/page.tsx`, which is this list's criterion. Its other six subjects
        // drive the gesture and read the ring layer's paint and would survive a suppression on their own;
        // the file as a whole cannot. Design-view regardless — the gesture lives in the selection shield.
        '**/reorder-drag.spec.ts',
        // Neutral, and collected by `plain` as well: the only file whose retained runtime guards do real work.
        '**/overlay-shell.spec.ts',
      ],
      fullyParallel: false,
      // The sidecar is a process-global singleton on a hardcoded port, so `workers > 1` on any sidecar-touching project is unsound whatever files the specs splice.
      workers: 1,
      retries: 0,
      use: { ...devices['Desktop Chrome'], baseURL: 'http://localhost:3001' },
    },
    {
      name: 'solo',
      testMatch: ['**/undo-session-restart.spec.ts', '**/unresolved-refresh.spec.ts'],
      fullyParallel: false,
      workers: 1,
      // A retry would re-run a destructive spec against an already-mutated fixture.
      retries: 0,
      dependencies: ['plain', 'design-view'],
      use: { ...devices['Desktop Chrome'], baseURL: 'http://localhost:3001' },
    },
  ],
  webServer: [
    {
      command: 'vite',
      url: 'http://localhost:3000',
      // The harness owns every process it depends on. `reuseExistingServer: !CI` let a bare local invocation adopt an arbitrary process on this port; the cost of `false` is a developer who has to stop `descvi:dev` first and gets a loud correct error, and the alternative is a silent wrong result.
      reuseExistingServer: false,
      timeout: 120_000,
    },
    {
      command: 'vite --config descvi.vite.config.mts',
      url: 'http://localhost:3001',
      reuseExistingServer: false,
      timeout: 120_000,
    },
  ],
});
