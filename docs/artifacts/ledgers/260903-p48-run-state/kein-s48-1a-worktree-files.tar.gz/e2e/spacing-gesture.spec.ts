import { test, expect, type Page } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

/**
 * spacing-gesture.spec.ts — the canvas spacing affordances and the numeric popup in a REAL browser (phase-44 S44-3; G44-1, G44-3, G44-4, G44-5 universes B and C, G44-6's canvas arm, G44-9's BOTH arms) — plus S44-4's live coverage: G44-8's sampled drags with the disk read-back, G44-9's live click arm, and acceptance 10's forced popup flip.
 *
 * WHY A BROWSER IS REQUIRED FOR THIS SET, stated because `__tests__/spacing-affordance-geometry.test.ts` asserts the same numbers. Four of these subjects do not exist in jsdom at all:
 *
 *  1. **`document.elementFromPoint`.** G44-9's whole claim is about which node a pixel belongs to, and a host     with no layout cannot answer. The vitest half asserts the ARITHMETIC that claim rests on; this half     asserts that the arithmetic reached the screen.
 *  2. **Computed `pointer-events`.** Measured on this repo's jsdom, a class-only `pointer-events-none` node     reads back `auto`, so C9's universe B would select every descendant and go RED against a correct     implementation. The class-only control below is what proves this run is reading the real cascade.
 *  3. **A computed `gap` and `padding`.** The affordance's extent comes from the computed property (never from     the geometric distance between two children — see `spacing-affordance-geometry.ts`'s header), and jsdom     computes neither from a Tailwind class.
 *  4. **Pointer capture and the synthesized click.** Acceptance 2's release OFF the affordance is decided by     whether capture was held, and jsdom implements neither the method nor the retargeting.
 *
 * CLASSIFICATION: **ambient** (`e2e/fixtures/spec-classes.json`). The committing rows drive a real gesture whose release POSTs through the sidecar on :7331 and splices `page.tsx` on disk. The non-committing rows read the resting DOM and would survive a suppression on their own — the file as a whole cannot.
 *
 * THE SUBJECT IS `lab/tests/spacing-nesting` (S44-0, plan §3.10), whose sixteen containers exist because the corpus has none of these shapes. `lab/tests/**` is the one namespace an `e2e/` file may name — the artifact oracle's `labSubjects` clause is a `lab/` whitelist — which is what lets these rows and the `descvi:dev` smoke share one subject.
 *
 * ⚠ **DESTRUCTIVE, ON THE COMMITTING ROWS ONLY.** Each restores the bytes it snapshotted and then RE-DERIVES `.descvi/` through `scripts/check-extract-outcome.mjs` rather than restoring the artifact from a snapshot — invariant 1's requirement for a derived file, and what makes the restore self-verifying.
 *
 * SERIAL: one shared on-disk fixture, one process-global sidecar.
 */

// `playwright test` always runs from the repo root (playwright.config.ts's dir).
const repoRoot = path.resolve(process.cwd());
const pageFixture = path.join(repoRoot, "src", "app", "lab", "tests", "spacing-nesting", "page.tsx");

const SCREEN = "/lab/tests/spacing-nesting";

// ── The fixture containers this file points at, by oid (see the screen's own numbered comments) ──
/** ③ `flex gap-2 gap-x-4` — an above-floor, below-ceiling gap with two children. The plain drag subject. */
const GAP_SUBJECT = "sngapn";
/** ⑤ `flex justify-between gap-x-4 gap-2` — G44-2's canvas arm: the Auto fold's ONE above-floor subject. */
const GAP_AUTO_COLLATERAL = "sngaco";
/** ⑦ `flex justify-between` — the Auto state itself. Computed gap 0, so the canvas shows NOTHING (G44-2c). */
const GAP_AUTO = "sngaut";
/** ⑧ `flex` — the FLOOR arm's zero-gap subject. */
const GAP_ZERO = "sngzro";
/** ⑨ `flex gap-[6px]` — the CLAMP arm: strictly inside `4 < gap < 16`. */
const GAP_THIN = "sngthn";
/** ⑩ `p-[8px]` — the padding CLAMP arm: strictly inside `4 < band < 12`. */
const PAD_THIN = "snpthn";
/** ⑭ `block p-4` — 16 px on all four edges, so every edge carries a strip AND an apron. The corner-conflict subject. */
const PAD_BROAD = "snnflx";
/** ⑯ `flex flex-wrap gap-[12px]` — the WRAPPING subject (S44-3 fix round, architect MF-2). */
const GAP_WRAP = "sngwrp";
/** ⑪ `flex p-0` with two STAMPED flush children — the drill-down surface. */
const PAD_FLUSH = "snpflu";
/** ⑫ `flex gap-[40px]` — the CEILING, and the only gap subject with a popup apron. */
const GAP_LARGE = "snglrg";
/** ⑥ `p-0 pt-4` — exactly one padding handle renders (top), and it has an apron (16 > 12). */
const PAD_ZERO_EXPLICIT = "snpzer";
/** ⑬ `p-2 md:p-8` — the variant refusal. Its padding family renders NOTHING (see the universe-B row). */
const PAD_VARIANT = "snpvar";
/** ⑮ `flex gap-[2px] p-[2px]` — BOTH floors' non-zero subject. */
const BELOW_FLOOR = "snbflr";

/** ⚠ THE CONSTANTS THIS FILE RE-STATES, deliberately, so a value that moved in the implementation alone turns
 * these rows RED rather than leaving them describing a bound the affordances have outgrown. They are NOT imported: an import would make every row below a tautology, which is the second-implementation discipline `e2e/resize-handles.spec.ts` states at length for phase-42's own numbers. */
const GAP_CEILING = 16;
const PAD_CEILING = 12;
const RENDER_FLOOR = 4;
/** S44-4's fourth re-stated constant, on the same terms as the three above: `use-spacing-drag.ts#const READOUT_GAP_PX = 12;` places the readout and the popup this far from their anchor, and the live rows assert that distance rather than importing it. An import would make the cursor-adjacency leg and the flip leg tautologies — the whole point of both is that the number reached the screen. */
const READOUT_GAP = 12;
/** G44-8's sampling rate — `k` fixed pointer offsets, evenly spaced across the drag's travel (S44-4 acceptance 1). */
const K_SAMPLES = 6;

interface AffordanceRecord {
  id: string;
  role: string;
  rect: { left: number; top: number; width: number; height: number };
  hasHandleAttr: boolean;
  hasGlyphControlAttr: boolean;
  hasGlyphDescendant: boolean;
  /** C46-1's DECLARED KIND — the marker's VALUE, or `null` when absent (ralplan-phase-46 §3.1 clause 2). */
  glyphKind: string | null;
  /** The size term a `glyph-conditional` node publishes, so a scan can check the hiding is a function of it. */
  hiddenBelow: string | null;
  /** The mark is in the DOM but computed `display: none` — the THIRD state §2.12 ratified. */
  markHidden: boolean;
  /** This node's own measured short side, the input the hiding is a function of. */
  shortSide: number;
  descriptor: string;
}

interface SpacingScene {
  /** Every OPERABLE node under `#dsh-spacing-layer` — keyed on computed `pointer-events`, never on a marker. */
  operable: AffordanceRecord[];
  /** The measured facts the expected count is DERIVED from, so no row carries a literal. */
  measured: {
    gapPx: number;
    padding: { top: number; right: number; bottom: number; left: number };
    childCount: number;
    isFlex: boolean;
  };
  /** The container's own children's border boxes — G44-9's probe subjects. */
  children: { left: number; top: number; width: number; height: number }[];
}

/**
 * ONE measurement pass over the resting DOM with `oid` selected. Everything a row asserts comes from this single evaluate, so no row can compare two reads of a layer that moved between them.
 */
async function readSpacingScene(page: Page, oid: string): Promise<SpacingScene> {
  return page.evaluate((oid) => {
    const layerEl = document.getElementById("dsh-spacing-layer")!;
    const el = document.querySelector(`[data-oid="${oid}"]`)! as HTMLElement;
    const style = getComputedStyle(el);
    const describe = (n: Element): string =>
      `${n.tagName.toLowerCase()}${n.id === "" ? "" : `#${n.id}`}[${n.getAttribute("data-dsh-spacing") ?? "-"}]`;
    const rect = (n: Element) => {
      const r = n.getBoundingClientRect();
      return { left: r.left, top: r.top, width: r.width, height: r.height };
    };
    const gapRaw = Number.parseFloat(style.flexDirection.startsWith("column") ? style.rowGap : style.columnGap);
    return {
      operable: Array.from(layerEl.querySelectorAll<HTMLElement>("*"))
        .filter((n) => getComputedStyle(n).pointerEvents !== "none")
        .map((n) => ({
          id: n.getAttribute("data-dsh-spacing") ?? "",
          role: n.getAttribute("data-dsh-spacing-role") ?? "",
          rect: rect(n),
          hasHandleAttr: n.hasAttribute("data-dsh-handle"),
          hasGlyphControlAttr: n.hasAttribute("data-v3-glyph-control"),
          hasGlyphDescendant: n.querySelector("svg, [data-glyph]") !== null,
          glyphKind: n.getAttribute("data-v3-glyph-control"),
          hiddenBelow: n.getAttribute("data-v3-glyph-hidden-below"),
          markHidden: (() => {
            const mark = n.querySelector("svg, [data-glyph]");
            return mark !== null && getComputedStyle(mark).display === "none";
          })(),
          shortSide: Math.min(n.getBoundingClientRect().width, n.getBoundingClientRect().height),
          descriptor: describe(n),
        })),
      measured: {
        gapPx: Number.isFinite(gapRaw) ? gapRaw : 0,
        padding: {
          top: Number.parseFloat(style.paddingTop) || 0,
          right: Number.parseFloat(style.paddingRight) || 0,
          bottom: Number.parseFloat(style.paddingBottom) || 0,
          left: Number.parseFloat(style.paddingLeft) || 0,
        },
        childCount: el.children.length,
        isFlex: style.display === "flex" || style.display === "inline-flex",
      },
      children: Array.from(el.children).map(rect),
    };
  }, oid);
}

/**
 * C46-1's `glyph-conditional` obligation (ralplan-phase-46 §3.1 clause 2), as a CHECKER rather than as inline expectations — so the identical expression can be run over a PLANTED node and shown to reject it. An expectation that has never been seen to reject anything is not yet an expectation, and an earlier revision of this row asserted this equality inline with no mutant at all.
 *
 * ⚠ **WHAT THIS DOES AND DOES NOT BUY, STATED SO THE STRONGER READING CANNOT STAND.** It is a CONSISTENCY check between two things the same phase writes — the hide predicate and the published term — so **a phase that lies consistently sails through**: a family that hid on `size >= 9999` and published `9999` satisfies every clause here, because the mark is hidden on every real node and every real node is below 9999. That escape hatch is NOT closed by C46-1 and is not claimed to be. What IS bought is real and was previously understated: the term becomes machine-readable rather than source-only; DRIFT between the hide predicate and the published term is RED; and the comparison crosses the rect `placeSpacingAffordances` placed the node with against the box the browser actually gave it, which are two different measurements rather than one read twice.
 *
 * ⚠ **AND THE 9999 HATCH IS CLOSED FOR TODAY'S SPACING FAMILY ONLY, BY SOMETHING ELSE ENTIRELY** — the F10 row below pins `display` against a hard-coded literal 8 that no production symbol feeds. That is a PER-FAMILY pin, not a property of the kind vocabulary: a second `glyph-conditional` family arriving in a later story inherits nothing from it and reopens the hatch on arrival.
 *
 * ⚠ **THE ±0.5 px BAND IS DELIBERATE.** Production hides on the rect `placeSpacingAffordances` computed; this reads `getBoundingClientRect()`. A node whose short side lands within a layout unit of exactly its own threshold would flip the expected side on a sub-pixel difference between two honest measurements. Nodes in that band are EXCLUDED from the equality and collected instead — and the row's bucket-inhabitance assertion is what stops that exclusion from silently hollowing the leg, because both buckets are counted from DECIDED nodes only.
 */
function conditionalArmViolations(scene: SpacingScene, nearBand: string[] = []): string[] {
  const out: string[] = [];
  for (const n of scene.operable) {
    if (n.glyphKind !== "glyph-conditional") continue;
    // ⚠ **THE NULL CASE IS TESTED BEFORE THE COERCION, AND AN EARLIER REVISION OF THIS FUNCTION GOT IT WRONG — caught by running the checker over its own mutants rather than by reading it.** `Number(null)` is **0**, which IS finite, so a `!Number.isFinite` guard alone lets a node with NO published term fall through to the equality and be named for the wrong reason, with a message reporting a "0px term" that nothing ever published. `Number("abc")` is `NaN` and `x < NaN` is FALSE, so a garbage term over a painted mark would sail through a bare equality too. Both are named here, distinctly, rather than left to the caller's `not.toBeNull()`, which catches neither.
    if (n.hiddenBelow === null || n.hiddenBelow.trim() === "") {
      out.push(`${n.descriptor}: declares glyph-conditional and publishes NO size term`);
      continue;
    }
    const term = Number(n.hiddenBelow);
    if (!Number.isFinite(term)) {
      out.push(`${n.descriptor}: size term ${JSON.stringify(n.hiddenBelow)} is not a finite number`);
      continue;
    }
    if (Math.abs(n.shortSide - term) <= 0.5) {
      nearBand.push(`${n.descriptor} short=${n.shortSide} term=${term}`);
      continue;
    }
    if (n.markHidden !== n.shortSide < term) {
      out.push(`${n.descriptor}: mark hidden=${n.markHidden} at ${n.shortSide}px against its own ${term}px term`);
    }
  }
  return out;
}

/**
 * §3.8's universe-B formula, RE-IMPLEMENTED here against the numbers THIS run measured.
 *
 * ⚠ A SECOND IMPLEMENTATION ON PURPOSE, and never an import of `expectedSpacingAffordanceCount`: an import makes every count row a tautology, which is the mistake `layout-table-fixtures.ts`'s own docblock forbids and `e2e/resize-handles.spec.ts` re-states for phase-42's admission rule. The `variantRefused` argument is threaded rather than derived because a className is not on this scene — and stating it per call is what makes `pad-variant`'s zero an assertion about the REFUSAL rather than about a container that happened to render nothing.
 */
function deriveExpectedCount(
  scene: SpacingScene,
  refused: { gap?: boolean; pad?: boolean } = {},
): number {
  const { gapPx, padding, isFlex } = scene.measured;
  // The FLEX guard is explicit: gap is refused on a non-flex container (`gap-requires-flex-container`), and the computed `"normal"` → 0 coincidence must not be the only thing holding the zero up.
  const gapEnabled = isFlex && refused.gap !== true;
  // ⚠ THE WRAP TERM, RE-STATED HERE RATHER THAN IMPORTED (S44-3 fix round). A band exists between two adjacent children only when they SHARE A FLEX LINE; on a wrapping container the pair that straddles the break is not separated by a gap at all. Two children overlap on the cross axis iff they are on one line, which is the whole test — measured from the boxes THIS run read, exactly as the count above is.
  const pairsOnOneLine = scene.children.reduce((total, child, i) => {
    const next = scene.children[i + 1];
    if (next === undefined) return total;
    const overlapCross = child.top < next.top + next.height && child.top + child.height > next.top;
    return overlapCross ? total + 1 : total;
  }, 0);
  const bands = gapEnabled && gapPx >= RENDER_FLOOR ? pairsOnOneLine : 0;
  const gapAprons = bands > 0 && gapPx > GAP_CEILING ? bands * 2 : 0;
  const padEnabled = refused.pad !== true;
  const edges = padEnabled ? Object.values(padding).filter((px) => px >= RENDER_FLOOR) : [];
  const padAprons = edges.filter((px) => px > PAD_CEILING).length;
  return bands + gapAprons + edges.length + padAprons;
}

async function select(page: Page, oid: string, position?: { x: number; y: number }): Promise<void> {
  await page.goto(SCREEN);
  await expect(page.locator("#dsh-ring-layer")).toBeAttached();
  await expect(page.locator("#dsh-spacing-layer")).toBeAttached();
  await page.locator(`[data-oid="${oid}"]`).click(position === undefined ? {} : { position });
  await expect(page.locator("#dsh-selection-ring")).toBeVisible();
}

/**
 * ⚠ **`select(page, PAD_FLUSH)` DOES NOT SELECT `snpflu`, AND EVERY ROW BELOW THAT NAMES THAT SUBJECT BELIEVED IT DID — measured in the S44-4 lane, corrected here.**
 *
 * `pad-flush-parent` is flush on all four edges by construction, so every pixel of its box belongs to one of its two stamped children. A centred `.click()` therefore passes Playwright's hit-target check — a child IS a descendant of the target, which is all that check asks — and descvi then resolves the selection to the DEEPEST stamped element under the pointer, which is a child. Measured by reading back which element the ring lands on after the shipped helper runs: `snpflu` → **`snpflb`**, while `sngzro`, `snbflr`, `sngwrp` and `sngapn` each select themselves.
 *
 * What that cost is the FLOOR arm's most important subject. With a leaf child selected, the parent's spacing family cannot render whatever the floor rule says, so the flush pair's probes were green under the render-floor mutation as well as under the correct implementation; the arm stayed falsifiable only through its other three subjects, which is why nothing observed it.
 *
 * The live route to a flush parent is the shield's own Cmd/Ctrl-click parent climb — `use-canvas-selection-shield.ts#Plain click → deepest stamped element; Cmd/Ctrl-click → the POINTER-RELATIVE parent` — which is also the route a user reaching this container takes. The climb is verified here rather than assumed: a helper that silently failed to climb would restore exactly the blindness it exists to remove.
 */
async function selectFlushParent(page: Page): Promise<void> {
  await select(page, PAD_FLUSH);
  const child = (await page.locator(`[data-oid="snpfla"]`).boundingBox())!;
  await page.keyboard.down("Meta");
  await page.mouse.click(child.x + child.width * 0.25, child.y + child.height * 0.25);
  await page.keyboard.up("Meta");
  await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  expect(await ringOwner(page), "the Cmd-click climb put the ring on the FLUSH PARENT, not on a child").toBe(PAD_FLUSH);
}

/**
 * The centre of one affordance's hit rect, in page coordinates — where a real press lands.
 *
 * ⚠ `nth` IS NOT OPTIONAL SUGAR: a clamped GAP band carries TWO aprons, one on each side of the centred strip, because the strip is centred in the band. A clamped PADDING edge carries ONE, because its strip is flush to the border box. The asymmetry is the geometry's, and a locator that assumed one apron per affordance resolved to two here and failed strict mode — which is the shape being asserted, arriving as an error.
 */
async function affordanceCentre(page: Page, id: string, role = "strip", nth = 0): Promise<{ x: number; y: number }> {
  const box = await page.locator(`[data-dsh-spacing="${id}"][data-dsh-spacing-role="${role}"]`).nth(nth).boundingBox();
  expect(box, `the ${role} #${nth} for ${id} is rendered`).not.toBeNull();
  return { x: box!.x + box!.width / 2, y: box!.y + box!.height / 2 };
}

/**
 * The affordance's DEEPEST INWARD point (plan `EG-1`'s alternate path (a)). RE-POINTING obligation: the straddling resize band now reaches 5 px inside the selected element's border box (plan §2), so a `pad:top` strip press aimed at its own bounding-box CENTRE — `snpthn`'s 8 px band puts that centre 4 px inside the border box, inside the band's reach — starts a resize gesture instead of a padding drag. `snpthn`'s `hitDepth` is 8 (`min(band, PAD_EDGE_HIT_BAND_PX)`), which exceeds the 5 px reach, so a point aimed at the strip's own deepest edge clears it. ⚠ Only `pad:top`/bottom/left/ right STRIP presses need this — the apron role is unaffected (an apron exists only where the band exceeds the 12 px ceiling, at least 12 px inward, clear of the 5 px band reach by construction).
 *
 * ⚠ **THE MARGIN IS BORROWED FROM `G48-4`'S MEASUREMENT RATHER THAN FRESHLY TAKEN AT `hitDepth` ON THIS SUBJECT (plan `EG-1`, whose own text licenses this as the declared alternative to a fresh reading taken AT `hitDepth`: state the borrowing and the reason it is sound, at the point where the value is used).** `e2e/resize-handles.spec.ts# const MARGIN = 1.5;` measured, on a REAL press, that `elementFromPoint` keeps resolving to the LOWER-z node beneath a higher-z neighbour up to ~1 px past that neighbour's own geometric edge — a quantisation at the STACKING boundary between two z-layered nodes sharing the same pixel, not a property of which two families are stacked. The boundary this function aims at is the SAME SHAPE: the resize band sits above the padding strip (`G48-7`'s `RESIZE_STRIP_Z > SPACING_STRIP_Z` inequality) along the identical inward axis, so a press at the strip's own deepest edge crosses the same kind of z-boundary `G48-4` measured, on furniture built by the same layer-compositing code path. The transfer moves a MEASURED quantity between two structurally identical boundaries rather than inventing a fresh unverified number; a subject-specific re-measurement here would be expected to land within noise of the borrowed 1.5, not to license a materially different one.
 */
async function affordancePaddingDeepestPoint(page: Page, id: string, edge: "top" | "bottom" | "left" | "right"): Promise<{ x: number; y: number }> {
  const box = await page.locator(`[data-dsh-spacing="${id}"][data-dsh-spacing-role="strip"]`).boundingBox();
  expect(box, `the strip for ${id} is rendered`).not.toBeNull();
  const b = box!;
  // Borrowed from `e2e/resize-handles.spec.ts# const MARGIN = 1.5;` (`G48-4`'s own measured z-boundary reach) rather than freshly measured at `hitDepth` here — see this function's docblock for why the transfer is sound.
  const MARGIN = 1.5;
  switch (edge) {
    case "top":
      return { x: b.x + b.width / 2, y: b.y + b.height - MARGIN };
    case "bottom":
      return { x: b.x + b.width / 2, y: b.y + MARGIN };
    case "left":
      return { x: b.x + b.width - MARGIN, y: b.y + b.height / 2 };
    default:
      return { x: b.x + MARGIN, y: b.y + b.height / 2 };
  }
}

interface Rect {
  left: number;
  top: number;
  width: number;
  height: number;
}

/**
 * ONE G44-8 sample: the container's band, the PAINTED band, every child box and the readout, captured in a SINGLE `page.evaluate` (S44-4 acceptance 1's mechanism, verbatim — "one sample, one layout read, so the container and children are read at the same instant rather than across two round trips").
 */
interface DragSample {
  /** The band the BROWSER renders — the computed gap on the drag's axis, or the computed padding edge. */
  bandPx: number;
  /**
   * ⚠ **THE PAINTED REGION IS THE HATCH AND NOT THE DRAG STRIP, and the choice is what makes the second RED-when reachable.** The strip is clamped to its ceiling, so on `gap-large` it is 16 px wide however far the drag travels, and a PADDING strip does not move at all as its band grows — a strip-only reading would call the padding drag motionless and the row would assert nothing. The hatch paints the MEASURED band (acceptance 5's own two numbers), which is exactly the quantity the second RED-when replaces with the drag delta.
   */
  region: Rect | null;
  children: Rect[];
  readout: { text: string; rect: Rect } | null;
  pointer: { x: number; y: number };
}

async function sampleDrag(
  page: Page,
  subject: { oid: string; id: string; edge: "gap" | "top" },
  pointer: { x: number; y: number },
): Promise<DragSample> {
  return page.evaluate(
    ({ oid, id, edge, pointer }) => {
      const rect = (n: Element | null): Rect | null => {
        if (n === null) return null;
        const r = n.getBoundingClientRect();
        return { left: r.left, top: r.top, width: r.width, height: r.height };
      };
      const el = document.querySelector(`[data-oid="${oid}"]`)! as HTMLElement;
      const style = getComputedStyle(el);
      const band =
        edge === "gap"
          ? Number.parseFloat(style.flexDirection.startsWith("column") ? style.rowGap : style.columnGap)
          : Number.parseFloat(style.paddingTop);
      const readout = document.getElementById("dsh-spacing-readout");
      const readoutRect = rect(readout);
      return {
        bandPx: Number.isFinite(band) ? band : 0,
        region: rect(document.querySelector(`[data-dsh-spacing-hatch="${id}"]`)),
        children: Array.from(el.children).map((c) => rect(c)!),
        readout: readout === null || readoutRect === null ? null : { text: readout.textContent ?? "", rect: readoutRect },
        pointer,
      };
    },
    { ...subject, pointer },
  );
}

/**
 * G44-8's assertion, applied to one drag's whole sample series (S44-4 acceptance 1). THREE legs, and the middle one is what keeps the first from being vacuous.
 *
 *  1. **THE PER-SAMPLE IMPLICATION, which is the gate.** In any sample where the band changed against the previous one, at least one child box must have moved IN THAT SAME SAMPLE. **RED-when: paint the band from the drag delta rather than from the measured box** — the region then tracks the cursor while the element is untouched until the release, and every sample reports a band that moved with all children standing still. ⚠ **AND THAT MUTATION DOES NOT FIRE ON ITS OWN — the third reversal of this story, measured by the review lane (plan erratum 2026-08-21):** with the preview write intact, the children keep moving whatever paints the hatch, so the implication's consequent still holds and the row stays GREEN under hatch-from-delta alone. Leg 1 is falsifiable only by the COMPOUND — preview write deleted AND the region painted from a non-measured source — and that compound is what the observed mutation B was. The plan's "and no child ever does" was false as written.
 *  2. **THE CONTROL.** An implication whose antecedent is never true is green on a gesture that does nothing at all, which is precisely the shape the FIRST RED-when produces from the other direction: **move the commit into the move handler** and the preview write disappears, so neither the band nor the children move and leg 1 passes on a drag that changed nothing. This leg requires the antecedent to hold in EVERY sample — `k` bands moved, `k` children moved with them.
 *  3. **THE READOUT LEG.** Every sample carries a cursor-adjacent numeric readout, and the number it reports is the band the element renders rather than the delta the pointer travelled.
 */
function assertSpacingDragSamples(samples: DragSample[], label: string): void {
  const moved = (a: Rect, b: Rect): boolean =>
    Math.abs(a.left - b.left) >= 0.5 ||
    Math.abs(a.top - b.top) >= 0.5 ||
    Math.abs(a.width - b.width) >= 0.5 ||
    Math.abs(a.height - b.height) >= 0.5;

  expect(samples, `${label}: the baseline plus k samples`).toHaveLength(K_SAMPLES + 1);
  for (const [i, s] of samples.entries()) {
    expect(s.region, `${label} sample ${i}: the painted band is on screen`).not.toBeNull();
  }

  const verdicts = samples.slice(1).map((cur, idx) => {
    const prev = samples[idx]!;
    return {
      sample: idx + 1,
      bandChanged: moved(prev.region!, cur.region!) || Math.abs(prev.bandPx - cur.bandPx) >= 0.5,
      childMoved: cur.children.some((c, i) => prev.children[i] === undefined || moved(prev.children[i]!, c)),
    };
  });
  // Leg 1 — the gate.
  expect(
    verdicts.filter((v) => v.bandChanged && !v.childMoved),
    `${label}: samples whose band moved while every child stood still`,
  ).toEqual([]);
  // Leg 2 — the control, without which leg 1 is green on a gesture that moved nothing.
  expect(
    verdicts.filter((v) => v.bandChanged && v.childMoved).map((v) => v.sample),
    `${label}: samples in which the band and a child moved together`,
  ).toEqual(Array.from({ length: K_SAMPLES }, (_, i) => i + 1));

  // Leg 3 — the readout. The BASELINE sample is exempt and the exemption is the classification rule rather than a tolerance: at the press the gesture has not travelled `POINTER_DRAG_THRESHOLD_PX`, so it is not yet a drag and owes no readout.
  for (const [i, s] of samples.entries()) {
    if (i === 0) continue;
    expect(s.readout, `${label} sample ${i}: a readout is in the DOM`).not.toBeNull();
    const px = /(\d+)px/.exec(s.readout!.text);
    expect(px, `${label} sample ${i}: the readout carries a number — "${s.readout!.text}"`).not.toBeNull();
    // RED-when: paint the readout from the drag delta → it disagrees with the band the element renders on the very first sample, because the drag starts from a non-zero band.
    expect(Number(px![1]), `${label} sample ${i}: the readout reports the rendered band`).toBe(Math.round(s.bandPx));
    // …and it is CURSOR-ADJACENT, asserted as INTERVAL OVERLAP with a ±(gap+1) window at the pointer rather than as a distance bound — deliberately loose so the flip branch passes on either side, which means a readout WIDE enough to span the pointer passes wherever its near edge sits; the observed mutation (a fixed layer-corner park) fires because the box is ~70px and the corner is far. RED-when: place it at a fixed corner of the ring layer → both axes fail from the first sample on.
    const r = s.readout!.rect;
    expect(
      r.left <= s.pointer.x + READOUT_GAP + 1 && r.left + r.width >= s.pointer.x - READOUT_GAP - 1,
      `${label} sample ${i}: the readout is beside the cursor horizontally`,
    ).toBe(true);
    expect(
      r.top <= s.pointer.y + READOUT_GAP + 1 && r.top + r.height >= s.pointer.y - READOUT_GAP - 1,
      `${label} sample ${i}: the readout is beside the cursor vertically`,
    ).toBe(true);
  }
}

/** The className literal one container carries ON DISK, scoped to its own `data-oid` — never a whole-file read of a per-element fact (the correction the G44-6 row above carries at length). */
function diskLiteral(oid: string): string {
  const found = new RegExp(`data-oid="${oid}"\\s+className="([^"]*)"`).exec(fs.readFileSync(pageFixture, "utf8"));
  expect(found, `${oid}'s className literal is findable on disk`).not.toBeNull();
  return found![1]!;
}

/**
 * Which stamped element the selection ring is on, resolved by matching its BOX against every `[data-oid]` on the page.
 *
 * The overlay publishes no selected-oid attribute, so the ring's own geometry is the only live read of the selection — and a box match is enough here because the subjects it separates (`snpflu` at 320 wide against its two 156-wide children, which share its top-left corner) differ in width by more than the tolerance.
 */
async function ringOwner(page: Page): Promise<string> {
  return page.evaluate(() => {
    const ring = document.getElementById("dsh-selection-ring");
    if (ring === null) return "none";
    const r = ring.getBoundingClientRect();
    const hit = Array.from(document.querySelectorAll<HTMLElement>("[data-oid]")).find((n) => {
      const b = n.getBoundingClientRect();
      return (
        Math.abs(b.left - r.left) < 3 &&
        Math.abs(b.top - r.top) < 3 &&
        Math.abs(b.width - r.width) < 3 &&
        Math.abs(b.height - r.height) < 3
      );
    });
    return hit?.getAttribute("data-oid") ?? `unmatched@${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.width)}`;
  });
}

/** The popup's placement against the layer that clips it — acceptance 10's containment reading, plus the two numbers the FLIP is decided by. */
async function readPopupPlacement(page: Page): Promise<{
  top: number;
  bottom: number;
  width: number;
  height: number;
  layerBottom: number;
  insideClip: boolean;
}> {
  return page.evaluate(() => {
    const layer = document.getElementById("dsh-ring-layer")!.getBoundingClientRect();
    const popup = document.getElementById("dsh-spacing-popup")!.getBoundingClientRect();
    return {
      top: popup.top,
      bottom: popup.bottom,
      width: popup.width,
      height: popup.height,
      layerBottom: layer.bottom,
      insideClip:
        popup.left >= layer.left - 0.5 &&
        popup.top >= layer.top - 0.5 &&
        popup.right <= layer.right + 0.5 &&
        popup.bottom <= layer.bottom + 0.5,
    };
  });
}

/** Counts every `POST /edit` the page issues from the moment it is installed. */
function countPosts(page: Page): { count: () => number; bodies: string[] } {
  const bodies: string[] = [];
  page.on("request", (req) => {
    if (req.method() !== "POST" || !req.url().endsWith("/edit")) return;
    bodies.push(req.postData() ?? "");
  });
  return { count: () => bodies.length, bodies };
}

test.describe.serial("S44-3 — the canvas spacing affordances and the popup", () => {
  test.setTimeout(120_000);
  let originalPage: Buffer | undefined;

  test.beforeEach(() => {
    originalPage = fs.readFileSync(pageFixture);
  });

  test.afterEach(() => {
    // The SAFETY NET, not the primary restore: every committing row puts the file back itself, so this only fires when a row failed BETWEEN its POST and its own restore.
    if (originalPage === undefined) return;
    const snapshot = originalPage;
    originalPage = undefined;
    if (fs.readFileSync(pageFixture).equals(snapshot)) return;
    fs.writeFileSync(pageFixture, snapshot);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  // ── acceptance 4 + G44-9a's FLOOR arm ──────────────────────────────────────────────────────────
  test("acceptance 4 — the render floors as COUNTS, both families, DERIVED per fixture", async ({ page }) => {
    // INSTRUMENT CONTROL FIRST: the scan can report a NON-ZERO count, so the zeros below are evidence.
    await select(page, GAP_SUBJECT);
    const live = await readSpacingScene(page, GAP_SUBJECT);
    expect(live.operable.length, "the scan finds a non-empty set on a subject that has one").toBeGreaterThan(0);
    expect(live.operable.length).toBe(deriveExpectedCount(live));

    // `gap-zero-flex` — no gap affordance at all, and the panel field is the live route.
    await select(page, GAP_ZERO);
    const zero = await readSpacingScene(page, GAP_ZERO);
    expect(zero.measured.gapPx).toBe(0);
    expect(zero.operable.filter((n) => n.id.startsWith("gap:"))).toEqual([]);
    expect(zero.operable.length).toBe(deriveExpectedCount(zero));
    // RED-when: render at zero → this count is 1 where 0 is correct. And the PANEL field is the live route, which is the half that makes the absence a design rather than a gap — §3.6.4's own sentence, asserted.
    await expect(page.getByTestId("dsh-spacing-gap")).toBeEnabled();

    // `pad-zero-explicit` — EXACTLY ONE padding handle, the top one, plus its apron (16 > the 12 ceiling).
    await select(page, PAD_ZERO_EXPLICIT);
    const explicit = await readSpacingScene(page, PAD_ZERO_EXPLICIT);
    expect(explicit.operable.filter((n) => n.role === "strip").map((n) => n.id)).toEqual(["pad:top"]);
    expect(explicit.operable.length).toBe(deriveExpectedCount(explicit));

    // ⚠ `spacing-below-floor` — ZERO of EITHER family at 2 px, which is above zero and below the floor.
    // RED-when: implement the floor as `band <= 0` → this count is 5 where 0 is correct, while every exactly-zero subject above stays green under the same mutation.
    await select(page, BELOW_FLOOR);
    const below = await readSpacingScene(page, BELOW_FLOOR);
    expect(below.measured.gapPx).toBe(2);
    expect(below.measured.padding).toEqual({ top: 2, right: 2, bottom: 2, left: 2 });
    expect(below.operable).toEqual([]);
    expect(deriveExpectedCount(below)).toBe(0);
  });

  test("G44-9a — with the parent selected, a pixel inside a FLUSH child's border box never returns a SPACING affordance (a resize band may, and is the priced outcome)", async ({
    page,
  }) => {
    // P44-4's gate, and the phase's most important row: the affordance must not eat the drill-down click.
    // ⚠ **`GAP_WRAP` IS IN THIS LIST AND IT IS THE ONLY MEMBER THAT CAN FALSIFY THE WRAP RULE.** The other three are FLOOR subjects — they render nothing, so they are green under any band geometry whatsoever. Measured before the fix, `gap-wrap`'s DOM-order band landed at left 94 / width 12 / full content height and overlapped BOTH of its children; the three floor subjects stayed green throughout. A universal row whose population cannot contain the shape it forbids is the blindness MF-3 filed against r0, one geometry along.
    // RED-when: delete the same-flex-line guard from `gapBands` → this row fires on `gap-wrap` alone.
    // ⚠ **AND `PAD_FLUSH` IS SELECTED THROUGH THE CLIMB, NOT THROUGH `select()` — a correction, and the reason is in `selectFlushParent`'s own docblock: the shipped helper lands on a CHILD on this one subject, so the flush pair contributed nothing to this row. The A/B, measured in the S44-4 lane with the GAP floor deleted AND the GAP clamp replaced by the ceiling (gap family only — mutating the padding pair too makes the pre-reversal row fail on the selected child's own zero-padding bands and the A/B degenerates, measured by the review lane): through the climb the row fails naming `snpflu`, the FIRST subject; through the shipped helper the same mutation lets `snpflu` pass and the row fails naming `sngzro`.**
    //
    // ⚠ **AND THE ROW'S OWN RED-when (i) IS NARROWER THAN ITS WORDING — MEASURED, and corrected here rather than left to be re-derived.** "Delete the render-floor rule → every probe returns the affordance" does NOT hold on the exactly-zero subjects on its own: a zero band renders a ZERO-EXTENT node, and `elementFromPoint` cannot return a box with no area. Deleting both floors alone leaves every probe in this loop green and fires the DERIVED-COUNT leg at the bottom instead (measured: `gap-wrap` reports 4 where 0 is correct). The probes fire when the missing floor is combined with a hit band that is not the measured one — the clamp mutation — which is the geometry that actually takes surface from a child. Both mutations are caught, by different legs; the sentence claiming one leg catches both was the thing that was wrong.
    for (const oid of [PAD_FLUSH, GAP_ZERO, BELOW_FLOOR, GAP_WRAP]) {
      if (oid === PAD_FLUSH) await selectFlushParent(page);
      else await select(page, oid);
      const scene = await readSpacingScene(page, oid);
      expect(scene.children.length, `${oid} has children to probe`).toBeGreaterThan(0);
      // ⚠ **RE-POINTED (phase-48 B-Q5, plan §8.1).** The straddling resize band (plan §2) now reaches 5 px INSIDE the selected PARENT's border box along its whole perimeter, so a probe 1 px inside a FLUSH child's edge can land on the parent's OWN resize furniture rather than on the page — a hit this row's old `gap:`/`pad:` filter could not see, because a resize handle carries neither prefix. The classification below NAMES the family that answered: `spacing`, `resize` or `page`. The row's real claim — the SPACING family must never eat the drill-down click — is unchanged; a resize-family hit on a flush child is recorded as the PRICED, ACCEPTED outcome under the owner's 2026-09-02 ruling (`.omc/research/phase48-straddle-drilldown-cost.md`) rather than silently counted as a page hit.
      const hits = await page.evaluate((children) => {
        const out: string[] = [];
        for (const child of children) {
          // One pixel inside the border box, at 25 % along each edge — the plan's own probe.
          const probes: [number, number][] = [
            [child.left + 1, child.top + child.height * 0.25],
            [child.left + child.width - 1, child.top + child.height * 0.25],
            [child.left + child.width * 0.25, child.top + 1],
            [child.left + child.width * 0.25, child.top + child.height - 1],
          ];
          for (const [x, y] of probes) {
            const n = document.elementFromPoint(x, y);
            if (n === null) {
              out.push("null");
              continue;
            }
            const spacingId = n.getAttribute("data-dsh-spacing");
            if (spacingId !== null) {
              out.push(spacingId);
            } else if (n.hasAttribute("data-dsh-handle")) {
              out.push(`resize:${n.getAttribute("data-dsh-handle")}`);
            } else {
              out.push(`page:${n.tagName.toLowerCase()}`);
            }
          }
        }
        return out;
      }, scene.children);
      // RED-when: delete the render-floor rule → every probe returns a spacing affordance id.
      expect(
        hits.filter((h) => h.startsWith("gap:") || h.startsWith("pad:")),
        `${oid}: probes that hit a SPACING affordance (never expected)`,
      ).toEqual([]);
      const resizeHits = hits.filter((h) => h.startsWith("resize:"));
      if (resizeHits.length > 0) console.log(`${oid}: resize-family hits on a flush child (priced, accepted):`, resizeHits);
      // ⚠ ASSERTED, NOT MERELY LOGGED (plan §8's honesty requirement) — a `console.log` alone cannot fail and therefore cannot catch a LATER widening of the resize band's inward reach. Pinned per fixture, sorted (the probe ORDER is an artifact of `scene.children`'s own order, not part of the claim): measured 2026-09-03.
      //
      // ⚠ **THE DERIVATION — stated so a future RED reads as "the band widened" or "the fixture moved" instead of as an opaque literal.** Every probe above sits 1 px inside ONE edge of ONE child, at 25 % along that edge's own long axis (the four `[number, number]` tuples, above). A probe resolves to `resize:<compass>` iff (a) that child's edge is FLUSH — zero gap — with the PARENT's own border box on the SAME side, and (b) that 1 px depth sits inside the parent's straddling band's 5 px inward reach (`HANDLE_BAND_PX / 2`) on that side. The compass named is always the PARENT's OWN edge (`w` for a west-edge probe, `n` for north, and so on) — never a corner, because every probe here sits at 25 % along an edge, well outside any corner square's reach on these `320×120` fixtures — and never the CHILD's own compass, because the furniture belongs to the selected PARENT. Each entry below is one (child, edge) pair that is flush with the parent on that edge, read off `src/app/lab/tests/spacing-nesting/page.tsx`'s own static layout:
      //
      // - `PAD_FLUSH` (`snpflu`, `p-0`, two 160×120 children, zero row-gap, `flex`): the LEFT child (`snpfla`) sits at `x:[0,160]` — flush on `w` (parent left) and, top-aligned in a 120-tall parent with a 120-tall child, on `n` AND `s` too; the RIGHT child (`snpflb`) sits at `x:[160,320]` — flush on `e` (parent right), `n` and `s`. Total: `e:1, n:2, s:2, w:1`. - `GAP_ZERO` (`sngzro`, no padding token, two 120×40 children, zero gap, `flex`, top-aligned): the left child is flush on `w` and `n`; the right child (`x:[120,240]`) is flush on `n` only (its `right:240` and the parent's own `320` do not coincide). Total: `n:2, w:1`. - `BELOW_FLOOR` (`snbflr`, `p-[2px] gap-[2px]`, two 120×40 children): NEITHER child's edge is literally flush (the 2 px padding offsets both from the parent's own border), but the band's reach is 5 px, not 0 — the left child's west probe (`child.left + 1` = `2 + 1 = 3`) and both children's north probes (`child.top + 1` = `2 + 1 = 3`) still fall inside the `w` and `n` bands' `[−5, 5]` reach from the parent's own edges. Total: `n:2, w:1` — the SAME shape as `GAP_ZERO`, for a different reason (reach past a padding gap, not literal flush). - `GAP_WRAP` (`sngwrp`, `flex flex-wrap gap-[12px]`, two 200×40 children that do not fit on one 320 px line): line 1 holds the first child at `x:[0,200], y:[0,40]` — flush on `w` and `n`; line 2 starts fresh at the container's own left edge after the 12 px row-gap, so the second child sits at `x:[0,200], y:[52,92]` — flush on `w` only (its `y` range touches neither the parent's top nor its bottom). Total: `n:1, w:2`.
      //
      // A band widened past 5 px would ADD entries (a probe further from the parent's edge starts landing inside the wider reach, exactly as `BELOW_FLOOR`'s padding-offset children already do at the shipped 5 px); a fixture whose layout moved — a child no longer flush, or newly flush — changes WHICH (child, edge) pairs appear, not merely how many.
      const RESIZE_HITS_BY_OID: Record<string, string[]> = {
        [PAD_FLUSH]: ["resize:e", "resize:n", "resize:n", "resize:s", "resize:s", "resize:w"],
        [GAP_ZERO]: ["resize:n", "resize:n", "resize:w"],
        [BELOW_FLOOR]: ["resize:n", "resize:n", "resize:w"],
        [GAP_WRAP]: ["resize:n", "resize:w", "resize:w"],
      };
      expect(
        [...resizeHits].sort(),
        `${oid}: the resize-family hit set on this flush-child probe is pinned, not open-ended`,
      ).toEqual(RESIZE_HITS_BY_OID[oid]);
    }

    // …and the WRAP subject's own positive statement, so its zero above is a fact about the rule rather than about a container that happened to render nothing: the gap really is above the floor and really is enabled, and the band count is nonetheless ZERO because the only adjacent pair straddles a line break.
    const wrap = await readSpacingScene(page, GAP_WRAP);
    expect(wrap.measured.gapPx, "the wrap subject's gap is above the render floor").toBeGreaterThanOrEqual(RENDER_FLOOR);
    expect(wrap.measured.isFlex).toBe(true);
    expect(wrap.measured.childCount).toBe(2);
    expect(wrap.operable.filter((n) => n.id.startsWith("gap:")), "a wrapped pair mints no band").toEqual([]);
    // The two children really are on different lines — the premise, measured rather than authored.
    const [a1, b1] = wrap.children;
    expect(a1!.top + a1!.height, "the second child is on a second line").toBeLessThanOrEqual(b1!.top + 0.5);
    // And the derived formula agrees, which is what keeps the count row from drifting from the placement rule.
    expect(wrap.operable.length).toBe(deriveExpectedCount(wrap));
  });

  // ── G44-9b, the CLAMP arm ──────────────────────────────────────────────────────────────────────
  test("G44-9b — `gap-thin` and `pad-thin`: the rendered hit band is the MEASURED band, not the ceiling", async ({
    page,
  }) => {
    await select(page, GAP_THIN);
    const thin = await readSpacingScene(page, GAP_THIN);
    expect(thin.measured.gapPx).toBe(6);
    const band = thin.operable.find((n) => n.id === "gap:0" && n.role === "strip");
    expect(band, "the gap strip renders on a 6 px gap").toBeDefined();
    // RED-when: replace `min(band, CEILING)` with `CEILING` → the band is 16 and reaches 5 px into each neighbouring child, which the overlap assertion below sees.
    expect(Math.round(band!.rect.width)).toBe(6);
    expect(Math.round(band!.rect.width)).not.toBe(GAP_CEILING);
    for (const child of thin.children) {
      const overlaps =
        band!.rect.left < child.left + child.width &&
        band!.rect.left + band!.rect.width > child.left &&
        band!.rect.top < child.top + child.height &&
        band!.rect.top + band!.rect.height > child.top;
      expect(overlaps, `the 6 px band overlaps ${JSON.stringify(child)}`).toBe(false);
    }
    // …and below the ceiling there is NO apron, so the popup has no opening surface on this subject.
    expect(thin.operable.filter((n) => n.role === "apron")).toEqual([]);

    await select(page, PAD_THIN);
    const padThin = await readSpacingScene(page, PAD_THIN);
    expect(padThin.measured.padding.top).toBe(8);
    const top = padThin.operable.find((n) => n.id === "pad:top" && n.role === "strip");
    expect(Math.round(top!.rect.height)).toBe(8);
    expect(Math.round(top!.rect.height)).not.toBe(PAD_CEILING);
  });

  // ── acceptance 5, the CEILING ──────────────────────────────────────────────────────────────────
  test("acceptance 5 — `gap-large` (40 px): the DRAG band is the ceiling and the hatch is the measured band", async ({
    page,
  }) => {
    await select(page, GAP_LARGE);
    const scene = await readSpacingScene(page, GAP_LARGE);
    expect(scene.measured.gapPx).toBe(40);
    const strip = scene.operable.find((n) => n.id === "gap:0" && n.role === "strip");
    // RED-when: drop the ceiling → the drag band matches the gap and a 200 px gap becomes a 200 px hot region.
    // ⚠ This mutation is INVISIBLE on `gap-thin` and `gap-thin`'s is invisible here — opposite mutations on opposite subjects, which is why the two rows are separate.
    expect(Math.round(strip!.rect.width)).toBe(GAP_CEILING);
    const aprons = scene.operable.filter((n) => n.id === "gap:0" && n.role === "apron");
    expect(aprons).toHaveLength(2);
    expect(aprons.map((a) => Math.round(a.rect.width))).toEqual([12, 12]);
    // ⚠ THE HATCH IS HOVER-DRIVEN AND THE HIT TARGET IS NOT (§3.8's ruling), so the hatch has to be HOVERED before it can be measured — measured the hard way in this lane: a resting read returned width 0, which is the ruling working rather than a defect. The strip and the apron light the SAME hatch, because they are one band split by the ceiling and a hover that lit only the part under the pointer would draw the split as if it were the geometry.
    const restingHatch = await page.evaluate(
      () => getComputedStyle(document.querySelector('[data-dsh-spacing-hatch="gap:0"]')!).display,
    );
    expect(restingHatch, "the hatch does not paint at rest").toBe("none");
    await page.mouse.move(strip!.rect.left + strip!.rect.width / 2, strip!.rect.top + strip!.rect.height / 2);
    await expect(page.locator('[data-dsh-spacing-hatch="gap:0"]')).toBeVisible();
    const hatchWidth = await page.evaluate(
      () => document.querySelector('[data-dsh-spacing-hatch="gap:0"]')!.getBoundingClientRect().width,
    );
    // The hatch paints the MEASURED band exactly — 40 — while the drag band above is the ceiling. The two numbers differing is the whole of §3.6.1-vs-§3.6.2.
    expect(Math.round(hatchWidth)).toBe(40);
  });

  // ── G44-4, the scope ───────────────────────────────────────────────────────────────────────────
  test("G44-4 — bands appear between the SELECTED container's own children only, never its siblings", async ({
    page,
  }) => {
    await select(page, GAP_SUBJECT);
    const scene = await readSpacingScene(page, GAP_SUBJECT);
    const bands = scene.operable.filter((n) => n.id.startsWith("gap:") && n.role === "strip");
    // The count is DERIVED from the measured child list, never a literal.
    expect(bands).toHaveLength(scene.measured.childCount - 1);
    // RED-when: widen the query to the grandparent → every band's rect would have to sit inside the SELECTED container's box, and a grandparent band does not. Asserted positively so the widening is what fires.
    const box = await page.locator(`[data-oid="${GAP_SUBJECT}"]`).boundingBox();
    for (const b of bands) {
      expect(b.rect.left).toBeGreaterThanOrEqual(box!.x - 0.5);
      expect(b.rect.left + b.rect.width).toBeLessThanOrEqual(box!.x + box!.width + 0.5);
    }
  });

  // ── G44-2 arm (c) — the Auto state renders NOTHING of the gap family ───────────────────────────
  test("G44-2(c) — on `gap-auto` the canvas renders no strip, no hatch and no popup", async ({ page }) => {
    await select(page, GAP_AUTO);
    const scene = await readSpacingScene(page, GAP_AUTO);
    // ⚠ THE DISTANCE BETWEEN THE CHILDREN IS LARGE AND THE COMPUTED GAP IS ZERO — which is the whole Auto state, and the reason the affordance's extent comes from the computed property. RED-when: measure the band geometrically → an 80 px strip renders here and this row fires.
    expect(scene.measured.gapPx).toBe(0);
    const [first, second] = scene.children;
    expect(second!.left - (first!.left + first!.width), "the free space is real").toBeGreaterThan(RENDER_FLOOR);
    expect(scene.operable.filter((n) => n.id.startsWith("gap:"))).toEqual([]);
    await expect(page.locator('[data-dsh-spacing-hatch^="gap:"]')).toHaveCount(0);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);
  });

  // ── G44-5, C9 universes B and C ────────────────────────────────────────────────────────────────
  test("G44-5 universe B — every operable node in the spacing layer is MARKED, GLYPHED and hit-targeted", async ({
    page,
  }) => {
    // ⚠ **THE SUBJECT IS A SET, NOT ONE CONTAINER, AND THE SET IS CHOSEN TO CONTAIN ALL FOUR NODE CLASSES (W-4).** The first draft ran this on `nest-gap`, whose whole inventory is ONE gap strip — so the marker, glyph and hit-target legs were asserted about a single node and three of the four classes the layer can render (gap apron, pad strip, pad apron) were never scanned at all. No container carries all four (none has both an above-ceiling gap AND above-ceiling padding), so the row iterates two that together do, and ASSERTS the coverage rather than assuming it.
    const seen = new Set<string>();
    // C46-1's two arms, collected across the fixtures so the row can assert both are INHABITED. Without this the equality could be asserting one answer everywhere and read as a clean pass — the shape F10 below already guards against for its own buckets, applied here to the leg C46-1 added.
    const hiddenArm: string[] = [];
    const paintedArm: string[] = [];
    const nearBand: string[] = [];
    for (const oid of [GAP_LARGE, PAD_BROAD]) {
      await select(page, oid);
      const scene = await readSpacingScene(page, oid);
      expect(scene.operable.length, `${oid}: the derived count`).toBe(deriveExpectedCount(scene));
      expect(scene.operable.length, `${oid}: something renders`).toBeGreaterThan(0);
      for (const node of scene.operable) {
        seen.add(`${node.id.split(":")[0]}/${node.role}`);
        // (B1) RED-when: an operable node without the marker.
        expect(node.hasHandleAttr, `${node.descriptor} carries data-dsh-handle`).toBe(true);
        expect(node.hasGlyphControlAttr, `${node.descriptor} carries data-v3-glyph-control`).toBe(true);
        // ⚠ **(B1a) C46-1's DECLARED KIND, ADDED AT phase-46 S46-1 — AND IT IS WHY THAT STORY OWNS THIS FILE.** `#dsh-spacing-layer` is a CHILD of `#dsh-ring-layer`, so these nodes are inside C46-0's universe (ralplan-phase-46 §3.0); the marker used to be written here with an EMPTY value, so the kind-declaration gate would have fired on them the moment the mechanism landed in `use-resize-handles.ts`. Stamping the kind in the same commit is what keeps the commit whose entire purpose is proving there is no red window from opening one, and this row is where that stamping is asserted. **The set is written out by hand, never imported** — this file's own header states why its oracles are second implementations.
        expect(["glyph", "glyph-conditional", "cursor"], `${node.descriptor} declares a kind from the closed set`).toContain(node.glyphKind);
        // ⚠ **AND THIS FAMILY'S KIND IS `glyph-conditional` SPECIFICALLY, WITH ITS SIZE TERM PUBLISHED.** The mark below `SPACING_GLYPH_PX` is present in the DOM and hidden as a measured function of the node's OWN size — shipped, spec-ratified, separately-gated behaviour (the F10 row below asserts both halves of it), which is why C46-1 has a third kind at all rather than making every 4–7 px strip a violation in exactly the state another gate mandates. ⚠ **What the declaration buys is a LABEL, not an enforcement**: nothing in it fixes a floor, a ceiling or a reachable threshold. What it stops is a permanently-hidden mark being SILENTLY legitimate — the hider must name itself, and `data-v3-glyph-hidden-below` is how it does so where a scan can read it.
        expect(node.glyphKind, `${node.descriptor} is the conditional kind`).toBe("glyph-conditional");
        expect(node.hiddenBelow, `${node.descriptor} publishes its size term`).not.toBeNull();
        if (Math.abs(node.shortSide - Number(node.hiddenBelow)) > 0.5) {
          (node.markHidden ? hiddenArm : paintedArm).push(`${oid} ${node.descriptor} short=${node.shortSide}`);
        }
        // (B2) RED-when: a `+` character instead of a glyph.
        expect(node.hasGlyphDescendant, `${node.descriptor} has an svg/[data-glyph] descendant`).toBe(true);
        expect(node.rect.width, `${node.descriptor} has a hit target`).toBeGreaterThan(0);
        expect(node.rect.height, `${node.descriptor} has a hit target`).toBeGreaterThan(0);
      }
    }
    // THE COVERAGE ASSERTION — without it the two subjects could both degrade to one class and the row would still pass, which is the exact failure the widening was for.
    expect([...seen].sort()).toEqual(["gap/apron", "gap/strip", "pad/apron", "pad/strip"]);
    // ⚠ **BOTH ARMS OF THE CONDITIONAL EQUALITY MUST BE INHABITED ON THESE TWO FIXTURES, OR THE LEG IS ASSERTING ONE ANSWER EVERYWHERE.** Predicted from the geometry module's own browser-free oracle before this row was written, so a red here is a real change rather than a surprise: `GAP_LARGE` (`flex gap-[40px]`) gives a 16 px strip and two 12 px aprons — all painted; `PAD_BROAD` (`block p-4`) gives four 12 px strips and four **4 px aprons**, and 4 < 8 is what inhabits the hidden arm. Nothing sits near the threshold, which is why the ±0.5 band above excludes nobody here.
    expect(paintedArm.length, `painted arm: ${paintedArm.join(" | ")}`).toBeGreaterThan(0);
    expect(hiddenArm.length, `hidden arm: ${hiddenArm.join(" | ")} (near-threshold, excluded: ${nearBand.join(" | ") || "none"})`).toBeGreaterThan(0);

    const scene = await readSpacingScene(page, PAD_BROAD);
    // Glyph descendants are non-hittable BY RULE, which is what keeps this universe equal to the set of hit target ROOTS instead of swelling to every `<path>` inside them.
    expect(scene.operable.every((n) => !n.descriptor.startsWith("svg") && !n.descriptor.startsWith("path"))).toBe(true);

    // CONTROL 1, positive: an UNMARKED hittable node must be NAMED by this universe. Without it a scan that selected nothing at all would read as a clean pass.
    const withPlant = await page.evaluate(() => {
      const plant = document.createElement("div");
      plant.setAttribute("data-probe-plant", "");
      plant.style.pointerEvents = "auto";
      plant.style.position = "absolute";
      document.getElementById("dsh-spacing-layer")!.appendChild(plant);
      const n = Array.from(document.getElementById("dsh-spacing-layer")!.querySelectorAll<HTMLElement>("*"))
        .filter((el) => getComputedStyle(el).pointerEvents !== "none")
        .filter((el) => !el.hasAttribute("data-dsh-handle")).length;
      plant.remove();
      return n;
    });
    expect(withPlant).toBe(1);

    // ⚠ **(B2) THE MARKED TEXT-ONLY PLANT — the pair's second half, applied rather than described.** An operable node that carries BOTH markers but whose "glyph" is a `+` character must be NAMED by the glyph leg. Without this, half (2) of the universe is asserted only about nodes that already pass it, and a `+`-for-an-svg regression would ship green. The plant is removed in the same evaluate, so the row leaves nothing behind.
    const markedTextOnly = await page.evaluate(() => {
      const layer = document.getElementById("dsh-spacing-layer")!;
      const plant = document.createElement("div");
      plant.setAttribute("data-dsh-spacing", "gap:99");
      plant.setAttribute("data-dsh-spacing-role", "strip");
      plant.setAttribute("data-dsh-handle", "spacing-gap");
      plant.setAttribute("data-v3-glyph-control", "");
      plant.style.pointerEvents = "auto";
      plant.style.position = "absolute";
      plant.textContent = "+";
      layer.appendChild(plant);
      const offenders = Array.from(layer.querySelectorAll<HTMLElement>("*"))
        .filter((n) => getComputedStyle(n).pointerEvents !== "none")
        .filter((n) => n.hasAttribute("data-v3-glyph-control"))
        .filter((n) => n.querySelector("svg, [data-glyph]") === null).length;
      plant.remove();
      return offenders;
    });
    expect(markedTextOnly, "a marked, text-only node is named by the glyph leg").toBe(1);

    // ⚠ **G46-3's CONDITIONAL ARM — ITS MUTANTS ARE PLANTED, NOT BORROWED, AND THAT IS A CORRECTION THIS PLAN PAID FOR.** Making this file's own suppression unconditional would turn the SHIPPED phase-44 F10 row RED, which it would do with or without C46-1 and which demonstrates nothing about the new obligation. The mutants that ARE about the declaration are below.
    //
    // ⚠ **THEY ARE RUN THROUGH `conditionalArmViolations` OVER A REAL `readSpacingScene` READ — the identical expression the loop above asserts — rather than through a predicate re-implemented inside a `page.evaluate`.** An earlier revision did the latter, and it left the leg's actual expectation with no mutant at all while looking like it had one: the plant exercised a second predicate that merely resembled it, and only that predicate's `term === null` branch. Both branches of the real equality are fired here.
    //
    // ⚠ **AND EACH PLANT IS ASSERTED TO HAVE APPLIED**: a reading of 1 is otherwise consistent with "the plant contributed 0 and something real contributed 1". The before-reading and the after-removal reading are what distinguish those.
    await select(page, PAD_BROAD);
    const plantConditional = (attrs: Record<string, string>): Promise<void> =>
      page.evaluate((a) => {
        const plant = document.createElement("div");
        plant.setAttribute("data-probe-plant", "");
        plant.setAttribute("data-dsh-spacing", "gap:98");
        plant.setAttribute("data-dsh-spacing-role", "strip");
        plant.setAttribute("data-dsh-handle", "spacing-gap");
        plant.setAttribute("data-v3-glyph-control", "glyph-conditional");
        for (const [k, v] of Object.entries(a)) plant.setAttribute(k, v);
        plant.style.pointerEvents = "auto";
        plant.style.position = "absolute";
        plant.style.width = "40px";
        plant.style.height = "40px";
        plant.innerHTML = '<svg data-glyph="probe" width="8" height="8" style="display:none"></svg>';
        document.getElementById("dsh-spacing-layer")!.appendChild(plant);
      }, attrs);
    const dropPlants = (): Promise<void> =>
      page.evaluate(() => {
        for (const n of Array.from(document.querySelectorAll("[data-probe-plant]"))) n.remove();
      });
    const armViolations = async (): Promise<string[]> => conditionalArmViolations(await readSpacingScene(page, PAD_BROAD));

    expect(await armViolations(), "BEFORE any plant: the live layer is clean").toEqual([]);

    // MUTANT 1 — hidden with **no size term at all**: permanently invisible, and under the pre-C46-1 contract silently legitimate, because a DOM scan for a descendant finds one. This is the `term` branch.
    await plantConditional({});
    expect(await armViolations(), "no size term").toEqual([expect.stringContaining("publishes NO size term")]);
    await dropPlants();
    expect(await armViolations(), "…and the layer is clean again").toEqual([]);

    // MUTANT 2 — hidden while at or ABOVE its own published term: 40 px node, `data-v3-glyph-hidden-below="8"`, mark `display:none`. ⚠ **THIS IS THE EQUALITY'S OWN CONTENT** and an earlier revision never fired it: the node is otherwise fully eligible — right kind, right marker, a real `[data-glyph]` descendant, a finite term, a non-zero hit box — so it can be named by nothing except the leg it breaks.
    await plantConditional({ "data-v3-glyph-hidden-below": "8" });
    expect(await armViolations(), "hidden while above its own term").toEqual([
      expect.stringMatching(/mark hidden=true at 40(\.\d+)?px against its own 8px term/),
    ]);
    await dropPlants();
    expect(await armViolations(), "…and the layer is clean again").toEqual([]);

    // MUTANT 3 — a NON-NUMERIC term over the same hidden mark. `Number("abc")` is `NaN` and `x < NaN` is false, so a bare equality would have called this legitimate; `not.toBeNull()` does not catch it either.
    await plantConditional({ "data-v3-glyph-hidden-below": "abc" });
    expect(await armViolations(), "a garbage size term").toEqual([expect.stringContaining('"abc" is not a finite number')]);
    await dropPlants();
    expect(await armViolations(), "…and the layer is clean again").toEqual([]);

    await select(page, PAD_BROAD);

    // CONTROL 2, mandatory: a CLASS-ONLY `pointer-events-none` node must classify NON-operable here. In jsdom it reads `auto` and this universe would go RED against a correct implementation; this is the assertion that proves this run is reading the real cascade.
    const classOnlyOperable = await page.evaluate(() => {
      const plant = document.createElement("div");
      plant.className = "pointer-events-none";
      document.getElementById("dsh-spacing-layer")!.appendChild(plant);
      const operable = getComputedStyle(plant).pointerEvents !== "none";
      plant.remove();
      return operable;
    });
    expect(classOnlyOperable).toBe(false);
  });

  // ── F10 — THE GLYPH's OWN ADMISSION RULE ──────────────────────────────────────────────────────
  test("⚠ C9's GLYPH LEG IS DOM PRESENCE, AND BELOW 8 px THE GLYPH IS PRESENT BUT NOT PAINTED — stated, not hidden", async ({
    page,
  }) => {
    // ⚠ **THE CONTRADICTION THIS ROW SETTLES, AND THE MEASUREMENT THAT SETTLED IT.** The implementation drops a glyph whose node is narrower than the glyph itself (8 px) — a mark scaled below its own stroke weight greys into a smudge — while C9's half (2) asks only that a marked element HAVE an `svg`/`[data-glyph]` descendant. So on a sub-8 px node the C9 leg passes on a glyph nobody can see. An earlier lane note called the 6 px strip's mark "legible"; **measured on a real browser it is `display: none`**, and that note was wrong.
    //
    // THE RULING: the exclusion is REAL and is stated here rather than papered over. What C9 buys on those nodes is that the mark EXISTS and would paint the moment the band widened — the affordance is not a bare hit rect with no visual vocabulary — and what it does not buy is a visible mark at every size. The populations are named so the accounting is checkable rather than implied.
    // RED-when: change the drop threshold in either direction → a row below reports the wrong bucket.
    const painted: string[] = [];
    const unpainted: string[] = [];
    for (const oid of [GAP_THIN, PAD_THIN, PAD_BROAD, GAP_LARGE]) {
      await select(page, oid);
      const rows = await page.evaluate(() =>
        Array.from(document.querySelectorAll<HTMLElement>("#dsh-spacing-layer [data-dsh-spacing]")).map((n) => {
          const r = n.getBoundingClientRect();
          const svg = n.querySelector("svg");
          return {
            key: `${n.getAttribute("data-dsh-spacing")}/${n.getAttribute("data-dsh-spacing-role")}`,
            short: Math.round(Math.min(r.width, r.height)),
            present: svg !== null,
            display: svg === null ? "absent" : getComputedStyle(svg).display,
          };
        }),
      );
      for (const row of rows) {
        // The glyph node is ALWAYS present — that is the C9 leg, and it holds at every size.
        expect(row.present, `${oid} ${row.key}: the glyph node exists`).toBe(true);
        (row.short >= 8 ? painted : unpainted).push(`${oid} ${row.key} short=${row.short} ${row.display}`);
        expect(row.display, `${oid} ${row.key} (short=${row.short})`).toBe(row.short >= 8 ? "block" : "none");
      }
    }
    // BOTH buckets are inhabited, or the rule above is asserting one answer everywhere.
    expect(painted.length, `painted: ${painted.join(" | ")}`).toBeGreaterThan(0);
    expect(unpainted.length, `unpainted: ${unpainted.join(" | ")}`).toBeGreaterThan(0);
  });

  // ── F11 — THE POPUP's PLACE IN THE C9 ACCOUNTING ──────────────────────────────────────────────
  test("⚠ the POPUP is excluded from universe B BY ROLE, and the exclusion is asserted rather than accidental", async ({
    page,
  }) => {
    // ⚠ **THE POPUP IS AN OPERABLE, UNMARKED NODE INSIDE THE SPACING LAYER, AND IT ESCAPED BOTH UNIVERSES BY ACCIDENT (W-6/W-11).** Universe B scans that layer for operable nodes and requires every one to be marked and glyphed; the popup carries `data-dsh-handle` (the shield needs it) but NOT `data-v3-glyph-control` (it is a numeric field, not a glyph control) — so universe B would fail on it if it were ever open when the scan ran, and it never is, because every universe-B row runs at rest. Universe C scans the popup's own INSIDE and never counts the container. The node fell between them.
    //
    // THE RULING: it is excluded BY ROLE, exactly as universe A excludes the panel's native value fields — a numeric input and the box that holds it are not glyph controls, and marking them would make the marker mean "operable" instead of "a control with a mark". What changes is that the exclusion is now STATED and ASSERTED: universe B reads the layer with a popup OPEN and requires the excluded set to be exactly the popup subtree.
    await select(page, GAP_LARGE);
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const audit = await page.evaluate(() => {
      const layer = document.getElementById("dsh-spacing-layer")!;
      const popup = document.getElementById("dsh-spacing-popup")!;
      const operable = Array.from(layer.querySelectorAll<HTMLElement>("*")).filter(
        (n) => getComputedStyle(n).pointerEvents !== "none",
      );
      return {
        unmarked: operable
          .filter((n) => !n.hasAttribute("data-v3-glyph-control"))
          .map((n) => ({ tag: n.tagName.toLowerCase(), id: n.id, insidePopup: popup === n || popup.contains(n) })),
        popupAriaHidden: popup.getAttribute("aria-hidden"),
      };
    });
    // EVERY unmarked operable node is the popup or inside it — nothing else escapes the marker rule.
    expect(audit.unmarked.length, "the popup subtree really is unmarked (the exclusion has a subject)").toBeGreaterThan(0);
    expect(audit.unmarked.filter((n) => !n.insidePopup), "an unmarked operable node OUTSIDE the popup").toEqual([]);
    // ⚠ **THE `aria-hidden` CHECK (W-11), MEASURED RATHER THAN ASSUMED.** Chromium warns "Blocked aria-hidden on an element because its descendant retained focus" when focus lands inside an aria-hidden subtree. Measured on this build with the popup open and its input focused: **the warning does NOT fire.** So `aria-hidden` stays — §3.9's (a) choice is unreversed — and the check is recorded here so the next lane does not re-derive it. RED-when: if a future Chromium does warn, this assertion is where it surfaces and the fix is to drop `aria-hidden` from the popup, which corrects a broken cost rather than reversing the ruling.
    expect(audit.popupAriaHidden).toBe("true");
    const warnings: string[] = [];
    page.on("console", (m) => {
      if (/aria-hidden/i.test(m.text())) warnings.push(m.text());
    });
    await page.locator("#dsh-spacing-popup input").focus();
    await page.waitForTimeout(300);
    expect(warnings, "Chromium's aria-hidden focus warning").toEqual([]);
    await page.keyboard.press("Escape");
  });

  test("⚠ the VARIANT-refused container renders NO padding affordance — `pad-variant` is unreachable, not a subject", async ({
    page,
  }) => {
    // THE `snpvar` ADJUDICATION, asserted rather than described. It is the ONE live container measured with a child inside its own padding band (24 px into a 32 px bottom band, at the pinned viewport where `md:p-8` is live). It is NOT a free G44-9 CLAMP subject, because `spacingFamilyRefusal("pad", "p-2 md:p-8")` is `spacing-controlled-by-variant` and §3.11 rules that this phase mints no non-operable spacing marker — so the honest rendering is absence, and the universe-B count subtracts its four edges.
    await select(page, PAD_VARIANT);
    const scene = await readSpacingScene(page, PAD_VARIANT);
    // The band really is above the floor, so the zero below is the refusal and not the floor.
    expect(Math.min(...Object.values(scene.measured.padding))).toBeGreaterThanOrEqual(RENDER_FLOOR);
    expect(scene.operable.filter((n) => n.id.startsWith("pad:"))).toEqual([]);
    expect(scene.operable.length).toBe(deriveExpectedCount(scene, { pad: true }));
  });

  // ── F1(d) — THE ARM TABLE ITSELF ───────────────────────────────────────────────────────────────
  test("§3.9's THREE-ARM TABLE — a handle press is preventDefault-ed (ROW D) and a popup-input press is NOT (ROW P)", async ({
    page,
  }) => {
    // ⚠ **THIS PAIR IS THE ONLY THING THAT PINS THREE ARMS RATHER THAN TWO, and it exists because a two-arm implementation passed every behavioural row in this file.** The shipped predicate decided ROW P with `target.closest(FOCUSABLE_SELECTOR)`; `#dsh-stage` carries `tabIndex={-1}` and is the ancestor of every canvas node, so EVERY press took ROW P and phase-42's `preventDefault()` — the whole of ROW D — was unreachable code. Nothing observed it: the drag still worked, the popup still focused, the commits still landed. What that regression changes is exactly one bit per press, and this row reads that bit.
    //
    // The probe listens AFTER the shield's capture-phase handler on `#dsh-stage` — a bubble-phase listener on `document` sees the flag the shield left. RED-when, both directions, and both were applied:
    //   (a) `closest` instead of `matches` in `isFocusableHandleEvent` → the strip press reads `false` (ROW D dead);   (b) delete the ROW P early return                             → the input press reads `true` (ROW P dead).
    await select(page, GAP_LARGE);
    const install = () =>
      page.evaluate(() => {
        (window as unknown as { __dp: boolean[] }).__dp = [];
        document.addEventListener(
          "pointerdown",
          (e) => (window as unknown as { __dp: boolean[] }).__dp.push(e.defaultPrevented),
          { once: false },
        );
      });
    await install();
    const strip = await affordanceCentre(page, "gap:0", "strip");
    await page.mouse.move(strip.x, strip.y);
    await page.mouse.down();
    await page.mouse.up();
    const afterHandle = await page.evaluate(() => (window as unknown as { __dp: boolean[] }).__dp.slice());
    expect(afterHandle.length, "the probe saw the spacing-strip press").toBeGreaterThan(0);
    expect(afterHandle[0], "ROW D — a spacing drag surface IS preventDefault-ed").toBe(true);

    // ⚠ **AND A PHASE-42 RESIZE HANDLE, WHICH IS THE TARGET CLASS THE REGRESSION WAS ACTUALLY ABOUT.** The press above is a phase-44 spacing strip — it exercises ROW D, but it is not the population `preventDefault()` was minted for, and a fix that restored the arm for spacing while leaving the eight resize handles on ROW P would pass it. `data-dsh-handle="se"` is a corner chip: a shipped, non-focusable drag surface that has held this arm since phase-42. RED-when: the same `closest`-for-`matches` regression → this reads `false` too, which is the failure phase-42's own suite could not see.
    await install();
    const seBox = (await page.locator('#dsh-handle-layer [data-dsh-handle="se"]').boundingBox())!;
    await page.mouse.move(seBox.x + seBox.width / 2, seBox.y + seBox.height / 2);
    await page.mouse.down();
    await page.mouse.up();
    const afterResize = await page.evaluate(() => (window as unknown as { __dp: boolean[] }).__dp.slice());
    expect(afterResize.length, "the probe saw the resize-handle press").toBeGreaterThan(0);
    expect(afterResize[0], "ROW D — a phase-42 resize handle IS preventDefault-ed").toBe(true);

    // …and the popup's input, which must NOT be.
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    await install();
    const inputBox = (await page.locator("#dsh-spacing-popup input").boundingBox())!;
    await page.mouse.click(inputBox.x + inputBox.width - 3, inputBox.y + inputBox.height / 2);
    const afterInput = await page.evaluate(() => (window as unknown as { __dp: boolean[] }).__dp.slice());
    expect(afterInput.length, "the probe saw the input press").toBeGreaterThan(0);
    expect(afterInput[0], "ROW P — a focusable handle target is NOT preventDefault-ed").toBe(false);
    await page.keyboard.press("Escape");
  });

  // ── F3 — THE CORNER SUPPRESSION RULE ──────────────────────────────────────────────────────────
  test("the corner suppression rule — a press 4 px inside a corner belongs to the RESIZE handle, never a padding strip", async ({
    page,
  }) => {
    // ⚠ **THE TWO FAMILIES REALLY DO CLAIM THESE PIXELS.** A phase-42 corner chip is 14 px centred on the box corner, so ~7 px of it lies inside the border box — inside this family's padding bands on both of that corner's edges. Until this row the winner was a z-index accident (43 over 42) pinned nowhere.
    // RED-when: raise the spacing strip's z to 44 → every corner probe returns a `pad:*` node instead.
    await select(page, PAD_BROAD);
    const box = (await page.locator(`[data-oid="${PAD_BROAD}"]`).boundingBox())!;
    const corners: [number, number][] = [
      [box.x + 4, box.y + 4],
      [box.x + box.width - 4, box.y + 4],
      [box.x + 4, box.y + box.height - 4],
      [box.x + box.width - 4, box.y + box.height - 4],
    ];
    const owners = await page.evaluate((pts) => {
      // `elementsFromPoint`, not `elementFromPoint`: the point belongs to BOTH families and the row is about which one is on top, so the whole stack is read and the winner named.
      return pts.map(([x, y]) => {
        const stack = document.elementsFromPoint(x, y).filter((n) => getComputedStyle(n).pointerEvents !== "none");
        const top = stack[0];
        return {
          top: top === undefined ? "none" : (top.getAttribute("data-dsh-handle") ?? top.tagName.toLowerCase()),
          spacingInStack: stack.some((n) => n.hasAttribute("data-dsh-spacing")),
        };
      });
    }, corners);
    for (const [i, owner] of owners.entries()) {
      expect(owner.top, `corner ${i}: the top operable node is a resize handle`).toMatch(/^(nw|ne|sw|se|n|e|s|w)$/);
      // …and the spacing family really IS underneath, or this row is asserting a conflict that does not exist.
      expect(owner.spacingInStack, `corner ${i}: a padding strip is in the stack (the conflict is real)`).toBe(true);
    }
  });

  // ── G44-1 + acceptance 9, the popup and its shield seam ────────────────────────────────────────
  test("G44-1 — a click on the APRON opens the numeric input; a sub-threshold press on the STRIP is a no-op", async ({
    page,
  }) => {
    const posts = countPosts(page);
    await select(page, GAP_LARGE);
    // A sub-threshold press on the drag strip: the shipped classification, unchanged. No popup, no POST.
    const strip = await affordanceCentre(page, "gap:0", "strip");
    await page.mouse.move(strip.x, strip.y);
    await page.mouse.down();
    await page.mouse.move(strip.x + 1, strip.y);
    await page.mouse.up();
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);
    await page.waitForTimeout(400);
    expect(posts.count(), "a sub-threshold press writes nothing").toBe(0);

    // The APRON's click opens the popup. RED-when: ship drag-only → there is no popup to find.
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const input = page.locator("#dsh-spacing-popup input");
    await expect(input).toHaveCount(1);
    // acceptance 9 leg 1 — the popup did NOT unmount and the selection did NOT change.
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    // ⚠ acceptance 9 leg 2 — ROW P. The input TAKES FOCUS. With ROW D's `preventDefault()` applied to the popup on either `mousedown` or `pointerdown` this is dead, and the blur/Enter commits below have no target.
    expect(await input.evaluate((n) => n === document.activeElement)).toBe(true);
    // ⚠ **ROW P's OWN FALSIFIABLE OBSERVABLE — CARET PLACEMENT, not focus and not the commit.** See the row's long note in the report: under this implementation the input takes focus PROGRAMMATICALLY (the popup is created by the very press that would otherwise have focused it), so ROW D's `preventDefault()` cannot stop the FIRST focus and the plan's stated failure — "the commit never happens" — does not occur. What ROW D does still kill is the behaviour §3.9 names in its own argument: caret placement and intra-field selection inside an already-focused input. That IS reachable, and it is what this leg asserts.
    // RED-when: apply `preventDefault()` to the popup target on either `mousedown` or `pointerdown` → a press inside the field cannot move the caret and this reads back the `select()`-time selection instead.
    const inputBox = (await input.boundingBox())!;
    await page.mouse.click(inputBox.x + inputBox.width - 3, inputBox.y + inputBox.height / 2);
    expect(await input.evaluate((n: HTMLInputElement) => n.selectionStart)).toBeGreaterThan(0);

    // Escape CANCELS: the popup goes and nothing is written.
    await page.keyboard.press("Escape");
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);
    await page.waitForTimeout(400);
    expect(posts.count(), "Escape cancels").toBe(0);
    // …and the selection survived the popup's whole lifetime.
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  });

  test("acceptance 9 — the popup's ENTER commits, ONCE, through the sidecar", async ({ page }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, GAP_LARGE);
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    const input = page.locator("#dsh-spacing-popup input");
    await expect(input).toHaveCount(1);
    expect(await input.evaluate((n) => n === document.activeElement)).toBe(true);
    await input.fill("28");
    await page.keyboard.press("Enter");

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the popup's own write").toBe(1);
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after).toContain("gap-[28px]");

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("⚠ A PRISTINE POPUP COMMITS NOTHING — an apron press on a SCALE token, closed with no keystroke (owner live test, 2026-08-21)", async ({
    page,
  }) => {
    // ⚠ **THE OWNER'S LIVE OBSERVATION, AND IT IS THE CANVAS TWIN OF THE PANEL FIELD'S.** The popup opens PRE-FILLED with the live band, the writer emits the arbitrary form exclusively, and `changed` is byte-identity — so a blur or an Enter over a value the user never entered rewrote `p-4` to `pt-[16px]`. Escape already cancelled; the two boundaries that COMMIT had no gate at all.
    //
    // ⚠ **THE SUBJECT MUST CARRY A SCALE TOKEN OR THIS ROW CANNOT GO RED**, which is why it is `snnflx` (`block p-4`) and not `GAP_LARGE`: on `flex gap-[40px]` the pristine composition is byte-IDENTICAL to the source, the writer's own short-circuit swallows it, and the zero POSTs below would be reported by a defect that was still there. Measured RED on this subject before the gate: one POST, and the fixture came back carrying `pt-[16px]`.
    const posts = countPosts(page);
    const before = fs.readFileSync(pageFixture);
    await select(page, PAD_BROAD);
    const apron = await affordanceCentre(page, "pad:top", "apron");

    // (1) ENTER with nothing typed.
    await page.mouse.click(apron.x, apron.y);
    const input = page.locator("#dsh-spacing-popup input");
    await expect(input).toHaveCount(1);
    // The pre-fill IS the hazard: the number is in the box and the user put none of it there.
    await expect(input).toHaveValue("16");
    await page.keyboard.press("Enter");
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);

    // (2) BLUR with nothing typed — the other committing boundary, reached by moving focus off the field rather than by pressing a key the popup handles.
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup input")).toHaveCount(1);
    await page.keyboard.press("Tab");
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);

    await page.waitForTimeout(700);
    expect(posts.count(), "a popup nobody typed into writes nothing").toBe(0);
    expect(fs.readFileSync(pageFixture).equals(before), "the fixture is byte-identical on disk").toBe(true);

    // ⚠ CONTROL (ENTER leg) — the SAME popup with a real keystroke commits, so the Enter zero above is the gate and not a popup that had stopped writing.
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup input")).toHaveCount(1);
    await page.locator("#dsh-spacing-popup input").pressSequentially("20");
    // `pressSequentially` is the gesture the gate is about — real keystrokes, real `input` events — and it types over the `select()`ed pre-fill rather than beside it. Asserted, because "1620" would compose a token this row's `toContain` would then miss the meaning of.
    await expect(page.locator("#dsh-spacing-popup input")).toHaveValue("20");
    await page.keyboard.press("Enter");
    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    await page.waitForTimeout(700);
    expect(posts.count(), "the typed value is one POST").toBe(1);
    expect(fs.readFileSync(pageFixture, "utf8")).toContain("pt-[20px]");

    // ⚠ **CONTROL (BLUR leg) — AND IT IS A SEPARATE CONTROL BECAUSE THE ENTER ONE DOES NOT COVER IT (review W-3).** The two boundaries are two different code paths: Enter reaches `closePopup(true)` through the document-capture key handler, blur reaches it through the input's own `blur` listener. Measured: changing that listener to `closePopup(false)` leaves this whole spec green at 26/26 — so without this leg the blur zero above would be reported by a popup whose blur had stopped writing entirely.
    // The subject is re-selected first: the write above HMR'd the page and moved the top band 16 → 20, so both the selection and the apron's geometry have to be taken again rather than reused.
    await select(page, PAD_BROAD);
    const apronAfter = await affordanceCentre(page, "pad:top", "apron");
    await page.mouse.click(apronAfter.x, apronAfter.y);
    await expect(page.locator("#dsh-spacing-popup input")).toHaveCount(1);
    await page.locator("#dsh-spacing-popup input").pressSequentially("24");
    await expect(page.locator("#dsh-spacing-popup input")).toHaveValue("24");
    await page.keyboard.press("Tab");
    const blurResponse = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(blurResponse.ok()).toBe(true);
    await page.waitForTimeout(700);
    expect(posts.count(), "the BLUR boundary writes too, once").toBe(2);
    expect(fs.readFileSync(pageFixture, "utf8")).toContain("pt-[24px]");

    fs.writeFileSync(pageFixture, before);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G44-5 universe C — the popup's own inventory: everything operable but the numeric input is marked and glyphed", async ({
    page,
  }) => {
    await select(page, GAP_LARGE);
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const inventory = await page.evaluate(() => {
      const popup = document.getElementById("dsh-spacing-popup")!;
      return Array.from(popup.querySelectorAll<HTMLElement>("*"))
        .filter((n) => getComputedStyle(n).pointerEvents !== "none")
        // The numeric input is excluded BY ROLE, exactly as universe A excludes the native value fields.
        .filter((n) => n.tagName.toLowerCase() !== "input")
        .map((n) => ({
          descriptor: n.tagName.toLowerCase(),
          marked: n.hasAttribute("data-v3-glyph-control"),
          glyphed: n.querySelector("svg, [data-glyph]") !== null,
        }));
    });
    // (C1) RED-when: plant an unmarked `<button>` in the popup → it appears here unmarked.
    // (C2) RED-when: plant a marked text-only one → it appears here marked and unglyphed.
    for (const node of inventory) {
      expect(node.marked, `${node.descriptor} is marked`).toBe(true);
      expect(node.glyphed, `${node.descriptor} is glyphed`).toBe(true);
    }
    // CONTROL: the scan can report a non-empty inventory, so an empty one above is a fact about the popup.
    const withPlant = await page.evaluate(() => {
      const popup = document.getElementById("dsh-spacing-popup")!;
      const plant = document.createElement("button");
      plant.textContent = "+";
      popup.appendChild(plant);
      const n = Array.from(popup.querySelectorAll<HTMLElement>("*"))
        .filter((el) => getComputedStyle(el).pointerEvents !== "none")
        .filter((el) => el.tagName.toLowerCase() !== "input")
        .filter((el) => !el.hasAttribute("data-v3-glyph-control")).length;
      plant.remove();
      return n;
    });
    expect(withPlant).toBe(1);
    // ⚠ **(C2) THE POPUP's OWN MARKED TEXT-ONLY PLANT.** Same pair, same reason, inside universe C: a control that carries the marker and renders a character instead of a glyph must be named by this universe's glyph leg, or half (2) is asserted here about an empty set.
    const markedTextOnlyInPopup = await page.evaluate(() => {
      const popup = document.getElementById("dsh-spacing-popup")!;
      const plant = document.createElement("button");
      plant.setAttribute("data-v3-glyph-control", "");
      plant.textContent = "+";
      popup.appendChild(plant);
      const offenders = Array.from(popup.querySelectorAll<HTMLElement>("*"))
        .filter((el) => getComputedStyle(el).pointerEvents !== "none")
        .filter((el) => el.tagName.toLowerCase() !== "input")
        .filter((el) => el.hasAttribute("data-v3-glyph-control"))
        .filter((el) => el.querySelector("svg, [data-glyph]") === null).length;
      plant.remove();
      return offenders;
    });
    expect(markedTextOnlyInPopup, "a marked, text-only control in the popup is named").toBe(1);
    await page.keyboard.press("Escape");
  });

  test("acceptance 10 — the popup is CONTAINED by the clip and keeps its full width (the flip's forced subject is S44-4's)", async ({ page }) => {
    await select(page, GAP_LARGE);
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const placement = await page.evaluate(() => {
      const layer = document.getElementById("dsh-ring-layer")!.getBoundingClientRect();
      const popup = document.getElementById("dsh-spacing-popup")!.getBoundingClientRect();
      return {
        insideClip:
          popup.left >= layer.left - 0.5 &&
          popup.top >= layer.top - 0.5 &&
          popup.right <= layer.right + 0.5 &&
          popup.bottom <= layer.bottom + 0.5,
        width: popup.width,
      };
    });
    // ⚠ **WHAT THIS ROW ASSERTS AND WHAT IT DOES NOT — stated, because the title promises more than the body delivers.** It asserts CONTAINMENT: nothing is painted outside the layer that clips it, and the popup keeps its full width rather than being squeezed (a clamped readout loses a whole language before it loses a word — R42-D3 verbatim). It does NOT force the FLIP: `gap-large` sits mid-frame, so the preferred side holds the popup and the flip branch is never taken. A forced subject needs a container flush against the frame's bottom edge, which this screen has none of and which S44-4's live smoke is the right place to add — the flip's whole point is a tool-feel failure at a real frame boundary. **ROUTED TO S44-4**, recorded here rather than left as a title that overstates its row. ⚠ **LANDED at S44-4: the forced row is the last one in this file, and its subject is manufactured by SCROLLING an existing apron to the frame's bottom edge rather than by authoring a sixteenth container** — the screen never needed one, which is worth knowing before the next lane mints a fixture for a placement rule.
    expect(placement.insideClip).toBe(true);
    expect(placement.width).toBeGreaterThan(0);
    await page.keyboard.press("Escape");
  });

  // ── G44-6 + acceptance 2 + G44-3 — the drag itself ─────────────────────────────────────────────
  test("G44-6 — an N-move GAP drag produces EXACTLY ONE POST /edit", async ({ page }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, GAP_SUBJECT);
    const start = await affordanceCentre(page, "gap:0");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    // TWELVE moves, so a commit that lived in the move handler would count twelve.
    for (let i = 1; i <= 12; i += 1) await page.mouse.move(start.x + i * 3, start.y);
    await page.mouse.up();

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    await page.waitForTimeout(700);
    // RED-when: move the commit into the move handler → this is 12.
    expect(posts.count(), "one POST for the gesture's own write").toBe(1);
    // ⚠ SCOPED TO THIS CONTAINER'S OWN LITERAL. A whole-file `/gap-\[\d+px\]/` is GREEN AT HEAD — the fixture already authors `gap-[6px]`, `gap-[40px]`, `gap-[2px]` and `gap-[12px]` — so the row would have passed against a gesture that wrote nothing at all. That is the same file-wide-read-of-a-per-element-fact defect the G44-2(b) row below was corrected for, found by the review round on this row.
    const literal = /data-oid="sngapn"\s+className="([^"]*)"/.exec(fs.readFileSync(pageFixture, "utf8"));
    expect(literal, "the container's className literal is findable on disk").not.toBeNull();
    expect(literal![1]).toMatch(/gap-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G44-6 — an N-move PADDING drag produces EXACTLY ONE POST, and OPTION-symmetric is still ONE", async ({
    page,
  }) => {
    // ⚠ RE-AIMED (phase-48 B-Q5, plan `EG-1` alternate path (a)): `snpthn`'s 8 px band puts the strip's own bounding-box CENTRE 4 px inside the border box — inside the straddling resize band's 5 px reach, which now wins at z 42 over 41. A press there starts a RESIZE gesture, not a padding drag, and reads a write neither of these two sub-drags asked for — a wrong-committed-token failure rather than a five-second hang. `affordancePaddingDeepestPoint` aims at the affordance's own deepest inward point instead, which the resize band cannot reach.
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, PAD_THIN);
    const start = await affordancePaddingDeepestPoint(page, "pad:top", "top");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= 12; i += 1) await page.mouse.move(start.x, start.y + i * 2);
    await page.mouse.up();
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the plain edge drag").toBe(1);
    const afterEdge = fs.readFileSync(pageFixture, "utf8");
    expect(afterEdge).toMatch(/pt-\[\d+px\]/);
    // ⚠ **THE MID-ROW RE-DERIVATION IS LOAD-BEARING AND MUST NOT BE COLLAPSED INTO A TRAILING ONE — I TRIED, AND BOTH HALVES OF THIS ROW BROKE.** It looks redundant (the artifact is a pure function of these bytes, so one re-derivation at the end would verify the same thing) and it is not: the extractor also rewrites `.descvi/edit-map.json`, which is the map the SIDECAR resolves a write against. Restore the source without re-deriving and the next sub-drag posts against a stale map — measured, the Option half wrote no `py-*` token at all and the row's first gap sub-drag wrote nothing. The cost is that a failing re-derivation truncates the row; the alternative is a row whose later halves silently write nowhere.
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });

    // ⚠ THE OPTION-SYMMETRIC ROW IS SEPARATE. RED-when: implement it as two sequential `padEdge` writes → the POST count is 2 AND the className carries two edge tokens where one axis token is correct.
    const optionPosts = countPosts(page);
    await select(page, PAD_THIN);
    const optStart = await affordancePaddingDeepestPoint(page, "pad:top", "top");
    await page.keyboard.down("Alt");
    await page.mouse.move(optStart.x, optStart.y);
    await page.mouse.down();
    for (let i = 1; i <= 8; i += 1) await page.mouse.move(optStart.x, optStart.y + i * 2);
    await page.mouse.up();
    await page.keyboard.up("Alt");
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(700);
    expect(optionPosts.count(), "one POST for the Option-symmetric drag").toBe(1);
    const afterAxis = fs.readFileSync(pageFixture, "utf8");
    // ONE AXIS TOKEN, and no edge token from this write.
    expect(afterAxis).toMatch(/py-\[\d+px\]/);
    expect(afterAxis).not.toMatch(/pt-\[\d+px\][\s\S]*pb-\[\d+px\]/);
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("acceptance 2 — the shield bypass on a REAL drag released OFF the affordance, over `#dsh-screen`", async ({
    page,
  }) => {
    const original = fs.readFileSync(pageFixture);
    await select(page, GAP_SUBJECT);
    const selectedBefore = await page.evaluate(
      () => document.querySelector("#dsh-selection-ring")?.getAttribute("style") ?? "",
    );
    expect(selectedBefore).not.toBe("");
    const start = await affordanceCentre(page, "gap:0");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    // ⚠ RELEASE OFF THE AFFORDANCE. A press-and-release ON it passes BOTH of this row's mutations, which is why the row specifies the release point: (1) drop the `onClick` half → deselect-on-release returns; (2) drop `setPointerCapture` → the synthesized click retargets to `#dsh-frame` and the target check stops matching.
    for (let i = 1; i <= 8; i += 1) await page.mouse.move(start.x + i * 8, start.y + i * 4);
    await page.mouse.up();
    // ⚠ **READ THE SELECTION AT THE RELEASE, BEFORE THE POST RESOLVES — AND THAT ORDER IS THE ROW, not a latency saving. MEASURED: with the read placed AFTER `waitForResponse`, BOTH of this row's mutations were GREEN.** The deselect the shield would perform is synchronous on the release click; the controller's `onCommit` re-select (`reselectBySpecId`, phase-42's machinery) runs after the sidecar answers and puts the selection back. So a row that waits for the response is asserting that the RE-SELECT works, and the shield bypass it claims to test can be deleted underneath it without a murmur. That masking is the finding, and this is the re-aim: the observation window is between the release and the response.
    const atRelease = await page.evaluate((oid) => {
      const ringEl = document.querySelector("#dsh-selection-ring") as HTMLElement | null;
      const el = document.querySelector(`[data-oid="${oid}"]`)!.getBoundingClientRect();
      const ring = ringEl?.getBoundingClientRect();
      return {
        visible: ringEl !== null && getComputedStyle(ringEl).display !== "none",
        onSubject: ring !== undefined && Math.abs(ring.left - el.left) < 6 && Math.abs(ring.top - el.top) < 6,
      };
    }, GAP_SUBJECT);
    expect(atRelease, "the ring survived the release click, before any re-select could restore it").toEqual({
      visible: true,
      onSubject: true,
    });
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(500);
    // …and it is still there after the round trip, which is the state the user is left in.
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G44-3 — Shift is a 10-step on both families; Option is a MEASURED no-op on gap; Cmd is bound to nothing", async ({
    page,
  }) => {
    const original = fs.readFileSync(pageFixture);
    // SHIFT — the committed value lands on a multiple of ten.
    await select(page, GAP_SUBJECT);
    const start = await affordanceCentre(page, "gap:0");
    await page.keyboard.down("Shift");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= 10; i += 1) await page.mouse.move(start.x + i * 2, start.y);
    await page.mouse.up();
    await page.keyboard.up("Shift");
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(500);
    // Same scoping, same reason: the fixture's own `gap-[40px]` would satisfy an unscoped `% 10 === 0`.
    const shiftedLiteral = /data-oid="sngapn"\s+className="([^"]*)"/.exec(fs.readFileSync(pageFixture, "utf8"));
    const shifted = /gap-\[(\d+)px\]/.exec(shiftedLiteral?.[1] ?? "");
    expect(shifted, "the Shift drag wrote a gap token").not.toBeNull();
    expect(Number(shifted![1]) % 10, "Shift quantises to a 10-step").toBe(0);
    // Bytes back AND the map re-derived between sub-drags — see the padding row above for the measurement that says why this cannot be deferred to the end.
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });

    // ⚠ OPTION ON GAP IS A MEASURED NO-OP, not an undefined behaviour. RED-when: leave it undefined → this row has nothing to assert. The two drags below are the SAME travel with and without the modifier, and the committed token must be byte-identical.
    const withoutOption = await dragGapAndReadToken(page, false);
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
    const withOption = await dragGapAndReadToken(page, true);
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
    expect(withOption, "Option changes nothing on a gap drag").toBe(withoutOption);
    expect(withoutOption).not.toBeNull();
  });

  /** One fixed-travel gap drag, with or without Option held, returning the token it committed. */
  async function dragGapAndReadToken(page: Page, option: boolean): Promise<string | null> {
    await select(page, GAP_SUBJECT);
    const start = await affordanceCentre(page, "gap:0");
    if (option) await page.keyboard.down("Alt");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= 6; i += 1) await page.mouse.move(start.x + i * 2, start.y);
    await page.mouse.up();
    if (option) await page.keyboard.up("Alt");
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(500);
    // The Option no-op comparison is per-container too — an unscoped read would compare the fixture's own untouched `gap-[40px]` with itself and report "Option changed nothing" whatever the modifier did.
    const lit = /data-oid="sngapn"\s+className="([^"]*)"/.exec(fs.readFileSync(pageFixture, "utf8"));
    const m = /gap-\[\d+px\]/.exec(lit?.[1] ?? "");
    return m === null ? null : m[0];
  }

  test("G44-2(b) — the canvas gap drag on `gap-auto-collateral` FOLDS the Auto clear into ONE write", async ({
    page,
  }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, GAP_AUTO_COLLATERAL);
    const start = await affordanceCentre(page, "gap:0");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= 6; i += 1) await page.mouse.move(start.x + i * 3, start.y);
    await page.mouse.up();
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(700);
    // RED-when: issue the `clearAutoGap` fold as a second POST → this is 2.
    expect(posts.count(), "the fold is ONE POST").toBe(1);
    // ⚠ THE ASSERTION IS SCOPED TO THIS CONTAINER'S OWN LITERAL, and the scoping is a correction rather than a refinement: a whole-file `not.toContain("justify-between")` is GREEN only by accident on a screen with one such container and RED on this one, because fixture ⑦ (`gap-auto`) carries `justify-between` too and this row never touches it. A file-wide read of a per-element fact is the same defect in both directions.
    const literal = /data-oid="sngaco"\s+className="([^"]*)"/.exec(fs.readFileSync(pageFixture, "utf8"));
    expect(literal, "the container's className literal is findable on disk").not.toBeNull();
    // The fifth op's EMIT — `justify-start` — and the gap value, in one composed literal.
    expect(literal![1]).toContain("justify-start");
    expect(literal![1]).toMatch(/gap-\[\d+px\]/);
    expect(literal![1]).not.toContain("justify-between");
    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  // ══ S44-4 — the live coverage: G44-8's sampled drags, the disk read-back, G44-9's live arm and the forced flip ══

  test("G44-8 — a GAP drag sampled at six fixed offsets: the band and the children move together, and the disk literal is the POSTED one", async ({
    page,
  }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, GAP_SUBJECT);
    const start = await affordanceCentre(page, "gap:0");
    const subject = { oid: GAP_SUBJECT, id: "gap:0", edge: "gap" } as const;
    const travelPx = 60;
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    // The BASELINE, read at the press: sample 1 needs a predecessor, and the resting band is the honest one to compare it against.
    const samples: DragSample[] = [await sampleDrag(page, subject, start)];
    for (let i = 1; i <= K_SAMPLES; i += 1) {
      const at = { x: start.x + Math.round((i * travelPx) / K_SAMPLES), y: start.y };
      await page.mouse.move(at.x, at.y);
      samples.push(await sampleDrag(page, subject, at));
    }
    await page.mouse.up();
    // ⚠ **THE SAMPLES ARE ASSERTED AFTER THE ROUND TRIP, NOT BEFORE IT, AND THE ORDER IS A CORRECTION MEASURED IN THIS LANE.** The samples are already in hand, so asserting on them here costs nothing — but the release has a `POST /edit` in flight, and a row that fails BEFORE awaiting it ends with the write still on the wire: `afterEach` then restores bytes the sidecar has not yet spliced, the splice lands afterwards, and the fixture is left dirty by a row whose own restore ran correctly. Observed here while applying this row's first RED-when, which left `sngapn` carrying `gap-[136px]` in the working tree.
    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    await page.waitForTimeout(700);
    assertSpacingDragSamples(samples, "gap");
    expect(posts.count(), "one POST for the whole sampled gesture").toBe(1);

    // ── acceptance 2 — the className read back FROM DISK ──
    const posted = JSON.parse(posts.bodies[0]!) as { newClassName: string; prevClassName: string };
    const literal = diskLiteral(GAP_SUBJECT);
    // ⚠ **THE TOKEN-COUNT RULE, AND WHAT IT IS MEASURED AGAINST.** G44-8's forbidden observation is "a disk literal whose token COUNT differs from what `emitted`/`stripped` predicted", and an `e2e` row cannot see those two sets: they are the producer's, and nothing crosses the wire. What DOES cross is the composed `newClassName`, which IS `emitted`/`stripped` already applied to the baseline — the last observable form of that prediction before the splice — so the comparison here is between what the writer promised and what the splice produced. Asserted as the token SEQUENCE rather than the count, because a count is satisfied by one token swapped for another.
    // ⚠ **AND A WHITESPACE-ONLY DIFFERENCE IS INVISIBLE TO IT, DELIBERATELY.** The value path renormalises the author's whitespace (S44-1's routed measurement, re-measured live in the S44-4 smoke and recorded in `docs/e3/tracker.md`): a baseline carrying a double space comes back single-spaced with the same tokens in the same order. That is a real property of the writer, it is NOT what this rule is about, and splitting on `\s+` here is what keeps the two separate — a row that compared raw strings would go red on the whitespace and stop saying anything about the token set.
    expect(literal.split(/\s+/)).toEqual(posted.newClassName.split(/\s+/));
    const gapTokens = literal.split(/\s+/).filter((t) => /^gap(-[xy])?-/.test(t));
    // The gap family FOLDS to ONE token, which is what the drag's own all-bands hint promises the user. RED-when: leave `gap-x-4` standing beside the new broad token → the container renders one band the panel does not report.
    expect(gapTokens, `the gap family on disk: ${literal}`).toHaveLength(1);
    expect(gapTokens[0]).toMatch(/^gap-\[\d+px\]$/);
    // …and nothing outside the family moved: the layout, sizing and colour tokens are carried through byte-for-byte.
    const untouched = (s: string): string[] => s.split(/\s+/).filter((t) => !/^gap(-[xy])?-/.test(t));
    expect(untouched(literal)).toEqual(untouched(posted.prevClassName));

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G44-8 — a PADDING drag sampled at six fixed offsets, and the disk literal carries the LAYERED shape", async ({
    page,
  }) => {
    // ⚠ RE-AIMED (plan `EG-1` alternate path (a)) — same ground as the `G44-6` row above: `snpthn`'s centred press is inside the straddling resize band's reach.
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await select(page, PAD_THIN);
    const start = await affordancePaddingDeepestPoint(page, "pad:top", "top");
    const subject = { oid: PAD_THIN, id: "pad:top", edge: "top" } as const;
    const travelPx = 36;
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    const samples: DragSample[] = [await sampleDrag(page, subject, start)];
    for (let i = 1; i <= K_SAMPLES; i += 1) {
      const at = { x: start.x, y: start.y + Math.round((i * travelPx) / K_SAMPLES) };
      await page.mouse.move(at.x, at.y);
      samples.push(await sampleDrag(page, subject, at));
    }
    await page.mouse.up();
    // The same ordering, for the same measured reason as the gap row above.
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(700);
    assertSpacingDragSamples(samples, "padding");
    expect(posts.count(), "one POST for the whole sampled gesture").toBe(1);

    const posted = JSON.parse(posts.bodies[0]!) as { newClassName: string; prevClassName: string };
    const literal = diskLiteral(PAD_THIN);
    expect(literal.split(/\s+/)).toEqual(posted.newClassName.split(/\s+/));
    const tokens = literal.split(/\s+/);
    // ⚠ **THE LAYERED SHAPE, asserted as the three things acceptance 2 names it is NOT.** The broad base SURVIVES the edge write (not a flattened broad token), exactly ONE edge token is added (not four longhands), and no axis token appears — a `py-*` here would be the Option-symmetric write arriving on a plain drag.
    expect(tokens.filter((t) => /^p-/.test(t)), `the broad base on disk: ${literal}`).toEqual(["p-[8px]"]);
    const edges = tokens.filter((t) => /^p[trbl]-/.test(t));
    expect(edges, `the edge tokens on disk: ${literal}`).toHaveLength(1);
    expect(edges[0]).toMatch(/^pt-\[\d+px\]$/);
    expect(tokens.filter((t) => /^p[xy]-/.test(t))).toEqual([]);
    // …and the edge really did overtake the base, or the "layered" claim is about two tokens that agree.
    expect(Number(/^pt-\[(\d+)px\]$/.exec(edges[0]!)![1])).toBeGreaterThan(8);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G44-9's LIVE arm — with a gap band rendered between two flush children, a real click one pixel inside a child still selects the CHILD (never a spacing affordance; a resize band's press, if any, is a separate priced outcome)", async ({
    page,
  }) => {
    // ⚠ **WHY THIS ROW EXISTS BESIDE THE `elementFromPoint` ONE ABOVE, and it is not "the same probe in a browser" — both are already in a browser.** The FLOOR arm asks which node OWNS a pixel; this asks what the tool DOES when a user presses it, which is a different question the moment anything between the two can swallow the event: the shield's capture-phase click arm, the affordance's own listener, a pointer capture left held. That path has no hit test in it.
    //
    // ⚠ **AND ITS SUBJECT HAS TO BE MANUFACTURED, WHICH IS THE HALF THE FIXTURE CANNOT AUTHOR.** Acceptance 4 asks for a click on a flush child *with a spacing affordance rendered*, and `pad-flush-parent` renders NONE at rest — `p-0` and a zero gap are both under the floor, which is the FLOOR arm's whole point. The only stamped children on this screen are its two, so it is also the only container where a click on a child is distinguishable from a click on the container at all. The band is therefore WRITTEN first, through the panel's own gap field — acceptance 4's "the panel field is the live route", used as the route — and the row then asserts the affordance is really there before probing it.
    const original = fs.readFileSync(pageFixture);
    await selectFlushParent(page);
    const field = page.getByTestId("dsh-spacing-gap");
    await expect(field).toBeEnabled();
    await field.fill("8");
    await field.press("Enter");
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(900);
    expect(diskLiteral(PAD_FLUSH)).toMatch(/gap-\[8px\]/);
    // The write does not move the selection, so the parent is still the selected container — stated as an assertion because the whole row is about what is rendered while IT is selected.
    expect(await ringOwner(page)).toBe(PAD_FLUSH);

    const scene = await readSpacingScene(page, PAD_FLUSH);
    // THE PRECONDITION, MEASURED: an affordance really is rendered, and it really is between the two children. Without it every probe below is a fact about an empty layer.
    const bands = scene.operable.filter((n) => n.id.startsWith("gap:") && n.role === "strip");
    expect(bands, "the written gap really did mint a band").toHaveLength(1);
    expect(scene.measured.gapPx).toBe(8);
    expect(scene.children).toHaveLength(2);
    const [a, b] = scene.children as [Rect, Rect];

    // Leg 1 — the FLOOR arm's own probe, now with the parent genuinely selected AND a band on screen.
    // ⚠ **RE-POINTED (phase-48 B-Q5, plan §8.1), on the same ground as the FLOOR arm above.** The straddling resize band reaches 5 px inside the selected parent's border box, so a probe near a flush child's edge can land on the parent's own resize furniture. The classification below NAMES the family — `spacing`, `resize` or `page`; the SPACING assertion is unchanged, and a resize-family hit is the priced, accepted outcome (owner, 2026-09-02) rather than a page hit.
    const hits = await page.evaluate((children: Rect[]) => {
      const out: string[] = [];
      for (const child of children) {
        const probes: [number, number][] = [
          [child.left + 1, child.top + child.height * 0.25],
          [child.left + child.width - 1, child.top + child.height * 0.25],
          [child.left + child.width * 0.25, child.top + 1],
          [child.left + child.width * 0.25, child.top + child.height - 1],
        ];
        for (const [x, y] of probes) {
          const n = document.elementFromPoint(x, y);
          if (n === null) {
            out.push("null");
            continue;
          }
          const spacingId = n.getAttribute("data-dsh-spacing");
          if (spacingId !== null) {
            out.push(spacingId);
          } else if (n.hasAttribute("data-dsh-handle")) {
            out.push(`resize:${n.getAttribute("data-dsh-handle")}`);
          } else {
            out.push(`page:${n.tagName.toLowerCase()}`);
          }
        }
      }
      return out;
    }, scene.children);
    expect(
      hits.filter((h) => h.startsWith("gap:") || h.startsWith("pad:")),
      "probes that hit a SPACING affordance (never expected)",
    ).toEqual([]);
    const leg1ResizeHits = hits.filter((h) => h.startsWith("resize:"));
    if (leg1ResizeHits.length > 0) console.log("Leg 1: resize-family hits on a flush child (priced, accepted):", leg1ResizeHits);
    // ⚠ ASSERTED, NOT MERELY LOGGED (plan §8's honesty requirement) — the twin of `G44-9a`'s own row, and for the same reason: a `console.log` cannot fail, and this classification's job is catching a LATER widening of the resize band's inward reach. `PAD_FLUSH`'s two children, sorted (measured 2026-09-03, with the gap now written to 8px — same subject as `G44-9a`'s own `PAD_FLUSH` reading, since neither the write nor the selection state changes which handles are eligible to answer these four points per child).
    //
    // ⚠ **THE DERIVATION is `G44-9a`'s own `PAD_FLUSH` derivation, unchanged by this row's write.** The `gap-[8px]` write moves `snpflb` 8 px right of `snpfla` (both still 160×120), which does not touch either child's flushness on the parent's OWN `n`/`s`/`w` (`snpfla`) or `n`/`s`/`e` (`snpflb`) edges — the gap sits strictly BETWEEN the two children, and neither the left child's right edge nor the right child's left edge was ever a probe point (both are internal, gap-facing edges, which Leg 2 below probes on its own terms). See the multiset's derivation, above, at `RESIZE_HITS_BY_OID[PAD_FLUSH]`.
    expect(
      [...leg1ResizeHits].sort(),
      "Leg 1: the resize-family hit set on this flush-child probe is pinned, not open-ended",
    ).toEqual(["resize:e", "resize:n", "resize:n", "resize:s", "resize:s", "resize:w"]);

    // Leg 2 — REAL CLICKS, on the two edges that FACE the band.
    // ⚠ **THE OTHER SIX PROBE POINTS ARE NOT CLICKED, AND THE EXCLUSION IS A RULING RATHER THAN A CONVENIENCE.** They sit one pixel inside the PARENT's border box, where the resize furniture's straddling band legitimately owns the pixel along the whole edge (plan §2, `S48-0` reverses R42-D1's outward-only ruling) — which the corner-suppression row above already pins as a resolved conflict for the family precedence, and Leg 1's classification above is what records it for THIS row. A click there answers a resize question, not this one. The band-facing edges are where a too-wide spacing band would actually take the drill-down surface, and they belong to no other family.
    // The parent is re-selected before EACH click, because a click that succeeds CHANGES the selection and the next probe then lands on a canvas carrying different furniture. Measured in this lane with the re-selection absent: after the first child had been selected, a click one pixel inside the SECOND child left the ring on the first — something the new selection put over that pixel owns it, and re-selecting the parent removes the question rather than answering it. What each probe is then aimed at is the state the row is about: the parent selected, its band rendered, nothing else on screen.
    const facing: { at: [number, number]; expect: string }[] = [
      { at: [a.left + a.width - 1, a.top + a.height * 0.25], expect: "snpfla" },
      { at: [a.left + a.width - 1, a.top + a.height * 0.75], expect: "snpfla" },
      { at: [b.left + 1, b.top + b.height * 0.25], expect: "snpflb" },
      { at: [b.left + 1, b.top + b.height * 0.75], expect: "snpflb" },
    ];
    const selected: string[] = [];
    for (const probe of facing) {
      await selectFlushParent(page);
      await page.mouse.click(probe.at[0], probe.at[1]);
      await page.waitForTimeout(150);
      selected.push(await ringOwner(page));
    }
    // RED-when: widen the band past its measured extent → these clicks land on the strip, which is a sub-threshold press and a no-op, and every entry reads `snpflu`.
    expect(selected, "a click one pixel inside a flush child, on the edge facing the band").toEqual(
      facing.map((p) => p.expect),
    );
    // …and the geometric reason the four answers above are what they are, asserted AFTER them on purpose: under the clamp mutation the click leg is the headline and this is its explanation, so the row should fail on the behaviour first and on the arithmetic second.
    expect(bands[0]!.rect.left, "the band starts at or after the first child's right edge").toBeGreaterThanOrEqual(
      a.left + a.width - 0.5,
    );
    expect(bands[0]!.rect.left + bands[0]!.rect.width, "…and ends at or before the second child's left edge").toBeLessThanOrEqual(
      b.left + 0.5,
    );

    // THE CONTROL, and it is what makes the four answers above evidence: the SAME click machinery over the band's own centre answers differently — the press is a sub-threshold no-op and the parent keeps the selection. Without it a run in which nothing at all was clickable would report the same four children.
    await selectFlushParent(page);
    const centre = await affordanceCentre(page, "gap:0");
    await page.mouse.click(centre.x, centre.y);
    await page.waitForTimeout(150);
    expect(await ringOwner(page), "a press on the band itself is a no-op, not a drill-down").toBe(PAD_FLUSH);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("acceptance 10's FLIP, FORCED — a frame-flush apron puts the popup ABOVE its anchor and still inside the clip", async ({
    page,
  }) => {
    // ⚠ **THE SUBJECT THE ACCEPTANCE-10 ROW ABOVE COULD NOT REACH, ROUTED HERE AND MANUFACTURED RATHER THAN AUTHORED.** That row asserts containment and says so; the FLIP branch needs an anchor whose preferred side cannot hold the popup, and this screen authors no container flush against the frame's bottom edge. It does not need to: the frame SCROLLS, so the subject is made by putting an existing apron at the bottom edge — and the scroll distance is computed from THIS run's own geometry rather than pinned, so the row cannot drift with the fixture's height or the viewport's.
    await select(page, GAP_LARGE);
    const midAnchor = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(midAnchor.x, midAnchor.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const mid = await readPopupPlacement(page);
    // THE CONTROL BRANCH, first: mid-frame the popup takes its PREFERRED side, below the anchor. Both branches inhabited, or the assertion below is one answer everywhere.
    expect(mid.top, "mid-frame the popup sits below its anchor").toBeGreaterThan(midAnchor.y);
    expect(mid.insideClip).toBe(true);
    await page.keyboard.press("Escape");
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(0);

    // Put the apron's centre 8 px above the layer's bottom edge — inside the clip, so the press still lands on it.
    await page.evaluate((delta: number) => {
      document.getElementById("dsh-screen")!.scrollTop -= delta;
    }, mid.layerBottom - 8 - midAnchor.y);
    await page.waitForTimeout(400);
    const lowAnchor = await affordanceCentre(page, "gap:0", "apron");
    // THE PRECONDITION: the preferred side genuinely cannot hold the popup now. Without this the flip assertion below would pass on a page that simply never scrolled.
    expect(
      lowAnchor.y,
      "the apron is close enough to the frame's bottom edge that the preferred side cannot hold the popup",
    ).toBeGreaterThan(mid.layerBottom - READOUT_GAP - mid.height);

    await page.mouse.click(lowAnchor.x, lowAnchor.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);
    const low = await readPopupPlacement(page);
    // ⚠ **THE FLIP, AND THE ASSERTION IS "CLEAR OF THE ANCHOR" RATHER THAN "HIGHER UP" — because a CLAMP also moves the popup up and would pass the loose form.** Clamped, the popup's top would be `layerHeight - height` and its box would still cover the anchor point; flipped, its whole box sits above the anchor. That difference is the entire ruling — `use-spacing-drag.ts#FLIP, NEVER CLAMP` — and it is the one bit these two implementations disagree on.
    // RED-when: replace the flip branch with a clamp to the clip → the popup's bottom edge lands past the anchor and this reads false.
    expect(low.bottom, "the flipped popup is clear of its anchor").toBeLessThanOrEqual(lowAnchor.y);
    expect(low.top).toBeLessThan(lowAnchor.y);
    // …and R42-D3's other half, which is why a flip is worth having at all: nothing is painted outside the clip, and the readout keeps its FULL WIDTH rather than losing a language to a squeeze.
    expect(low.insideClip).toBe(true);
    expect(low.width).toBe(mid.width);
    await page.keyboard.press("Escape");
  });
});

/**
 * ── S46-4 — C46-7's focus indicator and the spacing family's readout accent ──────────────────────
 *
 * **G46-9's `pnpm test:e2e` leg**, the PAINTED half. Its `pnpm gates` sibling is
 * `packages/descvi/src/react/overlay/__tests__/panel-focus-indicator.test.tsx`, and the two are
 * deliberately not the same claim: jsdom cascades no Tailwind stylesheet and implements no
 * `:focus-visible`, so the unit leg can only assert that the utility is ON the element. **A class
 * Tailwind never emits is green there and red here** — which is why the plan puts a leg in each set
 * and why "the local loop is green" is not this story's definition of done.
 *
 * ⚠ **WHY THESE ROWS LIVE IN THIS FILE, stated rather than left to look like a filing accident.**
 * They need the design-view panel rendered over a real selection, and this file already arranges
 * exactly that. A spec file of their own would need an entry in `e2e/fixtures/spec-classes.json` and
 * one in `playwright.config.ts`'s `testMatch`, and the gate that audits the first (`pnpm
 * test:e2e:gate-cx1`) spawns a full Playwright run — which the implementing lane does not own. The
 * placement is a routed question rather than a ruling: if the lead prefers a `panel-focus-ring`
 * spec, these rows move as a unit and nothing else about them changes.
 *
 * ⚠ **NON-COMMITTING AND NON-DESTRUCTIVE.** No row here releases a drag over a strip, POSTs, or
 * touches `page.tsx`. The one drag is a readout measurement that is cancelled on Escape.
 *
 * ⚠ **THE FOCUS IS REACHED BY KEYBOARD, AND THAT IS NOT DECORATION.** Chromium grants
 * `:focus-visible` on a heuristic, and a script `focus()` after a POINTER interaction — which
 * `select` performs, since it clicks the subject — does not get it. Every measurement below
 * therefore lands on its element through a real `Tab` / `Shift+Tab` round trip, and asserts BOTH
 * that focus came back to the intended node and that the node matches `:focus-visible`. A row that
 * measured a script-focused button would be reading the RESTING style under a focused name.
 */
test.describe.serial("S46-4 — the focus indicator (C46-7) and the readout accent, PAINTED", () => {
  /** The three v3 sections' ids, in panel order. */
  const SECTIONS = ["dsh-sizing", "dsh-layout", "dsh-spacing"] as const;

  interface Paint {
    key: string;
    borderColor: string;
    boxShadow: string;
    focusVisible: boolean;
    active: boolean;
  }

  /** Reads one control's painted state WITHOUT touching focus — the resting reading. */
  async function restingPaint(page: Page, key: string): Promise<Paint> {
    return page.evaluate((k: string) => {
      const el = document.querySelector<HTMLElement>(`[data-focus-probe="${k}"]`)!;
      const cs = getComputedStyle(el);
      return {
        key: k,
        borderColor: cs.borderLeftColor,
        boxShadow: cs.boxShadow,
        focusVisible: el.matches(":focus-visible"),
        active: document.activeElement === el,
      };
    }, key);
  }

  /**
   * Puts KEYBOARD focus on one control and reads its painted state.
   *
   * The round trip is `focus()` (to position), `Tab` (which is what tells Chromium the modality is
   * keyboard), then `Shift+Tab` (which lands back on the same node, now focus-visible).
   */
  async function focusedPaint(page: Page, key: string): Promise<Paint> {
    await page.evaluate((k: string) => {
      document.querySelector<HTMLElement>(`[data-focus-probe="${k}"]`)!.focus();
    }, key);
    await page.keyboard.press("Tab");
    await page.keyboard.press("Shift+Tab");
    return restingPaint(page, key);
  }

  /**
   * Stamps `data-focus-probe` on every ENABLED control of one ROLE across the three sections.
   *
   * ⚠ **DISABLED CONTROLS ARE EXCLUDED, AND THE EXCLUSION IS RETURNED RATHER THAN SILENT.** A
   * disabled `<button>` cannot take focus at all, so a focus-indicator obligation over it is not
   * merely untestable — it is meaningless. But an exclusion that narrowed the sweep quietly would be
   * indistinguishable from a section that rendered nothing, so `skipped` comes back with the keys
   * and the rows below say what they expect to find in each.
   */
  async function stampControls(page: Page, role: "marked" | "field"): Promise<{ keys: string[]; skipped: string[] }> {
    return page.evaluate(
      ({ sections, role: r }: { sections: readonly string[]; role: string }) => {
        const INTERACTIVE =
          "button, a[href], input, select, textarea, [role=button], [role=menuitem], [tabindex]:not([tabindex='-1'])";
        const keys: string[] = [];
        const skipped: string[] = [];
        for (const id of sections) {
          const section = document.getElementById(id);
          if (section === null) continue;
          for (const el of Array.from(section.querySelectorAll<HTMLElement>(INTERACTIVE))) {
            const isField = el.tagName.toLowerCase() === "input" && (el.getAttribute("type") ?? "text") === "text";
            const isMarked = el.hasAttribute("data-v3-glyph-control");
            if (r === "marked" ? !(isMarked && !isField) : !isField) continue;
            const own =
              el.getAttribute("data-cell") ??
              el.getAttribute("data-value") ??
              el.getAttribute("data-testid") ??
              el.getAttribute("aria-label") ??
              el.tagName.toLowerCase();
            const key = `${id}:${own}`;
            const off =
              (el as HTMLButtonElement | HTMLInputElement).disabled === true ||
              el.getAttribute("aria-disabled") === "true";
            if (off) {
              skipped.push(key);
              continue;
            }
            el.setAttribute("data-focus-probe", key);
            keys.push(key);
          }
        }
        return { keys, skipped };
      },
      { sections: SECTIONS, role },
    );
  }

  /**
   * Every stamped key resolves to a DISTINCT node.
   *
   * ⚠ **A COLLISION WOULD NARROW THE SWEEP IN SILENCE, WHICH IS THE ONE FAILURE THESE ROWS CANNOT
   * OTHERWISE SEE.** The key falls back through `data-cell → data-value → data-testid → aria-label →
   * tagName`, so two controls in one section that share none of the first four collapse onto the same
   * key; `querySelector` then answers the FIRST for both and the second is measured zero times while
   * the row reports a clean sweep. There is no collision on today's panel — which is exactly why the
   * assertion has to be written now rather than after one appears.
   */
  function assertKeysDistinct(keys: string[]): void {
    expect(new Set(keys).size, `every probe key is unique (keys: ${keys.join(", ")})`).toBe(keys.length);
  }

  test("G46-9 leg (ii), PAINTED — every rendered MARKED control paints the ruled ring, the nine grid cells included", async ({
    page,
  }) => {
    await select(page, GAP_SUBJECT);
    for (const id of SECTIONS) await expect(page.locator(`#${id}`)).toBeAttached();

    const { keys, skipped } = await stampControls(page, "marked");
    // NON-VACUITY, as a LOWER BOUND rather than a count: the population is state-dependent (the two
    // sizing chevrons are always there, Layout's other three families render only on a container),
    // and P46-5 forbids pinning it. What must hold is that the sweep had a subject.
    expect(keys.length, "the sweep found enabled marked controls to sweep").toBeGreaterThan(0);
    assertKeysDistinct(keys);
    // …and specifically that it reached the NINE GRID CELLS, which are `LayoutSection`'s second,
    // independent render site. A conformance pass applied only to the shared `ControlButton` leaves
    // them behind, and a sweep that never named them could not say so.
    //
    // ⚠ **THE SET OF NAMES, NEVER A TOTAL OF NINE.** {@link stampControls} skips DISABLED controls
    // (a disabled button cannot take focus, so a focus obligation over it is meaningless), so a
    // count would turn this row RED whenever a cell refusal shrank the population — a reason with
    // nothing to do with focus rings, on a subject chosen for its gap rather than its alignment.
    // The SET says the same thing about coverage and names WHICH cell went missing when one does.
    const cells = keys.filter((k) => k.startsWith("dsh-layout:")).map((k) => k.slice("dsh-layout:".length));
    const positions = ["start", "center", "end"] as const;
    const expectedCells = positions.flatMap((cross) => positions.map((main) => `${cross}-${main}`));
    expect(
      cells.filter((c) => expectedCells.includes(c)).sort(),
      `the nine grid cells are enabled and in the population (skipped as disabled: ${skipped.join(", ") || "none"})`,
    ).toEqual([...expectedCells].sort());

    for (const key of keys) {
      const rest = await restingPaint(page, key);
      const focused = await focusedPaint(page, key);
      // THE TWO PRECONDITIONS. Without them a resting reading could pass under a focused name.
      expect(focused.active, `${key}: Shift+Tab landed back on the control`).toBe(true);
      expect(focused.focusVisible, `${key}: the control matches :focus-visible under keyboard focus`).toBe(true);
      // THE MEASUREMENT: a RING appears, and the border colour moves. `ring-3` is a box-shadow, so
      // a resting control has none of it and a focused one carries a 3 px spread.
      expect(rest.boxShadow, `${key}: the RESTING control paints no ring`).toBe("none");
      expect(focused.boxShadow, `${key}: focused box-shadow`).not.toBe("none");
      expect(focused.boxShadow, `${key}: a 3 px ring`).toContain("3px");
      expect(focused.borderColor, `${key}: the border colour moves on focus`).not.toBe(rest.borderColor);
    }
  });

  test("G46-9 leg (ii), PAINTED — the instrument can report a control WITHOUT the ring (the in-row planted mutant)", async ({
    page,
  }) => {
    // ⚠ **A ZERO RESULT IS EVIDENCE ONLY ONCE THE INSTRUMENT HAS BEEN SHOWN PRODUCING A NON-ZERO
    // ONE.** The row above reports "every control paints a ring". This one plants the defect that
    // row exists to catch — the plan's own mutant, the raw `<button>` inside `LayoutSection`'s
    // `CELLS.map` losing the treatment — and confirms the same measurement reports it.
    await select(page, GAP_SUBJECT);
    await stampControls(page, "marked");
    const key = "dsh-layout:start-start";

    const before = await focusedPaint(page, key);
    expect(before.focusVisible, "the control really is keyboard-focused before the plant").toBe(true);
    expect(before.boxShadow, "…and it paints the ring before the plant").toContain("3px");

    const stripped = await page.evaluate((k: string) => {
      const el = document.querySelector<HTMLElement>(`[data-focus-probe="${k}"]`)!;
      const removed = Array.from(el.classList).filter((c) => c.startsWith("focus-visible:"));
      // ASSERT THE MUTATION APPLIED, and how much of it: a plant that removed nothing would leave
      // this row reading an unmutated control and calling the result a demonstration.
      el.classList.remove(...removed);
      return removed;
    }, key);
    expect(stripped.length, `the plant removed the focus utilities (removed: ${stripped.join(" ")})`).toBe(3);

    const after = await focusedPaint(page, key);
    expect(after.focusVisible, "the control is still keyboard-focused after the plant").toBe(true);
    expect(after.boxShadow, "…and now paints NO ring — the measurement sees the defect").toBe("none");

    // Put it back, so nothing after this row measures a mutated control.
    await page.evaluate(
      ({ k, classes }: { k: string; classes: string[] }) => {
        document.querySelector<HTMLElement>(`[data-focus-probe="${k}"]`)!.classList.add(...classes);
      },
      { k: key, classes: stripped },
    );
    expect((await focusedPaint(page, key)).boxShadow, "the restore is verified, not assumed").toContain("3px");
  });

  test("G46-9 leg (ii), PAINTED — a value FIELD paints the ruled border and NO ring, which is the role split", async ({
    page,
  }) => {
    await select(page, GAP_SUBJECT);
    const { keys, skipped } = await stampControls(page, "field");
    expect(
      keys.length,
      `the sweep found enabled value fields to sweep (skipped as disabled: ${skipped.join(", ") || "none"})`,
    ).toBeGreaterThan(0);
    assertKeysDistinct(keys);

    for (const key of keys) {
      const rest = await restingPaint(page, key);
      const focused = await focusedPaint(page, key);
      expect(focused.active, `${key}: Shift+Tab landed back on the field`).toBe(true);
      // ⚠ **THE FIELD IS ASSERTED ON `:focus`, NOT `:focus-visible`, AND THAT IS THE RULING RATHER
      // THAN A WEAKER TEST.** C46-7 gives a value field `ui/input.tsx`'s `focus:` treatment
      // precisely so a CLICK into it shows the indicator — a text field should, a button should not.
      expect(focused.borderColor, `${key}: the focus border colour differs from resting`).not.toBe(rest.borderColor);
      // …and NO ring: the two roles stay visually distinguishable, which is the whole point of
      // matching by role instead of applying one string everywhere.
      expect(focused.boxShadow, `${key}: a value field takes no ring`).toBe("none");
    }
  });

  test("S46-4 — the spacing readout's 3 px leading accent, on first paint AND after a re-anchor", async ({ page }) => {
    // ⚠ **THE RE-ANCHOR IS THE ASSERTION, NOT DECORATION** — the same shape G46-14 pins on the resize
    // family's copy of this look. `ensureNode` returns REUSED nodes on every tick, and the `border`
    // shorthand resets all four sides, so the write ORDER inside `styleReadout` (shorthand first,
    // `borderLeft*` second) only matters on the SECOND pass over a node that already has an accent.
    // A first paint is green with the writes in either order.
    await select(page, GAP_SUBJECT);
    const strip = await affordanceCentre(page, "gap:0");
    await page.mouse.move(strip.x, strip.y);
    await page.mouse.down();

    await page.mouse.move(strip.x + 8, strip.y + 8, { steps: 4 });
    const first = await page.evaluate(() => {
      const node = document.getElementById("dsh-spacing-readout")!;
      // Stamp the node so the second reading can prove it is the SAME one — a re-anchor that
      // replaced the node instead of reusing it would make this row assert a first paint twice.
      node.setAttribute("data-reanchor-witness", "1");
      const cs = getComputedStyle(node);
      return { left: cs.borderLeftWidth, top: cs.borderTopWidth, colour: cs.borderLeftColor };
    });
    expect(first.left, "the leading accent on first paint").toBe("3px");
    expect(first.top, "…and the other three sides stay hairline").toBe("1px");

    await page.mouse.move(strip.x + 40, strip.y + 24, { steps: 6 });
    const second = await page.evaluate(() => {
      const node = document.getElementById("dsh-spacing-readout")!;
      const cs = getComputedStyle(node);
      return {
        reused: node.getAttribute("data-reanchor-witness") === "1",
        left: cs.borderLeftWidth,
        top: cs.borderTopWidth,
        colour: cs.borderLeftColor,
      };
    });
    expect(second.reused, "the re-anchor REUSED the node, which is what makes the order load-bearing").toBe(true);
    expect(
      second.left,
      "the accent SURVIVED the re-anchor — RED-when: move the `border` shorthand after the `borderLeft*` writes",
    ).toBe("3px");
    expect(second.top).toBe("1px");
    expect(second.colour, "…in the same hue").toBe(first.colour);

    // THE IN-ROW PLANTED MUTANT. The defect is a source-order swap this page cannot perform, so what
    // is planted is its SIGNATURE: a sibling styled with the two writes in the wrong order reads back
    // 1px, which is what the measurement above would have found had the order been wrong.
    const wrongOrder = await page.evaluate(() => {
      const probe = document.createElement("div");
      probe.style.borderLeftWidth = "3px";
      probe.style.borderLeftColor = "#0F172A";
      probe.style.border = "1px solid rgba(100,116,139,0.30)"; // the shorthand LAST — the silent revert
      document.getElementById("dsh-ring-layer")!.appendChild(probe);
      const read = getComputedStyle(probe).borderLeftWidth;
      probe.remove();
      return read;
    });
    expect(wrongOrder, "the instrument distinguishes the reverted order from the shipped one").toBe("1px");

    await page.keyboard.press("Escape");
    await page.mouse.up();
  });

  test("S46-4 — the POPUP carries the family's accent, and its shipped C9 exclusion is untouched by the restyle", async ({
    page,
  }) => {
    // ⚠ **THIS ROW DOES NOT CONTRIBUTE THE EXCLUSION AND MUST NOT BE READ AS DOING SO.** The popup is
    // excluded from the marked universe BY ROLE, and the F11 row above is what asserts it. What S46-4
    // owes is that the restyle does not disturb that row — so this one re-reads the two facts the
    // exclusion rests on, beside the accent that is actually new.
    await select(page, GAP_LARGE);
    const apron = await affordanceCentre(page, "gap:0", "apron");
    await page.mouse.click(apron.x, apron.y);
    await expect(page.locator("#dsh-spacing-popup")).toHaveCount(1);

    const read = await page.evaluate(() => {
      const popup = document.getElementById("dsh-spacing-popup")!;
      const cs = getComputedStyle(popup);
      return {
        left: cs.borderLeftWidth,
        top: cs.borderTopWidth,
        marked: popup.hasAttribute("data-v3-glyph-control"),
        glyphed: popup.querySelector("svg, [data-glyph]") !== null,
        handle: popup.getAttribute("data-dsh-handle"),
      };
    });
    expect(read.left, "the popup takes the family's leading accent").toBe("3px");
    expect(read.top).toBe("1px");
    // The restyle spends a BORDER COLOUR. It adds no marker and no descendant, so the F11 row's
    // subject is the same DOM it was written against.
    expect(read.marked, "the restyle did not mark the popup").toBe(false);
    expect(read.glyphed, "…and added no glyph descendant to it").toBe(false);
    expect(read.handle, "…and the shield's ONE concession marker is where it was").toBe("spacing-popup");
    await page.keyboard.press("Escape");
  });
});
