import { test, expect, type Page } from "@playwright/test";

/**
 * resize-handles.spec.ts — the handle layer in a REAL browser (phase-48 B-Q5; ported corner-ramp model, plan §2.1, §4, §6).
 *
 * WHY A BROWSER IS REQUIRED FOR THIS HALF, stated because the jsdom suite beside it looks like it covers the same ground. Three of these assertions are unavailable there by construction:
 *
 *  1. **Computed `pointer-events`.** Measured on this repo's jsdom, a node carrying `class="pointer-events-none"` reads back `auto`, so a universe keyed on the computed property would select every descendant — every `<svg>`, every `<path>`, the hint and the marker — and go RED against a CORRECT implementation. A real browser has the real cascade. The control at the bottom of this file plants a class-only node and asserts the scan classifies it NON-operable, so a universe that silently read `auto` everywhere could not pass as green.
 *  2. **`document.elementFromPoint`.** jsdom has no layout, so hit identity is unaskable there.
 *  3. **A measured box, and the browser's own clip.** The straddling band and the corner ramp both legitimately reach outside `#dsh-ring-layer` and `#dsh-frame`, and it is those two elements' `overflow: hidden` — not this file's geometry — that decides what is reachable there (plan §2).
 *
 * NO GESTURE IS DRIVEN HERE, and that is the story's boundary rather than an omission: this file ships the layer and nothing that listens for a pointer. Every fixture below is arranged by writing inline styles onto the already-selected element and re-anchoring — mid-drag rows belong to `resize-write.spec.ts`, which needs capture, previews and a write, none of which exist here.
 *
 * THE EXPECTED HANDLE SET IS DERIVED, NEVER HAND-WRITTEN. `deriveExpected` below re-states the ported model — the corner ramp, the straddling band, the writable-axis filter — against the rects this run measured. It is deliberately a SECOND implementation of the model rather than an import of the first: an import would make every row a tautology. ⚠ Measured honestly, what the duplication proves is the SHAPE and the CODE PATH, not the constants: a breakpoint drift applied to BOTH implementations leaves every row here green. The ramp's exact numbers are pinned by `handle-geometry.test.ts`'s hand-derived coordinates — that file is the real oracle for the numbers; this one is for the placement realized in a live DOM.
 *
 * DOM-BASED THROUGHOUT, never accessibility-tree-based: `#dsh-ring-layer` is `aria-hidden`, so an
 * AT scan of it reports a vacuous green.
 *
 * The page is mutated (inline styles on one element) and never the repository — the artifact
 * oracle's tree delta stays empty by construction, and each fixture drops its own styles again.
 */

/** `lab/tests/style-edit`'s "simple static classes" card: a static, parseable, editable subject. */
const SUBJECT_OID = "v002k2";

/**
 * `lab/tests/style-edit`'s className-less button — the `no-class` refusal, resolved by the real edit
 * map rather than injected, and therefore the only subject on this screen whose marker text wraps
 * the way a user's would.
 */
const REFUSED_OID = "hakgqo";

/**
 * The owner's corner ramp (plan §4): a corner square's side, linear on the box's SHORT side between these two endpoints, clamped outside them. Literals, never imported — this file's standing discipline (see the header): an oracle that read the production constants would move with them.
 */
const CORNER_RAMP_NARROW_PX = 20;
const CORNER_RAMP_NARROW_EXTENT_PX = 8;
const CORNER_RAMP_WIDE_PX = 80;
const CORNER_RAMP_WIDE_EXTENT_PX = 16;

/**
 * The straddling side band's full thickness (plan §4) — half in the border box, half out. This replaces R42-D1's wholly-outside band, which `S48-0` supersedes: the constant this file used to pin (`STRIP_BAND = 12`, hung wholly outside the edge) described a ruling phase-48 reverses.
 */
const STRIP_BAND = 10;

/**
 * C46-1 clause 4's own-compass expectation set (G46-4's browser leg), hand-written — the same
 * deliberate-second-implementation discipline this file's header states for the admission rule, and
 * ralplan **RR-3's fix** rather than its restatement.
 *
 * ⚠ **DO NOT IMPORT `HANDLE_CURSOR` HERE.** An oracle that reads the production table moves WITH the
 * production table, so a mutation of the table changes gate and implementation together and ships
 * green. The jsdom half of G46-4 carries the same eight literals and mutates the real table against
 * them, which is where that claim is demonstrated rather than asserted.
 *
 * ⚠ It DISCRIMINATES, which had to be checked rather than assumed: the table pairs opposite
 * compasses on one value, so four of the twenty-eight unordered compass swaps are value-identical
 * and inert against any check. `nw`↔`ne` — the swap the plan names — is not one of them.
 */
const CURSOR_BY_COMPASS: Record<string, string> = {
  nw: "nwse-resize",
  ne: "nesw-resize",
  se: "nwse-resize",
  sw: "nesw-resize",
  n: "ns-resize",
  s: "ns-resize",
  e: "ew-resize",
  w: "ew-resize",
};

/** The canonical precedence (plan §4.1): first match wins among the eight ported regions. */
const ADMISSION_ORDER = ["nw", "ne", "se", "sw", "n", "e", "s", "w"] as const;
type Compass = (typeof ADMISSION_ORDER)[number];
const isCorner = (c: Compass): boolean => c.length === 2;

interface Rect {
  left: number;
  top: number;
  width: number;
  height: number;
}

interface HandleRecord {
  compass: Compass;
  /** Layer-relative hit-target rect. */
  rect: Rect;
  /**
   * The glyph's own rect, layer-relative — acceptance 4's 6–10 px box.
   *
   * ⚠ **ALWAYS `null` FOR A RESIZE HANDLE AFTER phase-46 S46-2**, which is why `boundsViolations`'
   * glyph leg is deleted there. The FIELD is kept because it is the reading that says so: a row that
   * wanted to check "no handle carries a mark" needs the measurement, and a field removed would make
   * that unaskable. Its `null` is now the expected value rather than the failure.
   */
  glyph: Rect | null;
  /** The node's own computed `cursor` — C46-1 clause 4's subject (G46-4), read in a REAL browser. */
  cursor: string;
  /** `document.elementFromPoint` at this handle's own centre returned this very node. */
  hitIsSelf: boolean;
  /** What the hit DID return, when it was not this node — named so a red says which. */
  hitDescriptor: string;
}

interface Scene {
  layer: Rect;
  frame: Rect;
  element: Rect;
  handles: HandleRecord[];
  /**
   * `#dsh-ring-layer`'s own VIEWPORT origin. Every rect above is LAYER-relative (via `rel()`), but `document.elementFromPoint` takes VIEWPORT coordinates — a probe point computed from the layer-relative rects must add this back before it is used to hit-test, or it silently probes the wrong pixel (caught in this row's own first live run, not assumed).
   */
  layerOrigin: { x: number; y: number };
  /**
   * `#dsh-frame`'s computed border box, read live so the clip (`G48-4`) is built from a MEASURED border width rather than a hard-coded one — `overflow: hidden` clips descendant HIT-TESTING at the PADDING edge (`frame` inset by `frameBorderWidthPx` on all four sides), and it clips to that edge's straight RECTANGLE only, never to the curve `frameBorderRadiusPx` paints (measured 2026-09-03, plan §6.1 — see the standing `G48-4 radius reading` row). `frameBorderRadiusPx` is kept only because that row's own probe geometry needs it, not because the clip does.
   */
  frameBorderWidthPx: number;
  frameBorderRadiusPx: number;
  /**
   * Nodes under `#dsh-ring-layer` whose COMPUTED `pointer-events` is not `none` (Universe B).
   *
   * ⚠ **`family` IS NEW IN PHASE-44 S44-3, AND IT IS THE ADMISSION-ORACLE MEASUREMENT's DISPOSITION.** Measured on this file's own subject: `v002k2` is `flex items-center gap-3 p-4` with two children, so with phase-44's spacing affordances shipped the ring layer carries the eight resize handles PLUS one gap strip, four padding edge handles and four popup aprons — and this scan collected all seventeen as "handles", because §3.9 rules the spacing family carries `data-dsh-handle` (it is the shield's one concession). Two of this file's rows went RED on a correct implementation.
   *
   * The disposition taken is S44-3 acceptance 12's FIRST arm: this oracle is a deliberate SECOND implementation, so it is edited BY HAND and never pointed at the production rule. What is added is the partition — the layer-wide claims (marked, DISCHARGING THE DECLARED KIND, no `<svg>`/`<path>` in the set) stay layer-wide because they are true of both families and phase-44 must not be able to break them silently (⚠ **the middle claim read *"glyph-bearing"* until phase-46 S46-2 — this file's BODY was amended there and this HEADER was not, which is the sweep miss the fix round caught: the class of stale look-claims is wider than the set of lines a story edits, and only a `grep -rnE "glyph-bearing|carries a glyph|painted pill"` over `docs .omc packages e2e` finds it**); only the COUNT, which is phase-42 §3.12's own derived expectation, is scoped to the furniture that rule governs.
   * A phase-42-plan erratum records that the §3.12 furniture population grew.
   */
  operable: {
    descriptor: string;
    /** Which furniture layer this node belongs to — `handle` is phase-42's, `spacing` is phase-44's. */
    family: "handle" | "spacing" | "other";
    hasHandleAttr: boolean;
    hasGlyphControlAttr: boolean;
    hasGlyphDescendant: boolean;
    /** C46-1's DECLARED KIND — the marker's VALUE, or `null` when the marker is absent (ralplan-phase-46 §3.1 clause 2). */
    glyphKind: string | null;
    /** The mark is in the DOM but computed `display: none` — the THIRD state only `glyph-conditional` may be in. */
    markHidden: boolean;
    /** The node's `data-dsh-handle` VALUE — clause 4's lookup key, which is not the same thing as carrying the attribute. */
    handleAttr: string | null;
    /** Computed `cursor`, for clause 4's positive obligation (G46-4). */
    cursor: string;
    /** The node's own rendered box — clause 4's "over a non-zero hit box". */
    hit: { width: number; height: number };
  }[];
  markerCount: number;
  hintCount: number;
  /** The refusal marker's own layer-relative rect, or null when none is live (R42-D3). */
  marker: Rect | null;
}

/**
 * One measurement pass. Everything the rows below assert comes from this single evaluate, so a row
 * can never compare two reads of a layer that moved between them.
 */
async function readScene(page: Page, oid: string = SUBJECT_OID): Promise<Scene> {
  return page.evaluate((oid) => {
    const rel = (r: DOMRect, o: DOMRect) => ({
      left: r.left - o.left,
      top: r.top - o.top,
      width: r.width,
      height: r.height,
    });
    const describe = (n: Element | null): string => {
      if (n === null) return "null";
      const handle = n.getAttribute("data-dsh-handle");
      return `${n.tagName.toLowerCase()}${n.id === "" ? "" : `#${n.id}`}${handle === null ? "" : `[handle=${handle}]`}`;
    };

    const layerEl = document.getElementById("dsh-ring-layer")!;
    const frameEl = document.getElementById("dsh-frame")!;
    const el = document.querySelector(`[data-oid="${oid}"]`)!;
    const layerRect = layerEl.getBoundingClientRect();

    const markerEl = layerEl.querySelector("#dsh-ring-refusal-marker");
    // ⚠ SCOPED TO `#dsh-handle-layer` IN PHASE-44 S44-3 — see the `operable` field's docblock. This scan is phase-42 §3.12's second implementation and its subject is phase-42's furniture; unscoped it collects phase-44's spacing affordances too, because they carry the same shield marker by ruling. ⚠ **THE `?? layerEl` FALLBACK IS GONE AS OF THIS COMMIT (plan §2.1; F46-D).** It used to let the scan fall back to `#dsh-ring-layer` itself when `#dsh-handle-layer` was absent, which folded phase-44's spacing family into the scan too — where the corner/strip classification misreads the spacing compasses. `#dsh-handle-layer` is a permanent fixture of the shell (`OverlayShell.tsx`), so its absence is a wiring defect this file should fail loudly on rather than silently widen its scan to paper over.
    const handleLayerEl = document.getElementById("dsh-handle-layer")!;
    const spacingLayerEl = document.getElementById("dsh-spacing-layer");
    const roots = Array.from(handleLayerEl.querySelectorAll<HTMLElement>("[data-dsh-handle]"));
    const handles = roots.map((root) => {
      const r = root.getBoundingClientRect();
      const glyph = root.querySelector("svg, [data-glyph]");
      const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return {
        compass: root.getAttribute("data-dsh-handle") ?? "",
        rect: rel(r, layerRect),
        glyph: glyph === null ? null : rel(glyph.getBoundingClientRect(), layerRect),
        // COMPUTED, not the inline value: C46-1 clause 4 is about what the pointer actually shows,
        // and only a real browser can answer that. The jsdom half of G46-4 has to read the inline
        // style instead, and that difference is the reason both halves exist.
        cursor: getComputedStyle(root).cursor,
        // OBJECT identity, not a class or attribute match: a full-edge strip overlaps both corner
        // handles on its edge, so an attribute match would call the strip a pass for the corner.
        hitIsSelf: hit === root,
        hitDescriptor: describe(hit),
      };
    });

    const operable = Array.from(layerEl.querySelectorAll<HTMLElement>("*"))
      .filter((n) => getComputedStyle(n).pointerEvents !== "none")
      .map((n) => ({
        descriptor: describe(n),
        family: (spacingLayerEl !== null && spacingLayerEl.contains(n)
          ? "spacing"
          : handleLayerEl.contains(n)
            ? "handle"
            : "other") as "handle" | "spacing" | "other",
        hasHandleAttr: n.hasAttribute("data-dsh-handle"),
        hasGlyphControlAttr: n.hasAttribute("data-v3-glyph-control"),
        hasGlyphDescendant: n.querySelector("svg, [data-glyph]") !== null,
        glyphKind: n.getAttribute("data-v3-glyph-control"),
        markHidden: (() => {
          const mark = n.querySelector("svg, [data-glyph]");
          return mark !== null && getComputedStyle(mark).display === "none";
        })(),
        handleAttr: n.getAttribute("data-dsh-handle"),
        cursor: getComputedStyle(n).cursor,
        hit: (() => {
          const b = n.getBoundingClientRect();
          return { width: b.width, height: b.height };
        })(),
      }));

    const frameStyle = getComputedStyle(frameEl);

    return {
      layer: { left: 0, top: 0, width: layerRect.width, height: layerRect.height },
      layerOrigin: { x: layerRect.left, y: layerRect.top },
      frame: rel(frameEl.getBoundingClientRect(), layerRect),
      element: rel(el.getBoundingClientRect(), layerRect),
      handles,
      frameBorderWidthPx: Number.parseFloat(frameStyle.borderLeftWidth),
      frameBorderRadiusPx: Number.parseFloat(frameStyle.borderTopLeftRadius),
      operable,
      markerCount: layerEl.querySelectorAll("#dsh-ring-refusal-marker").length,
      hintCount: layerEl.querySelectorAll("#dsh-ring-instance-hint").length,
      marker: markerEl === null ? null : rel(markerEl.getBoundingClientRect(), layerRect),
    };
  }, oid) as Promise<Scene>;
}

// ── The ported model, re-stated (plan §4) ──────────────────────────────────────────────────────
// A second implementation on purpose (see the header). Corner squares centred on the box's four corners, side interpolated on the SHORT side between the two owner endpoints; four straddling bands, one per edge, thickness `STRIP_BAND`, centreline on the border box. No clip, no coverage floor, no separation clause — the model refuses nothing (plan §1). Only `handleAxes` — a writable-axis filter — removes anything, and no fixture in this file blocks an axis, so `deriveExpected` always returns all eight for the fixtures this file drives.

/**
 * The reachable surface's clip: `#dsh-frame`'s padding-box RECTANGLE (its border box inset by `frameBorderWidthPx` on all four sides), intersected with `#dsh-ring-layer`'s own rect. **No arc** — measured 2026-09-03 (plan §6.1): `overflow: hidden` on `#dsh-frame` clips descendant HIT-TESTING to the padding-box rectangle, not to the curve `border-radius` paints. `G48-4`'s standing radius-reading row is the measurement this drops; the clip model here is what that measurement licenses.
 */
interface Clip {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

function clipOf(scene: Scene): Clip {
  const paddingLeft = scene.frame.left + scene.frameBorderWidthPx;
  const paddingTop = scene.frame.top + scene.frameBorderWidthPx;
  const paddingRight = scene.frame.left + scene.frame.width - scene.frameBorderWidthPx;
  const paddingBottom = scene.frame.top + scene.frame.height - scene.frameBorderWidthPx;
  return {
    left: Math.max(scene.layer.left, paddingLeft),
    top: Math.max(scene.layer.top, paddingTop),
    right: Math.min(scene.layer.left + scene.layer.width, paddingRight),
    bottom: Math.min(scene.layer.top + scene.layer.height, paddingBottom),
  };
}

function pointInClip(x: number, y: number, clip: Clip): boolean {
  return x >= clip.left && x <= clip.right && y >= clip.top && y <= clip.bottom;
}

function anchorOf(box: Rect, compass: Compass): { x: number; y: number } {
  const l = box.left;
  const t = box.top;
  const r = box.left + box.width;
  const b = box.top + box.height;
  const mx = l + box.width / 2;
  const my = t + box.height / 2;
  const table: Record<Compass, { x: number; y: number }> = {
    nw: { x: l, y: t },
    ne: { x: r, y: t },
    se: { x: r, y: b },
    sw: { x: l, y: b },
    n: { x: mx, y: t },
    e: { x: r, y: my },
    s: { x: mx, y: b },
    w: { x: l, y: my },
  };
  return table[compass];
}

/** The owner's ramp, clamped outside its two endpoints — the literal shape `G48-10` pins. */
function rampCorner(shortSide: number): number {
  if (shortSide <= CORNER_RAMP_NARROW_PX) return CORNER_RAMP_NARROW_EXTENT_PX;
  if (shortSide >= CORNER_RAMP_WIDE_PX) return CORNER_RAMP_WIDE_EXTENT_PX;
  return (
    CORNER_RAMP_NARROW_EXTENT_PX +
    ((shortSide - CORNER_RAMP_NARROW_PX) / (CORNER_RAMP_WIDE_PX - CORNER_RAMP_NARROW_PX)) *
      (CORNER_RAMP_WIDE_EXTENT_PX - CORNER_RAMP_NARROW_EXTENT_PX)
  );
}

interface Placed {
  compass: Compass;
  rect: Rect;
  centre: { x: number; y: number };
  anchor: { x: number; y: number };
}

/**
 * Places ONE region — a corner square centred on its box corner, or a band straddling its edge — with no clip and no trim (plan §2, "clip, don't push"). ⚠ `place()`'s job used to include the push and the outward-band offset (R42-D1); both are gone with the ruling `S48-0` reverses, and this function is now pure box arithmetic, exactly like the ported production module.
 */
function place(box: Rect, compass: Compass): Placed {
  const anchor = anchorOf(box, compass);
  if (isCorner(compass)) {
    const corner = rampCorner(Math.min(box.width, box.height));
    const half = corner / 2;
    const rect = { left: anchor.x - half, top: anchor.y - half, width: corner, height: corner };
    return { compass, rect, centre: anchor, anchor };
  }
  const half = STRIP_BAND / 2;
  const horizontal = compass === "n" || compass === "s";
  const l = box.left;
  const t = box.top;
  const r = box.left + box.width;
  const b = box.top + box.height;
  const rect = horizontal
    ? { left: l, top: (compass === "n" ? t : b) - half, width: box.width, height: STRIP_BAND }
    : { left: (compass === "w" ? l : r) - half, top: t, width: STRIP_BAND, height: box.height };
  return { compass, rect, centre: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }, anchor };
}

/**
 * The model's WHOLE output for the rects this run measured: every one of the eight, axis-filtered only. No fixture in this file blocks a writable axis, so this always returns all eight — and it stays a function, rather than a hard-coded `ADMISSION_ORDER`, because a future row that DOES block an axis inherits the filter for free.
 */
function deriveExpected(scene: Scene): Placed[] {
  return ADMISSION_ORDER.map((compass) => place(scene.element, compass));
}

/**
 * S42-1 acceptance 4's numeric bounds, as a checker rather than as inline expectations — so the
 * same instrument can be run over a PLANTED 1 px handle and shown to reject it. A criterion that
 * has never been seen to reject anything is not yet a criterion.
 *
 * REWRITTEN for the ported model (plan §2.1): the corner leg is the ramp's own bound at the measured short side (not a hand-written 16–24 band), the band leg is the straddling thickness, and the coverage leg is EXACT edge-spanning (`G48-8`) rather than a ≥ 90 % floor.
 */
function boundsViolations(handles: HandleRecord[], element: Rect): string[] {
  const out: string[] = [];
  const cornerExtent = rampCorner(Math.min(element.width, element.height));
  for (const h of handles) {
    // ⚠ **G46-11's DELETION LANDS HERE, AT S46-2, AND `AGENTS.md` REQUIRES THE REASON TO BE NAMED (KEPT verbatim — this record predates phase-48 and nothing here touches its subject).** This checker carried two more legs — `if (h.glyph === null) out.push(\`${h.compass}: no glyph\`)` and a 6–10 px bound on `h.glyph.width` / `h.glyph.height`. Its subject is `#dsh-handle-layer` alone (see `roots` in `readScene`), and C46-2 stops every resize handle building a mark, so from that commit those two legs have **no subject anywhere in this checker's universe, permanently**. The applicable permitted reason is the FIRST — *the code it covered is gone*.
    //
    // ⚠ **AND IT WAS SHOWN WORKING BEFORE IT WENT.** S46-1 (`e605aec`) added a row that removed a real corner's mark while every handle still declared `glyph` and watched the null leg name it — `["nw: no glyph"]` — precisely so that what is deleted here is a leg that was rejecting things last commit, not one that had gone quiet years ago and nobody noticed. That row goes with the leg it demonstrated; the two are one unit.
    //
    // ⚠ **NOT RE-POINTED AT THE SPACING FAMILY.** Re-pointing would move a phase-42 assertion onto phase-44's furniture, where `e2e/spacing-gesture.spec.ts` already owns the conditional mark, and the two would drift. What survives is the corner HIT-BOX leg below — a LITERAL bound rather than an imported constant, so no symbol rename carries it and only this row catches a footprint move.
    //
    // ⚠ **THE `readScene` `roots ?? layerEl` FALLBACK THIS PARAGRAPH ONCE ROUTED IS GONE (plan §2.1) — this is the commit that removes it, not a future one.** F46-D's own disposition named the hazard precisely: the fallback predated phase-46, had never fired, and under it the corner/strip legs below would collect phase-44's spacing family too, where `isCorner(c) = c.length === 2` misreads the spacing compasses. `docs/e3/tracker.md`'s phase-46 section (F46-D) records the original routing; this comment records that `S48-1a` is the lane that discharged it.
    const short = Math.min(h.rect.width, h.rect.height);
    if (isCorner(h.compass)) {
      if (Math.abs(short - cornerExtent) > 0.5) {
        out.push(`${h.compass}: hit short axis ${short} is not the ramp's ${cornerExtent.toFixed(3)} px bound`);
      }
    } else if (Math.abs(short - STRIP_BAND) > 0.5) {
      out.push(`${h.compass}: hit short axis ${short} is not the ${STRIP_BAND} px band`);
    }
    if (!isCorner(h.compass)) {
      // G48-8 — a band runs the WHOLE edge, exactly, not merely a share of it.
      const horizontal = h.compass === "n" || h.compass === "s";
      const edge = horizontal ? element.width : element.height;
      const long = horizontal ? h.rect.width : h.rect.height;
      if (Math.abs(long - edge) > 0.5) {
        out.push(`${h.compass}: strip spans ${long.toFixed(2)} of its ${edge.toFixed(2)} px edge, not exactly`);
      }
    }
  }
  return out;
}

// ── The run ────────────────────────────────────────────────────────────────────────────────────

async function selectSubject(page: Page): Promise<void> {
  await page.goto("/lab/tests/style-edit");
  await expect(page.locator("#dsh-ring-layer")).toBeAttached();
  // A POSITIONED click into the card's own padding: a centre click lands on a child that carries
  // its own `data-oid`, and the canvas would resolve the selection to THAT.
  await page.locator(`[data-oid="${SUBJECT_OID}"]`).click({ position: { x: 6, y: 6 } });
  await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  await expect(page.locator("#dsh-handle-layer [data-dsh-handle]")).toHaveCount(8);
}

/**
 * Sizes and positions the SELECTED element, then waits for the layer to re-anchor onto it. `oid`
 * defaults to the card every geometry row uses; R42-D3's row passes the `no-class` button instead,
 * because it needs a subject whose refusal marker is real rather than injected.
 *
 * RE-POINTED (plan §2.1): the settle poll's second half used to reject a scene where any handle had drifted more than one hit extent from its anchor. Under the ported model every drift is exactly zero (`G48-3`), so the poll's predicate is EXACT equality between each handle's own centre and its anchor — it keeps its job of telling "not re-anchored yet" apart from "placed wrongly".
 */
async function setFixture(page: Page, style: Record<string, string>, oid: string = SUBJECT_OID): Promise<Scene> {
  await page.evaluate(
    ({ oid, style: s }) => {
      const el = document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)!;
      el.removeAttribute("style");
      // Padding and border are zeroed FIRST, and it is not cosmetic: under `box-sizing: border-box`
      // the used width can never fall below padding + border, so this card's `p-4 border` floors it
      // at 34 px and every sub-34 px fixture below would silently measure 34. Observed, not assumed.
      Object.assign(el.style, { padding: "0px", border: "0px", minWidth: "0px", minHeight: "0px" });
      Object.assign(el.style, s);
      // The element-scoped ResizeObserver covers a size change; a pure MOVE changes no box it
      // watches, so the shell's own resize path is what re-anchors those fixtures.
      window.dispatchEvent(new Event("resize"));
    },
    { oid, style },
  );
  await expect
    .poll(
      async () => {
        const s = await readScene(page, oid);
        const wantW = style.width === undefined ? s.element.width : Number.parseFloat(style.width);
        const wantH = style.height === undefined ? s.element.height : Number.parseFloat(style.height);
        if (Math.abs(s.element.width - wantW) > 0.5 || Math.abs(s.element.height - wantH) > 0.5) {
          return `size ${s.element.width}×${s.element.height}, wanted ${wantW}×${wantH}`;
        }
        for (const h of s.handles) {
          const a = anchorOf(s.element, h.compass);
          const c = { x: h.rect.left + h.rect.width / 2, y: h.rect.top + h.rect.height / 2 };
          const d = Math.hypot(c.x - a.x, c.y - a.y);
          // ⚠ **0.5 px IS THE POLL'S OWN QUANTISATION FLOOR, NOT THE EXACT-EQUALITY BOUND §6/`G48-3` ASSERTS.** This predicate's ONE job is telling "not re-anchored yet" apart from "placed wrongly"; the exact figure — `G48-3`'s own declared `tolerance` (0.02 px, measured) — is what the dedicated row above actually asserts, once this poll has already confirmed the scene has settled.
          if (d > 0.5) return `${h.compass} drifted ${d.toFixed(2)} from its anchor (not yet settled)`;
        }
        return "settled";
      },
      { timeout: 5_000 },
    )
    .toBe("settled");
  return readScene(page, oid);
}

test.describe("G42-6a / G42-7 — the resize handle layer (phase-48 ported model)", () => {
  test.beforeEach(async ({ page }) => {
    await selectSubject(page);
  });

  test.afterEach(async ({ page }) => {
    await page.evaluate((oids) => {
      for (const oid of oids) document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)?.removeAttribute("style");
      for (const n of Array.from(document.querySelectorAll("[data-probe-plant]"))) n.remove();
    }, [SUBJECT_OID, REFUSED_OID]);
  });

  test("acceptance 4 + 9 — the numeric bounds hold on a comfortable subject, REJECT a 1 px stub, and every band spans its edge exactly (G48-8)", async ({
    page,
  }) => {
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    expect(scene.handles).toHaveLength(8);
    expect(boundsViolations(scene.handles, scene.element)).toEqual([]);

    // G48-8, spelled out: each strip's LONG axis against the element's own edge, EXACTLY.
    for (const h of scene.handles.filter((x) => !isCorner(x.compass))) {
      const horizontal = h.compass === "n" || h.compass === "s";
      const long = horizontal ? h.rect.width : h.rect.height;
      const edge = horizontal ? scene.element.width : scene.element.height;
      expect(long, `${h.compass} band length`).toBeCloseTo(edge, 0);
    }

    // THE CONTROL. A 1 px hit target must FAIL this criterion — otherwise the green above is the instrument's silence rather than the layer's geometry.
    const stub: HandleRecord = {
      compass: "nw",
      rect: { left: 0, top: 0, width: 1, height: 1 },
      // `null`, because after S46-2 that is what a real handle reads — a stub carrying a mark would
      // be a shape this layer can no longer produce, and the leg that used to read it is gone.
      glyph: null,
      cursor: "nwse-resize",
      hitIsSelf: true,
      hitDescriptor: "div[handle=nw]",
    };
    const violations = boundsViolations([stub], scene.element);
    expect(violations.length).toBeGreaterThan(0);
    expect(violations.join(" ")).toContain("hit short axis");
  });

  test("acceptance 5 — every handle's own centre hits THAT node, and the nodes are distinct", async ({ page }) => {
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    expect(scene.handles).toHaveLength(8);
    for (const h of scene.handles) {
      expect(h.hitIsSelf, `${h.compass} centre returned ${h.hitDescriptor}`).toBe(true);
    }
    // Distinct nodes follow from distinct compasses, each of which is unique among the roots — and
    // `hitIsSelf` is an object-identity comparison, so a class match could not have produced it.
    expect(new Set(scene.handles.map((h) => h.compass)).size).toBe(8);
  });

  test("G48-3 (browser half) — the corner's rendered centre equals the box corner EXACTLY, measured across regimes", async ({
    page,
  }) => {
    // ⚠ The IEEE question is settled by measurement, not by design (plan §6). These two fixtures are where the ramp yields a NON-INTEGER extent — `23×100` (fractional placement away from the origin) and `1×1 at the rounded corner` (worst-case quantisation) — and the deltas measured here are what decides whether the rows below ship bare equality or a declared tolerance.
    const deltas: Record<string, number> = {};
    for (const fixture of [
      { name: "23×100", style: { left: "220px", top: "180px", width: "23px", height: "100px" } },
      { name: "1×1 at the rounded corner", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
    ]) {
      const scene = await setFixture(page, { position: "absolute", ...fixture.style });
      let worst = 0;
      for (const h of scene.handles.filter((x) => isCorner(x.compass))) {
        const centre = { x: h.rect.left + h.rect.width / 2, y: h.rect.top + h.rect.height / 2 };
        const anchor = anchorOf(scene.element, h.compass);
        worst = Math.max(worst, Math.hypot(centre.x - anchor.x, centre.y - anchor.y));
      }
      deltas[fixture.name] = worst;
    }
    // The measurement loop above stays a LOGGED OBSERVATION, not the tolerance's source — a tolerance derived from the same run it bounds cannot fail. It is declared here as a LITERAL, at its declaration, with the run that produced it and both fixture readings named: measured 2026-09-03 at devicePixelRatio 1, `23×100` = 0.011048543…px (fractional placement away from the origin — the worst-case fixture) and `1×1 at the rounded corner` = 0px exactly (integer layout at the origin). Both are effectively zero, matching plan §6's own prediction ("integer layout at a device pixel ratio of 1 is the easy case"); 0.02 is the measured maximum (0.011…) rounded up.
    console.log("G48-3 measured corner-centre deltas (devicePixelRatio-quantised):", JSON.stringify(deltas));
    const tolerance = 0.02;
    for (const fixture of [
      { name: "300×120 comfortable", style: { left: "200px", top: "180px", width: "300px", height: "120px" } },
      { name: "30×30 interior", style: { left: "220px", top: "180px", width: "30px", height: "30px" } },
      { name: "23×100", style: { left: "220px", top: "180px", width: "23px", height: "100px" } },
      { name: "1×1 at the rounded corner", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
    ]) {
      const scene = await setFixture(page, { position: "absolute", ...fixture.style });
      for (const h of scene.handles.filter((x) => isCorner(x.compass))) {
        const centre = { x: h.rect.left + h.rect.width / 2, y: h.rect.top + h.rect.height / 2 };
        const anchor = anchorOf(scene.element, h.compass);
        // ⚠ **THE DECLARED `tolerance` ITSELF IS THE BOUND — no `+ 0.05` padding beyond the measured maximum this file's own run above produced .** A row that asserts a looser number than the one it declares is not asserting the tolerance it claims to.
        expect(Math.abs(centre.x - anchor.x), `${fixture.name} ${h.compass}.x`).toBeLessThanOrEqual(tolerance);
        expect(Math.abs(centre.y - anchor.y), `${fixture.name} ${h.compass}.y`).toBeLessThanOrEqual(tolerance);
        expect(Math.hypot(centre.x - anchor.x, centre.y - anchor.y), `${fixture.name} ${h.compass} delta`).toBeLessThanOrEqual(
          tolerance,
        );
      }
    }
  });

  test("acceptance 4b — every handle's placement matches the ported model exactly, on 12 fixtures, corners AND bands (G48-3/G48-8)", async ({
    page,
  }) => {
    const fixtures: { name: string; style: Record<string, string> }[] = [
      { name: "1×100", style: { left: "220px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1", style: { left: "220px", top: "180px", width: "100px", height: "1px" } },
      { name: "23×100", style: { left: "220px", top: "180px", width: "23px", height: "100px" } },
      { name: "100×23", style: { left: "220px", top: "180px", width: "100px", height: "23px" } },
      { name: "1×1", style: { left: "220px", top: "180px", width: "1px", height: "1px" } },
      { name: "30×30", style: { left: "220px", top: "180px", width: "30px", height: "30px" } },
      // ── each also FLUSH to a frame edge ──
      { name: "1×100 flush left", style: { left: "0px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1 flush top", style: { left: "220px", top: "0px", width: "100px", height: "1px" } },
      { name: "23×100 flush left", style: { left: "0px", top: "180px", width: "23px", height: "100px" } },
      { name: "100×23 flush top", style: { left: "220px", top: "0px", width: "100px", height: "23px" } },
      { name: "1×1 flush left", style: { left: "0px", top: "180px", width: "1px", height: "1px" } },
      // ── and the layer origin, the LAYOUT-QUANTISATION case (plan §6.1: the rectangle clip has no second clip rect here to diverge from; §2.1's "two clip rects diverge" premise is void under the measured rectangle reading) ──
      { name: "1×1 at the rounded corner", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
    ];

    for (const fixture of fixtures) {
      const scene = await setFixture(page, { position: "absolute", ...fixture.style });
      const expected = deriveExpected(scene);
      const rendered = scene.handles.map((h) => h.compass).sort();

      // The SET — under the ported model this is unconditionally all eight (plan §1, `G48-2`).
      expect(rendered, `${fixture.name}: rendered set`).toEqual(expected.map((p) => p.compass).sort());
      expect(rendered.length, `${fixture.name}: constant eight`).toBe(8);

      for (const h of scene.handles) {
        const exp = expected.find((p) => p.compass === h.compass)!;
        // G48-3/G48-8 realised in the DOM: the rendered rect equals the model's own rect, to THIS ROW'S OWN 0.5 px tolerance (`toBeCloseTo(…, 0)`). It is looser than the 0.02 px `G48-3` browser row (above) declares, and for a reason stated rather than borrowed: that row measures ONE quantity (a corner's own centre) on two chosen worst-case fixtures and reports the maximum it actually saw. This row checks FOUR numbers (left/top/width/height) per handle, over BOTH corners and bands, across all twelve of acceptance 4b's fixtures — including several this file never separately measures — so it takes `toBeCloseTo`'s standard rounding-tolerant bound rather than re-deriving a fresh maximum for every one of those combinations.
        expect(h.rect.left, `${fixture.name}: ${h.compass}.left`).toBeCloseTo(exp.rect.left, 0);
        expect(h.rect.top, `${fixture.name}: ${h.compass}.top`).toBeCloseTo(exp.rect.top, 0);
        expect(h.rect.width, `${fixture.name}: ${h.compass}.width`).toBeCloseTo(exp.rect.width, 0);
        expect(h.rect.height, `${fixture.name}: ${h.compass}.height`).toBeCloseTo(exp.rect.height, 0);
      }
    }
  });

  test("acceptance 4c (RETITLED) — small AND frame-flush: the reachable surface is what the clip leaves, and it is never empty (G48-4)", async ({
    page,
  }) => {
    // ⚠ RETITLED (plan §2.1): "nothing is clipped" is false the moment §2 hands clipping to the browser — a small, frame-flush subject's corner and band regions legitimately reach outside `#dsh-ring-layer` and `#dsh-frame`. What survives is the union floor: SOMETHING is still reachable. The per-handle reachable-surface reading (G48-4's full computation, with its two controls) lives in the row below; this one is the union-floor half stated on its own subject.
    const fixtures = [
      { name: "1×100 flush left", style: { left: "0px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1 flush top", style: { left: "220px", top: "0px", width: "100px", height: "1px" } },
      { name: "1×1 at the rounded corner", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
    ];
    for (const fixture of fixtures) {
      const scene = await setFixture(page, { position: "absolute", ...fixture.style });
      expect(scene.handles.length, `${fixture.name}: something renders`).toBeGreaterThan(0);
      expect(
        scene.handles.map((h) => h.compass).sort(),
        `${fixture.name}: rendered set is the constant eight`,
      ).toEqual(ADMISSION_ORDER.slice().sort());

      const clip = clipOf(scene);
      // The UNION floor: at least one handle's own rect, intersected with the padding-box RECTANGLE clip (plan §6.1 — no arc), contains an interior point — and `elementFromPoint` there returns SOME `[data-dsh-handle]` node. A small frame-flush subject still offers a reachable surface. A single clamped-centre candidate is not enough — a corner square straddling the clip boundary can be unreachable at its own centre while still owning an interior pocket near its inner edge (this is exactly `1×1 at the rounded corner`'s shape) — so this SAMPLES each rect on a 1 px grid.
      let foundReachable = false;
      for (const h of scene.handles) {
        for (let x = h.rect.left; x <= h.rect.left + h.rect.width && !foundReachable; x += 1) {
          for (let y = h.rect.top; y <= h.rect.top + h.rect.height && !foundReachable; y += 1) {
            if (!pointInClip(x, y, clip)) continue;
            const hit = await page.evaluate(
              ({ vx, vy }) => {
                const n = document.elementFromPoint(vx, vy);
                return n !== null && n.hasAttribute("data-dsh-handle");
              },
              { vx: x + scene.layerOrigin.x, vy: y + scene.layerOrigin.y },
            );
            if (hit) foundReachable = true;
          }
        }
        if (foundReachable) break;
      }
      expect(foundReachable, `${fixture.name}: at least one handle is reachable under the clip`).toBe(true);
    }
  });

  test("G48-4 — a frame-flush handle's reachable surface: exclusive identity where the exclusive region has room, the union floor and canonical owner otherwise", async ({
    page,
  }) => {
    // ⚠ **THE MARGIN IS MEASURED, NOT ASSUMED, AND IT IS LARGER THAN `G48-3`'s LAYOUT DELTA.** A probe run against this exact fixture (220×10's neighbour, `1×100 flush left`) found that `elementFromPoint` resolves to the HIGHER-z corner (`nw`, z 43) up to ~1 px past its own geometric edge against the lower-z band (`n`, z 42) beneath it — at y = 175.01 (0.99 px above `nw`'s measured top of 176) the hit is still `n`, and at y = 175.1 (0.9 px above) it has already flipped to `nw`. That is a HIT-TESTING quantisation at the z boundary, distinct from `G48-3`'s layout-quantisation delta (which measured effectively zero), and it is why this row's margin is its own measurement rather than a reuse of that one. `MARGIN` below is set to clear it with room, and a handle whose exclusive region cannot fit two such margins takes the fallback — which is the plan's own predicted outcome for a FLUSH fixture's outward-facing bands. ⚠ **THIS MARGIN DOES NOT GOVERN `G48-9`'S BAND-VS-BAND PROBE, WHICH MEASURES ITS OWN BOUNDARY SEPARATELY** — that probe crosses the nw square's RIGHT edge against `n`'s band on `220×10`, a different fixture and a different edge from the one measured here, and its own live scan (below, in `G48-9 (browser half)`) found a −0.05 px reach there, not this row's ~1 px.
    const MARGIN = 1.5;

    async function exclusiveProbe(handle: HandleRecord, others: HandleRecord[], clip: Clip): Promise<{ x: number; y: number } | null> {
      let best: { x: number; y: number } | null = null;
      let bestDist = Number.POSITIVE_INFINITY;
      const cx = handle.rect.left + handle.rect.width / 2;
      const cy = handle.rect.top + handle.rect.height / 2;
      for (let x = handle.rect.left + MARGIN; x <= handle.rect.left + handle.rect.width - MARGIN; x += 0.5) {
        for (let y = handle.rect.top + MARGIN; y <= handle.rect.top + handle.rect.height - MARGIN; y += 0.5) {
          if (!pointInClip(x, y, clip)) continue;
          // Excluded when within MARGIN of an OTHER handle's rect, not merely inside it — the measured z-boundary reach above means a literal rect test alone is not conservative enough near a higher-z neighbour.
          if (
            others.some(
              (o) =>
                x >= o.rect.left - MARGIN &&
                x <= o.rect.left + o.rect.width + MARGIN &&
                y >= o.rect.top - MARGIN &&
                y <= o.rect.top + o.rect.height + MARGIN,
            )
          )
            continue;
          const d = Math.hypot(x - cx, y - cy);
          if (d < bestDist) {
            bestDist = d;
            best = { x, y };
          }
        }
      }
      return best;
    }

    function rectReachable(handle: HandleRecord, clip: Clip): boolean {
      for (let x = handle.rect.left; x <= handle.rect.left + handle.rect.width; x += 0.5) {
        for (let y = handle.rect.top; y <= handle.rect.top + handle.rect.height; y += 0.5) {
          if (pointInClip(x, y, clip)) return true;
        }
      }
      return false;
    }

    /** The FIRST compass in canonical order whose corner square contains `p` — the fallback owner. */
    function canonicalOwner(scene: Scene, p: { x: number; y: number }): Compass | null {
      for (const compass of ADMISSION_ORDER) {
        const placed = place(scene.element, compass);
        if (p.x >= placed.rect.left && p.x <= placed.rect.left + placed.rect.width && p.y >= placed.rect.top && p.y <= placed.rect.top + placed.rect.height) {
          return compass;
        }
      }
      return null;
    }

    /**
     * SOME point of `rect` — intersected with `clip` when one is given, unfiltered when `clip` is `null` — returns SOME `[data-dsh-handle]` node. The candidate points are built here (Node side, against this file's own clip math) and handed to the browser as ONE array so the scan is a single round trip rather than one per point, with the browser's own loop returning as soon as it finds a hit.
     */
    async function anyHandleReachable(rect: Rect, layerOrigin: { x: number; y: number }, clip: Clip | null): Promise<boolean> {
      const points: { x: number; y: number }[] = [];
      for (let x = rect.left; x <= rect.left + rect.width; x += 1) {
        for (let y = rect.top; y <= rect.top + rect.height; y += 1) {
          if (clip !== null && !pointInClip(x, y, clip)) continue;
          points.push({ x: x + layerOrigin.x, y: y + layerOrigin.y });
        }
      }
      if (points.length === 0) return false;
      return page.evaluate((pts) => {
        for (const p of pts) {
          const n = document.elementFromPoint(p.x, p.y);
          if (n !== null && n.hasAttribute("data-dsh-handle")) return true;
        }
        return false;
      }, points);
    }

    // ⚠ **THE FULL FIFTEEN — 4b's twelve plus 4c's three, `300×120` left OUT of this loop and used only as CONTROL 1/CONTROL 2's own host below (plan §6's own assignment).** 4c's three are geometrically IDENTICAL to three of 4b's twelve (`1×100 flush left`, `100×1 flush top`, `1×1 at the rounded corner`): §6 assigns coverage to BOTH lists rather than to their union, so each is driven and reported on its own — the `(4c)` suffix on the repeats names the duplication rather than hiding it.
    const fixtures = [
      // ── acceptance 4b's twelve, verbatim (the "acceptance 4b" test, above) ──
      { name: "1×100", style: { left: "220px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1", style: { left: "220px", top: "180px", width: "100px", height: "1px" } },
      { name: "23×100", style: { left: "220px", top: "180px", width: "23px", height: "100px" } },
      { name: "100×23", style: { left: "220px", top: "180px", width: "100px", height: "23px" } },
      { name: "1×1", style: { left: "220px", top: "180px", width: "1px", height: "1px" } },
      { name: "30×30", style: { left: "220px", top: "180px", width: "30px", height: "30px" } },
      { name: "1×100 flush left", style: { left: "0px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1 flush top", style: { left: "220px", top: "0px", width: "100px", height: "1px" } },
      { name: "23×100 flush left", style: { left: "0px", top: "180px", width: "23px", height: "100px" } },
      { name: "100×23 flush top", style: { left: "220px", top: "0px", width: "100px", height: "23px" } },
      { name: "1×1 flush left", style: { left: "0px", top: "180px", width: "1px", height: "1px" } },
      { name: "1×1 at the rounded corner", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
      // ── acceptance 4c's three, verbatim (the "acceptance 4c (RETITLED)" test, above) ──
      { name: "1×100 flush left (4c)", style: { left: "0px", top: "180px", width: "1px", height: "100px" } },
      { name: "100×1 flush top (4c)", style: { left: "220px", top: "0px", width: "100px", height: "1px" } },
      { name: "1×1 at the rounded corner (4c)", style: { left: "0px", top: "0px", width: "1px", height: "1px" } },
    ];

    const report: Record<string, Record<string, string>> = {};

    for (const fixture of fixtures) {
      const scene = await setFixture(page, { position: "absolute", ...fixture.style });
      const clip = clipOf(scene);
      report[fixture.name] = {};

      for (const h of scene.handles) {
        const others = scene.handles.filter((o) => o.compass !== h.compass);
        const probe = await exclusiveProbe(h, others, clip);
        if (probe !== null) {
          const hit = await page.evaluate(
            ({ x, y }) => {
              const n = document.elementFromPoint(x, y);
              return n === null ? "null" : `${n.tagName.toLowerCase()}[handle=${n.getAttribute("data-dsh-handle")}]`;
            },
            { x: probe.x + scene.layerOrigin.x, y: probe.y + scene.layerOrigin.y },
          );
          report[fixture.name]![h.compass] = `identity:${hit}`;
          expect(hit, `${fixture.name}: ${h.compass} exclusive probe`).toBe(`div[handle=${h.compass}]`);
        } else {
          const predictedReachable = rectReachable(h, clip);
          report[fixture.name]![h.compass] = predictedReachable ? "fallback (reachable, no exclusive room)" : "empty (clip)";

          // (i) THE UNION FLOOR, for EVERY fallback handle — corner OR band, not corners alone (plan §6's "union floor plus the canonical-owner assertion" for every fallback handle). Some point of `rect ∩ clip` must return SOME `[data-dsh-handle]` node — a port that clipped MORE than this file's own math predicts fails here, on a band as readily as on a corner.
          if (predictedReachable) {
            const floorReachable = await anyHandleReachable(h.rect, scene.layerOrigin, clip);
            expect(floorReachable, `${fixture.name}: ${h.compass} union floor (rect ∩ clip is reachable)`).toBe(true);
          }

          // (ii) THE CLASSIFICATION ITSELF, CONFRONTED WITH THE BROWSER (plan §6). `predictedReachable` above is computed from this file's own clip MATH (`rectReachable`), never from the browser — so a port that clips LESS than predicted (the browser finds a reachable point where the math says `rect ∩ clip` is empty) would pass silently without this leg. It scans the handle's own rect UNFILTERED by the computed clip, so an "empty" classification is checked against the browser rather than merely asserted from arithmetic.
          if (!predictedReachable) {
            const anyReachableAtAll = await anyHandleReachable(h.rect, scene.layerOrigin, null);
            expect(anyReachableAtAll, `${fixture.name}: ${h.compass} predicted empty, confronted with the browser over its own rect`).toBe(false);
            continue; // expected observation — the clip acting, not a defect.
          }

          // Fallback + CORNER: the canonical-owner probe stays the corner-specific EXTRA beside the union floor above (plan §6) — bands have no box corner of their own to probe.
          const boxCorner = h.compass in { nw: 1, ne: 1, se: 1, sw: 1 } ? anchorOf(scene.element, h.compass as Compass) : null;
          if (boxCorner === null) continue;
          // ⚠ **THE PROBE IS THE NEAREST POINT OF THE CORNER'S OWN REGION INSIDE THE CLIP, MARGIN-INSET, NOT THE RAW BOX CORNER (plan §6).** On the flush fixtures the raw box corner sits EXACTLY on the clip's own boundary — a point the row cannot distinguish from a rounding — so probing it there silently drops the assertion (`continue`) while recording the SAME "fallback (reachable, no exclusive room)" string the union floor already wrote, one line up. The intersection of the handle's own rect and the clip, shrunk by `MARGIN` on every side, is where the probe is taken instead; when that intersection is empty (the corner's own region does not reach `MARGIN` inside the clip anywhere), the row records a DISTINCT string rather than silently reusing the union-floor's.
          const probeLoX = Math.max(h.rect.left, clip.left + MARGIN);
          const probeHiX = Math.min(h.rect.left + h.rect.width, clip.right - MARGIN);
          const probeLoY = Math.max(h.rect.top, clip.top + MARGIN);
          const probeHiY = Math.min(h.rect.top + h.rect.height, clip.bottom - MARGIN);
          if (probeLoX > probeHiX || probeLoY > probeHiY) {
            report[fixture.name]![h.compass] = "fallback (canonical-owner probe skipped: corner outside clip)";
            continue;
          }
          const cornerProbe = {
            x: Math.min(Math.max(boxCorner.x, probeLoX), probeHiX),
            y: Math.min(Math.max(boxCorner.y, probeLoY), probeHiY),
          };
          const owner = canonicalOwner(scene, cornerProbe);
          if (owner === null) {
            report[fixture.name]![h.compass] = "fallback (canonical-owner probe skipped: corner outside clip)";
            continue;
          }
          const hit = await page.evaluate(
            ({ x, y }) => {
              const n = document.elementFromPoint(x, y);
              return n === null ? "null" : `${n.tagName.toLowerCase()}[handle=${n.getAttribute("data-dsh-handle")}]`;
            },
            { x: cornerProbe.x + scene.layerOrigin.x, y: cornerProbe.y + scene.layerOrigin.y },
          );
          expect(hit, `${fixture.name}: ${h.compass} canonical-owner probe at the box corner (margin-inset into the clip)`).toBe(`div[handle=${owner}]`);
        }
      }
    }
    console.log("G48-4 reachable-surface report:", JSON.stringify(report, null, 2));
    // ⚠ **THE FULL FIFTEEN-FIXTURE SPLIT, MEASURED UNDER THE RECTANGLE (plan §6.1, over all of 4b's twelve fixtures plus 4c's three) — MEASURED, NOT PREDICTED, per §6's own instruction.**
    //
    // ALL EIGHT HANDLES TAKE IDENTITY (exclusive-probe room on every one): `23×100`, `100×23`, `30×30`.
    //
    // ALL EIGHT HANDLES TAKE THE FALLBACK (reachable, no exclusive room; the canonical-owner probe at the box corner resolves to the correct owner in every case): `1×100`, `100×1`, `1×1`, `1×100 flush left` (and its `(4c)` repeat), `100×1 flush top` (and its `(4c)` repeat), `1×1 flush left`, `1×1 at the rounded corner` (and its `(4c)` repeat).
    //
    // THE SPLIT ITSELF — the two fixtures the fifteen add beyond round 3's reading, where handles on ONE fixture genuinely divide: `23×100 flush left` — IDENTITY: `w, s, e, n, se, ne`; FALLBACK: `sw, nw` (the two corners nearest the flush left edge, where the outward half of their square leaves the layer). `100×23 flush top` — IDENTITY: `w, s, e, n, sw, se`; FALLBACK: `ne, nw` (the mirror, on the flush top edge).
    //
    // **NONE of the eight is `empty (clip)` on any of the fifteen fixtures** — the union-floor leg (below) and the classification-confrontation leg (below) both hold on every one. This directly falsifies round 1's classification, which predicted `n`/`w` as `empty (clip)` on `1×1 at the rounded corner`: under the rectangle (no arc, and the straight bounds are the same shape either way at this corner) the canonical-owner fallback covers every handle the arc-aware reading would have called empty — the emptiness that reading predicted never existed at rect level; it was an artefact of the retired arc math. Full JSON above is the artefact; this is the reading per fixture.

    // ⚠ CONTROL 1 (emptiness) — a rect planted WHOLLY outside the clip must be named unreachable.
    const comfortable = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    const clipC = clipOf(comfortable);
    // ⚠ The plant goes INSIDE `#dsh-ring-layer`, not onto `document.body`: the property under test is that the LAYER's own `overflow: hidden` clips it, and a `position: fixed` node appended to the body bypasses that ancestor entirely — which is a defect in the control, not a fact about the model, caught by this control's own first run.
    const plantOutsideReachable = await page.evaluate(
      ({ x, y }) => {
        const layer = document.getElementById("dsh-ring-layer")!;
        const plant = document.createElement("div");
        plant.setAttribute("data-probe-plant", "");
        plant.setAttribute("data-dsh-handle", "nw");
        plant.style.pointerEvents = "auto";
        plant.style.position = "absolute";
        plant.style.left = `${x - 5}px`;
        plant.style.top = `${y - 5}px`;
        plant.style.width = "10px";
        plant.style.height = "10px";
        plant.style.zIndex = "99999";
        layer.appendChild(plant);
        const layerRect = layer.getBoundingClientRect();
        const hit = document.elementFromPoint(layerRect.left + x, layerRect.top + y) === plant;
        plant.remove();
        return hit;
      },
      { x: clipC.right + 50, y: clipC.top + 50 },
    );
    expect(plantOutsideReachable, "CONTROL 1 — a plant wholly outside the layer is unreachable through it").toBe(false);

    // ⚠ CONTROL 2 (identity) — a plant OVERLAYING an exclusive probe point must flip the identity assertion red, proving the leg can fail before it is trusted to pass.
    const nwProbe = await exclusiveProbe(
      comfortable.handles.find((h) => h.compass === "nw")!,
      comfortable.handles.filter((h) => h.compass !== "nw"),
      clipC,
    );
    expect(nwProbe, "the comfortable fixture's nw handle has an exclusive probe point").not.toBeNull();
    const nwProbeViewport = { x: nwProbe!.x + comfortable.layerOrigin.x, y: nwProbe!.y + comfortable.layerOrigin.y };
    const withPlant = await page.evaluate(
      ({ x, y }) => {
        const plant = document.createElement("div");
        plant.setAttribute("data-probe-plant", "");
        plant.style.position = "fixed";
        plant.style.left = `${x - 3}px`;
        plant.style.top = `${y - 3}px`;
        plant.style.width = "6px";
        plant.style.height = "6px";
        plant.style.zIndex = "99999";
        document.body.appendChild(plant);
        const hit = document.elementFromPoint(x, y) === plant;
        plant.remove();
        return hit;
      },
      nwProbeViewport,
    );
    expect(withPlant, "CONTROL 2 — an overlaying plant intercepts the identity probe (demonstrated RED)").toBe(true);
    const afterRemoval = await page.evaluate(
      ({ x, y }) => {
        const n = document.elementFromPoint(x, y);
        return n === null ? "null" : `${n.tagName.toLowerCase()}[handle=${n.getAttribute("data-dsh-handle")}]`;
      },
      nwProbeViewport,
    );
    expect(afterRemoval, "and the row is green again once the plant is gone").toBe("div[handle=nw]");
  });

  test("G48-4 radius reading — the frame's rounded corner does NOT clip hit-testing (measured 2026-09-03; plan §6.1)", async ({
    page,
  }) => {
    // ⚠ **STANDING MEASUREMENT ROW (plan §6.1).** The owner ruled: `overflow: hidden` on `#dsh-frame` clips descendant HIT-TESTING to its padding-box RECTANGLE, never to the curve `border-radius` paints. Production is untouched (the module never computed this clip; the browser does), and every oracle in this file drops the arc accordingly (`clipOf`/`pointInClip`, above). This row is what stays: the reading itself, asserted rather than merely logged, so that a future browser which starts clipping hit-testing to the curve shows up as THIS row going RED with a name, instead of as an unexplained failure in `G48-4`'s reachable-surface reading elsewhere in this file. RED LEVER: Chromium begins clipping descendant hit-testing to the `border-radius` curve — the first assertion below (a point past the curve, still inside the frame's straight rect, still resolving to `nw`) is what would then fail.
    const fixture = await setFixture(page, { position: "absolute", left: "0px", top: "0px", width: "1px", height: "1px" });
    const paddingRadius = fixture.frameBorderRadiusPx - fixture.frameBorderWidthPx;
    const borderRadius = fixture.frameBorderRadiusPx;
    console.log(
      "G48-4 radius reading — measured frame (#dsh-frame / #dsh-ring-layer, border width, border and padding radius):",
      JSON.stringify({
        frame: fixture.frame,
        ringLayer: fixture.layer,
        borderWidthPx: fixture.frameBorderWidthPx,
        borderRadiusPx: fixture.frameBorderRadiusPx,
        paddingRadiusPx: paddingRadius,
      }),
    );

    // The nw corner's own centre, in LAYER coordinates — the point a curved clip would bend its boundary around. This fixture's box sits at the layer origin, so its `nw` corner square is the one whose rect straddles this corner.
    const cornerCentre = { x: fixture.frame.left + borderRadius, y: fixture.frame.top + borderRadius };
    async function hitAt(x: number, y: number): Promise<string> {
      return page.evaluate(
        ({ vx, vy }) => {
          const n = document.elementFromPoint(vx, vy);
          const oid = n?.getAttribute("data-oid") ?? null;
          const handle = n?.getAttribute("data-dsh-handle") ?? null;
          return `${n === null ? "null" : n.tagName.toLowerCase()}${n && n.id !== "" ? `#${n.id}` : ""}${oid === null ? "" : `[oid=${oid}]`}${handle === null ? "" : `[handle=${handle}]`}`;
        },
        { vx: x + fixture.layerOrigin.x, vy: y + fixture.layerOrigin.y },
      );
    }

    // PAST THE CURVE, INSIDE THE STRAIGHT RECT: `paddingRadius + 1.5` from the corner centre — clear of the padding-box radius by a full measured margin (`G48-4`'s own `MARGIN`) and comfortably inside the frame's own straight rect. Under the measured reading this point IS reachable.
    const insideDistance = paddingRadius + 1.5;
    const insideProbe = { x: cornerCentre.x - insideDistance / Math.SQRT2, y: cornerCentre.y - insideDistance / Math.SQRT2 };
    const insideHit = await hitAt(insideProbe.x, insideProbe.y);
    console.log(
      `G48-4 radius reading — past the curve, ${insideDistance.toFixed(2)} px from the corner centre (padding radius ${paddingRadius} + 1.5 px margin):`,
      insideHit,
    );
    expect(
      insideHit,
      "a point past the padding-box curve but inside the frame's straight rect is still the nw handle — hit-testing is not clipped by the curve",
    ).toContain("[handle=nw]");

    // JUST PAST THE FRAME'S OWN RECTANGULAR CORNER: `borderRadius·√2` is the diagonal distance from the corner centre to the frame's own straight corner — the point where the padding-box RECT clip does fire. A sample past it resolves to `#dsh-stage`, the frame's own ancestor, never `nw`.
    const outsideDistance = borderRadius * Math.SQRT2 + 0.5;
    const outsideProbe = { x: cornerCentre.x - outsideDistance / Math.SQRT2, y: cornerCentre.y - outsideDistance / Math.SQRT2 };
    const outsideHit = await hitAt(outsideProbe.x, outsideProbe.y);
    console.log(
      `G48-4 radius reading — just past the frame's rectangular corner, ${outsideDistance.toFixed(2)} px from the corner centre:`,
      outsideHit,
    );
    expect(
      outsideHit,
      "a point just past the frame's own rectangular corner is not the nw handle — the padding-box rectangle clip does fire there",
    ).not.toContain("[handle=nw]");
  });

  test("G48-9 (browser half) — the contested regions resolve by the canonical order, and a SIZE-only re-anchor there-and-back does not disturb it", async ({
    page,
  }) => {
    // ⚠ Both fixtures are chosen so the contested pocket is at or above the margin `G48-3` measured (floored at 0.5 px): the 220×10 L-residue's arms are 1 px wide and the 6×6 pocket is 2×1 px, so this half ASSERTS on them at the 0.5 px floor and would fall back to a recorded-only reading at a larger measured margin (plan §6).
    const bandVsBand = await setFixture(page, { position: "absolute", left: "220px", top: "180px", width: "220px", height: "10px" });
    const l = bandVsBand.element.left + bandVsBand.layerOrigin.x;
    const t = bandVsBand.element.top + bandVsBand.layerOrigin.y;

    // ⚠ **THE Z-BOUNDARY REACH IS RE-MEASURED AT THIS EXACT BOUNDARY, NOT BORROWED FROM `G48-4`'S DIFFERENT FIXTURE.** `G48-4`'s `MARGIN = 1.5` was measured on `1×100 flush left`'s nw/n boundary, at a different y and a different fixture; this probe crosses the nw-corner-square/n-band boundary on `220×10` at y = t + 2, so the reach is measured HERE, at the exact pixel this row's own probe sits near. Scan x from the nw square's own right edge (l + 4) outward in 0.05 px steps and record the last x at which `elementFromPoint` still answers the higher-z `nw` (z 43) rather than the lower-z `n` (z 42) beneath it.
    const zBoundaryScan = await page.evaluate(
      ({ l, t }) => {
        const rows: { x: number; hit: string | null }[] = [];
        for (let x = l + 3.5; x <= l + 5.5; x += 0.05) {
          const n = document.elementFromPoint(x, t + 2);
          rows.push({ x, hit: n === null ? null : n.getAttribute("data-dsh-handle") });
        }
        return rows;
      },
      { l, t },
    );
    const lastNw = zBoundaryScan.filter((r) => r.hit === "nw").reduce((max, r) => Math.max(max, r.x), Number.NEGATIVE_INFINITY);
    const measuredReach = Number.isFinite(lastNw) ? lastNw - (l + 4) : 0;
    console.log(
      `G48-9 z-boundary reach at the nw/n boundary on 220×10, y = t + 2 (measured 2026-09-03): last x answering "nw" is`,
      Number.isFinite(lastNw) ? lastNw.toFixed(2) : "(none — n answers at every sampled x)",
      `— reach past the nw square's own edge (l + 4):`,
      measuredReach.toFixed(2),
      "px",
    );

    // nw residue (n precedes w): a point at x∈(4,5], y∈[0,4] relative to the box's nw corner.
    const nwProbe = { x: l + 4.75, y: t + 2 };
    // ⚠ **THE PROBE CLEARS THE MEASURED REACH ABOVE BY CONSTRUCTION, NOT BY ASSUMPTION — AND THE TWO MARGINS GOVERN DIFFERENT BOUNDARIES.** `G48-4`'s `MARGIN = 1.5` governs the nw square's TOP edge against `n`'s band on `1×100 flush left`'s own fractional layout (measured ~1 px reach there); THIS boundary is the nw square's RIGHT edge against `n`'s band on `220×10` at y = t + 2, and the measured reach here (2026-09-03) is −0.05 px — effectively zero, not merely "below 0.75". The two boundaries differ because they sit on different fixtures with different sub-pixel layout: `1×100 flush left`'s box is 1 px wide at a fractional layer offset, while `220×10`'s nw/n boundary here lands on this suite's integer devicePixelRatio-1 grid with no fractional remainder to quantise. `G48-4`'s own `G48-3` reading already predicts this — the browser's layout delta was measured at effectively zero on integer layouts and non-zero only where the layout itself is fractional.
    expect(measuredReach, "the measured z-boundary reach at THIS boundary must stay below the probe's own 0.75 px offset").toBeLessThan(0.75);
    const nwHit = await page.evaluate(
      ({ x, y }) => {
        const n = document.elementFromPoint(x, y);
        return n === null ? "null" : n.getAttribute("data-dsh-handle");
      },
      nwProbe,
    );
    expect(nwHit, "nw residue resolves to n (n precedes w)").toBe("n");

    const cornerVsCorner = await setFixture(page, { position: "absolute", left: "220px", top: "180px", width: "6px", height: "6px" });
    const l2 = cornerVsCorner.element.left + cornerVsCorner.layerOrigin.x;
    const t2 = cornerVsCorner.element.top + cornerVsCorner.layerOrigin.y;
    const centreHit = await page.evaluate(
      ({ x, y }) => {
        const n = document.elementFromPoint(x, y);
        return n === null ? "null" : n.getAttribute("data-dsh-handle");
      },
      { x: l2 + 3, y: t2 + 3 },
    );
    expect(centreHit, "the shared [2,4]² square resolves to nw (first in canonical order)").toBe("nw");

    // ⚠ **SIZE-ONLY THERE-AND-BACK, AND THE LIMIT IS STATED RATHER THAN CLAIMED AWAY (plan §6, `G48-9`).** This leg re-anchors twice through a WIDTH/HEIGHT change and requires the contested pocket's winner to survive both passes — a real observable of the conditional-reorder loop's re-anchor path, since `applyHandleStyle` runs and the placement rects move on every pass. ⚠ **It does NOT drive the DOM-order comparison's `desiredOrder !== currentOrder` branch, and nothing in this file can.** `setFixture` writes only inline `width`/`height`; the axis filter (`use-resize-handles.ts# const shadowed = parsed.reasons.filter((r) => r.reason === AXIS_BLOCKED_REASON);`) reads a variant-prefixed sizing className resolved from the selection's source-derived target, not from the DOM's live `class` attribute — confirmed by probe: writing a `md:w-[…]` token directly onto the element's `class` attribute, with and without a forced reselect, left the rendered set at the constant eight both times. Driving the axis filter for real needs a SOURCE write (the chip-editor / sidecar commit path `resize-write.spec.ts` and `resize-handle-shield.spec.ts` use) and an HMR reload, which this file's own header rules out — "the page is mutated (inline styles on one element) and never the repository". So the SET never changes across this leg's two passes, `desiredOrder.length === currentOrder.length` and every element matches on both, and the reorder branch that actually re-appends the host's children is never exercised here. What this leg DOES prove is re-anchor stability under a size-only pass, which is a real and load-bearing property, just a narrower one than its previous title claimed. ⚠ **THE GAP IS CLOSED BY NAME, AT UNIT LEVEL (plan §4.1's history-dependence path).** `className` IS a render input the jsdom rig controls directly, so `packages/descvi/src/react/overlay/__tests__/resize-handle-layer.test.tsx#describe("G48-9 conditional reorder — unit level (the history-dependence path §4.1 names; the e2e leg cannot change the rendered set)", () => {` drives both branches this leg cannot reach: (a) the host's `[data-dsh-handle]` order becomes the reverse priority sequence once a blocked-axis subset regrows to the full eight, and (b) a size-only rerender over an UNCHANGED set never calls `appendChild` on the host at all.
    await setFixture(page, { position: "absolute", left: "220px", top: "180px", width: "40px", height: "220px" });
    const back = await setFixture(page, { position: "absolute", left: "220px", top: "180px", width: "220px", height: "10px" });
    const lBack = back.element.left + back.layerOrigin.x;
    const tBack = back.element.top + back.layerOrigin.y;
    const nwHitBack = await page.evaluate(
      ({ x, y }) => {
        const n = document.elementFromPoint(x, y);
        return n === null ? "null" : n.getAttribute("data-dsh-handle");
      },
      { x: lBack + 4.75, y: tBack + 2 },
    );
    expect(nwHitBack, "there-and-back: the nw residue still resolves to n").toBe("n");
  });

  test("G42-7 Universe B — everything hittable under the ring layer is a marked handle discharging its DECLARED KIND", async ({
    page,
  }) => {
    // ⚠ **RENAMED AT S46-2 BECAUSE THE OLD TITLE WAS FALSE, AND A FALSE TITLE ON A GREEN ROW IS WORSE
    // THAN A BROKEN CITATION.** It read *"…is a marked, glyph-bearing handle"*. From this commit a
    // resize handle carries no glyph by ruling, so the title described a property the row no longer
    // asserts and could not assert. The citation it breaks is re-pointed in the same commit.
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });

    // ⚠ THE COUNT IS SCOPED TO THIS PHASE'S OWN FURNITURE (S44-3 acceptance 12) — §3.12's derived expectation governs the resize handles, and phase-44's spacing affordances are a second family under the same layer with their own derived count in `e2e/spacing-gesture.spec.ts`. RED-when, unchanged: an unadmitted ninth handle, or one of the eight rendered non-operable.
    expect(scene.operable.filter((n) => n.family === "handle").length).toBe(8);
    // …and NOTHING operable escapes both furniture layers. This is the half that keeps the scoping above from being a hole: a node that opted back in outside either container is named here rather than skipped.
    expect(scene.operable.filter((n) => n.family === "other")).toEqual([]);
    // The layer-wide claims stay layer-wide, and DELIBERATELY so: "everything hittable under the ring layer is a marked affordance that discharges its own declared obligation" is true of both families, and phase-44 must not be able to break it without a phase-42 row seeing it.
    //
    // ⚠ **THE THIRD LEG IS AMENDED BY C46-1 AT S46-2 AND IT IS AMENDED RATHER THAN DROPPED — WHICH IS THE WHOLE TEST OF WHETHER THE AMENDMENT WAS HONEST (ralplan §2.2's assertion 2).** It read `expect(node.hasGlyphDescendant).toBe(true)` — layer-wide, unconditional. That claim is FALSE from this commit: a resize handle declares `cursor` and offers no mark, by ruling. Replacing it with nothing would leave the universe asserting only that a node is marked, which is the silent widening §6(1) calls drift and pre-mortem 3's exact mechanism. So the leg becomes the DECLARED KIND's own obligation, dispatched per node: a `glyph`/`glyph-conditional` node still owes the descendant, and a `cursor` node owes clause 4's positive obligation instead. Every operable node still owes something, and no node owes less than it did — a `cursor` node's obligation can fail on four distinct mutations where the old one could only fail on a missing descendant.
    for (const node of scene.operable) {
      expect(node.hasHandleAttr, `${node.descriptor} carries data-dsh-handle`).toBe(true);
      expect(node.hasGlyphControlAttr, `${node.descriptor} carries data-v3-glyph-control`).toBe(true);
      if (node.glyphKind === "cursor") {
        // ⚠ HAND-WRITTEN, NEVER `HANDLE_CURSOR` — this file's header states why its oracles are deliberate second implementations, and ralplan RR-3 names the specific hole a read of the production table would leave: gate and implementation would move together on a mutation of it.
        expect(CURSOR_BY_COMPASS[node.handleAttr ?? ""], `${node.descriptor} declares cursor for its own compass`).toBe(node.cursor);
        expect(node.hit.width > 0 && node.hit.height > 0, `${node.descriptor} declares cursor over a non-zero hit box`).toBe(true);
      } else {
        expect(node.hasGlyphDescendant, `${node.descriptor} declares ${node.glyphKind} and has an svg/[data-glyph] descendant`).toBe(true);
      }
    }
    // Glyph descendants are non-hittable BY RULE (§3.10) — which is what keeps this universe equal
    // to the set of hit-target ROOTS instead of swelling to every `<path>` inside them.
    expect(scene.operable.every((n) => !n.descriptor.startsWith("svg") && !n.descriptor.startsWith("path"))).toBe(true);

    // CONTROL 1, positive: an UNMARKED hittable node must be NAMED by this universe. Without it a
    // scan that selected nothing at all would read as a clean pass.
    const withPlant = await page.evaluate(() => {
      const plant = document.createElement("div");
      plant.setAttribute("data-probe-plant", "");
      plant.style.pointerEvents = "auto";
      plant.style.position = "absolute";
      document.getElementById("dsh-ring-layer")!.appendChild(plant);
      return Array.from(document.getElementById("dsh-ring-layer")!.querySelectorAll<HTMLElement>("*"))
        .filter((n) => getComputedStyle(n).pointerEvents !== "none")
        .filter((n) => !n.hasAttribute("data-dsh-handle")).length;
    });
    expect(withPlant).toBe(1);

    // CONTROL 2, mandatory: a CLASS-ONLY `pointer-events-none` node must be classified NON-operable
    // here. In jsdom it reads `auto` and this universe would go RED against a correct
    // implementation; a real browser has the real cascade, and this is the assertion that proves
    // this run is reading it.
    const classOnlyOperable = await page.evaluate(() => {
      const plant = document.createElement("div");
      plant.setAttribute("data-probe-plant", "");
      plant.className = "pointer-events-none";
      document.getElementById("dsh-ring-layer")!.appendChild(plant);
      return getComputedStyle(plant).pointerEvents !== "none";
    });
    expect(classOnlyOperable).toBe(false);
  });

  test("G46-1 — the COMPLETENESS half's own mutant: an operable, handle-marked node carrying NO marker is NAMED", async ({
    page,
  }) => {
    // ⚠ **CONTROL 1 IN THE ROW ABOVE IS NOT THIS MUTANT, AND THE DIFFERENCE IS THE WHOLE ROW.** CONTROL 1
    // filters on the ABSENCE of `data-dsh-handle` and runs after the assertion loop: it proves the scan's
    // COLLECTION works — that a planted operable node is seen at all — and it can never make the MARKER leg
    // fire, because the shape it plants is caught by the handle leg first. The completeness half of C9 is the
    // half that catches the hazard C9 exists for: a working, operable affordance nobody marked. Under C46-1
    // that half is unchanged and it is still the half that matters, so it owes a mutant of its own — one that
    // carries the shield's concession marker and lacks `data-v3-glyph-control`, which is exactly the shape a
    // restyle can ship by accident once handles stop being glyph-bearing.
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    expect(scene.operable.filter((n) => !n.hasGlyphControlAttr)).toEqual([]);

    const namedByCompleteness = await page.evaluate(() => {
      const layer = document.getElementById("dsh-ring-layer")!;
      const plant = document.createElement("div");
      plant.setAttribute("data-probe-plant", "");
      plant.setAttribute("data-dsh-handle", "nw");
      plant.style.pointerEvents = "auto";
      plant.style.position = "absolute";
      layer.appendChild(plant);
      const offenders = Array.from(layer.querySelectorAll<HTMLElement>("*"))
        .filter((n) => getComputedStyle(n).pointerEvents !== "none")
        .filter((n) => !n.hasAttribute("data-v3-glyph-control"))
        .map((n) => `${n.tagName.toLowerCase()}[handle=${n.getAttribute("data-dsh-handle")}]`);
      plant.remove();
      return offenders;
    });
    expect(namedByCompleteness).toEqual(["div[handle=nw]"]);

    // …and the layer is clean again once the plant is gone, so the reading above was the plant's and not a
    // standing violation this row happened to walk into.
    const afterRemoval = await readScene(page);
    expect(afterRemoval.operable.filter((n) => !n.hasGlyphControlAttr)).toEqual([]);
  });

  test("G46-2 / G46-3 — every marked node under the ring layer declares a kind, and a `glyph` declaration carries a RENDERED mark", async ({
    page,
  }) => {
    // C46-1 (ralplan-phase-46 §3.1 clause 2). ⚠ **THE CLOSED SET IS WRITTEN OUT HERE BY HAND**, never imported
    // from the production constants: this file's header states why its oracles are deliberate second
    // implementations, and a fourth kind added to production would ship green through an imported set.
    const kinds = ["glyph", "glyph-conditional", "cursor"];
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    expect(scene.operable.length, "the population is not empty").toBeGreaterThan(0);
    for (const node of scene.operable) {
      expect(kinds, `${node.descriptor} declares a kind from the closed set`).toContain(node.glyphKind);
      // G46-3's `glyph` arm. The `glyph-conditional` arm's population is the SPACING family and its own
      // mutant lives in `e2e/spacing-gesture.spec.ts`, which is where that family's fixtures are.
      if (node.glyphKind === "glyph") {
        expect(node.hasGlyphDescendant, `${node.descriptor} declares glyph and has a mark`).toBe(true);
        expect(node.markHidden, `${node.descriptor} declares glyph and its mark is painted`).toBe(false);
      }
    }
    // ⚠ **S46-2's FLIP, WHICH IS THIS ASSERTION READ FROM THE OTHER SIDE.** Until this commit the row here
    // required eight `glyph` declarations, because §3.1's ordering clause makes the mechanism land where no
    // pixel moves; this is the commit that ordering existed for, so the expectation flips with the value it
    // was guarding. ⚠ The `glyph` ARM above is now exercised only by the planted mutant below — no resize
    // handle declares `glyph` any more and the spacing family declares `glyph-conditional` — so a green from
    // that arm on the real population would be vacuous, and the plant is what keeps it from being.
    expect(scene.operable.filter((n) => n.family === "handle").map((n) => n.glyphKind)).toEqual(
      Array.from({ length: 8 }, () => "cursor"),
    );

    // THE THREE MUTANTS, planted and measured in one evaluate so the row leaves nothing behind. Each is
    // otherwise well-formed, so a naming can only be the leg it breaks.
    const named = await page.evaluate(() => {
      const layer = document.getElementById("dsh-ring-layer")!;
      const kindsInPage = ["glyph", "glyph-conditional", "cursor"];
      const plant = (patch: (n: HTMLElement) => void): HTMLElement => {
        const n = document.createElement("div");
        n.setAttribute("data-probe-plant", "");
        n.setAttribute("data-dsh-handle", "nw");
        n.setAttribute("data-v3-glyph-control", "glyph");
        n.style.pointerEvents = "auto";
        n.style.position = "absolute";
        n.innerHTML = '<svg data-glyph="probe" width="8" height="8"></svg>';
        patch(n);
        layer.appendChild(n);
        return n;
      };
      const read = () =>
        Array.from(layer.querySelectorAll<HTMLElement>("*"))
          .filter((n) => getComputedStyle(n).pointerEvents !== "none")
          .filter((n) => n.hasAttribute("data-v3-glyph-control"))
          .filter((n) => {
            const kind = n.getAttribute("data-v3-glyph-control");
            if (!kindsInPage.includes(kind ?? "")) return true;
            if (kind !== "glyph") return false;
            const mark = n.querySelector("svg, [data-glyph]");
            return mark === null || getComputedStyle(mark).display === "none";
          }).length;

      const out: Record<string, number> = {};
      // (1) the marker written with the EMPTY value — §5's own RED-when for G46-2.
      let victim = plant((n) => n.setAttribute("data-v3-glyph-control", ""));
      out.emptyValue = read();
      victim.remove();
      // (2) a FOURTH kind — the set is closed, not merely non-empty.
      victim = plant((n) => n.setAttribute("data-v3-glyph-control", "cursor-ish"));
      out.fourthKind = read();
      victim.remove();
      // (3) `glyph` declared over a mark that is present but NOT painted — the §2.12 escape hatch, refused
      // for the UNCONDITIONAL kind. This is the leg that stops "keep the descendant, set display:none" from
      // buying a green, which is the whole reason C46-1 beats hiding the glyph rather than ignoring it.
      victim = plant((n) => {
        (n.firstElementChild as SVGElement).style.display = "none";
      });
      out.hiddenMark = read();
      victim.remove();
      out.afterRemoval = read();
      return out;
    });
    expect(named.emptyValue, "a marker with an empty value is named").toBe(1);
    expect(named.fourthKind, "a fourth kind is named").toBe(1);
    expect(named.hiddenMark, "a `glyph` declaration over an unpainted mark is named").toBe(1);
    expect(named.afterRemoval, "and the layer is clean once the plants are gone").toBe(0);
  });

  test("G46-4 — the `cursor` arm in a REAL browser: the own-compass leg and the non-zero hit box, both shown RED", async ({
    page,
  }) => {
    // ⚠ **THIS ROW REPLACES G46-11's S46-1 DEMONSTRATION, AND THE SWAP IS THE POINT OF BOTH.** The row that
    // stood here removed a real corner's mark and watched `boundsViolations`' glyph leg name it — the leg
    // this commit deletes, exercised one commit before it went. It goes WITH that leg: a demonstration of a
    // deleted assertion is not a gate, it is a fossil. What arrives in its place is the obligation the same
    // commit puts on the same nodes, and its population is non-empty for the first time here — in S46-1
    // every handle declared `glyph`, so this row would have had nothing to read.
    const scene = await setFixture(page, { position: "absolute", left: "200px", top: "180px", width: "300px", height: "120px" });
    expect(scene.handles).toHaveLength(8);

    // The shipped population, against the hand-written set. COMPUTED cursors, which is the reading only a
    // browser has: jsdom's half of this gate can only see the inline value.
    for (const h of scene.handles) {
      expect(h.cursor, `${h.compass} carries the ruled cursor for its own compass`).toBe(CURSOR_BY_COMPASS[h.compass]);
      expect(h.rect.width > 0 && h.rect.height > 0, `${h.compass} has a non-zero hit box`).toBe(true);
    }
    // …and NO handle carries a mark any more, which is the fact that made the retired leg subjectless. It is
    // asserted rather than assumed, because "the leg has no subject" is the justification for deleting it.
    expect(scene.handles.filter((h) => h.glyph !== null), "no resize handle builds a mark after S46-2").toEqual([]);

    // ── THE MUTANTS, on the shipped nodes. Each is applied and read back in one evaluate, so the row can
    // never compare two reads of a layer that moved between them.
    const named = await page.evaluate((expected: Record<string, string>) => {
      const layer = document.getElementById("dsh-handle-layer")!;
      const roots = Array.from(layer.querySelectorAll<HTMLElement>("[data-dsh-handle]"));
      const violations = () =>
        roots
          .filter((n) => n.getAttribute("data-v3-glyph-control") === "cursor")
          .filter((n) => {
            const b = n.getBoundingClientRect();
            const want = expected[n.getAttribute("data-dsh-handle") ?? ""];
            return getComputedStyle(n).cursor !== want || b.width <= 0 || b.height <= 0;
          })
          .map((n) => `${n.getAttribute("data-dsh-handle")}:${getComputedStyle(n).cursor}`);

      const nw = roots.find((n) => n.getAttribute("data-dsh-handle") === "nw")!;
      const ne = roots.find((n) => n.getAttribute("data-dsh-handle") === "ne")!;
      const out: Record<string, string[]> = { clean: violations() };

      // (1) `default` on a node that declares `cursor` — §5's first named RED-when.
      nw.style.cursor = "default";
      out.defaultCursor = violations();
      nw.style.cursor = "nwse-resize";

      // (2) THE LOOKUP-KEY SWAP, synthesized: `nw`↔`ne`, which the plan names and which is NOT one of the
      // four value-identical swaps. Exchanging the two rendered cursors is the DOM that swapped key emits.
      // ⚠ A MEMBERSHIP check cannot see this — both values are in the ruled table — which is exactly why
      // clause 4 is about the LOOKUP KEY and not about the table.
      nw.style.cursor = "nesw-resize";
      ne.style.cursor = "nwse-resize";
      out.compassSwap = violations();
      // ⚠ THE SAME SWAPPED DOM, READ BY CLAUSE 3's MEMBERSHIP PREDICATE — the checker that asks only
      // whether a cursor is in the ruled table at all. It is RUN here rather than reasoned about,
      // because "membership cannot see a compass swap" is the claim that justifies clause 4 existing,
      // and a claim stated instead of measured is what this repo keeps getting wrong.
      const RULED = ["ew-resize", "ns-resize", "nwse-resize", "nesw-resize"];
      out.membershipOnSwap = roots
        .filter((n) => n.getAttribute("data-v3-glyph-control") === "cursor")
        .filter((n) => !RULED.includes(getComputedStyle(n).cursor))
        .map((n) => `${n.getAttribute("data-dsh-handle")}:${getComputedStyle(n).cursor}`);
      nw.style.cursor = "nwse-resize";
      ne.style.cursor = "nesw-resize";

      // (3) a COLLAPSED hit box on a node still wearing the right cursor.
      const keptW = nw.style.width;
      nw.style.width = "0px";
      out.zeroBox = violations();
      nw.style.width = keptW;

      out.afterRestore = violations();
      return out;
    }, CURSOR_BY_COMPASS);

    expect(named.clean, "the shipped eight are clean before any mutation").toEqual([]);
    expect(named.defaultCursor).toEqual(["nw:default"]);
    expect([...(named.compassSwap ?? [])].sort(), "BOTH swapped nodes are named").toEqual([
      "ne:nwse-resize",
      "nw:nesw-resize",
    ]);
    // ⚠ …AND THE MEASUREMENT THAT SAYS WHAT CLAUSE 4 BUYS: on that same swapped DOM the MEMBERSHIP
    // predicate names nobody. Both swapped values are in the ruled table, so a gate written as
    // "carries a cursor from the table" passes a handle wearing another handle's cursor. That gap is
    // why the obligation is keyed to the node's OWN compass, and this is the reading rather than the
    // argument for it.
    expect(named.membershipOnSwap, "clause 3's membership check is blind to the swap clause 4 catches").toEqual([]);
    expect(named.zeroBox).toEqual(["nw:nwse-resize"]);
    expect(named.afterRestore, "and the layer is clean again once every mutation is undone").toEqual([]);
  });

  test("R42-D3 — a refusal near the layer bottom flips above its subject instead of being cut by the clip", async ({
    page,
  }) => {
    // THE COMPANION TO THE jsdom ROWS, and the half only a browser can hold: the marker's height here
    // is whatever its bilingual text actually wraps to at this viewport, not a number a test chose.
    // The designer measured the shipped defect on exactly this shape — a 362 px layer with the
    // subject at its bottom put 16 px of the marker outside `overflow: hidden` (the whole English
    // half) and painted the rest on top of the element it was explaining.
    await page.locator(`[data-oid="${REFUSED_OID}"]`).click();
    await expect(page.locator("#dsh-ring-refusal-marker")).toHaveCount(1);

    const layerHeight = (await readScene(page, REFUSED_OID)).layer.height;
    // Low enough that the SHIPPED rule's clamp would land inside the subject's own box.
    const scene = await setFixture(
      page,
      { position: "absolute", left: "180px", top: `${Math.round(layerHeight - 34)}px`, width: "160px", height: "30px" },
      REFUSED_OID,
    );

    expect(scene.markerCount).toBe(1);
    const m = scene.marker!;
    const subjectTop = scene.element.top;
    const subjectBottom = scene.element.top + scene.element.height;
    expect({
      // Clause 2 — nothing is painted outside the layer that clips it. The English half survives.
      insideClip: m.top >= -0.5 && m.top + m.height <= scene.layer.height + 0.5,
      // Clause 3 — the readout never lands on its own subject.
      clearsSubject: m.top + m.height <= subjectTop + 0.5 || m.top >= subjectBottom - 0.5,
      // Clause 2, positively: it FLIPPED above rather than clamping down onto the frame edge.
      flippedAbove: m.top + m.height <= subjectTop + 0.5,
      // And the whole message is still there — a marker emptied to nothing would satisfy the box
      // assertions above while having refused nothing. ⚠ It is a DEGENERACY guard, not a truncation
      // detector: `innerText` reads the DOM, so it stays complete even when the clip eats half the
      // painted node. The clip assertion above is the half that sees that, and it is measured RED.
      hasBothHalves: (await page.locator("#dsh-ring-refusal-marker").innerText()).includes("not editable in v1"),
    }).toEqual({ insideClip: true, clearsSubject: true, flippedAbove: true, hasBothHalves: true });
  });

  test("acceptance 7 — the ring layer itself is unchanged", async ({ page }) => {
    const shape = await page.evaluate(() => {
      const layer = document.getElementById("dsh-ring-layer")!;
      return {
        isLastChild: layer.parentElement?.lastElementChild === layer,
        parentId: layer.parentElement?.id ?? null,
        tokens: Array.from(layer.classList).sort(),
        ariaHidden: layer.getAttribute("aria-hidden"),
      };
    });
    expect(shape.parentId).toBe("dsh-frame");
    expect(shape.isLastChild).toBe(true);
    expect(shape.tokens).toEqual(["absolute", "inset-0", "overflow-hidden", "pointer-events-none", "z-40"]);
    // The reason acceptance 3's scan is DOM-based: an AT scan of an aria-hidden layer is vacuous.
    expect(shape.ariaHidden).toBe("true");
  });

  test("a non-writable target renders zero handles and ONE marker carrying its reason", async ({ page }) => {
    // `hakgqo` is the className-less button on this screen — the `no-class` refusal, resolved by the
    // real edit map rather than by an injected target.
    await page.locator('[data-oid="hakgqo"]').click();
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    await expect(page.locator("#dsh-handle-layer [data-dsh-handle]")).toHaveCount(0);
    const marker = page.locator("#dsh-ring-refusal-marker");
    await expect(marker).toHaveCount(1);
    await expect(marker).toHaveAttribute("data-reason", "no-class");
    await expect(marker).not.toHaveText("");
    const markerShape = await marker.evaluate((n) => ({
      pointerEvents: getComputedStyle(n).pointerEvents,
      handleAttr: n.hasAttribute("data-dsh-handle"),
      glyphAttr: n.hasAttribute("data-v3-glyph-control"),
      insideLayer: document.getElementById("dsh-ring-layer")!.contains(n),
    }));
    expect(markerShape).toEqual({
      pointerEvents: "none",
      handleAttr: false,
      glyphAttr: false,
      insideLayer: true,
    });
  });
});
