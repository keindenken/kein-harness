import { test, expect, type Page } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

/**
 * resize-write.spec.ts — THE WRITE in a real browser (phase-42 S42-3; G42-3, G42-1(d), G42-6b).
 *
 * WHY A BROWSER IS REQUIRED FOR THIS SET, stated because the jsdom suite beside it asserts the same acceptance numbers.
 *  1. **`POST /edit` arithmetic against a real sidecar.** The jsdom rows count calls into a stub bridge; here the count is of real requests, and the write really splices `src/app/lab/tests/style-edit/page.tsx` on disk.
 *  2. **A MEASURED box.** §3.10's ring-truth rule is about the difference between the size the machine REQUESTS and the size the element RENDERS — a difference only a layout engine can produce. jsdom has no layout, so the whole subject of G42-6b is unaskable there.
 *  3. **Pointer capture and its retargeting.** The mid-drag rows read the ring "while capture is still held", which jsdom cannot express.
 *
 * THE PAGE IS REALLY EDITED, so every row that commits restores `src/app/lab/tests/style-edit/page.tsx` by bytes and RE-DERIVES `.descvi/` through the extractor (C-R1) — the restore is self-verifying, because the check exits non-zero if the regenerated manifest differs from HEAD.
 * Rows that only preview mutate nothing on disk and say so.
 *
 * ⚠ **SCOPED TO `#dsh-handle-layer` IN PHASE-44 S44-3, AND THE SCOPING IS A CORRECTION RATHER THAN TIDYING.**
 * `data-dsh-handle` is the SHIELD's marker, not the resize family's, and phase-44 §3.9 rules that the spacing
 * affordances and the numeric popup carry it too — it is the shield's one concession and all three classes need
 * it. Measured on this file's own subject, an unscoped `[data-dsh-handle]` count therefore reports seventeen
 * where eight is the claim. What this file is about is phase-42's furniture, so its selectors name that
 * furniture's own container; `e2e/spacing-gesture.spec.ts` carries the other family's counts.
 */

// `playwright test` always runs from the repo root (playwright.config.ts's dir).
const repoRoot = path.resolve(process.cwd());
const pageFixture = path.join(repoRoot, "src", "app", "lab", "tests", "style-edit", "page.tsx");

/**
 * The "simple static classes" card. Its layout parent is a `flex flex-col` column, so a width write is a CROSS-axis Fixed write — allowed, and it moves the card's border box by hundreds of pixels rather than by a rounding's worth.
 */
const SUBJECT_OID = "v002k2";
/** The column that holds it — the node this spec re-styles to arrange the flow-repositioning fixture. */
const PARENT_OID = "seroot";

/** §3.10's ring-truth tolerance, stated once. Sub-1 px is the rounding; at or above it is the implementation. */
const RING_TOLERANCE = 1;

interface Geometry {
  box: { left: number; top: number; width: number; height: number } | null;
  ring: { left: number; top: number; width: number; height: number } | null;
  /** Every rendered handle's compass, so the degradation rows can read the SET rather than a count. */
  handles: string[];
  className: string | null;
}

async function readGeometry(page: Page): Promise<Geometry> {
  return page.evaluate((oid) => {
    const rect = (el: Element | null): { left: number; top: number; width: number; height: number } | null => {
      if (el === null) return null;
      const r = el.getBoundingClientRect();
      return { left: r.left, top: r.top, width: r.width, height: r.height };
    };
    const subject = document.querySelector(`[data-oid="${oid}"]`);
    return {
      box: rect(subject),
      ring: rect(document.querySelector("#dsh-selection-ring")),
      handles: Array.from(document.querySelectorAll("#dsh-handle-layer [data-dsh-handle]")).map((n) => n.getAttribute("data-dsh-handle") ?? "?"),
      className: subject?.getAttribute("class") ?? null,
    };
  }, SUBJECT_OID);
}

async function selectSubject(page: Page): Promise<void> {
  await page.goto("/lab/tests/style-edit");
  await expect(page.locator("#dsh-ring-layer")).toBeAttached();
  // A POSITIONED click into the card's own padding: a centre click lands on a child that carries its
  // own `data-oid`, and the canvas resolves the selection to THAT.
  await page.locator(`[data-oid="${SUBJECT_OID}"]`).click({ position: { x: 6, y: 6 } });
  await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  await expect(page.locator("#dsh-handle-layer [data-dsh-handle]")).toHaveCount(8);
}

/** The centre of one handle's hit target, in page coordinates — where a real press lands. */
async function handleCentre(page: Page, compass: string): Promise<{ x: number; y: number }> {
  const box = await page.locator(`[data-dsh-handle="${compass}"]`).boundingBox();
  expect(box, `the ${compass} handle is rendered`).not.toBeNull();
  return { x: box!.x + box!.width / 2, y: box!.y + box!.height / 2 };
}

/** Counts every `POST /edit` the page issues from the moment it is installed. */
function countPosts(page: Page): { count: () => number; bodies: string[] } {
  const bodies: string[] = [];
  page.on("request", (req) => {
    if (req.method() !== "POST" || !req.url().endsWith("/edit")) return;
    bodies.push(req.postData() ?? "");
  });
  return { count: () => bodies.length, bodies };
}

test.describe.serial("G42-3 / G42-1(d) / G42-6b — the resize WRITE (S42-3)", () => {
  test.setTimeout(90_000);
  let originalPage: Buffer | undefined;

  test.beforeEach(() => {
    originalPage = fs.readFileSync(pageFixture);
  });

  test.afterEach(() => {
    // The SAFETY NET, not the primary restore: every committing row puts the file back itself, so
    // this only fires when a row failed BETWEEN its POST and its own restore. Keyed on the snapshot
    // rather than on a project name — no snapshot means the `beforeEach` never ran, which means
    // nothing was mutated to put back, true whether the test was skipped, filtered out, or the
    // `beforeEach` itself threw.
    if (originalPage === undefined) return;
    const snapshot = originalPage;
    originalPage = undefined;
    if (fs.readFileSync(pageFixture).equals(snapshot)) return;
    fs.writeFileSync(pageFixture, snapshot);
    // `.descvi/` is put back by RE-DERIVING it, not by restoring bytes — invariant 1's requirement of
    // a derived artifact, and what makes this restore self-verifying.
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G42-3 — an N-move drag on the E handle produces EXACTLY ONE POST /edit", async ({ page }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);
    const before = await readGeometry(page);
    expect(before.box).not.toBeNull();

    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    // TWELVE moves, so a commit that lived in the move handler would count twelve.
    for (let i = 1; i <= 12; i += 1) await page.mouse.move(start.x + i * 6, start.y);
    await page.mouse.up();

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    // Give any SECOND post a chance to appear before the count is read — a count taken immediately
    // after the first response would report 1 against an implementation that posts per move.
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the gesture's own write").toBe(1);

    // …and it really landed: the source now carries a width token the card did not have.
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after).not.toBe(original.toString("utf8"));
    expect(after).toMatch(/w-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G42-3 — a ZERO-DELTA press-and-release produces ZERO POSTs and a byte-identical page.tsx", async ({ page }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);
    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    await page.mouse.up();
    await page.waitForTimeout(700);
    expect(posts.count()).toBe(0);
    expect(fs.readFileSync(pageFixture).equals(original), "page.tsx is byte-identical").toBe(true);
    // …and the selection survived the press, so the row is not green because the gesture never began.
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  });

  test("G42-1(d) — the pointerup RECOMPUTES: a release at a coordinate no pointermove visited commits ITS delta", async ({ page }) => {
    /**
     * ⚠ THE STIMULUS IS THE WHOLE ROW, and §3.11's own theorem is why.
     * Every preview is composed from the armed baseline and the TOTAL delta, so "commit the controller's last preview" and "recompute through `commitResize`" produce the SAME string whenever the release lands where the last move landed — which is exactly what a coordinate-less `mouse.up()` does.
     * So the release below is dispatched at a coordinate the last `pointermove` did not visit, and the two implementations then differ by exactly that delta.
     * ⚠ RED-when: let pointerup commit the controller's last preview instead of re-running `commitResize` → the committed width is the last MOVE's, and this row fires.
     */
    const original = fs.readFileSync(pageFixture);
    await selectSubject(page);
    const before = await readGeometry(page);
    const startWidth = Math.round(before.box!.width);

    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    await page.mouse.move(start.x + 40, start.y);
    await page.mouse.move(start.x + 60, start.y);
    // The release: 30 px BEYOND the last move, a coordinate no move visited.
    await page.mouse.move(start.x + 90, start.y);
    await page.mouse.up();

    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(500);
    const after = fs.readFileSync(pageFixture, "utf8");
    const written = /w-\[(\d+)px\]/.exec(after);
    expect(written, "a width token landed").not.toBeNull();
    const committed = Number(written![1]);
    // The RELEASE's delta, not the last move's. The two differ by 30 px, far outside any rounding.
    expect(Math.abs(committed - (startWidth + 90))).toBeLessThanOrEqual(2);
    expect(Math.abs(committed - (startWidth + 60))).toBeGreaterThan(2);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G42-6b — MID-DRAG the ring tracks the element's MEASURED box on a MIN-CONTENT-constrained subject", async ({ page }) => {
    /**
     * ⚠ THE ONE ROW `startBox + delta` CANNOT PASS, and nothing else in this phase can see it.
     * V3-C5 explicitly ACCEPTS the browser's min-content floor, so a subject whose content refuses to shrink renders WIDER than the machine requested. An implementation that draws the ring from the requested size passes every pure-geometry row, keeps siblings reflowing and settles correctly — and separates from the element for the whole drag.
     * RED-when: draw the ring from `startBox + delta`.
     *
     * ⚠ NOTHING IS COMMITTED HERE. The gesture is cancelled with Escape before release, so this row writes no source and needs no restore.
     */
    await selectSubject(page);
    // `min-width: min-content` on the card: its own text is what floors the used width.
    await page.evaluate((oid) => {
      const el = document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)!;
      el.style.minWidth = "min-content";
      el.style.whiteSpace = "nowrap";
      window.dispatchEvent(new Event("resize"));
    }, SUBJECT_OID);
    await page.waitForTimeout(300);

    const before = await readGeometry(page);
    const start = await handleCentre(page, "w");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();

    const samples: { requested: number; box: number; ring: number }[] = [];
    // A WEST drag to the right SHRINKS the box (§3.10: width −dx), so these moves walk it into the floor.
    for (let i = 1; i <= 7; i += 1) {
      await page.mouse.move(start.x + i * 60, start.y);
      const g = await readGeometry(page);
      samples.push({ requested: before.box!.width - i * 60, box: g.box!.width, ring: g.ring!.width });
      // The bounds agree WHILE CAPTURE IS STILL HELD — the whole point of reading mid-drag.
      expect(Math.abs(g.ring!.width - g.box!.width), `frame ${i}: ring vs box width`).toBeLessThan(RING_TOLERANCE);
      expect(Math.abs(g.ring!.left - g.box!.left), `frame ${i}: ring vs box left`).toBeLessThan(RING_TOLERANCE);
    }
    await page.keyboard.press("Escape");

    // ⚠ THE PRECONDITION, ASSERTED RATHER THAN HOPED: at least one sampled frame must have the
    // element REFUSING the requested width, or the seven agreements above are seven frames in which
    // requested and rendered coincided and a `startBox + delta` ring would have passed them all.
    const constrained = samples.filter((s) => s.box - s.requested > 2 * RING_TOLERANCE);
    expect(constrained.length, "the min-content floor really engaged").toBeGreaterThanOrEqual(1);
  });

  test("G42-6b — MID-DRAG the ring tracks a FLOW-REPOSITIONING subject, whose left edge moves as it grows", async ({ page }) => {
    /**
     * The second subject §3.10 names. Here the box's POSITION moves for a reason no delta predicts:
     * the column is centred, so growing the card's width shifts its left edge by half the growth.
     * A ring drawn from the start rect's left keeps the old position and separates immediately.
     *
     * ⚠ NOTHING IS COMMITTED HERE either — Escape ends the gesture.
     */
    await selectSubject(page);
    await page.evaluate((oid) => {
      const parent = document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)!;
      parent.style.alignItems = "center";
      parent.style.maxWidth = "none";
      window.dispatchEvent(new Event("resize"));
    }, PARENT_OID);
    await page.waitForTimeout(300);

    const before = await readGeometry(page);
    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();

    const lefts: number[] = [];
    for (let i = 1; i <= 6; i += 1) {
      await page.mouse.move(start.x + i * 30, start.y);
      const g = await readGeometry(page);
      lefts.push(g.box!.left);
      expect(Math.abs(g.ring!.left - g.box!.left), `frame ${i}: ring vs box left`).toBeLessThan(RING_TOLERANCE);
      expect(Math.abs(g.ring!.width - g.box!.width), `frame ${i}: ring vs box width`).toBeLessThan(RING_TOLERANCE);
    }
    await page.keyboard.press("Escape");

    // The precondition: the box really REPOSITIONED, so the agreements above are not six frames of a
    // stationary element where a delta-drawn ring would also have been right.
    expect(Math.abs((lefts[lefts.length - 1] ?? 0) - before.box!.left), "the box moved in flow").toBeGreaterThan(2 * RING_TOLERANCE);
  });

  test("G42-6b — DRAG-TO-CLAMP: the furniture stays the CONSTANT EIGHT as the box shrinks, and the gesture stays completable to the 1 px floor", async ({ page }) => {
    /**
     * REPLACED (phase-48 B-Q5, plan §8): this row used to be the fifth shipped statement of the retired admission model — its middle assertion drove the W handle rightwards through five widths and required the set to have SHED handles by the last one, which is the direct negation of `G48-2`. The ported model refuses nothing, so that assertion is permanently false under a correct implementation; REPLACED by the property the new model actually promises: the set is EXACTLY EIGHT at every one of those widths, down to the 1 px floor, while both axes stay writable. That is a stronger statement than the one it replaces, and it is the drag path's own copy of `G48-2`.
     *
     * ⚠ THE CORNER-SURVIVED LEG IS KEPT, and that is a reversal of the disposition it looks like it should take. Neither of `AGENTS.md`'s two deletion reasons applies: corners plainly still render, and "subsumed by the stronger `toBe(8)` replacement" is not one of the two reasons — a deletion argued from subsumption is exactly what the second reason (the assertion could not go RED) exists to refuse. This leg CAN go red on a defect `G48-2`'s own lever hunts (a port that emits bands and no corners), so it stays.
     *
     * ⚠ §3.12 CLAUSE 5's ERRATUM, REWRITTEN RATHER THAN ROUTED (plan §8). It used to record that the non-empty floor was EMERGENT and conditional on the subject being inside the effective clip, and it routed to this row the open question of whether the drag path needs an EXPLICIT floor for a subject scrolled outside that clip. **The ported model moots the ROUTING, not the question.** The floor stops being emergent: eight is now UNCONDITIONAL on the box (plan §1), so there is no "does the drag need a floor" question left to route anywhere — nothing here can ever produce fewer than eight while both axes are writable. What survives, unrouted, is the separate fact §2 states outright: a subject scrolled wholly outside `#dsh-ring-layer` or `#dsh-frame`'s clip renders handles nobody can reach, because the browser's own `overflow: hidden` clips them — that is the clip acting, not a refusal, and it needs no marker on the drag path for the same reason it never did: the gesture is held by pointer capture and begins on a handle the user could already hit, so a live drag can never reach that state from inside it.
     *
     * The COMPLETABLE half is why it is safe regardless: the gesture is held by POINTER CAPTURE on the handle node and every terminal trigger listens on `document`, so how much furniture is rendered does not decide whether the drag can finish. That is asserted below rather than argued.
     */
    const original = fs.readFileSync(pageFixture);
    await selectSubject(page);
    const before = await readGeometry(page);
    expect(before.handles).toHaveLength(8);

    const start = await handleCentre(page, "w");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();

    const sets: string[][] = [];
    // Walk WEST-handle-rightwards, which shrinks the width, well past the card's own extent.
    for (const dx of [100, 300, 500, 700, 900]) {
      await page.mouse.move(start.x + dx, start.y);
      const g = await readGeometry(page);
      sets.push(g.handles);
      // G48-2, on the path this row owns: the model refuses nothing, so the set is the constant eight at every sampled width, not merely non-empty.
      expect(g.handles.length, `at dx=${dx} the rendered set is the constant eight`).toBe(8);
    }
    // …and corners outrank strips at every z-contested pixel, which is the precedence's own signature (KEPT — see the docblock above for why deletion is refused here).
    expect(sets[sets.length - 1]!.some((c) => c.length === 2), "a corner survived").toBe(true);

    // COMPLETABLE: the release lands, the POST goes out, and the source carries the V3-C5 floor.
    await page.mouse.up();
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(500);
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after, "the clamp wrote the 1 px floor through the serializer").toContain("w-[1px]");

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("acceptance 7 (LIVE) — a drag over a DIRTY CHIP DRAFT lands BOTH writes: two attributable POSTs, both tokens on disk", async ({ page }) => {
    /**
     * ⚠ THE ROW THAT CAUGHT A REAL SILENT LOSS, and the jsdom rig could not see it until the rig was made honest.
     * The gesture arms on the chip's own settlement — correctly — and then the HMR that commit causes re-keys the session, and §3.7(c-i)'s reseed guard used to invalidate the gesture before the box ever moved. Result: ONE POST, carrying the chip only, with no error anywhere. Reproduced 9/9 in a real browser.
     * The fix is the CONVERGENT-SELF-RESEED discriminator: a reseed adopting the very string the gesture armed on cannot make that baseline stale, so it no longer kills the gesture. Every reseed that MOVES `confirmed` still does.
     * RED-when: drop that clause and this row reports one POST with the resize token absent from disk.
     *
     * ⚠ THE GESTURE IS DELIBERATELY LONG. A press-move-release that finishes before settlement resolves emits `none` from every move (the machine is `armed-pending`), which is S42-2b acceptance 6's ruled unsettled-window behaviour and a different case — so the moves below are spaced to outlast the round trip, which is what a human hand does anyway.
     */
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);

    // The chip is STAGED, not committed: Enter adds it to the draft, and the drag's own arming
    // barrier is what commits it. Geometry-neutral on purpose, so the box the drag measures is the
    // box it would have measured without the chip.
    const input = page.getByLabel("className 추가");
    await input.click();
    await input.fill("opacity-50");
    await input.press("Enter");
    await expect(page.getByLabel("opacity-50 삭제")).toBeVisible();
    expect(posts.count(), "the chip is a DRAFT — nothing has posted yet").toBe(0);

    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= 10; i += 1) {
      await page.mouse.move(start.x + i * 8, start.y);
      await page.waitForTimeout(80);
    }
    await page.mouse.up();

    await expect.poll(() => posts.count(), { timeout: 10_000 }).toBe(2);
    await page.waitForTimeout(500);
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after, "the chip landed").toContain("opacity-50");
    expect(after, "…and so did the resize — this is the token the defect dropped").toMatch(/w-\[\d+px\]/);
    // Both on the SAME element, which a pair of counts alone would not establish.
    const card = /data-oid="v002k2"[\s\S]{0,200}?className="([^"]*)"/.exec(after);
    expect(card, "the subject's className is readable").not.toBeNull();
    expect(card![1]).toContain("opacity-50");
    expect(card![1]).toMatch(/w-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("acceptance 12 — double-clicking the E edge handle commits Hug as ONE POST", async ({ page }) => {
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);
    const centre = await handleCentre(page, "e");
    await page.mouse.dblclick(centre.x, centre.y);
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the hug").toBe(1);
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after).toContain("w-fit");
    expect(after, "and no fixed width — a Hug is a mode, not a measurement").not.toMatch(/w-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G42-8 corner row — an SE drag writes BOTH axes, and the committed bytes carry the ruled width-then-height composition", async ({ page }) => {
    /**
     * ⚠ THE ONLY ROW IN `e2e/` THAT DRIVES A CORNER, and the gap it closes was measured rather than
     * assumed: before it, every handle-driving row in this directory pressed an EDGE — `handleCentre`
     * was called with "e" six times and "w" twice across the whole suite, and no compass carrying two
     * axes was ever pressed through the production route. Four of the eight handles were therefore
     * exercised end-to-end by nothing.
     *
     * ⚠ WHAT ONLY A CORNER CAN SHOW, and why the assertion is on the COMMITTED BYTES rather than on
     * geometry. §3.10 rules a corner to be TWO `serializeSizing` calls — WIDTH first, then HEIGHT,
     * the second receiving the first's composed className as its `currentClassName`. Rendered
     * geometry is identical under either order, so a row that reads the box cannot see the ordering
     * at all; the committed STRING is the only surface on which the two-step is visible. Hence the
     * index comparison below: the width token must precede the height token in the literal the
     * sidecar spliced.
     *
     * ⚠ RED-when: compose height before width (the two tokens swap places in the source literal and
     * the ordering assertion fires) — or drop either axis from the corner's write, which the
     * two-token assertions catch first. Both mutations leave every geometry-reading row green.
     */
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);
    const before = await readGeometry(page);
    expect(before.box).not.toBeNull();

    // TWELVE moves on a DIAGONAL, with unequal per-axis steps so a dx/dy swap is as visible as a
    // dropped axis. §3.10's SE row is `+dx, +dy`, rounded once per axis before serialization.
    const start = await handleCentre(page, "se");
    const STEPS = 12;
    const STEP_X = 6;
    const STEP_Y = 4;
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= STEPS; i += 1) await page.mouse.move(start.x + i * STEP_X, start.y + i * STEP_Y);
    await page.mouse.up();

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    // A corner is two serializer calls; if it were also two WRITES this count would read 2.
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the corner gesture, though it composes two axes").toBe(1);

    // Hand-derived from the MEASURED start box, per §3.10's "Math.round to integer px, once, before
    // serialization" — not copied from a previous run.
    const expectedWidth = Math.round(before.box!.width + STEPS * STEP_X);
    const expectedHeight = Math.round(before.box!.height + STEPS * STEP_Y);

    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after, "the corner wrote the width axis").toContain(`w-[${expectedWidth}px]`);
    expect(after, "the corner wrote the height axis").toContain(`h-[${expectedHeight}px]`);
    // THE ORDERING ASSERTION — §3.10's width-then-height composition, read off the committed literal.
    expect(
      after.indexOf(`w-[${expectedWidth}px]`),
      "width is composed FIRST, so its token precedes the height token in the committed className",
    ).toBeLessThan(after.indexOf(`h-[${expectedHeight}px]`));

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G48-9 — a mid-drag probe in a contested region keeps its winner under held capture, and the gesture still commits", async ({
    page,
  }) => {
    /**
     * The leg a real drag can carry that a layer-only file cannot (plan §6, `G48-9`): hold a resize gesture on one handle, probe a CONTESTED region while capture is still held, and require both that the winner is unchanged and that the gesture completes with its write. This is what would catch a reorder firing under a held capture — an unconditional `appendChild` mid-drag would move the node holding `setPointerCapture`, which the machine treats as terminal (plan §4.1).
     */
    const original = fs.readFileSync(pageFixture);
    await selectSubject(page);
    // Size the subject to `220×10` — the band-vs-band L-residue's own fixture (plan §6) — so a real contested pixel exists to probe mid-drag. The `e` handle's drag grows WIDTH only, so the `nw` corner (fixed at the box's top-left) and its residue never move during this gesture.
    await page.evaluate((oid) => {
      const el = document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)!;
      el.removeAttribute("style");
      Object.assign(el.style, { padding: "0px", border: "0px", minWidth: "0px", minHeight: "0px" });
      Object.assign(el.style, {
        position: "absolute",
        left: "220px",
        top: "180px",
        width: "220px",
        height: "10px",
      });
      window.dispatchEvent(new Event("resize"));
    }, SUBJECT_OID);
    await page.waitForTimeout(300);

    const box = (await readGeometry(page)).box!;
    // nw residue: x∈(4,5], y∈[0,4] relative to the box's own nw corner — n precedes w (plan §4.1, `G48-9`'s band-vs-band leg). ⚠ **THE SAME BOUNDARY `e2e/resize-handles.spec.ts`'s `G48-9` browser half MEASURES LIVE, at rest** — the nw square's RIGHT edge against `n`'s band, on the same `220×10` geometry at the same y = t + 2 — where the z-boundary reach was measured at −0.05 px (2026-09-03), effectively zero and well clear of this 0.75 px offset. This test does not re-measure it mid-drag (disturbing a held pointer capture to scan a boundary is its own hazard); it relies on the at-rest reading, on the ground that the compositor's z-priority quantisation at a given pixel does not depend on whether a drag happens to be in progress elsewhere on the page.
    const probe = { x: box.left + 4.75, y: box.top + 2 };

    const start = await handleCentre(page, "e");
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    await page.mouse.move(start.x + 20, start.y);

    const winnerMidDrag = await page.evaluate(
      ({ x, y }) => {
        const n = document.elementFromPoint(x, y);
        return n === null ? null : n.getAttribute("data-dsh-handle");
      },
      probe,
    );
    expect(winnerMidDrag, "the nw residue still resolves to n while capture is held").toBe("n");

    await page.mouse.move(start.x + 40, start.y);
    await page.mouse.up();

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok(), "the gesture completed with its write").toBe(true);
    await page.waitForTimeout(500);
    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after, "the write landed").toMatch(/w-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("G48-5 / EG-2 (browser leg) — a press offset INWARD along the diagonal from the SE vertex, within the aim radius, still commits BOTH axes", async ({
    page,
  }) => {
    /**
     * Criterion ②'s statement in the one register that can falsify it for a user (plan §6, `G48-5`'s browser leg): the SE handle is pressed at a point 2 px INWARD along the box's diagonal from the box's own SE VERTEX (§4.1) — well within the aim radius — and the same two-axis write must still commit. ⚠ THE SIGN IS PART OF THE SPECIFICATION: an OUTWARD offset would leave the element and, past the corner square's own reach, resolve to nothing at all — a row written with the offset inverted would fail for a reason that has nothing to do with the criterion it carries. RED-when: shrink the corner extent until a band takes the offset press, and the write becomes single-axis (`G48-5`'s own lever).
     */
    const original = fs.readFileSync(pageFixture);
    const posts = countPosts(page);
    await selectSubject(page);
    const before = await readGeometry(page);
    expect(before.box).not.toBeNull();

    // AIM_RADIUS is `pointer-thresholds.ts`'s `POINTER_DRAG_THRESHOLD_PX`, stated as a literal per this file's no-import discipline (never imported — an oracle that read the constant would move with it).
    const AIM_RADIUS = 4;
    const OFFSET = 2; // well within AIM_RADIUS, so the press still lands inside the corner's aim disc
    expect(OFFSET).toBeLessThan(AIM_RADIUS);
    // The press is anchored to the box's OWN SE VERTEX, not to the rendered handle's centre — a square anchored at its corner rather than centred on it would still be pressed dead-centre if the anchor were the handle's own bounding box, which is exactly the confound plan §4.1's SE VERTEX wording rules out.
    const boxRight = before.box!.left + before.box!.width;
    const boxBottom = before.box!.top + before.box!.height;
    const start = { x: boxRight - OFFSET, y: boxBottom - OFFSET };
    const STEPS = 12;
    const STEP_X = 6;
    const STEP_Y = 4;
    await page.mouse.move(start.x, start.y);
    await page.mouse.down();
    for (let i = 1; i <= STEPS; i += 1) await page.mouse.move(start.x + i * STEP_X, start.y + i * STEP_Y);
    await page.mouse.up();

    const response = await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    expect(response.ok()).toBe(true);
    await page.waitForTimeout(700);
    expect(posts.count(), "one POST for the offset-pressed corner gesture").toBe(1);

    const after = fs.readFileSync(pageFixture, "utf8");
    expect(after, "the offset press still moved the width axis").toMatch(/w-\[\d+px\]/);
    expect(after, "…and the height axis — the two-axis write the criterion promises").toMatch(/h-\[\d+px\]/);

    fs.writeFileSync(pageFixture, original);
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });
});
