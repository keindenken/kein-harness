import { test, expect, type Page } from "@playwright/test";

/**
 * region-set-instrument.spec.ts — the STANDING §8.1 region-set instrument (phase-48 B-Q5, plan §8.1).
 *
 * §8.1 names a "green-and-wrong" hazard the red-row enumeration cannot see by construction: a row whose probe point the corner-ramp model's regions now claim, while the row's own assertion stays green because it filters on a vocabulary (`gap:`/`pad:` prefixes, a specific handle attribute) the claiming region doesn't use. §8.1 names the reach of a bounded instrument over that hazard: "every statically enumerable shipped probe point (affordanceCentre outputs, one-pixel-inside probes, G44-8's offsets, the six `{x:6,y:6}` selection sites and `alignment-write.spec.ts`'s `selectAt` points) with per-region distances." Round 1 substituted a full unfiltered `pnpm test:e2e` drive for this and reported (correctly, per §8.1's own text) that a green suite is evidence about the RED class and about nothing else — the green-and-wrong class needs its own instrument. This file is that instrument, run every time the design-view suite runs rather than driven once and discarded.
 *
 * WHAT THIS FILE COVERS, AND WHY IT MEASURES LIVE RATHER THAN STATICALLY. Every probe point below has a LITERAL offset (a fixed `{x, y}` its owning row hard-codes), but the FIXTURE the offset is taken against — a Korean-text card's rendered height, a padding token's computed pixel value, a flex child's laid-out box — is knowable only once the page has rendered. So "statically enumerable" describes the OFFSETS, which are transcribed from the owning files' own literals rather than recomputed, and this file supplies the one thing a static reading cannot: the measured box each offset is taken against, read live in the same browser the owning row runs in.
 *
 * ⚠ **THIS FILE IMPORTS NOTHING FROM `packages/descvi/src`, AND THAT IS DELIBERATE — but its OWN discipline is different from the oracle files beside it.** `resize-handles.spec.ts` and `handle-geometry.test.ts` are GATES on the model itself, so an oracle that imported the production constants would move with a defect and ship green; that risk is why they hand-write a second implementation. This file's subject is different: it asks whether OTHER rows' probe points fall inside whatever the shipped model actually emits, which is exactly the model those other rows must agree with — so a divergence between this file's hand-written ramp and the shipped one would make THIS file wrong about the hazard it exists to catch. The ramp and band constants below are therefore the same literals `resize-handles.spec.ts` already pins and `G48-10`/`G48-11` gate independently; a breakpoint drift here is caught there first.
 *
 * WHAT THIS FILE DOES NOT COVER, NAMED RATHER THAN GLOSSED (plan §8.1's own honesty requirement, and where a deleted stub row's cross-reference prose now lives — the row held only `expect(true).toBe(true)`, which cannot go RED, `AGENTS.md`'s own bar for an assertion, so it is gone and its content moves here). `affordanceCentre`'s outputs and `G44-8`'s mid-drag sample offsets are `EG-1`'s own subject — the press points measured there are the SAME `gap:*`/`pad:*` centres this file would otherwise re-derive, and `EG-1`'s reading (recorded in `docs/e3/tracker.md`'s phase-48 section) already measures the band value, `hitDepth`, and the `elementsFromPoint` stack at both the centre and the deepest inward point, for every above-floor `pad:*` edge on `lab/tests/spacing-nesting`, which is a strictly finer-grained version of the same "does a resize region claim this point" question this file asks elsewhere. Re-deriving it here would duplicate one finding under two names rather than add coverage; the fresh reading is `EG-1`'s.
 */

/** The owner's corner ramp (plan §4) — literals, transcribed from `resize-handles.spec.ts`'s own pins. */
const CORNER_RAMP_NARROW_PX = 20;
const CORNER_RAMP_NARROW_EXTENT_PX = 8;
const CORNER_RAMP_WIDE_PX = 80;
const CORNER_RAMP_WIDE_EXTENT_PX = 16;
/** The straddling band's full thickness (plan §4). */
const BAND_PX = 10;

function rampCorner(shortSide: number): number {
  if (shortSide <= CORNER_RAMP_NARROW_PX) return CORNER_RAMP_NARROW_EXTENT_PX;
  if (shortSide >= CORNER_RAMP_WIDE_PX) return CORNER_RAMP_WIDE_EXTENT_PX;
  return (
    CORNER_RAMP_NARROW_EXTENT_PX +
    ((shortSide - CORNER_RAMP_NARROW_PX) / (CORNER_RAMP_WIDE_PX - CORNER_RAMP_NARROW_PX)) *
      (CORNER_RAMP_WIDE_EXTENT_PX - CORNER_RAMP_NARROW_EXTENT_PX)
  );
}

interface Box {
  left: number;
  top: number;
  width: number;
  height: number;
}

interface RegionReport {
  /** Positive = inside that axis' reach; the MIN of the two axes is what a corner-square test needs. */
  corner: Record<"nw" | "ne" | "se" | "sw", { dx: number; dy: number; inside: boolean }>;
  band: Record<"n" | "e" | "s" | "w", { d: number; inside: boolean }>;
  claimed: boolean;
}

/**
 * The finding criterion, stated once (plan §8.1): a point is a finding when it lies inside ANY region
 * the model emits for `box` — within `cornerExtent / 2` on BOTH axes of a box corner, OR within
 * `bandPx / 2` of an edge. Reports the signed distance on every axis so a near-miss is visible, not
 * only a boolean.
 */
function regionMembership(box: Box, point: { x: number; y: number }): RegionReport {
  const half = rampCorner(Math.min(box.width, box.height)) / 2;
  const bandHalf = BAND_PX / 2;
  const l = box.left;
  const t = box.top;
  const r = box.left + box.width;
  const b = box.top + box.height;
  const corners = {
    nw: { cx: l, cy: t },
    ne: { cx: r, cy: t },
    se: { cx: r, cy: b },
    sw: { cx: l, cy: b },
  } as const;
  const corner: RegionReport["corner"] = {} as RegionReport["corner"];
  let claimed = false;
  for (const [name, c] of Object.entries(corners) as [keyof typeof corners, { cx: number; cy: number }][]) {
    const dx = half - Math.abs(point.x - c.cx);
    const dy = half - Math.abs(point.y - c.cy);
    const inside = dx >= 0 && dy >= 0;
    if (inside) claimed = true;
    corner[name] = { dx, dy, inside };
  }
  const band: RegionReport["band"] = {
    n: { d: bandHalf - Math.abs(point.y - t), inside: false },
    s: { d: bandHalf - Math.abs(point.y - b), inside: false },
    w: { d: bandHalf - Math.abs(point.x - l), inside: false },
    e: { d: bandHalf - Math.abs(point.x - r), inside: false },
  };
  // A band's reach is bounded to its own edge SEGMENT — the straight rect edge-spanning model
  // (`G48-8`), not the whole infinite line — so the cross-axis coordinate must also fall on the edge.
  band.n.inside = band.n.d >= 0 && point.x >= l && point.x <= r;
  band.s.inside = band.s.d >= 0 && point.x >= l && point.x <= r;
  band.w.inside = band.w.d >= 0 && point.y >= t && point.y <= b;
  band.e.inside = band.e.d >= 0 && point.y >= t && point.y <= b;
  if (band.n.inside || band.s.inside || band.w.inside || band.e.inside) claimed = true;
  return { corner, band, claimed };
}

async function boxOf(page: Page, oid: string): Promise<Box> {
  const box = await page.locator(`[data-oid="${oid}"]`).boundingBox();
  if (box === null) throw new Error(`[data-oid="${oid}"] has no box`);
  // ⚠ Playwright's `boundingBox()` returns `{x, y, width, height}`, NOT `{left, top, ...}` — mapped
  // explicitly rather than returned as-is, which is what a silent structural-typing pass-through
  // would have hidden (`Box.left`/`.top` would read `undefined`, and every distance below it would
  // too, which is exactly the false-negative shape this instrument exists to catch elsewhere).
  return { left: box.x, top: box.y, width: box.width, height: box.height };
}

test.describe("§8.1 region-set instrument — statically enumerable shipped probe points", () => {
  test("the six `{x:6,y:6}` selection sites", async ({ page }) => {
    // ⚠ **SIX SITES, TWO DISTINCT (screen, oid) PAIRS.** `late-remeasure.spec.ts`,
    // `resize-handle-shield.spec.ts` (×2), `resize-write.spec.ts` and `resize-handles.spec.ts` all
    // click `lab/tests/style-edit`'s `v002k2` card at the same position; `multi-select-shield.spec.ts`
    // clicks `lab/tests/shared-oid`'s `d1z5g6`. The geometric reading is therefore one measurement per
    // pair, reported once and named against every citing file.
    const sites: { screen: string; oid: string; citedBy: string[] }[] = [
      {
        screen: "/lab/tests/style-edit",
        oid: "v002k2",
        citedBy: [
          "late-remeasure.spec.ts",
          "resize-handle-shield.spec.ts (selectSubject)",
          "resize-handle-shield.spec.ts (R42-D1 row's own reselect)",
          "resize-write.spec.ts",
          "resize-handles.spec.ts",
        ],
      },
      { screen: "/lab/tests/shared-oid", oid: "d1z5g6", citedBy: ["multi-select-shield.spec.ts"] },
    ];
    // ⚠ **A RECORDED BASELINE, MEASURED 2026-09-03 — NOT A SPECIFICATION.** This is the `claimed` reading THIS RUN measured for each site, pinned so a model change that newly claims (or newly stops claiming) one of these two points shows RED by name rather than as a `console.log` line nobody is asked to compare. Both are `true` today: `(6, 6)` lies inside the target's own `nw` corner square once it is selected, on BOTH fixtures. Recording it as `true` is recording the ACCEPTED straddle this file's own docblock already prices (`v002k2`'s corner extent is 12.43 px at a 53.25 px short side; `d1z5g6`'s is 16 px, the wide clamp) — it is not a claim that this is how the model OUGHT to behave, only a fact about what it does today, so a future change is caught rather than absorbed silently.
    const BASELINE_CLAIMED: Record<string, boolean> = {
      "/lab/tests/style-edit#v002k2": true,
      "/lab/tests/shared-oid#d1z5g6": true,
    };
    const report: Record<string, unknown> = {};
    for (const site of sites) {
      await page.goto(site.screen);
      await expect(page.locator("#dsh-ring-layer")).toBeAttached();
      await page.locator(`[data-oid="${site.oid}"]`).click({ position: { x: 6, y: 6 } });
      await expect(page.locator("#dsh-selection-ring")).toBeVisible();
      const box = await boxOf(page, site.oid);
      const probe = { x: box.left + 6, y: box.top + 6 };
      const membership = regionMembership(box, probe);
      const key = `${site.screen}#${site.oid}`;
      report[key] = {
        box,
        shortSide: Math.min(box.width, box.height),
        cornerExtent: rampCorner(Math.min(box.width, box.height)),
        membership,
        citedBy: site.citedBy,
      };
      // ⚠ **THE FACT ITSELF IS REPORTED FOR CONTEXT — and the reason a re-press today is still safe is
      // what makes this an honest reading rather than a gate on a claim nobody makes.** Every citing
      // row is safe TODAY because the press happens BEFORE selection: nothing is rendered yet to claim
      // it, which is exactly plan §8.1's own reading of this class ("nothing is selected when the
      // press lands and no handle exists to claim it. That is a property of the surrounding row, not
      // of the point."). What this measures is the FUTURE-facing question — were this exact point
      // pressed AGAIN once the target is already selected — and a corner-square claim there is a real,
      // measured finding worth keeping visible in every run rather than a defect in any of the six
      // citing rows as they stand today. The assertion below is against the BASELINE above, not
      // against "unclaimed": the point is already claimed today, and what the row exists to catch is a
      // FUTURE move, in either direction.
      if (membership.claimed) {
        console.log(
          `region-set instrument FINDING: ${site.screen}#${site.oid} (short side ${Math.min(box.width, box.height).toFixed(1)}px, corner extent ${rampCorner(Math.min(box.width, box.height)).toFixed(2)}px) — (6,6) is inside the target's OWN corner square once it is selected; a re-press at this exact point after selection would hit a handle rather than drill into the element. Cited by: ${site.citedBy.join(", ")}`,
        );
      }
      expect(membership.claimed, `${key}: claimed-point baseline (measured 2026-09-03)`).toBe(BASELINE_CLAIMED[key]);
    }
    console.log("region-set instrument — six {x:6,y:6} sites:", JSON.stringify(report, null, 2));
  });

  test("`alignment-write.spec.ts`'s `selectAt` points", async ({ page }) => {
    // Four calls, one of them (F2_CONTAINER @ {160,10}) running with F2_STRETCH_CHILD already
    // selected from the row above it — the shape that makes a positioned click land on live
    // furniture (plan §8.1). The other three run on a clean screen (nothing selected yet).
    await page.goto("/lab/tests/align-wrap");
    await expect(page.locator(`[data-screen="lab/tests/align-wrap"]`)).toBeVisible();
    await expect(page.locator("#dsh-ring-layer")).toBeAttached();

    const report: Record<string, unknown> = {};

    // F2_STRETCH_CHILD selected first, exactly as G43-9 C4-INERT does.
    await page.locator('[data-oid="awf2cb"]').click({ position: { x: 60, y: 110 } });
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    const childBox = await boxOf(page, "awf2cb");

    // THE RISKY CALL: F2_CONTAINER pressed at {160,10} while awf2cb's furniture is still rendered.
    const containerBox = await boxOf(page, "awf2cn");
    const probeViewport = { x: containerBox.left + 160, y: containerBox.top + 10 };
    const membership = regionMembership(childBox, probeViewport);
    report["F2_CONTAINER @ {160,10}, against the PRIOR selection awf2cb's furniture"] = {
      childBox,
      containerBox,
      probeViewport,
      membership,
    };
    // ⚠ **ASSERTED, not merely reported — the ONE call in this test whose prior selection is LIVE
    // today**, distinguishing this from the abstract, future-facing readings elsewhere in this file:
    // `awf2cb`'s furniture is genuinely rendered on screen at the moment this exact press lands, so a
    // corner-square claim here would be a demonstrable defect in `G43-9 C4-INERT` as it stands, not a
    // hypothetical about a re-press nobody makes.
    expect(
      membership.claimed,
      `F2_CONTAINER's selectAt point {160,10} (viewport ${JSON.stringify(probeViewport)}) is inside awf2cb's OWN resize furniture, rendered from the PRIOR selectAt call — the click would hit a handle rather than drilling into the container`,
    ).toBe(false);

    // The other three sites are checked against their OWN just-selected box — the same FUTURE-facing
    // reading as the six {x:6,y:6} sites above (reported, not asserted, for the same reason: nothing
    // is selected when each of these presses itself lands).
    await page.locator('[data-oid="awhgcn"]').click({ position: { x: 160, y: 5 } });
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    const hugBox = await boxOf(page, "awhgcn");
    const hugProbe = { x: hugBox.left + 160, y: hugBox.top + 5 };
    const hugMembership = regionMembership(hugBox, hugProbe);
    report["HUG_CONTAINER @ {160,5}"] = { hugBox, hugMembership };
    if (hugMembership.claimed) {
      console.log(
        `region-set instrument FINDING: HUG_CONTAINER's own selectAt point {160,5} is inside its OWN just-rendered furniture (${JSON.stringify(hugMembership.band)}) — a re-press there after selection would hit a handle`,
      );
    }

    await page.locator('[data-oid="awf1cn"]').click({ position: { x: 160, y: 10 } });
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    const f1Box = await boxOf(page, "awf1cn");
    const f1Probe = { x: f1Box.left + 160, y: f1Box.top + 10 };
    const f1Membership = regionMembership(f1Box, f1Probe);
    report["F1_CONTAINER @ {160,10}"] = { f1Box, f1Membership };
    if (f1Membership.claimed) {
      console.log(
        `region-set instrument FINDING: F1_CONTAINER's own selectAt point {160,10} is inside its OWN just-rendered furniture (${JSON.stringify(f1Membership.band)}) — a re-press there after selection would hit a handle`,
      );
    }

    console.log("region-set instrument — alignment-write.spec.ts selectAt points:", JSON.stringify(report, null, 2));
  });

  test("`G44-9a`'s one-pixel-inside drill probes, against each selected PARENT's own furniture", async ({ page }) => {
    // The four subjects G44-9a probes (`e2e/spacing-gesture.spec.ts`'s own constants): PAD_FLUSH
    // ("snpflu", selected through the shield's Cmd-click parent climb — a plain click resolves to a
    // child, per that file's own measured correction), GAP_ZERO ("sngzro"), BELOW_FLOOR ("snbflr"),
    // GAP_WRAP ("sngwrp") — each selected, then every child's border box probed 1 px inside on all
    // four edges (the row's own points). This instrument checks those exact points against the
    // SELECTED PARENT's own emitted regions, which is the geometry that can claim them (plan §2's
    // straddling band reaches 5 px inside the parent's own border box).
    const SCREEN = "/lab/tests/spacing-nesting";
    const subjects = ["snpflu", "sngzro", "snbflr", "sngwrp"];
    // ⚠ **A RECORDED BASELINE, MEASURED 2026-09-03 — NOT A SPECIFICATION.** The claimed `(child, edge)`
    // pairs THIS RUN found for each subject, pinned so a model change that newly claims (or newly
    // stops claiming) one of these probe points shows RED by name rather than as a `console.log` line.
    // `snpflu` (`PAD_FLUSH`) is the only subject with rendered children under this reading — its two
    // children are flush with the parent on three edges each (`snpfla`: left/top/bottom, `snpflb`:
    // right/top/bottom), and every one of those six probes is claimed by the parent's straddling band
    // — the ACCEPTED outcome plan §8.1 and `G44-9a`'s own row already price. `sngzro`, `snbflr` and
    // `sngwrp` measure zero children under `[data-oid="${oid}"] [data-oid]"` at the point this test
    // selects them (their own children, if any, are not exposed as `[data-oid]` descendants of this
    // parent at this probe), so their claimed-pair sets are empty. Recording these as the baseline is
    // recording what this run measured, not a claim that the empty three OUGHT to stay empty.
    const BASELINE_CLAIMED: Record<string, readonly string[]> = {
      snpflu: ["snpfla:bottom", "snpfla:left", "snpfla:top", "snpflb:bottom", "snpflb:right", "snpflb:top"],
      sngzro: [],
      snbflr: [],
      sngwrp: [],
    };
    const report: Record<string, unknown> = {};
    for (const oid of subjects) {
      await page.goto(SCREEN);
      await expect(page.locator('[data-screen="lab/tests/spacing-nesting"]')).toBeVisible();
      await expect(page.locator("#dsh-ring-layer")).toBeAttached();
      const locator = page.locator(`[data-oid="${oid}"]`);
      if ((await locator.count()) === 0) {
        report[oid] = "not present on this fixture — skipped rather than assumed";
        continue;
      }
      if (oid === "snpflu") {
        // The Cmd-click parent climb, in `selectFlushParent`'s own order: select the child first
        // (a plain click on the parent resolves to it), then Cmd-click the SAME point to climb.
        await locator.click();
        await expect(page.locator("#dsh-selection-ring")).toBeVisible();
        const child = (await page.locator('[data-oid="snpfla"]').boundingBox())!;
        await page.keyboard.down("Meta");
        await page.mouse.click(child.x + child.width * 0.25, child.y + child.height * 0.25);
        await page.keyboard.up("Meta");
      } else {
        await locator.click({ position: { x: 4, y: 4 } });
      }
      await expect(page.locator("#dsh-selection-ring")).toBeVisible();
      const parentBox = await boxOf(page, oid);
      const children = await page.evaluate(
        (parentOid) =>
          Array.from(document.querySelectorAll<HTMLElement>(`[data-oid="${parentOid}"] [data-oid]`)).map((el) => {
            const r = el.getBoundingClientRect();
            return { left: r.left, top: r.top, width: r.width, height: r.height, oid: el.getAttribute("data-oid") };
          }),
        oid,
      );
      const findings: unknown[] = [];
      for (const child of children) {
        const probes: { name: string; x: number; y: number }[] = [
          { name: "left", x: child.left + 1, y: child.top + child.height * 0.25 },
          { name: "right", x: child.left + child.width - 1, y: child.top + child.height * 0.25 },
          { name: "top", x: child.left + child.width * 0.25, y: child.top + 1 },
          { name: "bottom", x: child.left + child.width * 0.25, y: child.top + child.height - 1 },
        ];
        for (const probe of probes) {
          const membership = regionMembership(parentBox, probe);
          if (membership.claimed) {
            findings.push({ child: child.oid, edge: probe.name, point: { x: probe.x, y: probe.y }, membership });
          }
        }
      }
      report[oid] = { parentBox, childCount: children.length, findings };
      const claimedKeys = (findings as { child: string; edge: string }[]).map((f) => `${f.child}:${f.edge}`).sort();
      expect(claimedKeys, `${oid}: claimed-pair baseline (measured 2026-09-03)`).toEqual([...BASELINE_CLAIMED[oid]!].sort());
    }
    console.log("region-set instrument — G44-9a drill probes vs. each selected parent's furniture:", JSON.stringify(report, null, 2));
    // ASSERTED AGAINST THE RECORDED BASELINE ABOVE, per subject, not per-point against a fixed
    // expectation of "unclaimed" — findings ARE expected for a flush child under the accepted straddle
    // cession, which is what `G44-9a`'s own row already re-points and records as the priced outcome
    // (plan §8.1, this round's tracker entry). What the baseline equality catches is a MOVE — a probe
    // that newly joins or newly leaves the claimed set — rather than the presence of claims itself.
  });
});
