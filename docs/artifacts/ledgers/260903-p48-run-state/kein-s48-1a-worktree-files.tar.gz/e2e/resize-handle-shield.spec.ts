import { test, expect, type Page } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";

/**
 * resize-handle-shield.spec.ts — the shield bypass on a REAL drag (phase-42 S42-2b acceptance 1, 2,
 * 3 and 8; G42-2), plus R42-D1's own RED-when.
 *
 * WHY A BROWSER IS REQUIRED, and it is not "browsers are more realistic". Three of the four things
 * asserted here do not exist in jsdom at all:
 *
 *  1. **The synthesized click.** A press and release produce a `click` the test never dispatches, and
 *     its target is decided by whether pointer CAPTURE was held. That is the whole subject of rows 1
 *     and 3, and jsdom synthesizes nothing.
 *  2. **`setPointerCapture` retargeting.** jsdom implements neither the method nor the retargeting,
 *     so the "drop capture and the click retargets to `#dsh-frame`" mutation is unobservable there.
 *  3. **`document.elementFromPoint`.** R42-D1's ruling is about which node a pixel belongs to, and a
 *     host with no layout cannot answer.
 *
 * THE PROBES, AND WHY THERE ARE TWO OF THEM. `defaultPrevented` and `rootDelegated` are read at
 * DIFFERENT places on purpose:
 *
 *  - a `document`-CAPTURE probe keeps a reference to the click event. It runs before the shield's own
 *    capture listener, so it cannot read the flag at the time — but the event object retains it, so
 *    reading it after the dispatch has finished is how a suppressed click's `defaultPrevented` is
 *    observed at all.
 *  - a BUBBLE probe bound ABOVE `#dsh-stage` counts `rootDelegated`. The phase is specified rather
 *    than incidental: an ancestor CAPTURE listener runs BEFORE the stage's and is outside the
 *    suppression guarantee by construction, so a capture-phase probe here would make correct code
 *    RED. What the suppression buys is keeping the handle's click off every listener at or above the
 *    stage, and this is the only observable difference there is — measured, a host control under the
 *    release point fires no navigation either way, because with capture held the click's ancestor
 *    chain never traverses `#dsh-screen`.
 *
 * ⚠ THE "THE PAGE IS NEVER WRITTEN" PREMISE WAS S42-2b's, AND S42-3 RETIRED IT — corrected here rather than in a comment somewhere else, because it was an ASSERTION in every row of this file.
 * At S42-2b the gesture's commit seam was a production no-op, so "zero POSTs, `page.tsx` byte-identical" was a property of the whole file and its `afterEach` could assert it unconditionally.
 * S42-3 fills that seam: a drag that CLASSIFIES and RELEASES now recomputes through `commitResize` and posts exactly once. A drag cancelled mid-flight — Escape, and every other §3.5(d) trigger — still writes nothing, and that half is unchanged and is still asserted.
 * So the file's expectation is now PER ROW: each row declares how many `POST /edit`s its own stimulus owes, and the `afterEach` RESTORES the fixture (re-deriving `.descvi/` through the extractor, C-R1) instead of asserting that nothing touched it.
 * ⚠ The subject of this file did not change with it: G42-2 is about the SHIELD — that the drag's synthesized click never deselects — and every row still asserts exactly that. What changed is the accounting around it.
 *
 * ⚠ **SCOPED TO `#dsh-handle-layer` IN PHASE-44 S44-3, AND THE SCOPING IS A CORRECTION RATHER THAN TIDYING.**
 * `data-dsh-handle` is the SHIELD's marker, not the resize family's, and phase-44 §3.9 rules that the spacing
 * affordances and the numeric popup carry it too — it is the shield's one concession and all three classes need
 * it. Measured on this file's own subject, an unscoped `[data-dsh-handle]` count therefore reports seventeen
 * where eight is the claim. What this file is about is phase-42's furniture, so its selectors name that
 * furniture's own container; `e2e/spacing-gesture.spec.ts` carries the other family's counts.
 */

// `playwright test` always runs from the repo root (playwright.config.ts's dir).
const repoRoot = path.resolve(process.cwd());
const pageFixture = path.join(repoRoot, "src", "app", "lab", "tests", "style-edit", "page.tsx");

/** The "simple static classes" card — static, parseable, editable, and big enough to drag on. */
const SUBJECT_OID = "v002k2";

/** The fixture geometry every row below uses: comfortably inside the frame, on both axes. */
const FIXTURE = { left: 200, top: 180, width: 300, height: 120 };

interface DragReadout {
  handleDown: number;
  handleMoves: number;
  clickTarget: string | null;
  defaultPrevented: boolean | null;
  rootDelegated: number;
  captureCalled: boolean;
}

async function selectSubject(page: Page): Promise<void> {
  await page.goto("/lab/tests/style-edit");
  await expect(page.locator("#dsh-ring-layer")).toBeAttached();
  // A POSITIONED click into the card's own padding: a centre click lands on a child that carries its
  // own `data-oid`, and the canvas resolves the selection to THAT.
  await page.locator(`[data-oid="${SUBJECT_OID}"]`).click({ position: { x: 6, y: 6 } });
  await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  await expect(page.locator("#dsh-handle-layer [data-dsh-handle]")).toHaveCount(8);
}

/** Sizes and positions the selected element, then waits for the furniture to re-anchor onto it. */
async function setFixture(page: Page): Promise<void> {
  await page.evaluate(
    ({ oid, box }) => {
      const el = document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)!;
      el.removeAttribute("style");
      // Padding and border are zeroed FIRST: under `box-sizing: border-box` the used width can never
      // fall below padding + border, so this card's own would floor the fixture.
      Object.assign(el.style, { padding: "0px", border: "0px", minWidth: "0px", minHeight: "0px" });
      Object.assign(el.style, {
        position: "absolute",
        left: `${box.left}px`,
        top: `${box.top}px`,
        width: `${box.width}px`,
        height: `${box.height}px`,
      });
      window.dispatchEvent(new Event("resize"));
    },
    { oid: SUBJECT_OID, box: FIXTURE },
  );
  // Settled = the E band's CENTRELINE sits on the element's right edge. RE-POINTED (plan §8): under R42-D1's outward-only model this polled the band's LEFT edge against the element's right edge, which was true only while the band hung wholly outside; under the straddling band that difference is a constant −5 and the poll would never settle. The band's subject stands (the layer has re-anchored onto this element) and only the predicate moves — to the same centreline equality `G48-3` asserts, under the same tolerance obligation §6 records. It keeps its diagnostic return rather than becoming a boolean, because the poll's whole value is naming which of its two independent failure reasons occurred.
  await expect
    .poll(
      async () =>
        page.evaluate((oid) => {
          const el = document.querySelector(`[data-oid="${oid}"]`)!.getBoundingClientRect();
          const strip = document.querySelector('[data-dsh-handle="e"]');
          if (strip === null) return "no E strip";
          const r = strip.getBoundingClientRect();
          const centreline = r.left + r.width / 2;
          // ⚠ **0.6 IS THE POLL'S OWN QUANTISATION FLOOR, NOT THE EXACT-EQUALITY BOUND `G48-3` ASSERTS — the same distinction `e2e/resize-handles.spec.ts`'s sibling settle poll states at its own 0.5 px floor.** This poll's ONE job is telling "not yet re-anchored" apart from "placed wrongly"; it is not itself the row that checks placement precision, so it does not need `G48-3`'s measured 0.02 px bound and reusing that number here would make a slow re-anchor read as a five-second timeout instead of a diagnosable "not settled" state. 0.6 is a round, generous floor (looser than the sibling poll's 0.5 because this predicate also carries the `#dsh-handle-layer` query's own settle time, not merely the geometry), not a value derived from a specific measured run.
          if (Math.abs(centreline - el.right) > 0.6) return `E band centreline at ${centreline}, element right ${el.right}`;
          return "settled";
        }, SUBJECT_OID),
      { timeout: 5_000 },
    )
    .toBe("settled");
}

/** Installs the page-side probes: the handle's own listeners, and the two click observers. */
async function installProbes(page: Page): Promise<void> {
  await page.evaluate(() => {
    const w = window as unknown as { __dshProbe: DragReadout & { clickEvent: Event | null } };
    w.__dshProbe = {
      handleDown: 0,
      handleMoves: 0,
      clickTarget: null,
      defaultPrevented: null,
      rootDelegated: 0,
      captureCalled: false,
      clickEvent: null,
    };
    const probe = w.__dshProbe;
    const handle = document.querySelector<HTMLElement>('[data-dsh-handle="e"]')!;
    // The handle's OWN pointerdown — acceptance 2, asserted directly rather than inferred from the
    // selection surviving. It is on the handle node, i.e. below the stage's capture listener, so a
    // suppression that stops the event descending reads here as a zero.
    handle.addEventListener("pointerdown", () => {
      probe.handleDown += 1;
    });
    handle.addEventListener("pointermove", () => {
      probe.handleMoves += 1;
    });
    const nativeCapture = handle.setPointerCapture.bind(handle);
    handle.setPointerCapture = (id: number) => {
      probe.captureCalled = true;
      nativeCapture(id);
    };
    // Runs BEFORE the shield's own capture listener, so it cannot read `defaultPrevented` yet — it
    // keeps the event, which retains the flag once the dispatch has finished.
    document.addEventListener(
      "click",
      (e) => {
        probe.clickEvent = e;
        const t = e.target as Element | null;
        probe.clickTarget =
          t === null ? null : `${t.tagName.toLowerCase()}${t.id === "" ? "" : `#${t.id}`}${t.getAttribute("data-dsh-handle") === null ? "" : `[handle]`}`;
      },
      { capture: true },
    );
    // BUBBLE, above `#dsh-stage`. This is the count the suppression exists to keep at zero.
    document.getElementById("dsh-root")!.addEventListener("click", () => {
      probe.rootDelegated += 1;
    });
  });
}

async function readProbe(page: Page): Promise<DragReadout> {
  return page.evaluate(() => {
    const w = window as unknown as { __dshProbe: DragReadout & { clickEvent: Event | null } };
    const p = w.__dshProbe;
    return {
      handleDown: p.handleDown,
      handleMoves: p.handleMoves,
      clickTarget: p.clickTarget,
      defaultPrevented: p.clickEvent === null ? null : p.clickEvent.defaultPrevented,
      rootDelegated: p.rootDelegated,
      captureCalled: p.captureCalled,
    };
  });
}

/** Presses the E strip, drags N ≥ 10 steps of ≥ 10 px, and releases OVER `#dsh-screen`, off it. */
async function dragEStripAndReleaseOffIt(page: Page): Promise<void> {
  const strip = await page.locator('[data-dsh-handle="e"]').boundingBox();
  expect(strip, "the E strip is rendered and measurable").not.toBeNull();
  const startX = strip!.x + strip!.width / 2;
  const startY = strip!.y + strip!.height / 2;
  await page.mouse.move(startX, startY);
  await page.mouse.down();
  for (let step = 1; step <= 12; step += 1) {
    await page.mouse.move(startX + step * 12, startY);
  }
  // The release lands well inside the element's own body — over `#dsh-screen` and OFF the handle,
  // which is the case a press-and-release ON the handle would pass without testing anything.
  await page.mouse.move(FIXTURE.left + FIXTURE.width / 2, FIXTURE.top + FIXTURE.height / 2);
  await page.mouse.up();
}


/**
 * The three release points the review's matrix uses, discovered IN THE PAGE rather than guessed: a
 * point on the subject itself, a point inside `#dsh-screen` that resolves to no `[data-oid]` at all
 * (the one that produces a null selection, i.e. a deselect), and a point just outside the subject's
 * right edge. `null` for the unstamped point means this screen has none, which the row asserts
 * rather than silently skipping.
 *
 * ⚠ **`onElement` IS DERIVED TO THE ELEMENT'S OWN CENTRE (plan §8).** A point offset `{8, 8}` from the top-left corner sits ON the nw corner square's own inner boundary with ZERO margin: `FIXTURE`'s short side is 120, at or above the ramp's wide endpoint, so the nw square's side is 16 and its INWARD reach from the corner is half that, 8 px — a point at depth 8 is therefore still ambiguous between the element and the handle, inside the ~1 px z-boundary reach `G48-4`'s own measurement found (`MARGIN = 1.5` there). ⚠ **THE DEFECT PREDATES THIS PHASE (plan §8): under the RETIRED model the corner hit square was 20 px centred on the box corner, reaching 10 px inward on this fixture, so a depth-6 or depth-8 point was already a handle point before this phase shipped — what this phase changes is the depth at which the point stops being one, from 10 to 8, not whether it is one.** This row's own point does not need to sit near the corner at all — the docblock above states its intent as "a point ON THE SUBJECT ITSELF" — so it moves to the element's own centre, which clears every resize surface (corner INWARD reach 8 px, band inward reach 5 px) by a margin two orders of magnitude past `G48-4`'s measured 1.5 px: on the 300 × 120 fixture the centre sits 150 px from the nearest vertical edge and 60 px from the nearest horizontal one.
 */
async function releasePoints(page: Page): Promise<{ onElement: Point; unstamped: Point | null; besideElement: Point }> {
  return page.evaluate((oid) => {
    const el = document.querySelector(`[data-oid="${oid}"]`)!.getBoundingClientRect();
    const screen = document.getElementById("dsh-screen")!.getBoundingClientRect();
    let unstamped: { x: number; y: number } | null = null;
    // A coarse grid over the screen: the first point that hits the screen but no stamped element.
    for (let y = screen.bottom - 8; y > screen.top && unstamped === null; y -= 16) {
      for (let x = screen.right - 8; x > screen.left; x -= 16) {
        const n = document.elementFromPoint(x, y);
        if (n === null) continue;
        if (n.closest("[data-oid]") !== null) continue;
        if (!document.getElementById("dsh-screen")!.contains(n)) continue;
        unstamped = { x, y };
        break;
      }
    }
    return {
      onElement: { x: el.left + el.width / 2, y: el.top + el.height / 2 },
      unstamped,
      besideElement: { x: el.right + 30, y: el.top + el.height / 2 },
    };
  }, SUBJECT_OID);
}

interface Point {
  x: number;
  y: number;
}

/** Press the E strip, drag it, optionally press Escape mid-drag, then release at `at`. */
async function dragAndRelease(page: Page, opts: { escape: boolean; at: Point }): Promise<void> {
  const strip = (await page.locator('[data-dsh-handle="e"]').boundingBox())!;
  const startX = strip.x + strip.width / 2;
  const startY = strip.y + strip.height / 2;
  await page.mouse.move(startX, startY);
  await page.mouse.down();
  for (let step = 1; step <= 12; step += 1) await page.mouse.move(startX + step * 12, startY);
  if (opts.escape) await page.keyboard.press("Escape");
  await page.mouse.move(opts.at.x, opts.at.y);
  await page.mouse.up();
}

/** The selection, read the way a user sees it: the ring paints and the furniture is there. */
async function selectionAlive(page: Page): Promise<{ ring: boolean; handles: number }> {
  return page.evaluate(() => ({
    ring: (document.getElementById("dsh-selection-ring")?.style.display ?? "none") === "block",
    handles: document.querySelectorAll("#dsh-handle-layer [data-dsh-handle]").length,
  }));
}

test.describe("G42-2 — the shield bypass on a real handle drag (S42-2b)", () => {
  let originalPage: Buffer | undefined;

  /** Every `POST /edit` the current row's page issued, installed fresh per row. */
  let posts: string[] = [];

  test.beforeEach(async ({ page }) => {
    // The snapshot is now a RESTORE POINT as well as an oracle: rows whose drag completes write.
    originalPage = fs.readFileSync(pageFixture);
    posts = [];
    page.on("request", (r) => {
      if (r.method() === "POST" && r.url().includes("/edit")) posts.push(r.url());
    });
    await selectSubject(page);
    await setFixture(page);
  });

  test.afterEach(async ({ page }) => {
    await page.evaluate((oid) => {
      document.querySelector<HTMLElement>(`[data-oid="${oid}"]`)?.removeAttribute("style");
    }, SUBJECT_OID);
    // A write is dispatched at pointerup and lands asynchronously; restoring before it arrives would
    // race the sidecar and leave the NEXT row's fixture dirty for a reason it cannot diagnose.
    await page.waitForTimeout(600);
    const snapshot = originalPage!;
    originalPage = undefined;
    if (fs.readFileSync(pageFixture).equals(snapshot)) return;
    fs.writeFileSync(pageFixture, snapshot);
    // `.descvi/` is put back by RE-DERIVING it, never by restoring bytes (invariant 1), which is what
    // makes this restore self-verifying: the check exits non-zero if the manifest differs from HEAD.
    execFileSync(process.execPath, ["scripts/check-extract-outcome.mjs"], { cwd: repoRoot, stdio: "inherit" });
  });

  test("acceptance 1–3 — the drag survives, the handle's pointerdown ran, and the click reaches nothing above the stage", async ({
    page,
  }) => {
    await installProbes(page);
    const before = await page.evaluate((oid) => {
      const el = document.querySelector(`[data-oid="${oid}"]`)!;
      const r = el.getBoundingClientRect();
      return { oid: el.getAttribute("data-oid"), width: r.width, height: r.height };
    }, SUBJECT_OID);

    await dragEStripAndReleaseOffIt(page);
    // S42-3: this drag classifies and releases, so it owes exactly one write. Awaited rather than
    // slept on, so the count below is read after the request rather than racing it.
    await page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
    const probe = await readProbe(page);

    // Acceptance 2 — the handle's own listener RAN. Rows A and B of the measured table read zero
    // here, and the control that produced a non-zero is the shield-free case in the plan's own
    // probe; the drag below could not have moved the handle at all without it.
    expect(probe.handleDown, "the handle's own pointerdown").toBeGreaterThanOrEqual(1);
    expect(probe.captureCalled, "capture was taken — row E's precondition").toBe(true);
    expect(probe.handleMoves, "the moves reached the captured handle").toBeGreaterThanOrEqual(10);

    // Acceptance 3 — the synthesized click is suppressed, and nothing at or above the stage saw it.
    expect(probe.clickTarget, "with capture held the click targets the HANDLE").toContain("[handle]");
    expect(probe.defaultPrevented, "the click is defaultPrevented").toBe(true);
    expect(probe.rootDelegated, "no listener above #dsh-stage saw it").toBe(0);

    // Acceptance 1 — the selection is unchanged, ring and furniture included, and the panel still
    // names the same target.
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
    await expect(page.locator("#dsh-handle-layer [data-dsh-handle]")).toHaveCount(8);
    const after = await page.evaluate((oid) => {
      const el = document.querySelector(`[data-oid="${oid}"]`)!;
      const r = el.getBoundingClientRect();
      const ring = document.getElementById("dsh-selection-ring")!.getBoundingClientRect();
      return {
        oid: el.getAttribute("data-oid"),
        width: r.width,
        height: r.height,
        ringMatches: Math.abs(ring.width - r.width) <= 1 && Math.abs(ring.height - r.height) <= 1,
        className: el.getAttribute("class"),
      };
    }, SUBJECT_OID);
    expect(after.oid).toBe(before.oid);
    expect(after.ringMatches, "the ring still anchors THIS element").toBe(true);
    // ⚠ THE BOX IS STILL UNCHANGED, AND THE REASON IS THE FIXTURE RATHER THAN THE ABSENCE OF A WRITE.
    // `setFixture` pins width/height as INLINE styles, which outrank any utility class, so S42-3's
    // `w-[Npx]` write lands in the source without moving this element. Kept as an assertion because
    // it is what makes the ring reading above meaningful — but it is no longer evidence that nothing
    // was written, and the POST count below is what carries that claim now.
    expect({ width: after.width, height: after.height }).toEqual({ width: before.width, height: before.height });
    expect(posts, "S42-3: a completed drag owes exactly ONE POST").toHaveLength(1);
  });


  /**
   * THE ESCAPE-THEN-RELEASE MATRIX (review MUST-FIX 1). Three release positions × Escape on/off.
   *
   * THE DEFECT IT PINS, and it is a COUPLING rather than a missing branch: the terminal path
   * releases pointer capture synchronously (§3.5(c), which stands), so a gesture that ends while the
   * primary button is STILL DOWN leaves an eventual `click` that is no longer handle-targeted. The
   * shield's own bypass predicate is capture-dependent — it matches on `[data-dsh-handle]` — so it
   * stops matching, `handleShieldSelect` resolves the RELEASE POINT, and an unstamped target
   * deselects the element the user was resizing. Escape is the reachable case; a non-primary
   * terminate is the same shape.
   *
   * ⚠ It is scoped by the LATCH's expiry row below: suppressing the trailing click of an
   * already-ended gesture must not become a general "the shield ignores one click" hole.
   */
  const RELEASE_POSITIONS = ["onElement", "unstamped", "besideElement"] as const;

  for (const position of RELEASE_POSITIONS) {
    for (const escape of [true, false]) {
      test(`Escape matrix — release ${position}, Escape ${escape ? "MID-DRAG" : "not pressed"}: the selection survives`, async ({
        page,
      }) => {
        const points = await releasePoints(page);
        if (position === "unstamped") {
          expect(points.unstamped, "this screen has a point that resolves to no [data-oid]").not.toBeNull();
        }
        const at = position === "unstamped" ? points.unstamped! : points[position];

        const settled = escape
          ? Promise.resolve(null)
          : page.waitForResponse((r) => r.url().endsWith("/edit") && r.request().method() === "POST");
        await dragAndRelease(page, { escape, at });
        await settled;

        // The whole matrix asserts ONE thing, which is what makes the six rows one finding: the
        // selection is exactly where the user left it, ring and furniture included.
        expect(await selectionAlive(page)).toEqual({ ring: true, handles: 8 });
        // ⚠ THE POST COUNT FORKS ON `escape`, AND THAT FORK IS THE S42-3 HALF OF THIS MATRIX.
        // An Escape-cancelled gesture writes NOTHING — §3.5(d)'s zero-resize-POST ruling, and the
        // half that was true at S42-2b and still is. A completed one writes exactly once.
        expect(posts, escape ? "Escape cancels: zero POSTs" : "a completed drag: exactly one POST").toHaveLength(escape ? 0 : 1);
        if (escape) {
          expect(fs.readFileSync(pageFixture).equals(originalPage!), "a cancelled gesture leaves page.tsx byte-identical").toBe(true);
        }
      });
    }
  }

  test("Escape matrix — the suppression EXPIRES on the click it consumed: the NEXT click selects normally", async ({
    page,
  }) => {
    // The half that keeps the fix from being a general shield hole. Without an expiry the latch eats
    // an arbitrary later click and the canvas silently stops selecting — a worse defect than the one
    // being fixed, and invisible to every row above.
    const points = await releasePoints(page);
    expect(points.unstamped).not.toBeNull();
    await dragAndRelease(page, { escape: true, at: points.unstamped! });
    expect(await selectionAlive(page), "the Escape-cancelled gesture kept its selection").toEqual({
      ring: true,
      handles: 8,
    });

    // …and now an ordinary click at the SAME unstamped point must deselect, exactly as it would
    // have with no gesture in the history.
    await page.mouse.click(points.unstamped!.x, points.unstamped!.y);
    expect(await selectionAlive(page), "the next click is not suppressed").toEqual({ ring: false, handles: 0 });

    // …and selecting again works, so the shield is fully back to normal.
    await page.locator(`[data-oid="${SUBJECT_OID}"]`).click({ position: { x: 6, y: 6 } });
    expect(await selectionAlive(page)).toEqual({ ring: true, handles: 8 });
  });

  test("CONTROL — a click on the element itself still selects normally, so the bypass is scoped to handles", async ({
    page,
  }) => {
    // Without this the row above passes against a shield that stopped resolving anything at all.
    await installProbes(page);
    await page.mouse.click(FIXTURE.left + FIXTURE.width / 2, FIXTURE.top + FIXTURE.height / 2);
    const probe = await readProbe(page);
    expect(probe.clickTarget, "a plain canvas click is not handle-targeted").not.toContain("[handle]");
    expect(probe.rootDelegated, "and the shield still suppresses it above the stage").toBe(0);
    await expect(page.locator("#dsh-selection-ring")).toBeVisible();
  });

  test("R42-D1 (INVERTED, G48-12) — a strip's hit band STRADDLES the element: one pixel inside each edge belongs to the band, and it still reaches outside too", async ({
    page,
  }) => {
    // ⚠ **INVERTED (plan §8, `S48-0`), and it is the most direct casualty of the reversal `S48-0` declares.** This row used to be the shipped gate ON R42-D1's outward-only ruling — it probed one pixel inside each of the four edges, asserted all four returned the ELEMENT rather than a strip, and its own RED-when named the ruling's real content: *"a band centred on the edge, which is what shipped, returns the strip here, and in this corpus 51.6 % of nested pairs are flush with their parent."* **A band centred on the edge is exactly what phase-48 ships**, so the original row goes RED on a correct implementation. It is not deleted — neither of `AGENTS.md`'s two reasons applies: the code it covers is very much alive and the assertion can plainly go RED — it is INVERTED: one pixel inside each edge now returns the band that names that edge, which is the owner's 2026-09-02 ruling made falsifiable (plan §7, `S48-0`).
    const hits = await page.evaluate(
      ({ oid, share }) => {
        const el = document.querySelector(`[data-oid="${oid}"]`)!;
        const r = el.getBoundingClientRect();
        const at = (x: number, y: number) => {
          const n = document.elementFromPoint(x, y);
          return n === null ? "null" : (n.getAttribute("data-dsh-handle") ?? `<${n.tagName.toLowerCase()}>`);
        };
        // 25 % along each edge — far enough from both corner handles that a hit there is the strip's
        // own band and nothing else's.
        const alongX = r.left + r.width * share;
        const alongY = r.top + r.height * share;
        return {
          insideTop: at(alongX, r.top + 1),
          insideBottom: at(alongX, r.bottom - 1),
          insideLeft: at(r.left + 1, alongY),
          insideRight: at(r.right - 1, alongY),
          outsideTop: at(alongX, r.top - 4),
          outsideBottom: at(alongX, r.bottom + 4),
          outsideLeft: at(r.left - 4, alongY),
          outsideRight: at(r.right + 4, alongY),
        };
      },
      { oid: SUBJECT_OID, share: 0.25 },
    );

    // THE RULING, MADE FALSIFIABLE. RED-when: ship the band wholly OUTSIDE the edge (as it shipped before this phase) — the four inside probes then return the element, which is the row's PRE-INVERSION assertion and the reason the inversion is the observable for the owner's ruling.
    expect(
      { top: hits.insideTop, bottom: hits.insideBottom, left: hits.insideLeft, right: hits.insideRight },
      "one pixel INSIDE each edge belongs to the band that names it",
    ).toEqual({ top: "n", bottom: "s", left: "w", right: "e" });

    // ⚠ **THE INSTRUMENT CONTROL SURVIVES UNTOUCHED, AND IS WHY THE INVERSION IS SAFE.** The straddling band reaches 5 px outward exactly as R42-D1's outward-only band did, so this half stays green and still distinguishes "the bands moved" from "the bands vanished". RED-when: ship the band wholly INSIDE the edge — the four outside probes then return nothing.
    expect(
      { top: hits.outsideTop, bottom: hits.outsideBottom, left: hits.outsideLeft, right: hits.outsideRight },
      "and four pixels OUTSIDE each edge still return the same band",
    ).toEqual({ top: "n", bottom: "s", left: "w", right: "e" });
  });
});
