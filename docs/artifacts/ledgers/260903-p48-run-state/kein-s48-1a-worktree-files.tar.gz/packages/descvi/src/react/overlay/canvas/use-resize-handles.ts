/**
 * use-resize-handles.ts — the resize ring's furniture: up to eight handles, the refusal marker and
 * the shared-oid hint (phase-42 S42-1; plan §3.2, §3.3, §3.10, §3.12, V3-C7, V3-C9).
 *
 * ⚠ **NOTHING HERE LISTENS FOR A POINTER.** This story renders the layer and nothing else; the
 * shield bypass, capture and the gesture land in S42-2b, the immediately following commit. Until
 * then a click on a handle still reaches the selection shield and deselects — a known, bisectable
 * one-commit window, argued in the plan's S42-1 block rather than discovered here.
 *
 * WHY DIRECT DOM. The three shipped ring divs are positioned imperatively so the shell never
 * setStates on a remeasure (the stable-`children` invariant — a re-render would take the prototype
 * page's whole subtree with it). The furniture has the same cadence and a harder constraint on top:
 * the admitted SET depends on the element's measured box, which React cannot know without a
 * measure-then-setState round trip on every tick. So the nodes are built and moved here.
 *
 * NODES ARE REUSED, NOT REBUILT. A handle keeps its identity across remeasures, keyed by compass.
 * That is not an optimisation: S42-2b puts pointer capture on one of these nodes, and a re-anchor that replaced the node under a held capture would drop the gesture. ⚠ **The SIBLING ORDER is reused too, and only touched when it must move** — the DOM append order is compared against the canonical precedence's reverse before any `appendChild` runs, so a remeasure that changes no handle's membership in the rendered set never re-parents the node under capture either (plan §4.1; see the comparison itself, below, for the full argument).
 *
 * TWO PREDICATE LAYERS, IN ORDER (§3.3):
 *  1. TARGET — `chipEditorDisabled`, threaded from the value the PANEL already computed. Never
 *     recomputed from `selectedTarget.editable`: the two diverge on a static-but-unparseable
 *     className, where `editable` is true and the panel still refuses, and keying on `editable`
 *     would put eight operable handles over a target whose write silently no-ops.
 *  2. AXIS — `parseSizing(...).reasons`, over the `ParentContext` the panel derives from the same
 *     function. Only `element-axis-controlled-by-variant` blocks: it is tested before the mode
 *     check, so it disqualifies Fixed and Hug too, while the other three reasons are Fill-only
 *     refusals and a resize writes Fixed. A handle renders iff EVERY axis it writes is unblocked —
 *     so one blocked axis costs that axis' two strips AND all four corners, leaving two handles.
 *
 * Refusal is never silent: `#dsh-ring-refusal-marker` carries the reason, in the shared bilingual
 * vocabulary the panel's own affordance uses. It is a READOUT, not a control — no
 * `data-dsh-handle`, no `data-v3-glyph-control`, `pointer-events: none` set inline.
 *
 * ⚠ S42-4 ADDED A THIRD READOUT ON THE SAME TERMS: `#dsh-ring-refusal-hint`, for a Shift aspect lock
 * REFUSED mid-drag because the axis it would derive is blocked (§3.10's cross-product). It is the
 * other half of "one-axis resize survives" — the drag continues unlocked, and this is what stops
 * that from being a silent lock-failure. Its condition is a MODIFIER rather than the selection, so
 * it is fed by a ref the gesture writes and it is placed last in the stack.
 *
 * ⚠ **C46-0 — THE UNIVERSE THE KIND VOCABULARY APPLIES TO, STATED EXHAUSTIVELY AND EXCLUSIVELY (ralplan-phase-46 §3.0).** `data-v3-glyph-control` is written at seven production sites across five files; enumerate them with `grep -rn 'data-v3-glyph-control' packages/descvi/src | grep -v __tests__` rather than from any list, this one included, because the class has been miscounted three times. **The kind vocabulary is RING-LAYER-ONLY**, and the partition is:
 *
 *  - `#dsh-handle-layer` nodes (this file) — kind `cursor` after S46-2, kind `glyph` until then;
 *  - `#dsh-spacing-layer` nodes (`use-spacing-affordances.ts`; the layer is a CHILD of `#dsh-ring-layer`), **MINUS the `#dsh-spacing-popup` subtree** — kind `glyph-conditional`;
 *  - the `#dsh-spacing-popup` subtree (`use-spacing-drag.ts`) — EXCLUDED BY ROLE, carries no marker at all (§3.5, and `e2e/spacing-gesture.spec.ts` asserts the exclusion with the popup OPEN). ⚠ **The popup is appended INTO the spacing layer, not beside it** (`use-spacing-drag.ts`'s `host` is the spacing-layer ref), which is why the row above has to CARVE IT OUT rather than simply not mention it: without the carve-out the two rows overlap on the containment key while carrying contradictory obligations, and a gate author implementing the first row's key literally (`#dsh-spacing-layer *`) would require the popup to declare a kind this row forbids. **SUBTREE, not node** — the popup's own `<input>` is a second operable unmarked node in that layer, and the shipped exclusion row already rules the excluded set to be exactly the popup subtree.
 *  - any OPERABLE node under `#dsh-ring-layer` outside the rows above — **must not exist**, and that is the whole content of the completeness half: G46-1 is what proves the row is empty, not this comment. ⚠ The subject is OPERABLE nodes: the four ring readouts (`#dsh-hover-ring`, `#dsh-selection-ring`, `#dsh-selection-badge`, `#dsh-selection-ring-pool`) are rendered, unmarked children of that layer and sit outside this row by construction, being non-hittable;
 *  - the five panel-section controls, which are OUTSIDE the ring layer — no kind, `data-v3-glyph-control=""` unchanged, untouched by phase-46.
 *
 * SaaS-seam: overlay-CLIENT code — NO `node:*` / `process` / `fs`.
 */
import { useCallback, useLayoutEffect, type RefObject } from "react";
import type { ComponentSpecType } from "@descvi/core/schema";
import { ringGroupForOid, ringGroupShades } from "./selection-ring-model";
import type { ViewportDim } from "../toolbar/ViewportControls";
import { parseSizing } from "../engine/tailwind-class-model";
import { deriveParentContext } from "../panel/parent-context";
import {
  ASPECT_LOCK_REFUSED_MESSAGES,
  AXIS_BLOCKED_MESSAGES,
  AXIS_BLOCKED_REASON,
  CHIP_DISABLED_MESSAGES,
  CHIP_DISABLED_UNKNOWN_MESSAGE,
  bilingualLine,
  type AspectLockRefusalAxis,
  type BlockedAxis,
  type ChipDisabledReason,
} from "../shared/refusal-messages";
import {
  admitHandles,
  isCornerHandle,
  HANDLE_ADMISSION_ORDER,
  HANDLE_CHIP_PX,
  type HandleCompass,
  type HandlePlacement,
  type HandleRect,
} from "./handle-geometry";
// ⚠ `createHandleGlyph` IS NO LONGER IMPORTED AND THAT IS THE ONLY TRACE C46-2 LEAVES IN THIS LINE.
// The builder is retained in `handle-glyphs.ts` on purpose — see its header — because the revert path
// P46-3 paid for is `createHandleNode`'s corner branch plus this import, and deleting the builder
// would make putting the mark back a rewrite instead of a re-append.
import { HANDLE_CURSOR } from "./handle-glyphs";
import { styleReadout } from "./readout-style";
import { instanceHintText } from "../shared/instance-hint";

/** The subset of the resolved target this layer reads. Kept structural so tests need no resolver. */
export interface ResizeHandleTarget {
  editable: boolean;
  /** Absent on a non-editable target, which is why it is optional AND nullable here. */
  className?: string | null | undefined;
  instanceIndex?: number | undefined;
  instanceCount?: number | undefined;
}

export interface ResizeHandlesParams {
  /** `#dsh-ring-layer` — the coordinate ORIGIN for every placement, exactly as for the rings. */
  ringLayerRef: RefObject<HTMLDivElement | null>;
  /** `#dsh-handle-layer` — the imperatively-owned container React never reconciles into. */
  handleLayerRef: RefObject<HTMLDivElement | null>;
  selectedEl: Element | null;
  selectedTarget: ResizeHandleTarget | null;
  /** The PANEL's computed refusal (§3.3 layer 1) — threaded, never re-derived. */
  chipEditorDisabled: boolean;
  chipDisabledReason: ChipDisabledReason | undefined;
  /** Routes the furniture to the selection ring's own group colour. */
  ringComponents: ComponentSpecType[];
  /** The panel-parity gate: no write surface, no furniture. */
  active: boolean;
  /**
   * S42-2b — where this hook publishes its own placement pass, so the drag can re-anchor the
   * furniture directly on a pointermove while the `remeasure` tick is leased away. Optional: a
   * caller that never drags (every test that only asserts the rendered layer) passes nothing.
   */
  reanchorRef?: RefObject<(() => void) | null>;
  /**
   * S42-4 — the LIVE gesture's refused aspect lock (§3.10's cross-product), or `null`.
   *
   * ⚠ A REF, AND NOT A PROP, BECAUSE THE PRODUCER IS A POINTERMOVE. The drag writes it and then
   * calls {@link ResizeHandlesParams.reanchorRef}'s published pass in the same handler, so the hint
   * is painted by the pass that is already re-anchoring the furniture. A state prop would mean a
   * React render per move on a path whose whole design is to avoid one.
   * Optional: every caller that only renders the layer passes nothing and gets no hint.
   */
  aspectLockRefusalRef?: RefObject<AspectLockRefusalAxis | null>;
  // ── Re-anchor deps, the same set the rings ride ──
  stateMap: unknown;
  deviceMode: boolean;
  dim: ViewportDim;
  collapsed: boolean;
  dark: boolean;
  tick: number;
}

/**
 * **THE TWO RESIZE z LEVELS, NAMED IN PHASE-44 S44-3 SO A CROSS-FAMILY ORDERING CAN BE COMPARED RATHER THAN COINCIDED.**
 *
 * The values are phase-42's, unchanged: a corner paints above an edge strip, so a corner wins `elementFromPoint` at its own centre even though a full-edge strip covers that point by design (S42-1 acceptance 5's parenthetical).
 *
 * ⚠ **WHAT IS NEW IS THAT A SECOND FAMILY NOW SHARES THIS LAYER'S STACKING CONTEXT.** Phase-44's spacing bands live in a sibling container under the same `#dsh-ring-layer`, and — since phase-48's straddling band puts resize surface inside the border box along the WHOLE perimeter rather than at four corners' ~7 px reach — the two families now claim the same pixels along every edge, not only near the corners. **The ruling is that RESIZE WINS**, and the whole argument, the spacing side's constants and the row that pins the inequality live at `spacing-affordance-geometry.ts`'s `SPACING_STRIP_Z`. Keep these two strictly ABOVE that family: an edit here that lowered either number would hand a resize press to a spacing band with nothing but that row to notice.
 *
 * ⚠ **CORNERS OUTRANK BANDS BY CONSTRUCTION, AND THIS PAIR IS WHERE THAT PRECEDENCE ACTUALLY LIVES (plan §4.1).** `handle-geometry.ts`'s `HANDLE_ADMISSION_ORDER` states the two intra-class orders — which corner wins a shared corner square, which band wins a shared band square — but it does NOT decide corner-over-band: `elementFromPoint` answers that by z, from this pair, whatever the list says. `packages/descvi/src/react/overlay/__tests__/spacing-affordance-geometry.test.ts`'s `expect(RESIZE_STRIP_Z).toBeLessThan(RESIZE_CORNER_Z);` row is phase-48's gate on it (`G48-9`'s corners-before-bands leg is the oracle-side half).
 */
export const RESIZE_STRIP_Z = 42;
export const RESIZE_CORNER_Z = 43;

export const HANDLE_LAYER_ID = "dsh-handle-layer";
export const REFUSAL_MARKER_ID = "dsh-ring-refusal-marker";
export const INSTANCE_HINT_ID = "dsh-ring-instance-hint";
/**
 * §3.2's THIRD ring-layer readout, and its own id is the ruling rather than a detail (S42-4).
 * G42-7 counts instance hints and G42-5 asserts the Shift refusal; a node that could carry either
 * message makes both counts ambiguous, so this one is separate from {@link INSTANCE_HINT_ID} and
 * from {@link REFUSAL_MARKER_ID} and all three STACK when their conditions hold together — which on
 * an axis-blocked shared-oid subject mid-Shift-drag is all three at once.
 */
export const SHIFT_REFUSAL_HINT_ID = "dsh-ring-refusal-hint";

/**
 * DR46-6 — the readout family's restyle, expressed as ONE number (visual spec §5.8's look half).
 *
 * §5.8 asks whether *refused* deserves a stronger visual than a thin red border. This is that
 * stronger visual and it is deliberately the smallest one that answers the question: the leading
 * edge grows to 3 px in the readout's own hue while the other three sides stay at 1 px, so the node
 * reads as a callout rather than as a hairline box. **It costs 2 px of width and nothing else** —
 * R42-D3 lays the stack out from each node's MEASURED box, so no placement clause has to be re-read.
 *
 * ⚠ **THE STRENGTH IS THE OWNER'S CALL AND THIS IS NOT PRESENTED AS SETTLED (§9 U3).** The FORM is
 * ruled — bordered, restyled — and a live pass that wants more can spend fill, weight or an icon on
 * top of it without touching a gate.
 *
 * ⚠ **IT ALSO MAKES THE BOX ASYMMETRIC, WHICH *"costs 2 px of width and nothing else"* GLOSSED.** The
 * padding stays 2 × 6, so text now sits **9 px from the leading edge and 7 px from the trailing one**.
 * That is deliberate — a callout's rule reads as attached to the text it introduces, and equalising it
 * would mean a second padding number keyed to the accent — but it is a visible asymmetry rather than a
 * free 2 px, and the owner's live read is what confirms it (§9 U3).
 */
const READOUT_ACCENT_PX = 3;

/**
 * ⚠ **THE READOUTS' SHARED LOOK NOW LIVES IN `readout-style.ts`, AND THE ARGUMENT THAT USED TO BE HERE
 * WENT WITH IT (phase-47 S47-4, plan §4.4).** The three call sites below hand it a `ReadoutTone`,
 * this z and {@link READOUT_ACCENT_PX}; the base tone that was the REFUSAL's is now `"refusal"` chosen
 * by name, so the other two readouts no longer override three colour lines in a load-bearing order.
 * G47-7b holds every one of their values byte-identical across that move.
 *
 * WHAT STAYS HERE is the z, because it is a fact about THIS family's stacking rather than about the
 * look: 41 sits BELOW {@link RESIZE_STRIP_Z} (42) and {@link RESIZE_CORNER_Z} (43) — the reason a
 * corner chip wins the 1 px it overlaps at a readout's top-left, which the gap docblocks below price.
 * ⚠ **It is NOT the family's own z, and reading it as one is a mistake this plan's round 2 actually
 * made:** the POINTER-FOLLOWING member of the family paints at 44 (`use-spacing-drag.ts`'s drag readout,
 * and phase-47's three reorder nodes with it), because a node travelling under the user's cursor cannot
 * accept being occluded by whatever it passes beneath.
 */
const READOUT_STACK_Z = 41;

/**
 * Clause 1's gap between the element and the readout adjacent to it — the position the designer
 * ruled reads as *about this*, and it is unchanged from what shipped.
 *
 * ⚠ **ITS DERIVATION IS UNTOUCHED BY C46-2 AND SAYING OTHERWISE WOULD OVERSTATE THE RESTYLE'S REACH
 * (ralplan §2.9's fourth falsified rationale, and it is NOT the same case as {@link READOUT_STACK_GAP_PX}
 * one docblock below).** This number never derived from the paint. What it carried was an ACCEPTED
 * COST priced against the paint — *"the S strip's pill overhangs the element's bottom edge by 6 px,
 * so a wide axis-blocked subject can have the pill cover the first readout's first line by 2 px"* —
 * and that sentence loses its subject when the pills go, because a strip now paints nothing that can
 * reach anything.
 *
 * **The cost does not vanish; it changes owner and shrinks, and it is re-priced here rather than quietly dropped.** The four corner chips still paint, still sit centred on the box corners, and reach `min(HANDLE_CHIP_PX, corner hit extent) / 2` past the bottom edge — phase-48's chip rule (plan §5). A readout is left-aligned to the element's left edge and starts 4 px below its bottom, so the SW chip overlaps the readout's own top-left by **1 px at most** and wins at z 43 over 41. ⚠ **That 1 px is a MAXIMUM, not a constant, and it is smaller below it.** The chip reaches its ceiling — 5 px past the edge — only where the corner hit extent is at or above `HANDLE_CHIP_PX` (10), which the ramp gives at a short side of 35 or more; below that the chip shrinks with the corner extent and the overlap shrinks with it, reaching 0 at the ramp's narrow clamp. ⚠ **An earlier draft called the overlap *"a fifth of what the pill cost"*; the fraction is dropped because it is not re-derivable** — by depth the pill's 2 px against the chip's 1 px is a half, by overlapping area a quarter, and the two answers are not the same number. What is true without arithmetic is the SHAPE of the change: the overlap is smaller, and it is at one corner instead of along the whole edge. Clause 1's answer is unchanged either way: the alternative moves the readout away from the thing it is explaining.
 */
const READOUT_ELEMENT_GAP_PX = 4;

/**
 * The gap BETWEEN stacked readouts (R42-D3 clause 4's second half).
 *
 * ⚠ **THIS ONE LOSES ITS DERIVATION OUTRIGHT AND IS DELIBERATELY NOT GIVEN A NEW ONE (ralplan §2.9's
 * third falsified rationale, §3.2's disposition).** It read: *"clause 4's 'at least the strips'
 * outward paint overhang'. The overhang is 6 px and it is derived, not picked: a strip's pill is
 * `HANDLE_CHIP_PX - 2` = 12 px on its short axis and is centred on the element's edge, so it paints
 * 6 px beyond that edge."* **No painted pixel survives C46-2 on any strip, so the quantity that
 * derived this number no longer exists.**
 *
 * **Neither candidate replacement is admissible, which is why this is now a picked value.** The
 * corner chip is ruled out BY THIS DOCBLOCK'S OWN PREDECESSOR, which excluded it by name — it
 * reaches into the element-adjacent gap {@link READOUT_ELEMENT_GAP_PX} pins at 4, not into the gap
 * between two readouts, which is what this is. And the corner chip's NEW size cannot be substituted
 * either: §9 U2a rules that S46-2 picks it and the owner's live pass may revise it, and pinning a
 * shipped constant's derivation to a value still under review is the trade this refuses.
 *
 * **So: 6 px is a plain typographic minimum** — a hair under half the 14 px line box, enough that two
 * stacked notices read as two rather than as one wrapped paragraph. The VALUE is unchanged from what
 * shipped, so no placement moves. A later phase may re-derive it once the corner's final size gives
 * it a subject again.
 */
const READOUT_STACK_GAP_PX = 6;

/**
 * R42-D3 — where the readouts go, in one place, by MEASUREMENT (visual spec §5.8's four clauses).
 *
 * WHAT THIS REPLACES AND WHY IT WAS WRONG. The shipped rule was `top = elementBottom + 4` clamped to
 * `layerHeight − 18`, with the second readout pushed a CONSTANT 18 px below the first. Measured on
 * the shipped build: with a 362 px layer and the subject at its bottom, the marker pinned at 344,
 * stood 34 px tall, and lost 16 px — the whole English half — to the layer's `overflow: hidden`,
 * while what survived painted on top of the very element it was explaining. **A refusal that is cut
 * in half has not refused, and one that hides its subject has reported on something the user can no
 * longer see.** The constant 18 was wrong on its own terms too: the hint measures 20, so the second
 * readout began 2 px inside the first.
 *
 * THE RULE, in the clauses' own order:
 *  1. preferred — {@link READOUT_ELEMENT_GAP_PX} below the element's bottom edge, left-aligned to it;
 *  2. it FLIPS, it does not clamp: when the stack's measured height does not fit between the
 *     element's bottom and the clip's bottom, the whole stack renders ABOVE the element's top edge.
 *     Clamping is the last resort and clamps TO the clip, never past it;
 *  3. it never overlaps its own subject — both the preferred and the flipped placement land clear of
 *     the element's box by construction, and only the last resort (a stack that fits on neither
 *     side of a subject that fills the layer) can touch it;
 *  4. stacking is by the PREVIOUS readout's measured height plus {@link READOUT_STACK_GAP_PX}, never
 *     by a constant. RED-when: give the hint a string long enough to wrap and watch a constant
 *     offset put the marker's top inside it.
 *
 * THE STACK MOVES AS A UNIT, which is the one thing the clauses do not say outright. Laid out
 * independently, a hint that fits below and a marker that does not would end up on OPPOSITE sides of
 * the element, which reads as two unrelated notices rather than one stack.
 *
 * ⚠ Explicitly accepted (spec §5.8): overlapping page content BELOW the element. Reserving layout
 * space for a transient overlay readout would reflow the prototype, which this tool must never do.
 */
function layoutReadouts(
  stack: readonly HTMLElement[],
  box: HandleRect,
  layer: { width: number; height: number },
): void {
  if (stack.length === 0) return;
  // MEASURED, not assumed: heights are read back after the text and styles are on the node, because
  // the message's own wrapping is what decides them. A host with no layout (jsdom) reports 0 here,
  // which degrades to a single-position stack rather than to a wrong constant.
  const heights = stack.map((node) => node.offsetHeight);
  const total = heights.reduce((sum, h) => sum + h, 0) + READOUT_STACK_GAP_PX * (stack.length - 1);

  const elementTop = box.top;
  const elementBottom = box.top + box.height;
  const below = elementBottom + READOUT_ELEMENT_GAP_PX;
  const above = elementTop - READOUT_ELEMENT_GAP_PX - total;

  let start: number;
  if (below + total <= layer.height) start = below;
  else if (above >= 0) start = above;
  else {
    // LAST RESORT — neither side holds the stack. Clamp INTO the clip (clause 2's hard half: no part
    // of a refusal may be painted outside the layer that clips it), on whichever side has more room,
    // and accept the overlap clause 3 forbids everywhere it is avoidable.
    const roomBelow = layer.height - below;
    const roomAbove = elementTop - READOUT_ELEMENT_GAP_PX;
    start = roomAbove > roomBelow ? 0 : Math.max(0, layer.height - total);
  }

  let top = start;
  for (const [index, node] of stack.entries()) {
    node.style.top = `${top}px`;
    // Left-aligned to the element, then clamped by the node's OWN measured width so a long message
    // is not pushed out through the right edge of the same layer that clips its bottom.
    node.style.left = `${Math.max(0, Math.min(box.left, layer.width - node.offsetWidth))}px`;
    top += (heights[index] ?? 0) + READOUT_STACK_GAP_PX;
  }
}

function ensureReadout(host: HTMLElement, id: string): HTMLElement {
  const existing = host.ownerDocument.getElementById(id);
  if (existing instanceof HTMLElement && host.contains(existing)) return existing;
  const node = host.ownerDocument.createElement("div");
  node.id = id;
  node.setAttribute("aria-hidden", "true");
  host.appendChild(node);
  return node;
}

function dropById(host: HTMLElement, id: string): void {
  const node = host.querySelector(`#${id}`);
  if (node !== null) node.remove();
}

/**
 * This family's DECLARED KIND (C46-1, ralplan-phase-46 §3.1 clause 2). One of the closed three-value set — `glyph`, `glyph-conditional`, `cursor` — and no fourth without amending that clause.
 *
 * ⚠ **FLIPPED TO `cursor` AT S46-2 (C46-2, ralplan §3.2), WHICH IS THE COMMIT THIS ORDERING EXISTED FOR.** S46-1 landed the mechanism with this at `glyph`, every handle still carrying one and no pixel moved — green before, green after, and the amended gates shown RED there on their own mutations. This commit changes the VALUE and the render branch below it and edits no gate, which is the whole of what P46-3 bought: putting the mark back is this line plus that branch, with no red window in either direction.
 *
 * **What the new value OWES, and it is a positive obligation rather than an exemption (§3.1 clause 4).** A node declaring `cursor` must carry the {@link HANDLE_CURSOR} entry **for its own `data-dsh-handle` value** over a non-zero hit box, and must satisfy clause 3's four-term eligibility conjunction. Membership in the table is not enough: a table a later commit could extend with `default` would be a substitute obligation satisfiable by weakening the table, which is why G46-4's live mutant is in the LOOKUP KEY and why its oracles are hand-written expectation sets rather than reads of this table.
 *
 * ⚠ **NOT IMPORTED BY ANY GATE.** The rows that check the vocabulary state the closed set by hand — the same deliberate-second-implementation discipline `e2e/resize-handles.spec.ts`'s own header states for the admission rule. Pointing a gate at this symbol would make its assertion a tautology and a widening of the set would ship green.
 */
const HANDLE_GLYPH_CONTROL_KIND = "cursor";

/**
 * Builds a handle's node once.
 *
 * ⚠ **TWO SHAPES AFTER S46-2, WHERE THERE WAS ONE (C46-2's render branch).** A CORNER is root (hittable) > chip (painted); a STRIP is a bare root and paints nothing at all. Neither carries a glyph.
 *
 * **Why the strip's chip is not built rather than built-and-unpainted.** §5.11 direction 1 is that the whole-edge hit surface does not need a painted chip; a chip node kept alive with its paint properties cleared is a pixel decision expressed as four style writes that a later edit can silently undo, while an absent node cannot be repainted by accident. The revert path is symmetric and costs the same either way — it is the `corner ?` branch here plus the kind VALUE above.
 *
 * ⚠ **THE HIT SURFACE IS UNCHANGED BY ALL OF THIS**, which is the property the restyle is not allowed to spend: the root's box comes from `admitHandles`' placement and neither the chip nor the mark ever contributed to it. `applyHandleStyle` writes the same four geometry properties it always did.
 */
function createHandleNode(doc: Document, compass: HandleCompass): HTMLElement {
  const root = doc.createElement("div");
  root.setAttribute("data-dsh-handle", compass);
  // C46-1's DECLARED KIND (ralplan-phase-46 §3.1). The marker keeps its completeness meaning — an operable node under the ring layer carrying none is still named — and its VALUE now says WHICH affordance this node offers, from the closed three-value set `glyph` | `glyph-conditional` | `cursor`. S46-1 declared `glyph` on every handle while every handle still carried one, so no pixel moved there; S46-2 is this commit, which flips the value and adds the render branch below. That ordering was a contract clause and not a preference: it is what makes a reverted look decision a kind VALUE plus a render branch, with no gate edit and no red window.
  root.setAttribute("data-v3-glyph-control", HANDLE_GLYPH_CONTROL_KIND);
  root.setAttribute("aria-hidden", "true");
  root.style.position = "absolute";
  root.style.display = "flex";
  root.style.alignItems = "center";
  root.style.justifyContent = "center";
  // The ring layer is `pointer-events: none`; a handle opts itself back in, and nothing else in the
  // layer does. That is the invariant G42-7's Universe B is keyed on.
  root.style.pointerEvents = "auto";
  root.style.cursor = HANDLE_CURSOR[compass];

  // ⚠ THE RENDER BRANCH C46-2 ADDS, and the ONLY structural difference between the two shapes. A
  // strip returns here: no chip, no mark, nothing painted — its affordance is the cursor over a hit
  // band that did not move. To put the pills back, build the chip for every compass again; to put
  // the corner mark back, re-append `createHandleGlyph(doc, compass, HANDLE_GLYPH_PX)` inside the
  // chip. Both are retained in `handle-glyphs.ts` for exactly that reason.
  if (!isCornerHandle(compass)) return root;

  const chip = doc.createElement("div");
  chip.setAttribute("data-dsh-handle-chip", "");
  chip.style.display = "flex";
  chip.style.alignItems = "center";
  chip.style.justifyContent = "center";
  chip.style.pointerEvents = "none";
  root.appendChild(chip);
  return root;
}

/**
 * Writes one placement onto its node — geometry, colour and, for a CORNER only, the painted chip.
 *
 * ⚠ **THE GEOMETRY HALF IS UNTOUCHED BY C46-2 AND THAT IS THE POINT OF THE RULING.** §5.11 direction 1 removes PAINT, never hit surface: the four writes below come straight from `admitHandles`' placement, so a strip that paints nothing is exactly as grabbable as the one that painted a pill. The e2e bounds checker measures the rendered rect and is what would notice otherwise.
 */
function applyHandleStyle(
  root: HTMLElement,
  placement: HandlePlacement,
  deep: string,
  isDark: boolean,
): void {
  root.style.left = `${placement.left}px`;
  root.style.top = `${placement.top}px`;
  root.style.width = `${placement.width}px`;
  root.style.height = `${placement.height}px`;
  // Corners paint ABOVE strips, so a corner wins `elementFromPoint` at its own centre even though a
  // full-edge strip covers that point by design (S42-1 acceptance 5's parenthetical).
  root.style.zIndex = String(isCornerHandle(placement.compass) ? RESIZE_CORNER_Z : RESIZE_STRIP_Z);
  // ⚠ **DEAD IN PRODUCTION AFTER S46-2, AND RETAINED ON PURPOSE — ralplan §2.9's SIXTH falsified
  // rationale, found by the fix round rather than by the plan's own enumeration.** Its only consumer
  // was the glyph's `currentColor`; the chip's border below spends `deep` directly and inherits
  // nothing. It stays because it is part of the same revert path as `createHandleGlyph` and
  // `HANDLE_GLYPH_PX` — a re-appended mark reads its colour from here — and unlike those two it had
  // no note saying so, so a cleanup would have deleted it and quietly broken the documented revert.
  root.style.color = deep;

  // A STRIP HAS NO CHIP AT ALL after S46-2, so there is nothing here to paint. This is the same
  // branch `createHandleNode` takes, read from the other side — a strip's root has no element child.
  const chip = root.firstElementChild;
  if (!(chip instanceof HTMLElement)) return;

  // The corner chip. ⚠ R42-D2's STANDING CONDITION BINDS THIS BLOCK AND SURVIVES THE SHRINK: *"a
  // later restyle may change the fill, the radius and the shadow; it may not drop the border for a
  // fill-only chip."* With the glyph gone the 1.5 px group-coloured border is the ONLY group colour
  // left on a handle and it is the whole of what makes a chip read as furniture rather than as part
  // of the prototype — so it is load-bearing here in a way it was not while the mark shared the job.
  // §5.5's binding narrows to it for the same reason, and the marginal light-mode ratios it publishes
  // (teal 3.74, orange 3.56) are now ratios OF THIS BORDER against the fill.
  const chipSize = Math.min(HANDLE_CHIP_PX, placement.width, placement.height);
  chip.style.width = `${chipSize}px`;
  chip.style.height = `${chipSize}px`;
  chip.style.borderRadius = "3px";
  chip.style.backgroundColor = isDark ? "#0F141A" : "#FFFFFF";
  chip.style.border = `1.5px solid ${deep}`;
  chip.style.boxShadow = isDark ? "0 1px 3px rgba(0,0,0,0.55)" : "0 1px 2px rgba(15,23,42,0.20)";
}

/**
 * The furniture effect. One pass per re-anchor: measure, decide, place, sync.
 *
 * Re-anchor deps are the rings' own set — anything that can shift the element's geometry — plus the
 * two predicate inputs, because a refusal can change without any geometry moving at all.
 */
export function useResizeHandles({
  ringLayerRef,
  handleLayerRef,
  selectedEl,
  selectedTarget,
  chipEditorDisabled,
  chipDisabledReason,
  ringComponents,
  active,
  reanchorRef,
  aspectLockRefusalRef,
  stateMap,
  deviceMode,
  dim,
  collapsed,
  dark,
  tick,
}: ResizeHandlesParams): void {
  /**
   * ONE PASS, EXTRACTED SO A GESTURE CAN DRIVE IT DIRECTLY (S42-2b). The effect below still runs it
   * on every re-anchor dep, which is unchanged; what is new is that the drag can call the SAME pass
   * per pointermove while the geometry lease is held and the `remeasure` tick is suppressed. Two
   * placement paths would be two answers about where a handle is — this is one.
   */
  const placeFurniture = useCallback((): void => {
    const layer = ringLayerRef.current;
    const host = handleLayerRef.current;
    if (layer === null || host === null) return;
    const doc = host.ownerDocument;
    const isDark = layer.closest(".dark") !== null;

    const clearAll = (): void => {
      for (const node of Array.from(host.querySelectorAll("[data-dsh-handle]"))) node.remove();
      dropById(host, REFUSAL_MARKER_ID);
      dropById(host, INSTANCE_HINT_ID);
      dropById(host, SHIFT_REFUSAL_HINT_ID);
    };

    if (!active || selectedTarget === null || !(selectedEl instanceof HTMLElement)) {
      clearAll();
      return;
    }

    // ⚠ DEGENERATE-MEASUREMENT GUARD, in PARITY with the selection ring's (KI-19, `4e2c26f`). A
    // `selectedEl` held across a structural op's HMR round can be a node React has already replaced,
    // and measuring it returns an ALL-ZERO rect — which here would park the whole furniture set at
    // the layer origin, the same phantom the ring's guard exists to remove.
    //
    // KEEP the last placement rather than clearing, and the parity is the reason: the ring KEEPS its
    // last geometry on this exact condition, so clearing would make the furniture vanish from under
    // a ring that is still painted — a third behaviour for one state, and the more confusing half of
    // it. Nothing was ever painted before the first successful pass, so this cannot manufacture a
    // handle out of nothing; a genuine deselect arrives as `selectedTarget === null` above and still
    // clears. Like the ring's, this removes the wrong geometry and not the cause, which is KI-19's.
    if (!selectedEl.isConnected) return;

    // ── Layer-relative geometry, the same measurement the selection ring takes ──
    const layerRect = layer.getBoundingClientRect();
    const elRect = selectedEl.getBoundingClientRect();
    const box: HandleRect = {
      left: elRect.left - layerRect.left,
      top: elRect.top - layerRect.top,
      width: elRect.width,
      height: elRect.height,
    };

    // ── §3.3 layer 1: the target ──
    let blocked: BlockedAxis | null = null;
    let refusalText: string | null = null;
    let refusalReason: string | null = null;
    let axes = { width: true, height: true };

    if (chipEditorDisabled) {
      // W4 — the fallback states a GENERIC refusal, never a specific one. The panel always threads a
      // reason beside the flag, so this arm is unreachable today; the shape that made it worth
      // changing is what it would do IF reached: naming `dynamic-class` would tell a user their
      // className is computed at runtime on a target refused for some other reason entirely, and a
      // confident wrong reason is worse than an honest vague one.
      refusalReason = chipDisabledReason ?? null;
      refusalText =
        chipDisabledReason === undefined
          ? bilingualLine(CHIP_DISABLED_UNKNOWN_MESSAGE)
          : bilingualLine(CHIP_DISABLED_MESSAGES[chipDisabledReason]);
      axes = { width: false, height: false };
    } else {
      // ── §3.3 layer 2: the axes ──
      const className = selectedTarget.editable ? (selectedTarget.className ?? "") : "";
      const parsed = parseSizing({ className, parentContext: deriveParentContext(selectedEl) });
      const shadowed = parsed.reasons.filter((r) => r.reason === AXIS_BLOCKED_REASON);
      const widthBlocked = shadowed.some((r) => r.axis === "w");
      const heightBlocked = shadowed.some((r) => r.axis === "h");
      axes = { width: !widthBlocked, height: !heightBlocked };
      blocked = widthBlocked && heightBlocked ? "both" : widthBlocked ? "width" : heightBlocked ? "height" : null;
      if (blocked !== null) {
        refusalReason = AXIS_BLOCKED_REASON;
        refusalText = bilingualLine(AXIS_BLOCKED_MESSAGES[blocked]);
      }
    }

    const placements = axes.width || axes.height ? admitHandles({ box, axes }) : [];

    // ── Sync the handle nodes, reusing by compass ──
    const wanted = new Map<HandleCompass, HandlePlacement>();
    for (const placement of placements) wanted.set(placement.compass, placement);
    for (const node of Array.from(host.querySelectorAll("[data-dsh-handle]"))) {
      const compass = node.getAttribute("data-dsh-handle") as HandleCompass | null;
      if (compass === null || !wanted.has(compass)) node.remove();
    }
    const deep = ringGroupShades(
      ringGroupForOid(selectedEl.getAttribute("data-oid"), ringComponents),
      isDark,
    ).deep;
    for (const [compass, placement] of wanted) {
      const existing = host.querySelector<HTMLElement>(`[data-dsh-handle="${compass}"]`);
      const node = existing ?? createHandleNode(doc, compass);
      if (existing === null) host.appendChild(node);
      applyHandleStyle(node, placement, deep, isDark);
    }
    // ⚠ **THE CONDITIONAL REORDER (plan §4.1).**
    //
    // WHY REVERSE PRIORITY IS THE SIBLING SEQUENCE. `HANDLE_ADMISSION_ORDER` is read two ways (`handle-geometry.ts`'s own docblock): as a priority list for the unit oracles' first-match ownership, and — read BACKWARDS — as the DOM paint order here, because `elementFromPoint` resolves an overlap to whichever candidate paints LAST (topmost in the stacking order among siblings that share a z-index, which every corner does against every corner and every band does against every band). So the LOWEST-priority compass must be the FIRST child and the HIGHEST-priority compass the LAST, which is exactly `[...HANDLE_ADMISSION_ORDER].reverse()`.
    //
    // WHY THE COMPARISON IS CONDITIONAL, RATHER THAN AN UNCONDITIONAL `appendChild` LOOP. This placement pass runs on every pointermove of a LIVE drag (the gesture re-measures and re-anchors on each tick), and the node CURRENTLY HOLDING `setPointerCapture` is one of the very nodes this loop could re-parent. `appendChild` on a node that already has a parent MOVES it rather than cloning it, and moving a node mid-capture is exactly the hazard the module docblock's "NODES ARE REUSED, NOT REBUILT" invariant (above) exists to rule out — capture survives a MOVE in every browser this app targets, but the DOM order comparison here is what keeps a size-only, set-unchanged remeasure from touching the DOM at all, rather than relying on that survival on every single tick of every drag.
    //
    // THE TWO LEVERS THAT CAN CHANGE THE RENDERED SET, AND SO CAN MAKE THIS BRANCH FIRE: the AXIS filter (`handleAxes`, applied inside `admitHandles` — a resize that blocks a writable axis shrinks `wanted` to two handles) and `chipEditorDisabled` (§3.3 layer 1 — a target that stops being editable empties `wanted` to zero). Neither lever is exercised by a plain size or position change, which is why `e2e/resize-handles.spec.ts`'s `G48-9` browser leg — inline styles only — cannot drive this branch and the unit-level rig (`packages/descvi/src/react/overlay/__tests__/resize-handle-layer.test.tsx#describe("G48-9 conditional reorder — unit level (the history-dependence path §4.1 names; the e2e leg cannot change the rendered set)", () => {`) does, by controlling `className` directly.
    const desiredOrder = [...HANDLE_ADMISSION_ORDER].reverse().filter((compass) => wanted.has(compass));
    const currentOrder = Array.from(host.querySelectorAll<HTMLElement>("[data-dsh-handle]"))
      .map((node) => node.getAttribute("data-dsh-handle"));
    if (desiredOrder.length !== currentOrder.length || desiredOrder.some((compass, index) => compass !== currentOrder[index])) {
      for (const compass of desiredOrder) host.appendChild(host.querySelector<HTMLElement>(`[data-dsh-handle="${compass}"]`)!);
    }

    // ── The THREE readouts. They STACK: an axis-blocked shared-oid target mid-Shift-drag shows all
    // three at once, each counted by its own id (§3.2, §3.3, §3.10) ──
    // CONTENT FIRST, GEOMETRY SECOND, and the order is the point: R42-D3's placement is decided from
    // each node's MEASURED height, which is not knowable until its text and styling are on it. The
    // instance hint takes the slot nearest the element, as it always has, then the marker, then the
    // transient lock refusal; `layoutReadouts` places the whole stack as a unit.
    const stack: HTMLElement[] = [];

    const instanceCount = selectedTarget.instanceCount;
    if (instanceCount !== undefined && instanceCount > 1) {
      const hint = ensureReadout(host, INSTANCE_HINT_ID);
      // ⚠ **`tone: "info"` IS THE THREE COLOUR OVERRIDES THIS CALL SITE USED TO CARRY (phase-47 S47-4).**
      // They were `color`, `border` and `borderLeftColor`, written in that order because the shorthand
      // resets all four sides — the order is now inside `styleReadout` and cannot be got wrong here. The
      // measured argument for the exact light slate is unchanged and is directly below.
      styleReadout(hint, { isDark, tone: "info", zIndex: READOUT_STACK_Z, accentPx: READOUT_ACCENT_PX });
      // ⚠ **THE LIGHT SLATE — `#56657A`, now the `info` TONE'S light value in `readout-style.ts` (S47-4
      // MOVED THE LITERAL, NOT THE DECISION) — WAS RAISED HALF A STEP RATHER THAN THE FULL STEP THE PLAN
      // PRESCRIBED (C46-4, visual spec §5.7's routed follow-up), MEASURED, NOT PREFERRED.**
      // It was `#64748B` (slate-500), which §5.7 measures at 4.76 against this fill: the weakest text
      // in the family, clearing AA's 4.5 for a 10 px string by 0.26.
      //
      // **The obvious move is slate-600 `#475569`. It is REFUSED at 7.58, on two independent grounds,
      // and the first is decisive on its own:**
      //
      //  1. It falsifies §5.9(1) — *"every contrast in §5.5 and §5.7 is higher in dark than in light"*
      //     — for this member, since the dark slate measures 7.21. That finding is INHERITED by this
      //     phase and the restyle is forbidden to invert it.
      //  2. It would make the INSTANCE HINT — the one INFORMATIONAL readout in a family whose other
      //     two members are refusals — the loudest member of its own family, in either theme.
      //
      // ⚠ **CLAUSE 2 IS STATED NARROWLY ON PURPOSE, AND AN EARLIER DRAFT OF THIS COMMENT OVERSTATED IT
      // INTO A CLAIM THE SHIPPED BUILD ALREADY FALSIFIES.** That draft argued the hint must not
      // out-shout *a refusal* — but at 5.94 it does out-shout the Shift-lock refusal's 5.02, so the
      // draft's own rule condemned the value it was defending. Worse, **contrast ratio has never been
      // this family's urgency ordering**: measured on the shipped, designer-signed-off build, DARK
      // ranks the transient Shift-lock refusal at 12.83 ABOVE the hard refusal marker's 9.75. A rule
      // the build broke before this commit cannot be the reason for a decision inside it.
      //
      // **What IS true of all three members, in both themes, before and after this change: the
      // informational readout is never the loudest.** Light before: 6.47 > 5.02 > 4.76. Light after:
      // 6.47 > 5.94 > 5.02. Dark, untouched: 12.83 > 9.75 > 7.21. Under `#475569`: 7.58 leads in
      // light — the one arrangement that breaks it. The SEMANTIC ranking is carried by hue, which is
      // §5.7's own position (*"they differ only in hue ... and that is enough"*), not by ratio.
      //
      // `#56657A` is the exact per-channel MIDPOINT of slate-500 and slate-600 — on the ramp, not an
      // invented hue — and measures **5.94**: AA cleared by 1.44 instead of 0.26, still under the
      // marker's 6.47, still under its own dark counterpart. All figures from a probe that reproduces
      // §5.7's published marker, hint and Shift-lock figures and §5.5's six group figures exactly
      // before being pointed at anything new. The DARK slate is not touched; it was never marginal.
      //
      // ⚠ **THE FAMILY'S MARGINAL SEAT MOVED IN THIS COMMIT AND IS RECORDED RATHER THAN LEFT:** the
      // weakest LIGHT member is now the Shift-lock refusal at 5.02, not this hint. It clears AA and is
      // not a defect; it is the next candidate if a later pass raises this family again, and §5.7 says
      // so. Not raised here because this story's §5.7 obligation is the hint and the third readout's
      // ROW, and moving a second colour on the same pass would leave the owner's live read unable to
      // attribute what changed.
      // ⚠ **THE EXPLICIT `visibility: visible` RE-DECLARATION, AND IT IS NOT REDUNDANT (phase-47 §4.1(h), C47-1, M4).**
      // A reorder drag hides the canvas furniture for the duration of the gesture by setting
      // `visibility: hidden` on `#dsh-handle-layer` — and THIS NODE IS A CHILD OF THAT LAYER, while
      // `visibility` INHERITS. The instance hint is the one readout in that layer that must SURVIVE the drag
      // (a `.map()` subject reorders all N rendered instances from one request, and the hint is what says so),
      // so it re-declares its own value and the inherited hide stops at it. The layer's two other readouts —
      // `#dsh-ring-refusal-marker` and `#dsh-ring-refusal-hint` — are deliberately left to inherit the hide.
      //
      // ⚠ It is written on EVERY styling pass rather than once at creation, because `ensureReadout` recreates
      // this node whenever `dropById` has taken it out (an instance count that fell to 1 and rose again, a
      // selection switch mid-drag), and a re-created node carries no inline style. G47-16 leg (ii) deletes
      // exactly this line; the r2 mutation it replaces ("add the hint to the hidden set") was green on the
      // defect and on the correct behaviour alike, because the hint was already inside the hidden layer.
      hint.style.visibility = "visible";
      // ONE producer, shared with the panel's own hint (W3). Two literals were one claim that could
      // drift in front of the user while both surfaces' tests stayed green.
      hint.textContent = instanceHintText(selectedTarget.instanceIndex, instanceCount);
      stack.push(hint);
    } else {
      dropById(host, INSTANCE_HINT_ID);
    }

    if (refusalText !== null) {
      const marker = ensureReadout(host, REFUSAL_MARKER_ID);
      // The tone that used to be the function's hard-coded DEFAULT, now named. Nothing about this node's
      // look changes; what changes is that the next reader can see which tone it is in.
      styleReadout(marker, { isDark, tone: "refusal", zIndex: READOUT_STACK_Z, accentPx: READOUT_ACCENT_PX });
      if (refusalReason !== null) marker.setAttribute("data-reason", refusalReason);
      if (blocked !== null) marker.setAttribute("data-blocked-axis", blocked);
      else marker.removeAttribute("data-blocked-axis");
      marker.textContent = refusalText;
      stack.push(marker);
    } else {
      dropById(host, REFUSAL_MARKER_ID);
    }

    // ── §3.10's REFUSED ASPECT LOCK, the transient one ──
    // Last in the stack because it is the only readout whose condition is a modifier key: the two
    // above describe the SELECTION and persist for as long as it does, while this one appears and
    // disappears with Shift, and a readout that moved the persistent ones on every press would make
    // the stack jump under the user's own drag.
    const lockRefusalAxis = aspectLockRefusalRef?.current ?? null;
    if (lockRefusalAxis !== null) {
      const lockHint = ensureReadout(host, SHIFT_REFUSAL_HINT_ID);
      // `tone: "caution"` — the amber this call site used to write by hand. Its own contrast is 5.02
      // light / 12.83 dark on the same probe: it clears AA in both themes and is not the family's
      // marginal member, so the accent spends shape and nothing else.
      styleReadout(lockHint, { isDark, tone: "caution", zIndex: READOUT_STACK_Z, accentPx: READOUT_ACCENT_PX });
      // The SHARED constant, not a second spelling of the string three files away — which is the
      // exact pattern W2 exists to stop, and it had already produced two literals in THIS file.
      //
      // ⚠ IT IS ASSERTED, NOT DERIVED, AND HERE IS WHY IT CANNOT BE WRONG TODAY. The gesture publishes
      // only the AXIS, so this line names the reason rather than carrying it — which would be a defect
      // the moment a fixed write could refuse for two different whole-axis reasons. It cannot:
      // `sizingRefusalFor` tests `axisShadowedByVariant` FIRST and then returns `null` for every
      // non-`fill` mode, so a resize (which writes `fixed`) has exactly one reachable refusal reason.
      // A second whole-axis member would break that, and the fix then is to widen the ref to carry the
      // typed reason the machine already produces in `AspectLockRefusal` — not to add a second literal.
      lockHint.setAttribute("data-reason", AXIS_BLOCKED_REASON);
      lockHint.setAttribute("data-blocked-axis", lockRefusalAxis);
      lockHint.textContent = bilingualLine(ASPECT_LOCK_REFUSED_MESSAGES[lockRefusalAxis]);
      stack.push(lockHint);
    } else {
      dropById(host, SHIFT_REFUSAL_HINT_ID);
    }

    layoutReadouts(stack, box, { width: layerRect.width, height: layerRect.height });
    // The pass reads only what it measures and decides from; the RE-ANCHOR triggers live on the
    // effect below, which is where "run this again" belongs. Keeping them here instead would make
    // this callback's identity the re-anchor mechanism, which reads as a stale-closure bug.
  }, [
    selectedEl,
    selectedTarget,
    chipEditorDisabled,
    chipDisabledReason,
    ringComponents,
    active,
    ringLayerRef,
    handleLayerRef,
    // The REF, never its `.current`: the pass reads the live cell every time it runs, and putting
    // the value here would rebuild the callback mid-gesture and drop the ref the drag is holding.
    aspectLockRefusalRef,
  ]);

  useLayoutEffect(() => {
    placeFurniture();
    if (reanchorRef === undefined) return;
    // PUBLISHED, not exported: the ref holds the pass that closes over THIS render's props, and the
    // cleanup drops it only when it is still the one it published — so a stale render can never
    // leave a gesture holding a placement pass for a target that is no longer selected.
    reanchorRef.current = placeFurniture;
    return () => {
      if (reanchorRef.current === placeFurniture) reanchorRef.current = null;
    };
  }, [placeFurniture, reanchorRef, stateMap, deviceMode, dim, collapsed, dark, tick]);
}
