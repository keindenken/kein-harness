import { describe, expect, it } from "vitest";
import {
  admitHandles,
  buildEffectiveClip,
  buildHandleRegions,
  compassPoint,
  fitsInClip,
  FRAME_CORNER_RADIUS_PX,
  HANDLE_ADMISSION_ORDER,
  HANDLE_CHIP_PX,
  HANDLE_GLYPH_PX,
  HANDLE_HIT_PX,
  hitSizeFor,
  placeHandle,
  STRIP_EDGE_COVERAGE_MIN,
  STRIP_HIT_BAND_PX,
  type EffectiveClip,
  type HandleCompass,
  type HandleRect,
} from "../canvas/handle-geometry";

// ⚠ DELIBERATE SECOND IMPLEMENTATION (plan §7). This oracle imports the region builder and `admitHandles` themselves, because that IS the subject under test, but it never imports the ramp endpoints, the band thickness or any other production CONSTANT it checks — every numeric expectation below is a literal, and the eight compass names are hand-typed rather than read off `HANDLE_ADMISSION_ORDER` wherever a test's own subject is the model's GEOMETRY rather than the precedence list itself. An oracle that read the constants it is pinning would move with the implementation and ship green on a mistyped breakpoint.

const ALL_EIGHT: readonly HandleCompass[] = ["nw", "ne", "se", "sw", "n", "e", "s", "w"];
const CANONICAL_ORDER: readonly HandleCompass[] = ["nw", "ne", "se", "sw", "n", "e", "s", "w"];
const CORNER_COMPASSES: readonly HandleCompass[] = ["nw", "ne", "se", "sw"];

function placements(box: HandleRect) {
  return admitHandles({ box, axes: { width: true, height: true } });
}

/** Point-in-rect over ONE emitted region — no clip, since the model itself computes none (plan §2). */
function pointInRegion(x: number, y: number, r: { left: number; top: number; width: number; height: number }): boolean {
  return x >= r.left && x <= r.left + r.width && y >= r.top && y <= r.top + r.height;
}

/**
 * First-match ownership over `order` (plan §4.1's "priority list, first match wins"). The oracle's own hit-test, built on the production REGION SET but resolving overlap itself, exactly as `hitTestRegions` does in the lab.
 */
function ownerAt(
  regions: readonly { compass: HandleCompass; left: number; top: number; width: number; height: number }[],
  order: readonly HandleCompass[],
  x: number,
  y: number,
): HandleCompass | null {
  const byCompass = new Map(regions.map((r) => [r.compass, r]));
  for (const compass of order) {
    const region = byCompass.get(compass);
    if (region !== undefined && pointInRegion(x, y, region)) return compass;
  }
  return null;
}

describe("handle geometry — §3.3's axis layer, applied FIRST", () => {
  it("keeps only handles whose complete write set is writable", () => {
    const box = { left: 0, top: 0, width: 100, height: 100 };
    expect(admitHandles({ box, axes: { width: false, height: true } }).map((p) => p.compass)).toEqual(["n", "s"]);
    expect(admitHandles({ box, axes: { width: true, height: false } }).map((p) => p.compass)).toEqual(["e", "w"]);
    expect(admitHandles({ box, axes: { width: false, height: false } })).toEqual([]);
  });
});

describe("handle geometry — the admission order and its constants (KEEP, plan §7: same KIND of claim, new subject)", () => {
  it("declares corners before bands in canonical priority", () => {
    expect(HANDLE_ADMISSION_ORDER).toEqual(ALL_EIGHT);
    expect(HANDLE_ADMISSION_ORDER.slice(0, 4)).toEqual(["nw", "ne", "se", "sw"]);
    expect(HANDLE_ADMISSION_ORDER.slice(4)).toEqual(["n", "e", "s", "w"]);
  });

  // ⚠ RESTORED (plan §4 — `HANDLE_GLYPH_PX` survives this phase) — dropped without a named `AGENTS.md` reason; neither deletion reason applies to its bound.
  it("the glyph sits inside acceptance 4's 6–10 px bound", () => {
    expect(HANDLE_GLYPH_PX).toBeGreaterThanOrEqual(6);
    expect(HANDLE_GLYPH_PX).toBeLessThanOrEqual(10);
  });

  // ⚠ RESTORED, MARKED TRANSITIONAL — this row was dropped with neither `AGENTS.md` deletion reason available: `HANDLE_HIT_PX` is still exported this commit (plan §7, `S48-1a`; deleted in `S48-1b`) and the row can still go RED (a typo that widened or narrowed the retired decidability extent). It pins the RETIRED table's own bound while the constant waits for deletion, not a claim about the shipped model.
  it("⚠ TRANSITIONAL (deleted in S48-1b): the hit extent sits inside acceptance 4's 16–24 px band", () => {
    expect(HANDLE_HIT_PX).toBeGreaterThanOrEqual(16);
    expect(HANDLE_HIT_PX).toBeLessThanOrEqual(24);
  });

  // ⚠ RESTORED, MARKED TRANSITIONAL — same basis as the row above: `STRIP_HIT_BAND_PX` and `HANDLE_HIT_PX` are both still exported this commit, so neither deletion reason applies to dropping this pin either. Verbatim from `git show 5a53259:packages/descvi/src/react/overlay/__tests__/handle-geometry.test.ts` apart from this marking.
  it("⚠ TRANSITIONAL (deleted in S48-1b): R42-D1 — the strip band is a SEPARATE, smaller number than the decidability extent", () => {
    // Two unrelated jobs that shared one symbol: the extent decides which furniture is admitted, the band is how far outside its edge a strip is grabbable. A band that grew back to the extent would re-couple them, and clause 1's separation would start moving with an ergonomics decision — which is what this row refuses.
    expect(STRIP_HIT_BAND_PX).toBeLessThan(HANDLE_HIT_PX);
    // ⚠ **RE-POINTED AT phase-46 S46-2, NOT DELETED, AND `AGENTS.md`'s TWO-REASON RULE IS WHY THE DISTINCTION MATTERS HERE.** This read `≥ (HANDLE_CHIP_PX − 2) / 2` and its stated premise was *"it must still cover the painted PILL's outward overhang: the pill is centred on the edge and reaches (HANDLE_CHIP_PX − 2) / 2 beyond it"*. C46-2 removes every painted pixel from every strip, so that premise loses its subject — the assertion still PASSES, which is exactly the dangerous shape ralplan P46-5 names: it can no longer go RED for the thing it measures.
    //
    // **Deletion was available and is refused, because NEITHER permitted reason applies.** The code it covered is not gone — `STRIP_HIT_BAND_PX` and `HANDLE_CHIP_PX` both still ship and are both still painted-geometry numbers — and the assertion can still go RED, just about a different overhang. So it keeps a subject instead of a burial: **UNDER THE RETIRED MODEL, the CORNER chip was what reached across a strip's edge**, centred on the box corner and reaching `HANDLE_CHIP_PX / 2` past it, and a strip's band narrower than that would have left painted furniture sitting outside anything grabbable at the very place two handles met. ⚠ **SCOPED TO THE RETIRED MODEL** — this row pins a relationship between two TRANSITIONAL numbers (`STRIP_HIT_BAND_PX`, `HANDLE_CHIP_PX`) that no shipped code path reads any more; the shipped model's own band-vs-chip relationship is a different pair (`HANDLE_BAND_PX` and `min(HANDLE_CHIP_PX, corner extent)`) and is not this row's subject.
    expect(STRIP_HIT_BAND_PX).toBeGreaterThanOrEqual(HANDLE_CHIP_PX / 2);
  });

  // ⚠ RESTORED, MARKED TRANSITIONAL — `hitSizeFor` is still exported and uncalled this commit (plan §7, `S48-1a`; deleted in `S48-1b` with the constants it reads), so neither `AGENTS.md` deletion reason applies to dropping its pin either. This row pins the RETIRED table's own shape while it waits, against the values it has always answered from (`HANDLE_HIT_PX` and `STRIP_HIT_BAND_PX`, both transitional beside it) — not a claim about the shipped model, which `buildHandleRegions` answers in its place (plan §4.1).
  it("⚠ TRANSITIONAL (deleted in S48-1b): hitSizeFor is square for a corner and edge-long × band for a strip", () => {
    const box: HandleRect = { left: 200, top: 200, width: 100, height: 100 };
    expect(hitSizeFor(box, "se")).toEqual({ width: 20, height: 20 });
    expect(hitSizeFor(box, "s")).toEqual({ width: 100, height: 12 });
    expect(hitSizeFor(box, "w")).toEqual({ width: 12, height: 100 });
  });
});

// ⚠ RESTORED, MARKED TRANSITIONAL — dropped with neither `AGENTS.md` deletion reason available: `buildEffectiveClip` is still exported and uncalled this commit (plan §7, `S48-1a`; deleted in `S48-1b`) and both rows below can still go RED (a defect in the retired clip's own rect-intersection or arc-count arithmetic). Verbatim from `git show 5a53259:packages/descvi/src/react/overlay/__tests__/handle-geometry.test.ts` apart from this marking and the describe title.
describe("⚠ TRANSITIONAL (deleted in S48-1b): handle geometry — the effective clip is the INTERSECTION, arcs included", () => {
  it("takes the tighter rect of the two clippers and carries four arcs", () => {
    const clip: EffectiveClip = buildEffectiveClip(
      { left: 0, top: 0, width: 800, height: 600 },
      { left: 10, top: 10, width: 100, height: 100 },
    );
    expect(clip).toMatchObject({ left: 10, top: 10, right: 110, bottom: 110 });
    expect(clip.arcs.length).toBe(4);
  });

  it("with no frame there are no arcs, and the layer rect is the whole clip", () => {
    const clip: EffectiveClip = buildEffectiveClip({ left: 0, top: 0, width: 800, height: 600 }, null);
    expect(clip.arcs.length).toBe(0);
    expect(clip).toMatchObject({ left: 0, top: 0, right: 800, bottom: 600 });
  });
});

// ⚠ RESTORED, MARKED TRANSITIONAL (docs/e3/tracker.md's phase-48 disposition table, A1) — `placeHandle`, `fitsInClip` and `compassPoint` are still exported this commit (plan §7, `S48-1a`; `placeHandle`/`fitsInClip` deleted in `S48-1b`) and every row below can still go RED (a defect in the retired push-and-clip arithmetic these functions still compute). Verbatim from `git show 5a53259:packages/descvi/src/react/overlay/__tests__/handle-geometry.test.ts` apart from this marking, the describe title, and being split across two describes instead of one ("a comfortable subject, nothing clipped").
describe("⚠ TRANSITIONAL (deleted in S48-1b): handle geometry — placeHandle's push-and-clip arithmetic, on a comfortable subject", () => {
  const LAYER: HandleRect = { left: 0, top: 0, width: 800, height: 600 };
  const FRAME: HandleRect = { left: -1, top: -1, width: 802, height: 602 };
  const CLIP: EffectiveClip = buildEffectiveClip(LAYER, FRAME);
  const box: HandleRect = { left: 200, top: 200, width: 100, height: 100 };

  it("a corner's hit box is 20×20 CENTRED on the element corner", () => {
    const nw = placeHandle(box, "nw", CLIP);
    expect(nw).toMatchObject({ left: 190, top: 190, width: 20, height: 20 });
    expect(nw.centre).toEqual({ x: 200, y: 200 });
    expect(nw.anchor).toEqual({ x: 200, y: 200 });
  });

  it("a strip spans its whole edge on the long axis and the BAND on the short one — R42-D1", () => {
    // The band is 12 and it hangs OUTSIDE: N runs from `top − 12` to `top`, E from `right` to
    // `right + 12`. Coordinates to the digit, because this describe is the oracle for the RETIRED constants.
    const n = placeHandle(box, "n", CLIP);
    expect(n).toMatchObject({ left: 200, top: 188, width: 100, height: 12 });
    expect(n.edgeCoverage).toBe(1);
    const e = placeHandle(box, "e", CLIP);
    expect(e).toMatchObject({ left: 300, top: 200, width: 12, height: 100 });
    expect(e.edgeCoverage).toBe(1);
  });

  it("R42-D1 — NO PART of a strip's band is inside the element's border box, on any of the four", () => {
    const right = box.left + box.width;
    const bottom = box.top + box.height;
    const n = placeHandle(box, "n", CLIP);
    expect(n.top + n.height).toBeCloseTo(box.top, 9);
    const s = placeHandle(box, "s", CLIP);
    expect(s.top).toBeCloseTo(bottom, 9);
    const w = placeHandle(box, "w", CLIP);
    expect(w.left + w.width).toBeCloseTo(box.left, 9);
    const e = placeHandle(box, "e", CLIP);
    expect(e.left).toBeCloseTo(right, 9);
    // …and the band is its OWN number, not the decidability extent it used to borrow.
    for (const p of [n, s, w, e]) {
      const short = Math.min(p.width, p.height);
      expect(short).toBe(STRIP_HIT_BAND_PX);
    }
  });

  it("R42-D1 — the CORNERS keep their centred square, which is the half the ruling did NOT change", () => {
    for (const compass of ["nw", "ne", "se", "sw"] as const) {
      const p = placeHandle(box, compass, CLIP);
      expect(p.width).toBe(HANDLE_HIT_PX);
      expect(p.height).toBe(HANDLE_HIT_PX);
      expect(p.centre).toEqual(compassPoint(box, compass));
    }
  });

  it("every strip's long axis is at least 90 % of its edge (acceptance 9's shape, in arithmetic)", () => {
    for (const compass of ["n", "e", "s", "w"] as const) {
      const p = placeHandle(box, compass, CLIP);
      const edge = compass === "n" || compass === "s" ? box.width : box.height;
      const long = compass === "n" || compass === "s" ? p.width : p.height;
      expect(long / edge).toBeGreaterThanOrEqual(STRIP_EDGE_COVERAGE_MIN);
    }
  });
});

// ⚠ RESTORED, MARKED TRANSITIONAL (docs/e3/tracker.md's phase-48 disposition table, A1) — same basis as the describe above; the fourth row here (the arc trim) is the one that could not be restored verbatim, because its closing assertion (`expect(setOf(flush)).not.toContain("n")`) pins the retired REFUSAL clause that `admitHandles` no longer implements — that clause is deleted, under `AGENTS.md` reason 1, separately in the tracker.
describe("⚠ TRANSITIONAL (deleted in S48-1b): handle geometry — the flush-edge inset, to the digit", () => {
  /** Flush against the frame's top-left, i.e. against the rounded corner the retired push-and-clip machinery aimed at. */
  const LAYER: HandleRect = { left: 0, top: 0, width: 800, height: 600 };
  const FRAME: HandleRect = { left: -1, top: -1, width: 802, height: 602 };
  const CLIP: EffectiveClip = buildEffectiveClip(LAYER, FRAME);
  const flush: HandleRect = { left: 0, top: 0, width: 100, height: 100 };

  it("UNCLAMPED, the NW hit box would hang half outside the layer — which is the defect", () => {
    // The placement the RED-when ("keep outside wins at the frame boundary") would ship.
    const unclampedLeft = compassPoint(flush, "nw").x - HANDLE_HIT_PX / 2;
    expect(unclampedLeft).toBe(-10);
    expect(unclampedLeft).toBeLessThan(CLIP.left);
  });

  it("INSET, the NW hit box clears the layer rect AND the frame's 12 px arc", () => {
    const nw = placeHandle(flush, "nw", CLIP);
    // The rect clamp puts the box at the layer origin; the arc then pushes it along the radius by
    // r − r/√2 measured from the arc centre, which for a corner at −1 lands the box edge here.
    const arcInset = FRAME_CORNER_RADIUS_PX - FRAME_CORNER_RADIUS_PX / Math.SQRT2 + FRAME.left;
    expect(nw.left).toBeCloseTo(arcInset, 9);
    expect(nw.top).toBeCloseTo(arcInset, 9);
    expect(fitsInClip(nw, CLIP)).toBe(true);
    // Still inside the anchor envelope, and only just — this corner is the worst case in the corpus.
    const drift = Math.hypot(nw.centre.x - nw.anchor.x, nw.centre.y - nw.anchor.y);
    expect(drift).toBeGreaterThan(HANDLE_HIT_PX / 2);
    expect(drift).toBeLessThanOrEqual(HANDLE_HIT_PX);
  });

  it("a 100 px edge in the corner cannot carry a strip — the arc costs it more than 10 %", () => {
    // Not a coordinate assertion: the trim is derived from the arc, and — under the retired REFUSAL clause this describe no longer pins (see this file's tracker note, above) — the strip was refused because what survived no longer spanned its edge.
    const n = placeHandle(flush, "n", CLIP);
    const band = FRAME_CORNER_RADIUS_PX + FRAME.top; // the arc centre's y, in layer coords
    const trim = band - Math.sqrt(FRAME_CORNER_RADIUS_PX ** 2 - band ** 2) - flush.left;
    expect(n.width).toBeCloseTo(flush.width - 2 * trim, 9);
    expect(n.edgeCoverage).toBeLessThan(STRIP_EDGE_COVERAGE_MIN);
  });

  it("a strip's centre does NOT slide along its edge when the trim bites", () => {
    // Symmetric trimming is what keeps clause 4 satisfiable for a long strip; an asymmetric trim
    // would move the centre by half the trim and fail the envelope on a wide subject.
    const bleed: HandleRect = { left: 0, top: 0, width: 800, height: 600 };
    const n = placeHandle(bleed, "n", CLIP);
    expect(n.centre.x).toBeCloseTo(compassPoint(bleed, "n").x, 9);
    expect(n.width).toBeLessThan(bleed.width);
  });
});

describe("G48-1/G48-2 — no subject is refused", () => {
  it("G48-1 — every one of the eight owns a non-empty region at 220×10, on a 0.5 px off-lattice grid", () => {
    const box = { left: 0, top: 0, width: 220, height: 10 };
    const regions = buildHandleRegions(box);
    const counts = new Map<HandleCompass, number>(CANONICAL_ORDER.map((c) => [c, 0]));
    // 0.5 px step, origin offset by 0.25 off the integer lattice — every region boundary here sits on an integer or a half-integer, so an off-lattice sample never double-counts a boundary line.
    for (let x = -10.25; x <= 230.25; x += 0.5) {
      for (let y = -10.25; y <= 20.25; y += 0.5) {
        const owner = ownerAt(regions, CANONICAL_ORDER, x, y);
        if (owner !== null) counts.set(owner, (counts.get(owner) ?? 0) + 1);
      }
    }
    let scarcestCompass: HandleCompass | null = null;
    let scarcestCount = Number.POSITIVE_INFINITY;
    for (const [compass, count] of counts) {
      if (count < scarcestCount) {
        scarcestCompass = compass;
        scarcestCount = count;
      }
    }
    console.log(
      "G48-1 sample counts @ 220×10:",
      Object.fromEntries(counts),
      "— scarcest:",
      scarcestCompass,
      scarcestCount,
    );
    for (const [compass, count] of counts) {
      expect(count, `${compass} sample count at 220×10`).toBeGreaterThan(0);
    }
  });

  it("G48-2 — the model refuses nothing over a swept range of box sizes, including degenerate ones", () => {
    const sizes = [0, 0.5, 1, 2, 5, 8, 9, 10, 12, 14, 16, 20, 23, 30, 35, 50, 80, 100, 120, 220, 300, 500];
    for (const width of sizes) {
      for (const height of sizes) {
        const box = { left: 0, top: 0, width, height };
        expect(placements(box).map((p) => p.compass), `${width}×${height}`).toEqual(ALL_EIGHT);
      }
    }
  });

  it("applies only the writable-axis filter, even at a degenerate size", () => {
    const box = { left: 0, top: 0, width: 1, height: 1 };
    expect(admitHandles({ box, axes: { width: false, height: true } }).map((p) => p.compass)).toEqual(["n", "s"]);
    expect(admitHandles({ box, axes: { width: true, height: false } }).map((p) => p.compass)).toEqual(["e", "w"]);
  });

  it("keeps all eight at 220×10 and on a 0.5 px lattice offset", () => {
    expect(placements({ left: 0, top: 0, width: 220, height: 10 }).map((p) => p.compass)).toEqual(ALL_EIGHT);
    expect(placements({ left: 0.5, top: 0.5, width: 12.5, height: 14.5 })).toHaveLength(8);
  });
});

describe("G48-3 — the clip does not move a handle (unit half: the EMITTED RECT, never a carried centre)", () => {
  function cornerCentre(box: HandleRect, compass: HandleCompass): { x: number; y: number } {
    const region = buildHandleRegions(box).find((r) => r.compass === compass)!;
    // Computed from the rect the builder actually emitted, never read off `region.centre` — a `centre` assigned from the anchor it is compared to would be true of any rect the builder emits, including a mis-placed one (plan §6).
    return { x: region.left + region.width / 2, y: region.top + region.height / 2 };
  }
  function boxCorner(box: HandleRect, compass: HandleCompass): { x: number; y: number } {
    switch (compass) {
      case "nw":
        return { x: box.left, y: box.top };
      case "ne":
        return { x: box.left + box.width, y: box.top };
      case "se":
        return { x: box.left + box.width, y: box.top + box.height };
      default:
        return { x: box.left, y: box.top + box.height };
    }
  }
  const FIXTURES: readonly HandleRect[] = [
    { left: 200, top: 180, width: 300, height: 120 }, // comfortable
    { left: 0, top: 0, width: 30, height: 30 }, // AT THE LAYER ORIGIN — lever (i)'s subject
    // ⚠ MOVED OFF THE ORIGIN (plan §6's IEEE-recovery obligation) — at `left: 0, top: 0` recovery is exact BY CONSTRUCTION regardless of the fractional extent: `(0 − half) + half` is `-half + half`, which IEEE 754 guarantees is exactly `0` for any finite `half`, so the origin fixture could never exercise a rounding tolerance in the first place. `220, 180` is away from it, and `23×100`'s corner extent (8.4, non-integer) is still the fractional-extent case this fixture is for.
    { left: 220, top: 180, width: 23, height: 100 }, // fractional extent (23×100), off the origin
    { left: 0, top: 0, width: 30, height: 90 }, // fractional extent, 28/3, still at the origin
    { left: 200, top: 180, width: 1, height: 1 }, // degenerate
  ];

  it("keeps every corner's emitted centre exactly on the box corner, across regimes", () => {
    for (const box of FIXTURES) {
      for (const compass of CORNER_COMPASSES) {
        const centre = cornerCentre(box, compass);
        const anchor = boxCorner(box, compass);
        // ⚠ **`toBe`, NOT `toBeCloseTo(…, 9)` — `toBeCloseTo(…, 9)` is a ±5e-10 TOLERANCE, not "bare equality" despite reading like one, and a tolerance this file never demonstrated as NEEDED is a claim of looseness the row does not back up.** Measured directly (`node -e`, every FIXTURE × every corner, both axes): every one of `(anchor − half) + half` recovers `anchor` BIT-EXACTLY, including the `23×100` fixture now placed off the origin specifically to remove the origin's free exact-cancellation guarantee (above) — so this row asserts the equality it actually observes rather than a padded approximation of it. Should a future fixture or a future ramp value ever introduce a genuine ulp-level miss, `toBe` is what turns that into a visible RED instead of silently absorbing it into an unexercised tolerance.
        expect(centre.x, `${compass}@${box.width}×${box.height}.x`).toBe(anchor.x);
        expect(centre.y, `${compass}@${box.width}×${box.height}.y`).toBe(anchor.y);
      }
    }
  });
});

describe("G48-5 — criterion ②, wide: the aim disc around each corner", () => {
  const DIAGONAL_SHARE_FLOOR = 0.8; // owner-spec.ts's DIAGONAL_SHARE_FLOOR, stated as a literal
  const AIM_RADIUS = 4; // pointer-thresholds.ts's POINTER_DRAG_THRESHOLD_PX, stated as a literal and never imported

  interface CornerReport {
    diagonal: number;
    edge: number;
    otherCorner: number;
    empty: number;
    total: number;
  }

  function sweepShare(box: HandleRect, cornerOverride?: number): Record<"nw" | "ne" | "se" | "sw", CornerReport> {
    // The sweep's subject is a 100×100 (or 220×10) box, whose SHORT side already clamps to the wide (or narrow) endpoint — so the lever that actually moves its emitted extent is the endpoint its size clamps to, not the endpoint on the opposite side of the ramp.
    const regions =
      cornerOverride === undefined ? buildHandleRegions(box) : buildHandleRegions(box, 20, 8, 80, cornerOverride);
    const l = box.left;
    const t = box.top;
    const r = box.left + box.width;
    const b = box.top + box.height;
    const cornerPoints = {
      nw: { x: l, y: t },
      ne: { x: r, y: t },
      se: { x: r, y: b },
      sw: { x: l, y: b },
    } as const;
    const report = {} as Record<"nw" | "ne" | "se" | "sw", CornerReport>;
    for (const compass of CORNER_COMPASSES as readonly ("nw" | "ne" | "se" | "sw")[]) {
      const c = cornerPoints[compass];
      let diagonal = 0;
      let edge = 0;
      let otherCorner = 0;
      let empty = 0;
      let total = 0;
      for (let dx = -AIM_RADIUS; dx <= AIM_RADIUS; dx += 0.2) {
        for (let dy = -AIM_RADIUS; dy <= AIM_RADIUS; dy += 0.2) {
          if (dx * dx + dy * dy > AIM_RADIUS * AIM_RADIUS) continue;
          total++;
          const owner = ownerAt(regions, CANONICAL_ORDER, c.x + dx, c.y + dy);
          if (owner === compass) diagonal++;
          else if (owner === null) empty++;
          else if (CORNER_COMPASSES.includes(owner)) otherCorner++;
          else edge++;
        }
      }
      report[compass] = { diagonal, edge, otherCorner, empty, total };
    }
    return report;
  }

  // ⚠ **THIS ROW'S GREEN IS ARITHMETICALLY FORCED AT THE SHIPPED EXTENTS AGAINST THE SIZE LEVER, but NOT against every porting defect (measured below).** At both required sizes the corner half-extent is `≥ 4 = AIM_RADIUS` — 8 at the narrow clamp (220×10), 16 at the wide one (100×100) — so the aim disc sits wholly inside a CENTRED corner square by construction, and the RED sweep below (which walks the extent DOWN until the disc starts losing points) is what catches a mistyped ramp endpoint. But `G48-3`'s lever (ii) — a corner square anchored AT the box corner rather than centred on it — moves this row too: measured directly, the four per-corner shares under that mutant are 0.347 / 0.346 / 0.265 / 0.346 (nw/ne/se/sw), all below the 0.8 floor, so this row is not blind to a defect that misplaces the square rather than mis-sizing it.
  it("holds the floor at 100×100 and at 220×10, per corner, with the edge/otherCorner breakdown", () => {
    for (const box of [
      { left: 0, top: 0, width: 100, height: 100 },
      { left: 0, top: 0, width: 220, height: 10 },
    ]) {
      const report = sweepShare(box);
      console.log(`G48-5 per-corner shares @ ${box.width}×${box.height}:`, JSON.stringify(report));
      for (const compass of CORNER_COMPASSES as readonly ("nw" | "ne" | "se" | "sw")[]) {
        const { diagonal, empty, total } = report[compass];
        const denom = total - empty;
        const share = denom > 0 ? diagonal / denom : 0;
        expect(share, `${compass}@${box.width}×${box.height} diagonal share`).toBeGreaterThanOrEqual(DIAGONAL_SHARE_FLOOR);
      }
    }
  });

  it("RED sweep: reports the first corner extent (holding the mode pinned) at which a corner's share falls below the floor, and the last that passes", () => {
    const box = { left: 0, top: 0, width: 100, height: 100 };
    let lastPass: number | null = null;
    let firstFail: number | null = null;
    for (let extent = 16; extent >= 0; extent -= 0.5) {
      const report = sweepShare(box, extent);
      const shares = (CORNER_COMPASSES as readonly ("nw" | "ne" | "se" | "sw")[]).map((c) => {
        const { diagonal, empty, total } = report[c];
        const denom = total - empty;
        return denom > 0 ? diagonal / denom : 0;
      });
      const minShare = Math.min(...shares);
      if (minShare >= DIAGONAL_SHARE_FLOOR) {
        lastPass = extent;
      } else {
        firstFail = extent;
        break;
      }
    }
    console.log("G48-5 RED sweep @ 100×100 — last passing corner extent:", lastPass, "first failing:", firstFail);
    expect(firstFail, "the sweep must find a corner extent at which the floor breaks").not.toBeNull();
  });
});

describe("G48-8 — a band runs the whole edge", () => {
  it("spans each edge exactly, on a constructed box", () => {
    const box = { left: 10, top: 5, width: 137, height: 63 };
    const regions = new Map(buildHandleRegions(box).map((r) => [r.compass, r]));
    expect(regions.get("n")!.width).toBe(box.width);
    expect(regions.get("s")!.width).toBe(box.width);
    expect(regions.get("e")!.height).toBe(box.height);
    expect(regions.get("w")!.height).toBe(box.height);
    // ⚠ **A BAND'S LONG-AXIS ORIGIN, PINNED SEPARATELY** — `G48-8` pinned the LENGTH and `G48-11` the near-edge SHORT-axis position, but nothing pinned a band's LONG-axis ORIGIN: a band shortened at one end and grown at the other keeps its length and its near edge both, and neither gate above would catch it.
    expect(regions.get("n")!.left).toBe(box.left);
    expect(regions.get("s")!.left).toBe(box.left);
    expect(regions.get("e")!.top).toBe(box.top);
    expect(regions.get("w")!.top).toBe(box.top);
  });
});

describe("G48-9 — contested regions resolve by the canonical order, and the runtime derives from the same list", () => {
  // ⚠ These four tests resolve ownership against the IMPORTED `HANDLE_ADMISSION_ORDER`, unlike every other describe block in this file — deliberately. G48-9's own subject IS the precedence list: the runtime and the unit oracle are supposed to "agree by derivation rather than by inspection" (plan §4.1), which only has a RED lever if the oracle's ownership call reads the same symbol a permutation mutant edits. A hand-typed copy of the order here would make every one of this gate's three levers silently inert.
  it("band-vs-band: the 220×10 L-residue resolves to whichever band precedes at each corner (literal bounds)", () => {
    const box = { left: 0, top: 0, width: 220, height: 10 };
    const regions = buildHandleRegions(box);
    // nw residue — shared square x∈[0,5]×y∈[0,5] minus the corner's [0,4]×[0,4]; n precedes w.
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 4.75, 2)).toBe("n");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 2, 4.75)).toBe("n");
    // ne residue — mirrored at the right edge; n precedes e.
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 215.25, 2)).toBe("n");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 218, 4.75)).toBe("n");
    // se residue — e precedes s.
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 215.25, 8)).toBe("e");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 218, 5.25)).toBe("e");
    // sw residue — s precedes w.
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 4.75, 8)).toBe("s");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 2, 5.25)).toBe("s");
  });

  it("corner-vs-corner: the 6×6 box's shared [2,4]² square resolves to nw", () => {
    const box = { left: 0, top: 0, width: 6, height: 6 };
    const regions = buildHandleRegions(box);
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 3, 3)).toBe("nw");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 2.1, 3.9)).toBe("nw");
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 3.9, 2.1)).toBe("nw");
  });

  it("corners precede bands: every corner's list index is below every band's (invariant on the LIST)", () => {
    const cornerIdx = (["nw", "ne", "se", "sw"] as const).map((c) => HANDLE_ADMISSION_ORDER.indexOf(c));
    const bandIdx = (["n", "e", "s", "w"] as const).map((c) => HANDLE_ADMISSION_ORDER.indexOf(c));
    expect(Math.max(...cornerIdx)).toBeLessThan(Math.min(...bandIdx));

    // ⚠ **THE POCKET `G48-9`'S corners-before-bands LEVER MOVES** — the invariant above is true of the LIST alone and never touches a region; this probes the POCKET plan §6's own RED lever moves (`G48-9`'s corners-before-bands leg): `x ∈ [0, 2) × y ∈ (4, 5]` on the 6×6 fixture, which is `sw ∩ n` minus everything ahead of both. Under the SHIPPED list `sw` (index 3) precedes `n` (index 4); the 6×6 corner-vs-corner region `[2, 4]²` (above) is the case the lever does NOT move — this is the one it does.
    const box = { left: 0, top: 0, width: 6, height: 6 };
    const regions = buildHandleRegions(box);
    expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 1, 4.75)).toBe("sw");

    // The lever itself, re-driven against this exact pocket: `n` moved ahead of `sw`, giving `nw, ne, se, n, sw, e, s, w` — the pocket changes hands from `sw` to `n`, which is the observable plan §6 names for this leg (a literal, second, mutant ORDER — never the imported one edited in place, so the shipped assertion above stays a fact about the real list).
    const nAheadOfSw: readonly HandleCompass[] = ["nw", "ne", "se", "n", "sw", "e", "s", "w"];
    expect(ownerAt(regions, nAheadOfSw, 1, 4.75)).toBe("n");
  });
});

describe("G48-10 — the ramp's interior, on non-square fixtures (width AND height compared)", () => {
  it("pins the narrow clamp on both axes at 10×200", () => {
    const region = buildHandleRegions({ left: 0, top: 0, width: 10, height: 200 }).find((r) => r.compass === "nw")!;
    expect(region.width).toBe(8);
    expect(region.height).toBe(8);
  });

  it("pins the interior ramp value on both axes at 30×90", () => {
    const region = buildHandleRegions({ left: 0, top: 0, width: 30, height: 90 }).find((r) => r.compass === "nw")!;
    expect(region.width).toBeCloseTo(28 / 3, 9);
    expect(region.height).toBeCloseTo(28 / 3, 9);
  });

  // ⚠ RETITLED (plan §6, `G48-10`) — the shipped title claimed "extent only", but the row below asserts BOTH `region.width` and `region.height`. What is true is narrower: at the wide clamp BOTH drivers (isotropic and the anisotropic mutant `G48-10`'s second lever tests) agree on 16 for any box whose short side is ≥ 80, so this pair of assertions cannot DISCRIMINATE between them — squareness is inert here, not unchecked.
  it("pins the wide clamp's extent on both axes — squareness is inert above a short side of 80, not unasserted", () => {
    const region = buildHandleRegions({ left: 0, top: 0, width: 120, height: 400 }).find((r) => r.compass === "nw")!;
    expect(region.width).toBe(16);
    expect(region.height).toBe(16);
  });

  it("a second interior point at short side 40 catches a breakpoint typo no single sample would", () => {
    const region = buildHandleRegions({ left: 0, top: 0, width: 40, height: 400 }).find((r) => r.compass === "nw")!;
    expect(region.width).toBeCloseTo(8 + (20 * 8) / 60, 9); // 10.666…
    expect(region.height).toBeCloseTo(8 + (20 * 8) / 60, 9);
  });

  it("uses the short side for an isotropic clamped linear ramp (legacy sweep, kept alongside the pair above)", () => {
    const extent = (box: HandleRect) => buildHandleRegions(box).find((p) => p.compass === "nw")!.width;
    expect(extent({ left: 0, top: 0, width: 10, height: 200 })).toBe(8);
    expect(extent({ left: 0, top: 0, width: 30, height: 90 })).toBeCloseTo(28 / 3, 9);
    expect(extent({ left: 0, top: 0, width: 120, height: 200 })).toBe(16);
  });
});

describe("G48-11 — the band's thickness AND its position", () => {
  it("keeps each band's short axis at the literal 10, and its near edge at edge − 5", () => {
    const box = { left: 20, top: 30, width: 100, height: 60 };
    const regions = new Map(buildHandleRegions(box).map((r) => [r.compass, r]));
    const n = regions.get("n")!;
    const s = regions.get("s")!;
    const w = regions.get("w")!;
    const e = regions.get("e")!;
    expect(n.height).toBe(10);
    expect(s.height).toBe(10);
    expect(w.width).toBe(10);
    expect(e.width).toBe(10);
    expect(n.top).toBe(box.top - 5);
    expect(s.top).toBe(box.top + box.height - 5);
    expect(w.left).toBe(box.left - 5);
    expect(e.left).toBe(box.left + box.width - 5);
  });
});
