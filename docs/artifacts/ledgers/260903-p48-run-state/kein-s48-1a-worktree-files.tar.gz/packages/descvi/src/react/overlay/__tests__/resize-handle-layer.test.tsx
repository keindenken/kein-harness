/**
 * resize-handle-layer.test.tsx — the rendered handle layer's COUNTS, its refusal marker and its
 * shared-oid hint (phase-42 S42-1 acceptance 1, 2, 3, 6, 7; G42-7's count rows).
 *
 * WHY jsdom CAN HOLD THIS HALF. The counts turn on two predicates and a measured box, not on a
 * cascade: `chipEditorDisabled` is threaded from the panel's own computation, the axis layer reads
 * `parseSizing`, and the box is stubbed below to an exact rect. What jsdom CANNOT hold is a
 * computed `pointer-events` that came from a class — measured on this repo's jsdom, a node carrying
 * `class="pointer-events-none"` reads back `auto` — so every non-operable node in this layer sets
 * the property INLINE, and the control test below proves the reading is a reading.
 *
 * ⚠ THE GLYPH SCAN IS DOM-BASED, AND AN ACCESSIBILITY-TREE SCAN IS FORBIDDEN HERE (acceptance 3).
 * `#dsh-ring-layer` is `aria-hidden`, so an AT query returns nothing and every assertion over it
 * passes vacuously. The layer's `aria-hidden` is asserted below precisely so that prohibition has a
 * reason a reader can check rather than a rule they must trust.
 *
 * The browser half — real computed styles, `elementFromPoint` identity, the §3.12 degradation
 * matrix and the ≥ 90 % strip coverage — lives in `e2e/resize-handles.spec.ts` (G42-6a, G42-7's
 * Universe B).
 */

import { describe, it, expect, vi, beforeAll, beforeEach, afterEach } from "vitest";
import { render, renderHook, cleanup, act } from "@testing-library/react";
import "@testing-library/jest-dom/vitest";
import type { ScreenNode } from "@descvi/core/schema";
import { DescviStateProvider } from "../../DescviStateContext";
import { OverlayShell } from "../OverlayShell";
import { adaptScreen } from "../shared/overlay-screen-adapter";
import { createSourceResolver, type EditMapData, type ResolveResult } from "../engine/source-resolver";
import type { SidecarBridge } from "../engine/sidecar-bridge";
import { bridgeSuccess, bridgeReadStubs } from "../../../../test/helpers/bridge-fixtures.ts";
import {
  ASPECT_LOCK_REFUSED_MESSAGES,
  AXIS_BLOCKED_MESSAGES,
  CHIP_DISABLED_MESSAGES,
  type AspectLockRefusalAxis,
} from "../shared/refusal-messages";
import { useResizeHandles, type ResizeHandlesParams } from "../canvas/use-resize-handles";
// ⚠ IMPORTED TO BE MUTATED BY ONE ROW, NEVER TO BUILD AN EXPECTATION FROM — see `CURSOR_FOR_COMPASS`.
import { HANDLE_CURSOR } from "../canvas/handle-glyphs";

beforeAll(() => {
  vi.spyOn(console, "error").mockImplementation((msg: unknown) => {
    if (typeof msg === "string" && msg.includes("useLayoutEffect does nothing on the server")) return;
    console.warn(msg);
  });
});

const SCREEN_NODE: ScreenNode = {
  id: "test/screen",
  title: "Test",
  stateAxes: {},
  components: [],
  edges: [],
} as unknown as ScreenNode;
const SHELL_SCREEN = adaptScreen(SCREEN_NODE);

const EDIT_MAP: EditMapData = {
  version: "2",
  oids: { "test/screen": { row: { className: "flex", editable: true } } },
};
const RESOLVER = createSourceResolver(EDIT_MAP);

function makeBridge(): SidecarBridge {
  return {
    ...bridgeReadStubs(),
    probeHealth: () => Promise.resolve(true),
    editDescription: () => Promise.resolve(bridgeSuccess({ value: "" })),
    editClassName: (req) => Promise.resolve(bridgeSuccess({ value: req.newClassName })),
    editName: (req) => Promise.resolve(bridgeSuccess({ value: req.newName })),
    fetchEditMap: () => Promise.resolve(EDIT_MAP),
  };
}

/**
 * jsdom measures every box as 0×0, and a 0×0 subject legitimately renders one corner — so without a stub every count row here would read 1 and mean nothing. The three rects below are the ones the layer actually reads: the ring layer (the coordinate origin), the frame (`#dsh-ring-layer`'s own `overflow: hidden` ancestor — its rounded corner is paint only and does not clip hit-testing; plan §6.1) and the subject.
 */
const LAYER_RECT = { left: 0, top: 0, width: 800, height: 600 };
const FRAME_RECT = { left: -1, top: -1, width: 802, height: 602 };
const SUBJECT_RECT = { left: 200, top: 200, width: 100, height: 100 };
let subjectRect = SUBJECT_RECT;

function asDomRect(r: { left: number; top: number; width: number; height: number }): DOMRect {
  return {
    ...r,
    right: r.left + r.width,
    bottom: r.top + r.height,
    x: r.left,
    y: r.top,
    toJSON: () => r,
  } as DOMRect;
}

beforeEach(() => {
  vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(function (this: Element) {
    if (this.id === "dsh-ring-layer") return asDomRect(LAYER_RECT);
    if (this.id === "dsh-frame") return asDomRect(FRAME_RECT);
    if (this.getAttribute("data-oid") === "row") return asDomRect(subjectRect);
    return asDomRect({ left: 0, top: 0, width: 0, height: 0 });
  });
});

afterEach(() => {
  vi.restoreAllMocks();
  cleanup();
  for (const host of hookHosts.splice(0)) host.remove();
  subjectRect = SUBJECT_RECT;
});

const WRITABLE: ResolveResult = {
  screenId: "test/screen",
  specId: "row",
  identity: "oid",
  oid: "row",
  editable: true,
  className: "flex",
};

function target(patch: Record<string, unknown>): ResolveResult {
  // The refusal rows deliberately build shapes the union's two members do not cover between them
  // (`editable: true` WITH an unparseable className is the whole point of one of them), so the cast
  // goes through `unknown` — narrowing it would be asserting the very distinction under test.
  return { ...(WRITABLE as object), ...patch } as unknown as ResolveResult;
}

function renderShell(selectedTarget: ResolveResult) {
  const utils = render(
    <DescviStateProvider stateAxes={{}}>
      <OverlayShell
        screen={SHELL_SCREEN}
        screenId="test/screen"
        editable
        editMode
        bridge={makeBridge()}
        resolver={RESOLVER}
        selectedTarget={selectedTarget}
      >
        <div data-screen="test/screen">
          <div data-oid="row" className="flex">
            row
          </div>
        </div>
      </OverlayShell>
    </DescviStateProvider>,
  );
  // The handle layer anchors to `selectedEl`, which only the real capture-phase shield sets — the
  // injected `selectedTarget` prop is the WRITE target and carries no DOM instance.
  const subject = utils.container.querySelector<HTMLElement>('[data-oid="row"]')!;
  act(() => {
    subject.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
  });
  return utils;
}

const handles = (): HTMLElement[] => Array.from(document.querySelectorAll<HTMLElement>("[data-dsh-handle]"));
const compasses = (): string[] => handles().map((h) => h.getAttribute("data-dsh-handle") ?? "").sort();
const marker = (): HTMLElement | null => document.getElementById("dsh-ring-refusal-marker");
const ringHint = (): HTMLElement | null => document.getElementById("dsh-ring-instance-hint");

describe("S42-1 acceptance 1 — the TARGET predicate layer", () => {
  it("a writable target with both axes free renders exactly 8 handles and NO marker", () => {
    renderShell(WRITABLE);
    expect(handles()).toHaveLength(8);
    expect(compasses()).toEqual(["e", "n", "ne", "nw", "s", "se", "sw", "w"]);
    expect(marker()).toBeNull();
  });

  const refusals = [
    { reason: "dynamic-class", selected: target({ editable: false, reason: "dynamic-class", className: undefined }) },
    { reason: "no-class", selected: target({ editable: false, reason: "no-class", className: undefined }) },
    // `editable: true` AND refused — the member where `editable` and `chipEditorDisabled` diverge,
    // and the whole reason this layer keys on the panel's value rather than on `editable`.
    { reason: "unparseable", selected: target({ className: "flex w-[" }) },
  ] as const;

  for (const { reason, selected } of refusals) {
    it(`chipDisabledReason=${reason} renders ZERO handles and exactly one marker carrying its text`, () => {
      renderShell(selected);
      expect(handles()).toHaveLength(0);
      expect(document.querySelectorAll("#dsh-ring-refusal-marker")).toHaveLength(1);
      const node = marker()!;
      // Asserted on the TEXT, not on the node's existence — an empty marker is G42-7's RED-when (5).
      expect(node.textContent).toContain(CHIP_DISABLED_MESSAGES[reason].ko);
      expect(node.textContent).toContain(CHIP_DISABLED_MESSAGES[reason].en);
      expect(node.getAttribute("data-reason")).toBe(reason);
      // The assertion G42-7's Universe B depends on: a hittable marker turns a CORRECT
      // implementation RED there, and the cheap repair is to stamp it as a control.
      expect(getComputedStyle(node).pointerEvents).toBe("none");
      expect(node.hasAttribute("data-dsh-handle")).toBe(false);
      expect(node.hasAttribute("data-v3-glyph-control")).toBe(false);
    });
  }

  it("CONTROL — the computed reading above is a reading: a class-only rule reads back `auto` here", () => {
    // Without this, "pointerEvents === 'none'" could be jsdom's silence rather than the marker's
    // property, and the same green would follow from an implementation that set nothing at all.
    renderShell(WRITABLE);
    const plant = document.createElement("div");
    plant.className = "pointer-events-none";
    document.body.appendChild(plant);
    expect(getComputedStyle(plant).pointerEvents).toBe("auto");
    const inline = document.createElement("div");
    inline.style.pointerEvents = "none";
    document.body.appendChild(inline);
    expect(getComputedStyle(inline).pointerEvents).toBe("none");
  });
});

describe("S42-1 acceptance 2 — the AXIS predicate layer", () => {
  it("width axis BLOCKED leaves 2 handles — S and N — and the marker names the axis", () => {
    renderShell(target({ className: "flex md:w-1/2" }));
    expect(compasses()).toEqual(["n", "s"]);
    const node = marker()!;
    expect(node.getAttribute("data-blocked-axis")).toBe("width");
    expect(node.getAttribute("data-reason")).toBe("element-axis-controlled-by-variant");
    expect(node.textContent).toContain(AXIS_BLOCKED_MESSAGES.width.ko);
  });

  it("height axis BLOCKED leaves 2 handles — E and W", () => {
    renderShell(target({ className: "flex md:h-8" }));
    expect(compasses()).toEqual(["e", "w"]);
    expect(marker()!.getAttribute("data-blocked-axis")).toBe("height");
    expect(marker()!.textContent).toContain(AXIS_BLOCKED_MESSAGES.height.ko);
  });

  it("a variant-shadowed size-* blocks BOTH axes — zero handles plus the marker", () => {
    renderShell(target({ className: "flex md:size-8" }));
    expect(handles()).toHaveLength(0);
    expect(marker()!.getAttribute("data-blocked-axis")).toBe("both");
    expect(marker()!.textContent).toContain(AXIS_BLOCKED_MESSAGES.both.ko);
  });
});

describe("S42-1 acceptance 3, AS AMENDED BY C46-1/C46-2 — every handle is a marked, CURSOR-bearing control", () => {
  /**
   * ⚠ **THE GLYPH HALF OF THIS ROW IS DELETED AT S46-2 AND THE REASON IS NAMED HERE BECAUSE
   * `AGENTS.md` REQUIRES IT.** It asserted that every handle carries an `svg`/`[data-glyph]`
   * descendant sized `HANDLE_GLYPH_PX` — ralplan §2.2's assertion 1. The applicable permitted reason
   * is the FIRST — **the code it covered is gone**: C46-2 drops the corner's mark and unpaints the
   * strips entirely, so after this commit no resize handle builds a glyph at all and the assertion
   * has no subject in this layer, permanently. It is not merely quiet; it is unpopulated.
   *
   * **What replaces it is not weaker, and that is the test of whether the amendment was honest.** The
   * marker half is untouched and still asserted below. In place of the glyph obligation the node now
   * owes C46-1 clause 4's POSITIVE one — the ruled cursor for its OWN compass over a non-zero hit box
   * — which is checked here and whose mutants are the G46-4 row further down. The old assertion could
   * only fail on a missing descendant; the new one fails on a wrong cursor, an unruled cursor, a
   * swapped compass and a collapsed hit box.
   */
  it("each handle carries data-v3-glyph-control and the ruled cursor for its OWN compass", () => {
    renderShell(WRITABLE);
    const found = handles();
    expect(found).toHaveLength(8);
    for (const handle of found) {
      expect(handle.hasAttribute("data-v3-glyph-control")).toBe(true);
      expect(handle.getAttribute("data-v3-glyph-control")).toBe("cursor");
      expect(CURSOR_FOR_COMPASS[handle.getAttribute("data-dsh-handle") ?? ""]).toBe(handle.style.cursor);
    }
    expect(cursorArmViolations()).toEqual([]);
  });

  it("C46-2 — the strips paint NOTHING and the corners keep a chip, which is the whole render branch", () => {
    // §5.11 direction 1 is "the painted pills can go" and direction 2 is "shrink the corner chip".
    // Asserted STRUCTURALLY rather than as style values: a chip node kept alive with its paint
    // properties cleared would satisfy a colour assertion and still be a painted node one edit away.
    renderShell(WRITABLE);
    const byCompass = new Map(handles().map((h) => [h.getAttribute("data-dsh-handle") ?? "", h]));
    for (const strip of ["n", "e", "s", "w"]) {
      expect(byCompass.get(strip)!.children, `${strip} paints nothing`).toHaveLength(0);
    }
    for (const corner of ["nw", "ne", "se", "sw"]) {
      const chip = byCompass.get(corner)!.firstElementChild as HTMLElement;
      expect(chip, `${corner} keeps a chip`).not.toBeNull();
      expect(chip.style.width).toBe("10px");
      expect(chip.style.height).toBe("10px");
      // ⚠ R42-D2's STANDING CONDITION, asserted rather than trusted: the restyle may change the fill,
      // the radius and the shadow, and it MAY NOT drop the group-coloured border for a fill-only chip.
      // With the glyph gone this border is the only group colour left on a handle.
      expect(chip.style.border, `${corner} keeps the 1.5px group-coloured border`).toMatch(/^1\.5px solid rgb\(/);
      expect(chip.style.border).not.toBe("");
    }
  });

  it("G48-6 — a 30×30 corner chip follows its 9.333… px ramp extent while a wide chip keeps the 10 px ceiling", () => {
    subjectRect = { left: 200, top: 200, width: 30, height: 30 };
    renderShell(WRITABLE);
    const smallChip = handles().find((handle) => handle.getAttribute("data-dsh-handle") === "nw")!.firstElementChild as HTMLElement;
    expect(Number.parseFloat(smallChip.style.width)).toBeCloseTo(28 / 3, 9);
    subjectRect = SUBJECT_RECT;
    cleanup();
    renderShell(WRITABLE);
    const wideChip = handles().find((handle) => handle.getAttribute("data-dsh-handle") === "nw")!.firstElementChild as HTMLElement;
    expect(wideChip.style.width).toBe("10px");
  });

  it("C46-2 CONTROL — the two rows above REJECT the shapes the restyle replaced", () => {
    // Without this, "the strips have no children" and "the corners have a bordered chip" are readings
    // of an instrument that has never been seen to reject anything.
    renderShell(WRITABLE);
    const byCompass = new Map(handles().map((h) => [h.getAttribute("data-dsh-handle") ?? "", h]));

    // (a) a repainted strip — the pill this commit removes, put back on the shipped node.
    const strip = byCompass.get("n")!;
    const pill = document.createElement("div");
    pill.setAttribute("data-dsh-handle-chip", "");
    strip.appendChild(pill);
    expect(strip.children, "a repainted strip is a non-empty root").toHaveLength(1);
    pill.remove();
    expect(strip.children).toHaveLength(0);

    // (b) a FILL-ONLY corner chip — precisely what R42-D2 forbids, and the mutation a restyle ships
    // by accident when it decides the border is decoration.
    const chip = byCompass.get("nw")!.firstElementChild as HTMLElement;
    const kept = chip.style.border;
    chip.style.border = "";
    expect(chip.style.border, "a fill-only chip is named by the border assertion").not.toMatch(/^1\.5px solid rgb\(/);
    chip.style.border = kept;
    expect(chip.style.border).toMatch(/^1\.5px solid rgb\(/);
  });

  it("each handle is itself hittable, under a layer that is not", () => {
    renderShell(WRITABLE);
    for (const handle of handles()) expect(getComputedStyle(handle).pointerEvents).toBe("auto");
    expect(document.getElementById("dsh-handle-layer")!.style.pointerEvents).toBe("none");
  });

  it("the layer is aria-hidden — which is WHY an accessibility-tree scan is forbidden here", () => {
    renderShell(WRITABLE);
    expect(document.getElementById("dsh-ring-layer")!.getAttribute("aria-hidden")).toBe("true");
  });

  it("each handle carries the ruled directional cursor (§3.10)", () => {
    renderShell(WRITABLE);
    const byCompass = new Map(handles().map((h) => [h.getAttribute("data-dsh-handle"), h.style.cursor]));
    expect(byCompass.get("e")).toBe("ew-resize");
    expect(byCompass.get("w")).toBe("ew-resize");
    expect(byCompass.get("n")).toBe("ns-resize");
    expect(byCompass.get("s")).toBe("ns-resize");
    expect(byCompass.get("nw")).toBe("nwse-resize");
    expect(byCompass.get("se")).toBe("nwse-resize");
    expect(byCompass.get("ne")).toBe("nesw-resize");
    expect(byCompass.get("sw")).toBe("nesw-resize");
  });
});

// ── C46-1's DECLARED KIND — three instruments, not inline expectations (ralplan-phase-46 §3.1) ──
//
// ⚠ **THE CLOSED SET IS RE-STATED BY HAND AND NEVER IMPORTED FROM `use-resize-handles.ts`.** That is
// the same deliberate-second-implementation discipline this layer's e2e oracle states for the
// admission rule: a row that imports the vocabulary it checks is a tautology, and a fourth kind
// added to the production constant would ship green through it.
//
// ⚠ **AND THESE ROWS KEY ON THE DECLARATION, NEVER ON COMPUTED `pointer-events`.** The completeness
// universe — "every OPERABLE node under the ring layer" — belongs to `e2e/resize-handles.spec.ts`
// for the reason this file's header gives: `#dsh-selection-badge` is made non-hittable by the
// `pointer-events-none` CLASS, and in this jsdom that class reads back `auto`, so an operability-keyed
// scan here would name a correct implementation. What jsdom CAN hold soundly is the obligation each
// declaration puts on the node that carries it, which is what G46-2, G46-3 and G46-5 are.
const DECLARED_KINDS = ["glyph", "glyph-conditional", "cursor"];
/** §3.1 clause 3's third term — the ruled cursor table's VALUES, hand-copied for the same reason. */
const RULED_CURSORS = ["ew-resize", "ns-resize", "nwse-resize", "nesw-resize"];
/**
 * §3.1 clause **4**'s own-compass expectation set — eight entries, hand-written, and this is
 * ralplan **RR-3 being closed rather than carried** (S46-2).
 *
 * ⚠ **NEVER `HANDLE_CURSOR`, AND NEVER DERIVED FROM {@link RULED_CURSORS} EITHER — THE TWO ARE
 * DIFFERENT CLAUSES AND COLLAPSING THEM PUTS BACK THE HOLE THIS CLOSES.** `RULED_CURSORS` is clause
 * 3's MEMBERSHIP term: it asks whether a cursor is in the ruled table at all, and it stays a bare
 * value list. This map is clause 4's IDENTITY term: it asks whether the node carries the entry for
 * **its own** `data-dsh-handle` value. A membership check passes a handle wearing another handle's
 * cursor — `nw` with `nesw-resize` is in the table — and the G46-4 row below proves exactly that gap
 * by mutating both and showing which checker stays quiet.
 *
 * **And the reason it is written out instead of read from the production table** is RR-3's own
 * wording: an oracle that reads `HANDLE_CURSOR` moves WITH `HANDLE_CURSOR`, so a mutation of the
 * table changes gate and implementation together and ships green. The G46-4 row mutates the real
 * table and shows these eight literals firing, which is the demonstration that closes the row.
 *
 * ⚠ It **discriminates**, which is the property a hand-written set has to be checked for rather than
 * assumed: the table pairs opposite compasses on one value (`nw`/`se`, `ne`/`sw`, `n`/`s`, `e`/`w`),
 * so four of the twenty-eight unordered compass swaps are value-identical and inert against ANY
 * check. The row below uses `nw`↔`ne`, which is not one of them.
 */
const CURSOR_FOR_COMPASS: Record<string, string> = {
  nw: "nwse-resize",
  ne: "nesw-resize",
  se: "nwse-resize",
  sw: "nesw-resize",
  n: "ns-resize",
  s: "ns-resize",
  e: "ew-resize",
  w: "ew-resize",
};
const FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])';

const ringLayer = (): HTMLElement => document.getElementById("dsh-ring-layer")!;
const handleLayerEl = (): HTMLElement => document.getElementById("dsh-handle-layer")!;
const declaringNodes = (): HTMLElement[] =>
  Array.from(ringLayer().querySelectorAll<HTMLElement>("[data-v3-glyph-control]"));
const say = (n: Element): string =>
  `${n.tagName.toLowerCase()}${n.id === "" ? "" : `#${n.id}`}[handle=${n.getAttribute("data-dsh-handle") ?? "-"}][kind=${n.getAttribute("data-v3-glyph-control") ?? "-"}]`;

/** G46-2 — every marked node under the ring layer declares a kind from the CLOSED three-value set. */
function kindViolations(): string[] {
  return declaringNodes()
    .filter((n) => !DECLARED_KINDS.includes(n.getAttribute("data-v3-glyph-control") ?? ""))
    .map((n) => `${say(n)}: kind "${n.getAttribute("data-v3-glyph-control")}" is not one of ${DECLARED_KINDS.join(" | ")}`);
}

/** G46-3's `glyph` arm — a node DECLARING `glyph` has an `svg`/`[data-glyph]` descendant, rendered. */
function glyphArmViolations(): string[] {
  const out: string[] = [];
  for (const n of declaringNodes()) {
    if (n.getAttribute("data-v3-glyph-control") !== "glyph") continue;
    const glyph = n.querySelector("svg, [data-glyph]");
    if (glyph === null) {
      out.push(`${say(n)}: declares glyph, has no svg/[data-glyph] descendant`);
      continue;
    }
    // ⚠ RENDERED, not merely present. The `glyph-conditional` kind exists precisely because a
    // present-but-hidden mark is a THIRD state; a node that declares the unconditional `glyph` and
    // hides its mark anyway is claiming the state it is not in, and this is the leg that says so.
    if (getComputedStyle(glyph as Element).display === "none") {
      out.push(`${say(n)}: declares glyph, its mark is display:none`);
    }
  }
  return out;
}

/**
 * G46-4 — §3.1 clause 4's POSITIVE obligation on a node declaring `cursor`: the {@link HANDLE_CURSOR}
 * entry for its OWN compass, over a non-zero hit box.
 *
 * ⚠ **ITS POPULATION IS EMPTY UNTIL S46-2 AND NON-EMPTY FROM S46-2 ON**, which is why the plan routes
 * this row here rather than to the commit that added the vocabulary: in S46-1 every handle declared
 * `glyph`, so this checker had nothing to check and a green from it would have been silence.
 *
 * ⚠ **THE HIT BOX IS READ FROM THE INLINE STYLE, NOT FROM A MEASURED RECT, AND THAT IS FORCED.**
 * jsdom has no layout and this suite's `getBoundingClientRect` stub answers 0×0 for every handle, so
 * `offsetWidth` here would report a collapsed box for a correct implementation and this leg could
 * never be green. The inline value is what `applyHandleStyle` actually writes. The e2e half of G46-4
 * measures the rendered rect, which is the reading only a browser can take.
 *
 * ⚠ **`Number.parseFloat("") === NaN`, NOT 0, AND THE GUARD IS WRITTEN FOR THE VALUE NOBODY PLANTS.**
 * An unset width reads back `""` and an `auto` reads back `"auto"`; both must be violations, and a
 * naive `>= 0` or a `Number(...)` coercion (`Number("")` is 0, which is finite) would pass one of
 * them. The row below plants an unset box precisely because reading this function does not catch
 * that class.
 */
function cursorArmViolations(): string[] {
  const out: string[] = [];
  for (const n of declaringNodes()) {
    if (n.getAttribute("data-v3-glyph-control") !== "cursor") continue;
    const compass = n.getAttribute("data-dsh-handle") ?? "";
    const want = CURSOR_FOR_COMPASS[compass];
    if (want === undefined) {
      out.push(`${say(n)}: declares cursor for an unruled compass "${compass}"`);
    } else if (n.style.cursor !== want) {
      out.push(`${say(n)}: cursor "${n.style.cursor}" is not "${want}", the ruled entry for compass ${compass}`);
    }
    const w = Number.parseFloat(n.style.width);
    const h = Number.parseFloat(n.style.height);
    if (!(Number.isFinite(w) && w > 0 && Number.isFinite(h) && h > 0)) {
      out.push(`${say(n)}: declares cursor over a hit box "${n.style.width || "unset"}"×"${n.style.height || "unset"}"`);
    }
  }
  return out;
}

/**
 * G46-5 — §3.1 clause 3's FOUR-TERM CONJUNCTION, as the eligibility of a node declaring `cursor`.
 *
 * ⚠ **ITS POPULATION IS EMPTY IN S46-1 AND THAT IS BY CONTRACT, NOT BY OVERSIGHT** — every handle
 * still declares `glyph` until S46-2. So the row below PLANTS its subjects, one per conjunct, and the
 * empty real population is asserted only after the instrument has been shown to produce a non-zero
 * reading. ⚠ **The obvious real subject cannot be used here**: `#dsh-spacing-popup` is created by
 * `use-spacing-drag.ts` during a drag and no jsdom suite drives one, so naming it would be a recipe
 * nobody can run. It stays the real-world instance the clause exists to refuse.
 */
function cursorEligibilityViolations(): string[] {
  const out: string[] = [];
  const layer = handleLayerEl();
  for (const n of declaringNodes()) {
    if (n.getAttribute("data-v3-glyph-control") !== "cursor") continue;
    if (!n.hasAttribute("data-dsh-handle")) out.push(`${say(n)}: declares cursor without data-dsh-handle`);
    if (!layer.contains(n)) out.push(`${say(n)}: declares cursor outside #dsh-handle-layer`);
    if (!RULED_CURSORS.includes(n.style.cursor)) out.push(`${say(n)}: cursor "${n.style.cursor}" is not in the ruled table`);
    if (n.querySelector(FOCUSABLE) !== null) out.push(`${say(n)}: declares cursor with a focusable descendant`);
  }
  return out;
}

describe("C46-1 — the DECLARED-KIND amendment (ralplan-phase-46 §3.1; G46-2, G46-3's glyph arm, G46-5)", () => {
  it("G46-2 — every marked node under the ring layer declares a kind from the closed three-value set", () => {
    renderShell(WRITABLE);
    // NON-VACUITY FIRST: a checker over an empty population returns [] and reads as a clean pass.
    expect(declaringNodes()).toHaveLength(8);
    expect(kindViolations()).toEqual([]);
  });

  it("G46-2 CONTROL — the checker NAMES a marked node whose value is empty, and goes quiet again", () => {
    // The same mutation §5's RED-when names, applied to the DOM the production call produces: without
    // this the green above is the instrument's silence rather than the layer's declaration.
    renderShell(WRITABLE);
    const victim = declaringNodes()[0]!;
    victim.setAttribute("data-v3-glyph-control", "");
    const named = kindViolations();
    expect(named).toHaveLength(1);
    expect(named[0]).toContain('is not one of glyph | glyph-conditional | cursor');
    victim.setAttribute("data-v3-glyph-control", "glyph");
    expect(kindViolations()).toEqual([]);
  });

  it("G46-2 CONTROL — a FOURTH kind is named too; the set is closed, not merely non-empty", () => {
    renderShell(WRITABLE);
    const victim = declaringNodes()[0]!;
    victim.setAttribute("data-v3-glyph-control", "cursor-ish");
    expect(kindViolations()).toHaveLength(1);
    victim.setAttribute("data-v3-glyph-control", "glyph");
    expect(kindViolations()).toEqual([]);
  });

  it("S46-2's FLIP — every handle declares `cursor`, and NOTHING under the ring layer declares `glyph`", () => {
    // ⚠ THE COUNTERPART OF THE ROW THIS REPLACES, AND IT IS THE SAME CONTRACT READ FROM THE OTHER
    // SIDE. Until this commit the row here asserted the opposite — eight `glyph` declarations, every
    // one still carrying a mark — because §3.1's ordering clause makes the mechanism land in a commit
    // where no pixel moves. That commit is `e605aec`; this is the commit the ordering existed for, so
    // the assertion flips with the value it was guarding rather than being deleted.
    renderShell(WRITABLE);
    const kinds = declaringNodes().map((n) => n.getAttribute("data-v3-glyph-control"));
    expect(kinds).toEqual(Array.from({ length: 8 }, () => "cursor"));
    expect(kindViolations()).toEqual([]);
    // …and the glyph arm's real population under this layer is now EMPTY, which is the fact the two
    // rows below have to plant around rather than a green they may quietly inherit.
    expect(declaringNodes().filter((n) => n.getAttribute("data-v3-glyph-control") === "glyph")).toEqual([]);
  });

  it("G46-3 glyph arm — its population here is EMPTY after S46-2, so the arm is exercised on PLANTS", () => {
    // ⚠ **THE MUTANT IS PLANTED, NOT BORROWED, AND THE PLAN SAYS SO IN TERMS (§5's G46-3 row).** After S46-2 nothing in production declares `glyph` AT ALL.
    // ⚠ **CORRECTED AT S46-5's LANDING AUDIT.** This comment used to name the panel controls as the standing `glyph` population, and the plan's own §5 row said the same. Both were false against source and against C46-0: all five panel write sites write `data-v3-glyph-control=""`, they live OUTSIDE `#dsh-ring-layer`, and C46-0 rules that such a node DECLARES NOTHING. The sentence slid between C9's MARKED universe — where the panel controls really are the glyph-bearing population — and C46-1's DECLARED-KIND predicate, where they are not in it at all. So `glyph` is an UNINHABITED member of the closed three-value set, and the `glyph-conditional` population is the spacing family, which no jsdom suite here populates. Nothing below moved: this row already planted, which is why it stayed green while the prose was wrong.
    // So `glyphArmViolations()` over the real DOM returns `[]` **vacuously** — and a vacuous green is the instrument's silence, not the layer's conformance. Every reading below is on a node this row built, and the empty real population is asserted only after four non-zero readings.
    renderShell(WRITABLE);
    const layer = handleLayerEl();
    const plantGlyph = (patch: (n: HTMLElement) => void): HTMLElement => {
      const n = document.createElement("div");
      n.setAttribute("data-dsh-handle", "nw");
      n.setAttribute("data-v3-glyph-control", "glyph");
      n.innerHTML = '<svg data-glyph="probe" width="8" height="8"></svg>';
      patch(n);
      layer.appendChild(n);
      return n;
    };

    // (a) A WELL-FORMED plant must NOT be named — otherwise every reading below is the checker
    // rejecting everything rather than rejecting the leg each mutant breaks.
    const clean = plantGlyph(() => {});
    expect(glyphArmViolations(), "a `glyph` declaration over a painted mark is clean").toEqual([]);
    clean.remove();

    // (b) declared and ABSENT — §5's own RED-when: declare `glyph` while skipping the glyph build.
    const absent = plantGlyph((n) => {
      n.innerHTML = "";
    });
    expect(glyphArmViolations()).toEqual([expect.stringContaining("has no svg/[data-glyph] descendant")]);
    absent.remove();
    expect(glyphArmViolations()).toEqual([]);

    // (c) declared and HIDDEN — §2.12's escape hatch, refused for the UNCONDITIONAL kind. This is the
    // leg that stops "keep the descendant, set display:none" from buying a green, which is the whole
    // reason C46-1 beats hiding the glyph rather than ignoring it. ⚠ It matters MORE after S46-2, not
    // less: the hatch is now the cheapest way to fake a compliant handle.
    const hidden = plantGlyph((n) => {
      (n.firstElementChild as SVGElement).style.display = "none";
    });
    expect(glyphArmViolations()).toEqual([expect.stringContaining("its mark is display:none")]);
    hidden.remove();

    // ⚠ AND ONLY NOW THE REAL POPULATION, read after the last thing that could have added to it was
    // removed. "No `glyph` declaration under this layer" is an assertion about an instant.
    expect(declaringNodes().filter((n) => n.getAttribute("data-v3-glyph-control") === "glyph")).toEqual([]);
    expect(glyphArmViolations()).toEqual([]);
  });

  it("⚠ THE MEASUREMENT THAT CORRECTS THE PLAN: this suite DOES render `#dsh-spacing-layer`, empty", () => {
    // ⚠ **ralplan-phase-46 §5's G46-3 and G46-5 rows both assert that "no jsdom suite under
    // `packages/descvi/src/react/overlay/__tests__/` renders `#dsh-spacing-layer` at all". As written that
    // is FALSE, and this row is the measurement.** `OverlayShell.tsx` renders the container
    // UNCONDITIONALLY, beside `#dsh-handle-layer`, so every suite in this directory that mounts the shell
    // has it in the DOM. What is true — and what those two rows actually need — is that no suite here
    // POPULATES it: the affordances need a measured box the shell never gets in jsdom, and the popup is
    // built by `use-spacing-drag.ts` only during a drag no jsdom suite performs. Both rows' conclusions
    // stand on the corrected fact; only the reason had to be restated, and the plan was corrected in the
    // same commit rather than left to a reader.
    //
    // ⚠ **AND WHAT THE CORRECTION GAVE UP, STATED RATHER THAN LEFT TO BE DISCOVERED.** "Renders at all" was a
    // STRUCTURAL claim about the component; "populates" is a CONTINGENT one about how the suites in this
    // directory happen to be written today. `resize-drag-wiring.test.tsx` and `OverlayShell-ref-handoff.test.tsx`
    // already stub `Element.prototype.getBoundingClientRect` globally — the exact mechanism that would populate
    // this layer if a computed gap or padding ever appeared beside it. **This row asserts only that THIS suite's
    // container is empty. Nothing holds the directory-wide claim, and no gate does either** — so a future suite
    // that renders spacing affordances in jsdom would falsify the plan's premise without turning anything red.
    renderShell(WRITABLE);
    const spacing = document.getElementById("dsh-spacing-layer");
    expect(spacing, "the container IS rendered here").not.toBeNull();
    expect(ringLayer().contains(spacing!), "and it is a CHILD of the ring layer, which is why its nodes are in C46-0's universe").toBe(true);
    expect(spacing!.children, "…and it is EMPTY, which is the fact the two rows needed").toHaveLength(0);
    expect(document.getElementById("dsh-spacing-popup"), "no jsdom suite here drives a drag, so the popup is unbuildable as a mutant").toBeNull();
  });

  it("G46-5 — the `cursor` conjunction: EVERY conjunct is shown to fire, then the real population is read", () => {
    renderShell(WRITABLE);
    const layer = handleLayerEl();
    const ring = ringLayer();

    // One planted mutant per conjunct. ⚠ Each is otherwise ELIGIBLE, so a violation can only be the
    // term it breaks — a plant that failed two terms would leave the other three untested.
    const eligible = (): HTMLElement => {
      const n = document.createElement("div");
      n.setAttribute("data-dsh-handle", "nw");
      n.setAttribute("data-v3-glyph-control", "cursor");
      n.style.cursor = "nwse-resize";
      return n;
    };
    const mutants: { term: string; expected: string; build: () => HTMLElement }[] = [
      {
        term: "carries data-dsh-handle",
        expected: "declares cursor without data-dsh-handle",
        build: () => {
          const n = eligible();
          n.removeAttribute("data-dsh-handle");
          layer.appendChild(n);
          return n;
        },
      },
      {
        term: "contained in #dsh-handle-layer",
        expected: "declares cursor outside #dsh-handle-layer",
        // ⚠ THE CONJUNCT THAT EXISTS BECAUSE `data-dsh-handle` IS THE SHIELD'S CONCESSION MARKER,
        // shared with the spacing family and with a popup that contains a text input (§2.13). Planted
        // in the ring layer but outside the handle layer, which is exactly that popup's position.
        build: () => {
          const n = eligible();
          ring.appendChild(n);
          return n;
        },
      },
      {
        term: "carries a cursor from the ruled table",
        expected: 'cursor "default" is not in the ruled table',
        build: () => {
          const n = eligible();
          n.style.cursor = "default";
          layer.appendChild(n);
          return n;
        },
      },
      {
        term: "has no focusable descendant",
        expected: "declares cursor with a focusable descendant",
        build: () => {
          const n = eligible();
          n.appendChild(document.createElement("input"));
          layer.appendChild(n);
          return n;
        },
      },
    ];

    for (const { term, expected, build } of mutants) {
      const plant = build();
      const named = cursorEligibilityViolations();
      expect(named, `${term}: the plant must be NAMED`).toHaveLength(1);
      expect(named[0], term).toContain(expected);
      plant.remove();
      expect(cursorEligibilityViolations(), `${term}: and the checker goes quiet again`).toEqual([]);
    }

    // A fully eligible plant must NOT be named — otherwise the four readings above are the checker
    // rejecting everything rather than rejecting the term each mutant broke.
    const clean = eligible();
    layer.appendChild(clean);
    expect(cursorEligibilityViolations()).toEqual([]);
    clean.remove();

    // ⚠ AND ONLY NOW THE REAL POPULATION, read AFTER the instrument has produced four non-zero
    // readings AND after the last plant was removed. ⚠ **THIS HALF CHANGED AT S46-2 AND IT IS THE
    // MORE VALUABLE READING OF THE TWO.** Until this commit the real population was EMPTY by contract
    // and the four plants were all this row could ever say; now the eight shipped handles declare
    // `cursor`, so the conjunction is asserted over real furniture and each of the four terms above
    // has been shown to be capable of naming it.
    const real = declaringNodes().filter((n) => n.getAttribute("data-v3-glyph-control") === "cursor");
    expect(real).toHaveLength(8);
    expect(cursorEligibilityViolations()).toEqual([]);
  });

  it("G46-4 — the `cursor` arm's POSITIVE obligation, on the shipped eight, with the own-compass leg shown RED", () => {
    // ⚠ **THIS ROW BELONGS TO S46-2 BECAUSE ITS POPULATION IS EMPTY IN S46-1** (§5's G46-4 row). The
    // handles declare `cursor` from this commit on, so for the first time the clause has real subjects
    // and the mutants below are applied to shipped nodes rather than only to plants.
    renderShell(WRITABLE);
    const byCompass = new Map(handles().map((h) => [h.getAttribute("data-dsh-handle") ?? "", h]));
    expect(byCompass.size, "the population is not empty").toBe(8);
    expect(cursorArmViolations()).toEqual([]);

    // ── MUTANT 1: the cursor leg — `default` on a node that declares `cursor` (§5's first RED-when).
    const nw = byCompass.get("nw")!;
    nw.style.cursor = "default";
    let named = cursorArmViolations();
    expect(named).toHaveLength(1);
    expect(named[0]).toContain('cursor "default" is not "nwse-resize"');
    nw.style.cursor = "nwse-resize";
    expect(cursorArmViolations()).toEqual([]);

    // ── MUTANT 2: the OWN-COMPASS leg — the LOOKUP-KEY swap, synthesized. ⚠ The plan names
    // "swap `nw` with `ne` in `createHandleNode`'s lookup key" and notes it cannot be applied
    // verbatim, since the site reads `HANDLE_CURSOR[compass]` and has no literal pair to exchange.
    // Exchanging the two rendered nodes' cursors produces exactly the DOM that swapped key would.
    // `nw`↔`ne` is deliberately NOT one of the four value-identical swaps.
    const ne = byCompass.get("ne")!;
    nw.style.cursor = "nesw-resize";
    ne.style.cursor = "nwse-resize";
    named = cursorArmViolations();
    expect(named, "both swapped nodes are named").toHaveLength(2);
    expect(named.join(" ")).toContain('cursor "nesw-resize" is not "nwse-resize"');
    expect(named.join(" ")).toContain('cursor "nwse-resize" is not "nesw-resize"');

    // ⚠ **AND HERE IS WHAT THE NEW LEG BUYS, MEASURED RATHER THAN ASSERTED.** On this same swapped
    // DOM, clause 3's MEMBERSHIP checker stays completely quiet — both values are in the ruled table,
    // so a handle wearing another handle's cursor is invisible to it. That gap is the whole reason
    // clause 4 is a separate clause, and this is the reading that proves the two are not redundant.
    expect(cursorEligibilityViolations(), "the membership checker cannot see a compass swap").toEqual([]);
    nw.style.cursor = "nwse-resize";
    ne.style.cursor = "nesw-resize";
    expect(cursorArmViolations()).toEqual([]);

    // ── MUTANT 3: the NON-ZERO HIT BOX leg, planted on the value nobody plants. An unset width reads
    // back `""`; `Number("")` is 0 and 0 is finite, so a guard written with a coercion would pass it.
    const s = byCompass.get("s")!;
    const keptW = s.style.width;
    s.style.width = "";
    named = cursorArmViolations();
    expect(named).toHaveLength(1);
    expect(named[0]).toContain('hit box "unset"');
    s.style.width = "0px";
    expect(cursorArmViolations()[0], "and a zero box is named too, not only an absent one").toContain('hit box "0px"');
    s.style.width = keptW;
    expect(cursorArmViolations()).toEqual([]);
  });

  it("G46-4 — RR-3 CLOSED: a mutation of the PRODUCTION cursor table is RED here, not green", () => {
    // ⚠ **THE ONE ROW THAT IMPORTS `HANDLE_CURSOR`, AND IT IMPORTS IT TO BREAK IT — NEVER TO DERIVE AN
    // EXPECTATION FROM IT. DO NOT "SIMPLIFY" `CURSOR_FOR_COMPASS` INTO A READ OF THIS SYMBOL.** That
    // is the precise move ralplan RR-3 warns about: an oracle that reads the table moves WITH the
    // table, so a mutation of it changes gate and implementation together and ships green. RR-3 was
    // carried as an open residual because the hand-written set "costs four lines and is deliberately
    // not written here"; it is written now, and this row is the demonstration that it fires.
    // ⚠ **THE SAVED VALUE, NEVER A HARD-CODED ONE, AND THE DIFFERENCE IS THIS ROW'S OWN SUBJECT.** An
    // earlier draft restored with `HANDLE_CURSOR.nw = "nwse-resize"`, which does not restore — it
    // ASSERTS. Under a real source mutation of the production table that draft *repaired the table*
    // for every row after it in the file: the one row that names itself the demonstration was the one
    // row insensitive to the thing it demonstrates. File order happened to hide it; moving this row
    // earlier would have masked a genuine mutation for the whole suite.
    const kept = HANDLE_CURSOR.nw;
    HANDLE_CURSOR.nw = "default";
    try {
      renderShell(WRITABLE);
      const named = cursorArmViolations();
      expect(named, "the table mutation reaches the rendered node").toHaveLength(1);
      expect(named[0]).toContain('cursor "default" is not "nwse-resize"');
    } finally {
      HANDLE_CURSOR.nw = kept;
    }
    // …and the table is restored, so the reading above was this row's mutation and not a standing one.
    cleanup();
    renderShell(WRITABLE);
    expect(cursorArmViolations()).toEqual([]);
  });
});

describe("S42-1 acceptance 6 — the shared-oid hint, non-vacuously in both arms", () => {
  it("instanceCount > 1 renders exactly one ring hint with the live N/M text", () => {
    renderShell(target({ instanceIndex: 2, instanceCount: 3 }));
    expect(document.querySelectorAll("#dsh-ring-instance-hint")).toHaveLength(1);
    const node = ringHint()!;
    expect(node.textContent).toBe("인스턴스 2/3 · 편집은 전체에 적용");
    expect(node.hasAttribute("data-dsh-handle")).toBe(false);
    expect(node.hasAttribute("data-v3-glyph-control")).toBe(false);
    expect(getComputedStyle(node).pointerEvents).toBe("none");
    // The ring hint is its OWN node: the panel's `#dsh-instance-hint` still exists, and one id on
    // two nodes would make G42-7's count unreadable.
    expect(document.getElementById("dsh-instance-hint")).not.toBeNull();
    expect(node.id).not.toBe("dsh-instance-hint");
  });

  it("the Korean hint round-trips with no jamo separation", () => {
    renderShell(target({ instanceIndex: 2, instanceCount: 3 }));
    const text = ringHint()!.textContent ?? "";
    expect(text).toBe(text.normalize("NFC"));
    expect(/[ᄀ-ᇿ㄰-㆏]/.test(text)).toBe(false);
  });

  /**
   * G47-16 leg (ii) — phase-47 §4.1(h), M4.
   *
   * ⚠ **THE HINT IS A CHILD OF `#dsh-handle-layer` AND `visibility` INHERITS.** A reorder drag hides that layer
   * for the duration of the gesture, so without an explicit re-declaration on the hint the layer's hide takes
   * the hint with it — and r2's stated mutation ("add the hint to the hidden set") was green on the defect and
   * on the correct behaviour ALIKE, precisely because the hint was already inside the hidden node. The
   * mutation that fires is deleting the re-declaration, which is what this row reads.
   */
  it("declares its OWN `visibility: visible`, which its two sibling readouts deliberately do not", () => {
    renderShell(target({ className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 }));
    const node = ringHint()!;
    expect(node.style.visibility).toBe("visible");
    // The two other readouts in this layer are LEFT to inherit the hide — asserted so "everything declares it"
    // cannot pass for this row, which would make the hint's declaration meaningless.
    expect(marker()?.style.visibility ?? "").toBe("");
    // …and the property it buys: with the layer hidden, the hint's own computed value is still `visible`.
    const layer = document.getElementById("dsh-handle-layer")!;
    layer.style.visibility = "hidden";
    expect(getComputedStyle(node).visibility).toBe("visible");
    expect(getComputedStyle(layer).visibility).toBe("hidden");
  });

  it("a unique oid renders ZERO ring hints", () => {
    renderShell(WRITABLE);
    expect(document.querySelectorAll("#dsh-ring-instance-hint")).toHaveLength(0);
  });

  it("hint and marker STACK — both live on an axis-blocked shared-oid target", () => {
    renderShell(target({ className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 }));
    expect(ringHint()).not.toBeNull();
    expect(marker()).not.toBeNull();
    expect(ringHint()!.style.top).not.toBe(marker()!.style.top);
  });
});

describe("S42-1 acceptance 7 — the ring layer is unchanged (V3-C7)", () => {
  it("#dsh-ring-layer is still the LAST child of #dsh-frame", () => {
    renderShell(WRITABLE);
    const frame = document.getElementById("dsh-frame")!;
    expect(frame.lastElementChild!.id).toBe("dsh-ring-layer");
  });

  it("its class list is still exactly the five-token set, asserted as a SET", () => {
    renderShell(WRITABLE);
    const tokens = Array.from(document.getElementById("dsh-ring-layer")!.classList);
    expect(new Set(tokens)).toEqual(
      new Set(["z-40", "absolute", "inset-0", "overflow-hidden", "pointer-events-none"]),
    );
    expect(tokens).toHaveLength(5);
  });

  it("the furniture lives INSIDE the ring layer, and the layer keeps its three shipped children", () => {
    renderShell(WRITABLE);
    const layer = document.getElementById("dsh-ring-layer")!;
    for (const id of ["dsh-hover-ring", "dsh-selection-ring", "dsh-selection-badge", "dsh-handle-layer"]) {
      expect(layer.querySelector(`#${id}`)).not.toBeNull();
    }
    for (const handle of handles()) expect(layer.contains(handle)).toBe(true);
  });
});

/**
 * R42-D3's two rows (visual spec §5.8). BOTH are geometry, and jsdom has no layout — so both stubs
 * below are what makes the geometry expressible: `getBoundingClientRect` supplies the subject's box
 * and `offsetHeight` supplies the readouts' measured heights. That is not a workaround for a missing
 * assertion, it is the assertion: clause 4 says the stack offset must be the PREVIOUS readout's
 * MEASURED height, and a test that controls what the code measures is exactly what can tell a
 * measurement from a constant. The rendered-pixel half — a real browser, real wrapping — is the
 * companion row in `e2e/resize-handles.spec.ts`.
 */
function stubSubjectRect(subject: { left: number; top: number; width: number; height: number }): void {
  vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(function (this: Element) {
    if (this.id === "dsh-ring-layer") return asDomRect(LAYER_RECT);
    if (this.id === "dsh-frame") return asDomRect(FRAME_RECT);
    if (this.getAttribute("data-oid") === "row") return asDomRect(subject);
    return asDomRect({ left: 0, top: 0, width: 0, height: 0 });
  });
}

/** Heights by element id; everything else keeps jsdom's own 0, so nothing else changes shape. */
function stubReadoutBoxes(boxes: Record<string, { h: number; w: number }>): void {
  vi.spyOn(HTMLElement.prototype, "offsetHeight", "get").mockImplementation(function (this: HTMLElement) {
    return boxes[this.id]?.h ?? 0;
  });
  vi.spyOn(HTMLElement.prototype, "offsetWidth", "get").mockImplementation(function (this: HTMLElement) {
    return boxes[this.id]?.w ?? 0;
  });
}

const px = (value: string): number => Number.parseFloat(value);

describe("R42-D3 — a readout flips rather than clamping into the clip (visual spec §5.8)", () => {
  // The subject sits low enough that the SHIPPED rule's clamp (`layerHeight − 18` = 582) lands
  // INSIDE its box (520–595) and runs 16 px past the layer's own bottom — the two defects the
  // designer measured on the running build, reproduced here as one fixture.
  const LOW_SUBJECT = { left: 200, top: 520, width: 100, height: 75 };
  const MARKER_H = 34;

  it("near the layer bottom the marker flips ABOVE, stays wholly inside the clip, and clears its subject", () => {
    stubSubjectRect(LOW_SUBJECT);
    stubReadoutBoxes({ "dsh-ring-refusal-marker": { h: MARKER_H, w: 300 } });
    renderShell(target({ editable: false, reason: "no-class", className: undefined }));

    const node = marker()!;
    const top = px(node.style.top);
    const bottom = top + MARKER_H;

    const subjectTop = LOW_SUBJECT.top;
    const subjectBottom = LOW_SUBJECT.top + LOW_SUBJECT.height;
    // Asserted as ONE object rather than three statements, so a RED reports every clause that broke
    // instead of stopping at the first: the shipped placement violates two of them at once, and a
    // receipt that names only the first would understate what the row catches.
    expect({
      // Clause 2 — no part of a refusal is painted outside the layer that clips it.
      insideClip: top >= 0 && bottom <= LAYER_RECT.height,
      // Clause 3 — it never lands on its own subject.
      clearsSubject: bottom <= subjectTop || top >= subjectBottom,
      // Clause 2, positively: it FLIPPED above rather than clamping down onto the frame edge.
      flippedAbove: bottom <= subjectTop,
    }).toEqual({ insideClip: true, clearsSubject: true, flippedAbove: true });
  });

  it("with room below, the preferred position is unchanged — 4 px under the element, left-aligned", () => {
    // The other half of clause 1: the flip is a fallback, not the new normal.
    stubSubjectRect(SUBJECT_RECT);
    stubReadoutBoxes({ "dsh-ring-refusal-marker": { h: MARKER_H, w: 300 } });
    renderShell(target({ editable: false, reason: "no-class", className: undefined }));

    expect(px(marker()!.style.top)).toBe(SUBJECT_RECT.top + SUBJECT_RECT.height + 4);
    expect(px(marker()!.style.left)).toBe(SUBJECT_RECT.left);
  });

  it("clause 4 — the stack offset is the previous readout's MEASURED height, not a constant", () => {
    const HINT_H = 20;
    stubSubjectRect(SUBJECT_RECT);
    stubReadoutBoxes({
      "dsh-ring-instance-hint": { h: HINT_H, w: 200 },
      "dsh-ring-refusal-marker": { h: MARKER_H, w: 300 },
    });
    renderShell(target({ className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 }));

    const hintTop = px(ringHint()!.style.top);
    const markerTop = px(marker()!.style.top);
    // ⚠ RE-DERIVED (plan §8's outward-overhang comment sweep) — this sentence was already false before this phase (no strip has painted anything since S46-2's C46-2) and is doubly so now (the straddling band means a resize strip has no "outward" side to overhang from at all). No overlap by MEASURED boxes, and the gap is at least `READOUT_STACK_GAP_PX`'s own 6 px typographic minimum (its own docblock: enough that two stacked notices read as two rather than one wrapped line).
    expect(markerTop).toBeGreaterThanOrEqual(hintTop + HINT_H + 6);
  });

  it("clause 4, non-vacuously — a TALLER first readout pushes the second one further, by exactly its height", () => {
    // The row above passes against any constant ≥ 26. This one cannot: the only rule that satisfies
    // both is "the previous readout's own measured height". RED-when: any fixed offset at all.
    const readWith = (hintHeight: number): number => {
      stubSubjectRect(SUBJECT_RECT);
      stubReadoutBoxes({
        "dsh-ring-instance-hint": { h: hintHeight, w: 200 },
        "dsh-ring-refusal-marker": { h: MARKER_H, w: 300 },
      });
      renderShell(target({ className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 }));
      const delta = px(marker()!.style.top) - px(ringHint()!.style.top);
      cleanup();
      return delta;
    };
    expect(readWith(60) - readWith(20)).toBe(40);
  });
});

describe("S42-1 — a STALE selectedEl keeps its furniture, in parity with the ring (KI-19)", () => {
  it("a node React has replaced does not re-place the furniture at the layer origin", () => {
    const { container } = renderShell(WRITABLE);
    const before = handles().map((h) => [h.getAttribute("data-dsh-handle"), h.style.left, h.style.top]);
    expect(before).toHaveLength(8);

    // The KI-19 shape, minimally: the effect re-runs (the shell's own resize path bumps `tick`)
    // while `selectedEl` still points at a node that is no longer in the document. Measuring it
    // yields an all-zero rect, which is exactly what the ring's `4e2c26f` guard refuses to paint.
    const subject = container.querySelector<HTMLElement>('[data-oid="row"]')!;
    act(() => {
      subject.remove();
      window.dispatchEvent(new Event("resize"));
    });

    const after = handles().map((h) => [h.getAttribute("data-dsh-handle"), h.style.left, h.style.top]);
    expect(after).toEqual(before);
  });

  it("CONTROL — the same re-anchor DOES move the furniture while the node is still connected", () => {
    // Without this the row above passes against a layer that simply stopped re-anchoring at all.
    const { container } = renderShell(WRITABLE);
    const before = handles().map((h) => h.style.left);
    const subject = container.querySelector<HTMLElement>('[data-oid="row"]')!;
    act(() => {
      (subject as HTMLElement).getBoundingClientRect = () =>
        asDomRect({ left: SUBJECT_RECT.left + 60, top: SUBJECT_RECT.top, width: SUBJECT_RECT.width, height: SUBJECT_RECT.height });
      window.dispatchEvent(new Event("resize"));
    });
    expect(handles().map((h) => h.style.left)).not.toEqual(before);
  });
});

describe("S42-1 — deselection takes the furniture with it", () => {
  it("no selection renders no handles, no marker and no hint", () => {
    render(
      <DescviStateProvider stateAxes={{}}>
        <OverlayShell
          screen={SHELL_SCREEN}
          screenId="test/screen"
          editable
          editMode
          bridge={makeBridge()}
          resolver={RESOLVER}
        >
          <div data-screen="test/screen">
            <div data-oid="row" className="flex">
              row
            </div>
          </div>
        </OverlayShell>
      </DescviStateProvider>,
    );
    expect(handles()).toHaveLength(0);
    expect(marker()).toBeNull();
    expect(ringHint()).toBeNull();
  });
});

// ===========================================================================
// S42-4 — `#dsh-ring-refusal-hint`: the REFUSED aspect lock, on the same ring layer
// ===========================================================================

/**
 * The hint's condition is a MODIFIER on a live gesture, not a property of the selection, so it is
 * fed by a ref the drag writes rather than by a prop. That makes this the one readout the shell
 * rows above cannot reach: driving it through `OverlayShell` would mean performing a whole captured
 * drag on a height-blocked subject to observe a `<div>`. The hook is driven directly instead, with
 * the ref in the test's hand — and the WIRING half (that the gesture writes that ref, before the
 * pass that reads it) is asserted where the gesture lives, in `resize-write-contract.test.tsx`.
 */
/**
 * Every hand-built hook host, so a row that FAILS before its own `unmount()` cannot leave a
 * `#dsh-ring-refusal-hint` in the document for the next row to find.
 *
 * ⚠ MEASURED, NOT PRECAUTIONARY. Driving the constant-offset RED against the stacking row below left
 * its host behind, and the very next row — a CONTROL asserting the hint is absent — read the leaked
 * node and failed too. A control that can be knocked over by an unrelated failure reports on the
 * wrong subject, which is worse than not having it.
 */
const hookHosts: HTMLElement[] = [];

function mountLayerHook(
  /** The published refusal, or `"no-ref"` for the caller that passes the hook no cell at all. */
  refusal: AspectLockRefusalAxis | null | "no-ref",
  patch: Omit<Partial<ResizeHandlesParams>, "aspectLockRefusalRef"> = {},
): {
  ref: { current: AspectLockRefusalAxis | null };
  rerender: () => void;
  unmount: () => void;
} {
  const host = document.createElement("div");
  hookHosts.push(host);
  host.innerHTML = `<div id="dsh-ring-layer"><div id="dsh-handle-layer"></div></div><div data-oid="row" class="flex"></div>`;
  document.body.appendChild(host);
  const ringLayer = host.querySelector<HTMLDivElement>("#dsh-ring-layer")!;
  const handleLayer = host.querySelector<HTMLDivElement>("#dsh-handle-layer")!;
  const subject = host.querySelector<HTMLElement>('[data-oid="row"]')!;
  // ⚠ THE `"no-ref"` RIG STILL HOLDS A LIVE REFUSAL — it simply never hands the cell to the hook. A
  // cell that read `null` there would make the row vacuous: "no hint" would follow from the value
  // rather than from the wiring, and a hook reaching for anything but its own parameter would pass.
  const ref: { current: AspectLockRefusalAxis | null } = { current: refusal === "no-ref" ? "height" : refusal };

  const rendered = renderHook(() => {
    useResizeHandles({
      ringLayerRef: { current: ringLayer },
      handleLayerRef: { current: handleLayer },
      selectedEl: subject,
      selectedTarget: { editable: true, className: "flex" },
      chipEditorDisabled: false,
      chipDisabledReason: undefined,
      ringComponents: [],
      active: true,
      ...(refusal === "no-ref" ? {} : { aspectLockRefusalRef: ref }),
      stateMap: {},
      deviceMode: false,
      dim: { w: 800, h: 600 },
      collapsed: false,
      dark: false,
      tick: 0,
      ...patch,
    });
  });

  return {
    ref,
    // The gesture re-anchors by calling the published pass; a tick bump is the equivalent a test can
    // reach, and it drives the SAME `placeFurniture` the drag would.
    rerender: () => act(() => rendered.rerender()),
    unmount: () => {
      rendered.unmount();
      host.remove();
    },
  };
}

const lockHint = (): HTMLElement | null => document.getElementById("dsh-ring-refusal-hint");

describe("S42-4 — the ring layer's THIRD readout, for a refused aspect lock (§3.2, §3.10)", () => {
  for (const axis of ["width", "height"] as const) {
    it(`a refused lock on the ${axis} axis renders exactly one hint, carrying BOTH halves of the shared message`, () => {
      const rig = mountLayerHook(axis);
      expect(document.querySelectorAll("#dsh-ring-refusal-hint")).toHaveLength(1);
      const node = lockHint()!;
      // Asserted on the TEXT and against the SHARED map, so a surface that minted its own sentence
      // fails here rather than drifting quietly (W2's mechanism, applied to the new readout).
      expect(node.textContent).toContain(ASPECT_LOCK_REFUSED_MESSAGES[axis].ko);
      expect(node.textContent).toContain(ASPECT_LOCK_REFUSED_MESSAGES[axis].en);
      expect(node.getAttribute("data-blocked-axis")).toBe(axis);
      expect(node.getAttribute("data-reason")).toBe("element-axis-controlled-by-variant");
      rig.unmount();
    });
  }

  it("it is a READOUT, not a control — G42-7's Universe B must not name it", () => {
    const rig = mountLayerHook("height");
    const node = lockHint()!;
    expect(getComputedStyle(node).pointerEvents).toBe("none");
    expect(node.hasAttribute("data-dsh-handle")).toBe(false);
    expect(node.hasAttribute("data-v3-glyph-control")).toBe(false);
    // …and it is INSIDE the ring layer, which is what makes the assertions above the ones that gate.
    expect(document.querySelector("#dsh-ring-layer")?.contains(node)).toBe(true);
    rig.unmount();
  });

  it("no refusal, no node — and the SAME pass takes it down again when the ref clears", () => {
    // This is the release-Shift path: the drag nulls the ref and re-anchors, and the hint must go.
    // RED-when: create the node and only ever update its text — the hint then outlives its gesture.
    const rig = mountLayerHook("height");
    expect(lockHint()).not.toBeNull();
    rig.ref.current = null;
    rig.rerender();
    expect(lockHint()).toBeNull();
    rig.unmount();
  });

  it("a caller that passes NO ref gets no hint, even with a live refusal beside it — the parameter is the only channel", () => {
    const rig = mountLayerHook("no-ref");
    expect(rig.ref.current, "the rig's own cell IS set, so the assertion below is a reading").toBe("height");
    expect(lockHint()).toBeNull();
    rig.unmount();
  });

  it("it STACKS with the instance hint rather than replacing it — three ids, three nodes (§3.2)", () => {
    // §3.2's arithmetic: G42-7 counts instance hints and G42-5 asserts the refusal, so one node
    // carrying either message makes both counts unreadable. RED-when: reuse `#dsh-ring-instance-hint`
    // for the lock refusal — the instance count drops to zero and the G42-7 rows fire.
    const rig = mountLayerHook("height", {
      selectedTarget: { editable: true, className: "flex", instanceIndex: 0, instanceCount: 3 },
    });
    expect(document.querySelectorAll("#dsh-ring-instance-hint")).toHaveLength(1);
    expect(document.querySelectorAll("#dsh-ring-refusal-hint")).toHaveLength(1);
    expect(ringHint()!.id).not.toBe(lockHint()!.id);
    rig.unmount();
  });

  it("and with all THREE conditions live the stack is three nodes, each with its own id", () => {
    // An axis-blocked, shared-oid subject mid-Shift-drag. The marker and the hint are different
    // refusals about the same element and both are visible, which §3.3 rules explicitly.
    const rig = mountLayerHook("height", {
      selectedTarget: { editable: true, className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 },
    });
    expect(document.querySelectorAll("#dsh-ring-instance-hint")).toHaveLength(1);
    expect(document.querySelectorAll("#dsh-ring-refusal-marker")).toHaveLength(1);
    expect(document.querySelectorAll("#dsh-ring-refusal-hint")).toHaveLength(1);
    // The marker names the BLOCKED axis of the selection; the hint names the axis the LOCK wanted.
    expect(marker()!.textContent).toContain(AXIS_BLOCKED_MESSAGES.width.ko);
    expect(lockHint()!.textContent).toContain(ASPECT_LOCK_REFUSED_MESSAGES.height.ko);
    rig.unmount();
  });

  it("DR46-6 / C46-4 — every readout carries the 3 px leading accent, and it SURVIVES a re-anchor", () => {
    /**
     * ⚠ **THE PHASE'S ONLY VISIBLE READOUT CHANGE SHIPPED WITH ZERO ASSERTIONS UNTIL THIS ROW, AND ITS
     * REGRESSION PATH IS NAMED IN `styleReadout`'s OWN DOCBLOCK.** That docblock says the `border`
     * shorthand resets all four sides and would wipe the accent on a reused node — and `ensureReadout`
     * DOES return reused nodes on every re-anchor, so the write ORDER (shorthand first, `borderLeft*`
     * second) is load-bearing at runtime. A one-line reorder in either override site silently reverts
     * the restyle, green in both gate sets. This is the row that stops that.
     *
     * ⚠ **THE RE-ANCHOR IS THE POINT, NOT DECORATION.** A first paint would pass even with the writes
     * in the wrong order for the two OVERRIDING readouts, because their `border` shorthand and their
     * `borderLeft*` are both fresh on a fresh node. The bug only appears on the SECOND pass over a
     * REUSED node, which is what `rerender()` drives — the same `placeFurniture` the drag calls.
     */
    const rig = mountLayerHook("height", {
      selectedTarget: { editable: true, className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 },
    });
    const all = (): HTMLElement[] => [ringHint()!, marker()!, lockHint()!];
    expect(all().filter(Boolean)).toHaveLength(3);

    // The accent, on the first pass: the base tone (marker) and both overriding tones.
    for (const node of all()) {
      expect(node.style.borderLeftWidth, `${node.id} carries the accent`).toBe("3px");
      expect(node.style.borderLeftColor, `${node.id} accent is coloured`).not.toBe("");
    }
    // …and the other three sides stay hairline, which is what makes it an ACCENT rather than a border.
    for (const node of all()) {
      expect(node.style.borderTopWidth, `${node.id} top stays 1px`).toBe("1px");
    }

    // ⚠ THE RE-ANCHOR. Same nodes, second pass — the state the regression actually lives in.
    const identities = all();
    rig.rerender();
    expect(all(), "the nodes are REUSED, which is the precondition for the bug").toEqual(identities);
    for (const node of all()) {
      expect(node.style.borderLeftWidth, `${node.id} keeps the accent across a re-anchor`).toBe("3px");
    }

    // CONTROL — the checker must reject a cleared accent, or the six readings above are its silence.
    const victim = marker();
    victim!.style.borderLeftWidth = "1px";
    expect(all().filter((n) => n.style.borderLeftWidth !== "3px"), "a cleared accent is caught").toEqual([victim]);
    // …and the very next re-anchor PUTS IT BACK, because the look is written by the pass and not by
    // the node's history. That is also why the shorthand-then-accent order has to hold every pass.
    rig.rerender();
    expect(marker()!.style.borderLeftWidth, "the pass restores it").toBe("3px");
    rig.unmount();
  });

  /**
   * **G47-7b — THE EXTRACTION CHANGED NOTHING THAT SHIPS (phase-47 S47-4, plan §4.4 / §6).**
   *
   * S47-4 lifts `styleReadout` out of this file into `canvas/readout-style.ts` and gives it `tone`, `zIndex` and `accentPx` parameters, so a THIRD family — the reorder gesture's drop-position readout and its refusal, at z 44 — can take the same look without a fourth copy. The three readouts here are its existing callers, and the whole risk of the move is that one of them silently changes look: the base tone is the REFUSAL's palette, and before the extraction the other two overrode `color`, `border` and `borderLeftColor` by hand, in an order the `border` shorthand makes load-bearing.
   *
   * ⚠ **THE VALUES BELOW WERE READ OFF THE BUILD BEFORE THE EXTRACTION AND PASTED IN, WHICH IS WHAT MAKES THIS A BEFORE/AFTER RATHER THAN A RESTATEMENT OF THE NEW CODE.** Each is the full inline `cssText` of one node, so a tone table that drops, reorders or re-spells any declaration is RED — not only the three colour properties, but the z, the `pointer-events` and the accent width with them.
   *
   * ⚠ **RED-when (G47-7b leg (i)) — AND THE PLAN'S SPELLING OF IT CANNOT BE EXECUTED, SO THE ONE THAT DRIVES THIS ROW IS WRITTEN INSTEAD.** §6 says *"drop `tone` and let a new node inherit the default"*; there IS no default — `tone` is a required field of `ReadoutStyleOptions`, so dropping it is a COMPILE error rather than a silent red, and a mutation the type system refuses is not a mutation this row can be shown red under. **The mutation that drives it is to CHANGE one call site's tone: `tone: "info"` → `"refusal"` on the instance hint.** Driven under both runners: the hint ships the REFUSAL's red and the first assertion below names it.
   *
   * ⚠ Anchor that mutation on the whole `styleReadout(hint, {…});` LINE. `tone: "info"` occurs TWICE in `use-resize-handles.ts` — once in the comment above the call — and a substitution that takes the first occurrence rewrites the COMMENT and leaves the code untouched, which comes back green and reads as an inert gate. That happened once while this row was being built.
   */
  it("G47-7b — the three readouts' inline style is byte-identical to what shipped before the extraction", () => {
    const rig = mountLayerHook("height", {
      selectedTarget: { editable: true, className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 },
    });
    /**
     * ⚠ **PROPERTY BY PROPERTY, NOT `cssText` — AND THE FIRST SPELLING OF THIS ROW WAS `cssText`, WHICH
     * MEASURED THE RUNNER (driven, both ways).** This suite runs under two vitest projects carrying
     * different jsdom versions, and they SERIALISE the same declarations differently: under the package
     * runner the hint reads `… border: 1px solid rgba(100, 116, 139, 0.3); border-left-width: 3px; …`, and
     * under the ROOT runner the identical node reads `border-width: 1px 1px 1px 3px; border-style: solid;
     * border-color: …; border-image: none`. Every VALUE agrees; only the text does not — so a byte-identity
     * row over `cssText` was green in one runner and red in the other on one commit's code.
     *
     * The values below are still the ones captured from the build BEFORE the extraction; only the reading
     * instrument changed. `top` / `left` are excluded on purpose — they are `layoutReadouts`' output and have
     * their own row two below.
     */
    const look = (node: HTMLElement): Record<string, string> => {
      const s = node.style;
      return {
        position: s.position,
        maxWidth: s.maxWidth,
        padding: s.padding,
        borderRadius: s.borderRadius,
        fontSize: s.fontSize,
        lineHeight: s.lineHeight,
        fontFamily: s.fontFamily,
        whiteSpace: s.whiteSpace,
        zIndex: s.zIndex,
        pointerEvents: s.pointerEvents,
        backgroundColor: s.backgroundColor,
        color: s.color,
        borderTopWidth: s.borderTopWidth,
        borderTopStyle: s.borderTopStyle,
        borderTopColor: s.borderTopColor,
        borderLeftWidth: s.borderLeftWidth,
        borderLeftColor: s.borderLeftColor,
        visibility: s.visibility,
      };
    };
    const COMMON = {
      position: "absolute",
      maxWidth: "min(100%, 420px)",
      padding: "2px 6px",
      borderRadius: "4px",
      fontSize: "10px",
      lineHeight: "14px",
      fontFamily: "ui-sans-serif, system-ui, sans-serif",
      whiteSpace: "normal",
      zIndex: "41",
      pointerEvents: "none",
      backgroundColor: "rgba(255, 255, 255, 0.94)",
      // The other three sides stay hairline, which is what makes the leading edge an ACCENT.
      borderTopWidth: "1px",
      borderTopStyle: "solid",
      borderLeftWidth: "3px",
      visibility: "",
    };
    expect(look(ringHint()!), "the instance hint's slate tone, and its `visibility` re-declaration").toEqual({
      ...COMMON,
      color: "rgb(86, 101, 122)",
      borderTopColor: "rgba(100, 116, 139, 0.3)",
      borderLeftColor: "rgb(86, 101, 122)",
      visibility: "visible",
    });
    expect(look(marker()!), "the refusal marker's red — the tone the extracted default still carries").toEqual({
      ...COMMON,
      color: "rgb(185, 28, 28)",
      borderTopColor: "rgba(185, 28, 28, 0.35)",
      borderLeftColor: "rgb(185, 28, 28)",
    });
    expect(look(lockHint()!), "the Shift-lock hint's amber").toEqual({
      ...COMMON,
      color: "rgb(180, 83, 9)",
      borderTopColor: "rgba(180, 83, 9, 0.35)",
      borderLeftColor: "rgb(180, 83, 9)",
    });
    // CONTROL — the comparison must be able to SEE a tone change, or the three readings above are its
    // silence rather than its evidence. One property moved on one node, and the checker names it.
    marker()!.style.color = "#000000";
    expect(look(marker()!).color, "a moved tone is caught").not.toBe("rgb(185, 28, 28)");
    rig.unmount();
  });

  it("R42-D3 with THREE readouts — they stack by MEASURED height and no two of them overlap", () => {
    /**
     * ⚠ WHY THE EXISTENCE ROW ABOVE IS NOT ENOUGH, MEASURED. `mountLayerHook` reports
     * `offsetHeight: 0` for every node, so `layoutReadouts` gives all three the SAME top and a
     * pile-up passes an assertion that only counts nodes. Heights are stubbed here — the same
     * harness clause 4's two-readout rows use — so the placement is a reading rather than a count.
     *
     * The tops are hand-derived from the rule, not from the output: the subject's bottom is 300, so the stack starts at 304 (clause 1's 4 px gap) and each node begins at the previous one's top plus its OWN measured height plus `READOUT_STACK_GAP_PX`'s 6 px typographic minimum (⚠ RE-DERIVED, plan §8's outward-overhang comment sweep — this was already false before this phase, since no strip has painted anything to overhang since S46-2, and is doubly false now that straddle removes the "outward" side the retired sentence leaned on). RED-when: any constant offset — the shipped-and-replaced 18 puts the 34 px marker's box across the readout below it.
     */
    const H = { instance: 20, marker: 34, lock: 26 };
    stubReadoutBoxes({
      "dsh-ring-instance-hint": { h: H.instance, w: 200 },
      "dsh-ring-refusal-marker": { h: H.marker, w: 300 },
      "dsh-ring-refusal-hint": { h: H.lock, w: 260 },
    });
    const rig = mountLayerHook("height", {
      selectedTarget: { editable: true, className: "flex md:w-1/2", instanceIndex: 1, instanceCount: 4 },
    });

    const tops = {
      instance: px(ringHint()!.style.top),
      marker: px(marker()!.style.top),
      lock: px(lockHint()!.style.top),
    };
    expect(tops).toEqual({ instance: 304, marker: 330, lock: 370 });
    // …and the property those numbers are FOR, asserted separately so a future height change cannot
    // quietly turn the row above into three numbers nobody re-derived.
    expect({
      strictlyIncreasing: tops.instance < tops.marker && tops.marker < tops.lock,
      instanceClearsMarker: tops.marker >= tops.instance + H.instance + 6,
      markerClearsLock: tops.lock >= tops.marker + H.marker + 6,
    }).toEqual({ strictlyIncreasing: true, instanceClearsMarker: true, markerClearsLock: true });
    rig.unmount();
  });

  it("CONTROL — the hint is dropped by a DESELECT too, not merely by clearing the ref", () => {
    // `clearAll()` is a different code path from the per-pass `dropById`, and a hint left behind by
    // it would outlive the whole selection rather than just the gesture.
    const rig = mountLayerHook("height", { active: false });
    expect(lockHint()).toBeNull();
    rig.unmount();
  });
});

/**
 * G48-9 conditional reorder — UNIT LEVEL (plan §4.1's history-dependence path). `use-resize-handles.ts#    const desiredOrder = [...HANDLE_ADMISSION_ORDER].reverse().filter((compass) => wanted.has(compass));` onward compares the host's CURRENT `[data-dsh-handle]` order against the reverse-priority order it wants and only re-appends when they differ — `e2e/resize-handles.spec.ts`'s `G48-9` browser leg cannot drive that comparison's two branches, because its own header rules out a source write and the axis filter reads `selectedTarget.className`, not a live DOM attribute. `className` IS a render input `mountLayerHook`'s rig controls directly, so this is driven here.
 */
describe("G48-9 conditional reorder — unit level (the history-dependence path §4.1 names; the e2e leg cannot change the rendered set)", () => {
  // Hand-written, never `[...HANDLE_ADMISSION_ORDER].reverse()` — an oracle built from the production list would move WITH a mutation of it, exactly the hole this file's other hand-written literals (`CURSOR_FOR_COMPASS`, `REVERSE_PRIORITY` here) exist to avoid.
  const REVERSE_PRIORITY = ["w", "s", "e", "n", "sw", "se", "ne", "nw"];

  it("(a) the host's [data-dsh-handle] order becomes the reverse priority sequence once the rendered set grows", () => {
    // Starts a SUBSET: width blocked (`md:w-1/2`) leaves only n/s, matching acceptance 2's own measured set. `selectedTarget` is the SAME object `mountLayerHook`'s closure reads on every `rerender()` — mutating its `className` and calling `rerender()` is the file's own established pattern for driving a second render pass (see `rig.ref.current = null; rig.rerender();` above). `ResizeHandleTarget`, not `ResolveResult` — `mountLayerHook`'s param IS `ResizeHandlesParams`' own shape (the hook's boundary), never the resolver's; inferred rather than annotated so the SAME reference stays mutable and structurally matches without importing a second target type.
    const selectedTarget = { editable: true, className: "flex md:w-1/2" };
    const rig = mountLayerHook(null, { selectedTarget });
    expect(handles().map((h) => h.getAttribute("data-dsh-handle")).sort()).toEqual(["n", "s"]);

    // Both axes writable — the set grows from 2 to the full 8, which is the transition `desiredOrder !== currentOrder` needs a subject to observe at all.
    selectedTarget.className = "flex";
    rig.rerender();
    expect(handles()).toHaveLength(8);

    const host = document.getElementById("dsh-handle-layer")!;
    const order = Array.from(host.querySelectorAll<HTMLElement>("[data-dsh-handle]")).map((n) => n.getAttribute("data-dsh-handle"));
    expect(order, "the host's own DOM order, sibling by sibling").toEqual(REVERSE_PRIORITY);
    rig.unmount();
  });

  it("(b) a size-only rerender with an UNCHANGED rendered set never touches the host's children", () => {
    const selectedTarget = { editable: true, className: "flex" };
    const rig = mountLayerHook(null, { selectedTarget });
    expect(handles()).toHaveLength(8);

    // The spy attaches BETWEEN the two renders, per the brief: the first render's own eight `appendChild` calls (new nodes, nothing to compare them against) are not what this row gates.
    const host = document.getElementById("dsh-handle-layer")!;
    const appendSpy = vi.spyOn(host, "appendChild");

    // SIZE-only: `subjectRect` is this file's own stub for the subject's measured box (`beforeEach`, above) — the axis filter reads `className`, unchanged here, so the rendered SET cannot move.
    subjectRect = { left: 200, top: 200, width: 150, height: 90 };
    rig.rerender();
    expect(handles()).toHaveLength(8);

    expect(appendSpy, "no new node and no reorder — the comparison's own job is to stay silent here").not.toHaveBeenCalled();
    appendSpy.mockRestore();
    rig.unmount();
  });
});
