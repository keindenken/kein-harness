/**
 * handle-geometry.ts — where the eight resize handles go (phase-48 B-Q5; ported from the owner's corner-ramp spec, plan §4/§4.1 — supersedes phase-42 S42-1's admission walk, plan §1/§2).
 *
 * PURE. No DOM, no React, no measurement — every input is a rect the caller already measured, and every output is a number the caller writes onto a node. That split is what lets the model be tested with exact coordinates instead of through a rendered overlay.
 *
 * COORDINATES ARE LAYER-RELATIVE, exactly like the selection ring's: the caller subtracts `#dsh-ring-layer`'s own rect origin before calling in, and writes the results straight onto `style.left` / `style.top`. Nothing here knows about the viewport.
 *
 * CLIP, DON'T PUSH (plan §2). This module does not clip or translate anything any more: it returns eight region rects — four corner squares and four straddling edge bands — and any one of them may extend past the layer or the frame. The clip is real and it belongs to the DOM: `#dsh-ring-layer` carries `overflow: hidden` and `#dsh-frame` carries `overflow-hidden rounded-xl`, so a region that reaches outside either is clipped by the browser rather than by this file — in PAINT to the rounded shape `border-radius` draws, and in HIT-TESTING to the padding-box RECTANGLE only, never to that curve (plan §6.1, measured 2026-09-03; `G48-4`'s standing radius-reading row is the check). A region whose intersection with that clip is empty renders a node nobody can reach — the clip acting, not a refusal.
 *
 * THE MODEL REFUSES NOTHING (plan §1). Every subject gets all eight regions, axis-filtered only: `handleAxes` still runs first, so a handle whose complete write set is unwritable is not emitted — but nothing else drops a handle: no separation clause, no coverage floor, no size predicate. Overlap where two regions claim the same pixel is resolved by PRECEDENCE, not by refusal: {@link HANDLE_ADMISSION_ORDER} read as a priority list decides it for the unit oracles, and the z pair in `use-resize-handles.ts` (`RESIZE_CORNER_Z` over `RESIZE_STRIP_Z`) decides it in the DOM.
 *
 * A TRANSITIONAL PATH SURVIVES THIS COMMIT, EXPORTED AND UNCALLED. The retired push-and-clip machinery — {@link buildEffectiveClip}, {@link placeHandle}, {@link fitsInClip}, {@link hitSizeFor}, {@link HANDLE_HIT_PX}, {@link STRIP_HIT_BAND_PX}, {@link STRIP_EDGE_COVERAGE_MIN}, {@link FRAME_CORNER_RADIUS_PX}, {@link EffectiveClip} and {@link ClipArc} — stays because `src/app/sandbox/handle-lab`'s `policies.ts` and `order-walk.ts` still call it, and the lab must keep compiling untouched across the split (plan §7, `S48-1a`). `S48-1b` deletes the whole path — and repairs the lab — in the same commit.
 *
 * SaaS-seam: overlay-CLIENT code — NO `node:*` / `process` / `fs`.
 */

/** The eight handles, named by the EDGE or CORNER they sit on — never by the axis they write. */
export type HandleCompass = "nw" | "ne" | "se" | "sw" | "n" | "e" | "s" | "w";

/**
 * THE CANONICAL PRECEDENCE (plan §4.1), read two ways. As a priority list, first match wins: it resolves which region owns a pixel that two of the eight regions both claim — nw beats ne beats se beats sw at a shared corner square, n beats e beats s beats w at a shared band square. As a paint order, read BACKWARDS, it is the sibling sequence `use-resize-handles.ts` appends into the DOM, so the runtime and the unit oracles agree by derivation from the same list rather than by inspection of two independently-written ones.
 *
 * EVERY CORNER PRECEDES EVERY BAND, and that is an invariant ON THE LIST rather than something a reader could derive from it: the runtime answers corner-over-band by the z pair in `use-resize-handles.ts` (`RESIZE_CORNER_Z` over `RESIZE_STRIP_Z`), whatever this list says — so a list that put a band ahead of a corner would leave the runtime unchanged and desynchronise the oracle from it. `G48-9`'s leg for the invariant demonstrates its RED on the oracle side alone.
 */
export const HANDLE_ADMISSION_ORDER: readonly HandleCompass[] = [
  "nw",
  "ne",
  "se",
  "sw",
  "n",
  "e",
  "s",
  "w",
];

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for `src/app/sandbox/handle-lab` alone (plan §7, `S48-1a`); deleted in `S48-1b`.** The separation clause this decided is retired (plan §1/§2) and nothing in this file reads it any more.
 *
 * The DECIDABILITY extent: a corner's hit square, and the ONE constant §3.12's separation clause is pinned to. Owner-adjustable, but it must stay a single number: leaving it a free 16–24 px choice lets two gate rows predict different furniture for the same fixture.
 *
 * ⚠ It is NO LONGER a strip's hit band — see {@link STRIP_HIT_BAND_PX}. The two were one symbol doing two unrelated jobs, and R42-D1 is the ruling that split them.
 */
export const HANDLE_HIT_PX = 20;

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** The outward-band ruling this docblock argues for is reversed by `S48-0` — the shipped band now straddles the edge at {@link HANDLE_BAND_PX} — and nothing in this file reads this constant any more.
 *
 * R42-D1 (designer lane, visual spec §5.8) — a STRIP's short-axis hit band, and it lies wholly OUTSIDE the element's border box.
 *
 * WHY IT IS ITS OWN NUMBER. {@link HANDLE_HIT_PX} is a decidability constant — it is what the admission clauses measure separation against — while this is an ergonomics one. Sharing a symbol meant narrowing the hot edge to fit a hand also moved the furniture that renders.
 *
 * WHY IT IS OUTWARD, WHICH IS THE RULING'S REAL CONTENT. Measured over this corpus: of 628 nested parent/child `[data-oid]` pairs, 51.6 % are FLUSH with their parent, so an inward apron of ANY width swallows the click that drills into them — and descvi is drilled into, not clicked at, so that apron removes the tool's primary navigation gesture. Narrowing it is a marginal fix (10 → 2 px recovers 39 pairs of 373); moving it out is the fix. Outward, the same band costs "click just beside the element to reach its parent or sibling", a gesture that always has somewhere else to go, and a mis-started resize below the drag threshold is a no-op that leaves the selection alone.
 *
 * THE ONE EXCEPTION, and it is forced rather than chosen: at a frame-flush edge the outward band is outside the clip, where nothing can reach it, so the clamp moves it inward (acceptance 4c). That is the same inset the corners already take there.
 *
 * ⚠ **ITS DERIVATION WAS THE PAINT'S AND THE PAINT IS GONE (phase-46 S46-2, ralplan §2.9's first falsified rationale).** This docblock used to read *"the value covers the painted pill's outward overhang (the pill is centred on the edge and reaches 6 px beyond it) and doubles it, so every painted pixel outside the box is hittable"* — a derivation from a painted pill that C46-2 removes. **The VALUE does not move; only its justification does**, and the replacement is stated in terms of the HIT geometry this number now wholly describes: 12 px is the ergonomic reach outside the edge, and its only remaining relations are the two the unit oracle pins — it stays strictly below {@link HANDLE_HIT_PX}, the decidability extent it must not be confused with, and it stays at or above the corner chip's own overhang ({@link HANDLE_CHIP_PX} / 2), so a strip's band is never narrower than the paint that reaches across its edge at the corner.
 *
 * ⚠ **WIDENING IT IS A REAL OPTION THAT PHASE-46 REFUSES RATHER THAN OMITS**, and the standing objection is R42-D1's own measurement: the band lies outside the element, so widening it takes surface from whatever sits beside the element, and in this corpus that is very often a sibling. Phase-48 inherits the option with that as the objection to answer.
 */
export const STRIP_HIT_BAND_PX = 12;

/**
 * The glyph's rendered box (S42-1 acceptance 4 pins it to 6–10 px on both axes).
 *
 * ⚠ **NO RESIZE HANDLE RENDERS A GLYPH AFTER phase-46 S46-2** — the corner's mark is dropped and the strips lose their paint entirely (C46-2). This constant and `handle-glyphs.ts`'s builder are retained deliberately, not by oversight: P46-3's whole payment is that putting the mark back is a kind VALUE plus a render branch in `createHandleNode`, with no gate edit and no red window, and deleting the builder would take the branch with it. The 6–10 bound below is still pinned by the unit oracle, so the constant cannot drift while it waits.
 */
export const HANDLE_GLYPH_PX = 8;

/**
 * The painted CORNER chip inside the hit target.
 *
 * ⚠ **SHRUNK FROM 14 AT phase-46 S46-2, AND ITS OLD DERIVATION IS GONE WITH THE GLYPH.** It used to read *"big enough to hold the glyph with breathing room"*, which was a derivation from the 8 px mark C46-2 removes; §9 U2a rules that S46-2 picks the replacement and the owner's live pass may revise it. Why 10:
 *
 *  - **R42-D2's standing condition is the CONSTRAINT, and the size is a JUDGEMENT inside it.** The ruling is verbatim *"it may not drop the border for a fill-only chip"* — it names no minimum interior, no ratio and no measurement, and nothing else in this repo derives a legibility floor for a bordered box. So: the border must survive and the chip must leave an interior that still reads as a bordered chip rather than as a dot; **how much is legible is a judgement THIS STORY makes and the owner's live pass may revise (§9 U2a).** 10 leaves 7 px inside the 1.5 px border. ⚠ **8 is the smallest this lane would defend, not a derived bound** — an earlier draft of this docblock called it "the floor rather than a choice", which dressed a judgement in a derivation's clothes.
 *  - **§5.4's shape argument survives the restyle and needs a SQUARE**, so the radius comes down with the side rather than staying at 4, which on a 10 px box would round the chip toward a circle and lose the "no long axis, therefore both axes" read. ⚠ **3 is a ROUNDING, not a ratio carried over**: 10 × 2/7 = 2.857, and 3:10 is not 2:7. The shipped 14:4 is the reference point, not a law.
 *  - **It halves the small-element cost direction 2 was given for.** R42-D2 centres each chip on the box corner, so on a 30 × 30 subject the four corners take `4 × 5² / 900` ≈ 11.1 % of the element's own area, against `4 × 7² / 900` ≈ 21.8 % at 14 (visual spec §5.6, whose *"about 87 %"* counted four WHOLE chips and is corrected in the same commit as this line).
 *  - It happens to be exactly half {@link HANDLE_HIT_PX}. ⚠ **That is a property of the pair, not a reason for the value** — 14 against 20 did not suggest the hit size either, and no gate or ruling relates the two numbers.
 *
 * ⚠ **NO STRIP IS PAINTED AT ALL AFTER S46-2**, so this is a corner-only number now; the `HANDLE_CHIP_PX ± 6` pill dimensions it used to feed are deleted rather than re-valued.
 */
export const HANDLE_CHIP_PX = 10;

/** The owner's ramp starts at this short-side size. */
export const CORNER_RAMP_NARROW_PX = 20;
/** The owner's corner extent at and below {@link CORNER_RAMP_NARROW_PX}. */
export const CORNER_RAMP_NARROW_CORNER_PX = 8;
/** The owner's ramp reaches its upper extent at this short-side size. */
export const CORNER_RAMP_WIDE_PX = 80;
/** The owner's corner extent at and above {@link CORNER_RAMP_WIDE_PX}. */
export const CORNER_RAMP_WIDE_CORNER_PX = 16;
/**
 * The straddling side band's full thickness — half inside the border box, half outside (plan §4).
 *
 * ⚠ **THE 8-VS-10 CHOICE IS THE DESIGNER'S, NOT AN OWNER RULING, AND `10` IS A STARTING DEFAULT (plan §1).** The owner handed this value to a designer verbatim, so a designer may move it — that edit is one line here plus the mirrored literal `G48-11` pins, in the same change. `10` is what shipped first, not what was decided last.
 *
 * ⚠ **THIS IS THE ONE NUMBER `G48-11`'S UNIT ASSERTIONS AND TWO PRICED RECORDS ARE MEASURED AGAINST.** `G48-11` pins the band's short axis at this literal and its near edge at `edge − 5` (half of it) per band, so a change here without the mirrored literal edit there is caught rather than silently drifting. The drill-down cost — every selected element's inward-facing resize surface swallowing a click that used to drill into a flush child — is priced against this value in `.omc/research/phase48-straddle-drilldown-cost.md` (mean flush-child shadowing 25.8 % at `10` against 20.8 % at `8`, the more-than-half-shadowed class 32 pairs against 14). The swallowed-affordance record — a padding strip whose deepest reachable point falls inside this band's reach — is priced against it in `docs/e3/tracker.md`'s phase-48 section and the `| B-Q5 |` row of `docs/post-loop-backlog.md` (`EG-1`'s reading): the class is non-empty at either 8 or 10, emptying only for a band strictly below 8.
 */
export const HANDLE_BAND_PX = 10;

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** Clipping is the browser's job now (plan §2) and this file computes no clip.
 *
 * `#dsh-frame`'s `rounded-xl` radius, in px — READ ONLY BY THE LAB now. ⚠ **Its old gloss, "this is where the two clip rects diverge" (§2.1), is VOID under the rectangle reading (plan §6.1, measured 2026-09-03): hit-testing clips to the padding-box RECTANGLE, never to this curve, so no clip rect here diverges from another over it.** And the VALUE itself was never re-measured against the shipped `rounded-xl` class, which the same reading put at 14 — this constant carries `12` only because the lab still calls it, not because either number is trusted.
 */
export const FRAME_CORNER_RADIUS_PX = 12;

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** The new model refuses nothing (plan §1), so no strip is ever trimmed below a coverage floor and nothing in this file reads this constant any more.
 *
 * The share of its edge a strip must still span after clipping to remain worth rendering (S42-1 acceptance 9). A strip trimmed below this is refused rather than shipped as a stub that lies about which edge it controls.
 */
export const STRIP_EDGE_COVERAGE_MIN = 0.9;

const CORNERS: readonly HandleCompass[] = ["nw", "ne", "se", "sw"];

export function isCornerHandle(compass: HandleCompass): boolean {
  return CORNERS.includes(compass);
}

/** Which axes a handle writes (§3.10's table): corners write both, E/W width, N/S height. */
export function handleAxes(compass: HandleCompass): { width: boolean; height: boolean } {
  switch (compass) {
    case "e":
    case "w":
      return { width: true, height: false };
    case "n":
    case "s":
      return { width: false, height: true };
    default:
      return { width: true, height: true };
  }
}

/** A layer-relative box. `left`/`top` are the origin; `width`/`height` may be 0 or sub-pixel. */
export interface HandleRect {
  left: number;
  top: number;
  width: number;
  height: number;
}

export interface HandlePoint {
  x: number;
  y: number;
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** `use-resize-handles.ts` no longer builds or passes one (plan §2).
 *
 * One rounded corner of `#dsh-frame`, as a circle in LAYER coordinates.
 */
export interface ClipArc {
  cx: number;
  cy: number;
  r: number;
  /** Which quadrant of the circle is the clipped one — the sign pair a point must match to be tested. */
  sx: -1 | 1;
  sy: -1 | 1;
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** `AdmissionInput`'s `clip` member is optional and read by nothing (plan §2).
 *
 * The intersection of the ring layer's rect and the frame's rounded rect, in layer coordinates.
 */
export interface EffectiveClip {
  left: number;
  top: number;
  right: number;
  bottom: number;
  arcs: readonly ClipArc[];
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** Clipping is the browser's job now — see this file's module docblock and plan §2 — so nothing in this file calls this any more.
 *
 * Builds the effective clip. `layer` and `frame` are both LAYER-RELATIVE (the caller has already subtracted the layer's own origin, so `layer` is `{0, 0, w, h}` and `frame` is usually inset by the frame's 1 px border in the negative direction).
 *
 * The rect half is a plain intersection. The rounded half is carried as four arcs rather than folded into the rect, because a rect inset by the radius would refuse placements that are perfectly legal along the straight edges — which is most of them.
 */
export function buildEffectiveClip(
  layer: HandleRect,
  frame: HandleRect | null,
  radius: number = FRAME_CORNER_RADIUS_PX,
): EffectiveClip {
  const left = frame === null ? layer.left : Math.max(layer.left, frame.left);
  const top = frame === null ? layer.top : Math.max(layer.top, frame.top);
  const right =
    frame === null ? layer.left + layer.width : Math.min(layer.left + layer.width, frame.left + frame.width);
  const bottom =
    frame === null ? layer.top + layer.height : Math.min(layer.top + layer.height, frame.top + frame.height);

  const arcs: ClipArc[] = [];
  if (frame !== null && radius > 0) {
    const fl = frame.left;
    const ft = frame.top;
    const fr = frame.left + frame.width;
    const fb = frame.top + frame.height;
    arcs.push(
      { cx: fl + radius, cy: ft + radius, r: radius, sx: -1, sy: -1 },
      { cx: fr - radius, cy: ft + radius, r: radius, sx: 1, sy: -1 },
      { cx: fr - radius, cy: fb - radius, r: radius, sx: 1, sy: 1 },
      { cx: fl + radius, cy: fb - radius, r: radius, sx: -1, sy: 1 },
    );
  }
  return { left, top, right, bottom, arcs };
}

/**
 * The element point a handle is anchored to (§3.12 clause 4): the box CORNER for a corner handle,
 * the edge MIDPOINT for a strip.
 */
export function compassPoint(box: HandleRect, compass: HandleCompass): HandlePoint {
  const l = box.left;
  const t = box.top;
  const r = box.left + box.width;
  const b = box.top + box.height;
  const mx = l + box.width / 2;
  const my = t + box.height / 2;
  switch (compass) {
    case "nw":
      return { x: l, y: t };
    case "ne":
      return { x: r, y: t };
    case "se":
      return { x: r, y: b };
    case "sw":
      return { x: l, y: b };
    case "n":
      return { x: mx, y: t };
    case "e":
      return { x: r, y: my };
    case "s":
      return { x: mx, y: b };
    case "w":
      return { x: l, y: my };
  }
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** {@link buildHandleRegions} answers "how big is this handle" in its place now, from the ramp and {@link HANDLE_BAND_PX} rather than from this table.
 *
 * The UNCLIPPED hit-target size. A corner is square; a strip spans its whole edge on the long axis and {@link STRIP_HIT_BAND_PX} on the short one, which is what makes acceptance 9's ≥ 90 % coverage reachable at full size.
 */
export function hitSizeFor(box: HandleRect, compass: HandleCompass): { width: number; height: number } {
  if (isCornerHandle(compass)) return { width: HANDLE_HIT_PX, height: HANDLE_HIT_PX };
  if (compass === "n" || compass === "s") return { width: box.width, height: STRIP_HIT_BAND_PX };
  return { width: STRIP_HIT_BAND_PX, height: box.height };
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} still calls it (plan §7, `S48-1a`); deleted with `placeHandle` in `S48-1b`.**
 *
 * ⚠ **SCOPED TO THE RETIRED MODEL — R42-D1's outwardness is reversed by `S48-0`, and the shipped band straddles the edge instead (`HANDLE_BAND_PX`, {@link buildHandleRegions}).** What follows describes what THIS function computes, for `placeHandle`'s retired push-and-clip machinery alone, and is not a claim about the model this file ships: a strip's UNCLIPPED short-axis edges, wholly on the OUTSIDE of the edge it names, touching it and never crossing it. A corner is still centred on its box corner ({@link centredOn}), which the retired ruling kept deliberately: it overlapped 10 px on each axis at four points against the strips' whole-perimeter apron, and was the target a hand aimed for on a small element.
 */
function stripBandEdges(box: HandleRect, compass: HandleCompass): { near: number; far: number } {
  switch (compass) {
    case "n":
      return { near: box.top - STRIP_HIT_BAND_PX, far: box.top };
    case "s":
      return { near: box.top + box.height, far: box.top + box.height + STRIP_HIT_BAND_PX };
    case "w":
      return { near: box.left - STRIP_HIT_BAND_PX, far: box.left };
    default:
      return { near: box.left + box.width, far: box.left + box.width + STRIP_HIT_BAND_PX };
  }
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} and its retired helpers still use it (plan §7, `S48-1a`); deleted with them in `S48-1b`.**
 */
interface Edges {
  left: number;
  top: number;
  right: number;
  bottom: number;
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} still calls it (plan §7, `S48-1a`); deleted with `placeHandle` in `S48-1b`.**
 */
function centredOn(point: HandlePoint, size: { width: number; height: number }): Edges {
  return {
    left: point.x - size.width / 2,
    top: point.y - size.height / 2,
    right: point.x + size.width / 2,
    bottom: point.y + size.height / 2,
  };
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} still calls it (plan §7, `S48-1a`); deleted with `placeHandle` in `S48-1b`.** Clipping is the browser's job now (plan §2); nothing in the shipped model translates a placement into a clip rect.
 *
 * Translates `e` by the least amount that puts it inside the clip RECT (the arcs are separate).
 */
function translateIntoRect(e: Edges, clip: EffectiveClip): Edges {
  let dx = 0;
  let dy = 0;
  if (e.left + dx < clip.left) dx = clip.left - e.left;
  if (e.right + dx > clip.right) dx = clip.right - e.right;
  if (e.top + dy < clip.top) dy = clip.top - e.top;
  if (e.bottom + dy > clip.bottom) dy = clip.bottom - e.bottom;
  return { left: e.left + dx, top: e.top + dy, right: e.right + dx, bottom: e.bottom + dy };
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle}, {@link pushOutOfArcs} and {@link fitsInClip} still call it (plan §7, `S48-1a`); deleted with them in `S48-1b`.**
 *
 * The corner of `e` that sits in `arc`'s clipped quadrant, or null when none does.
 */
function cornerInArcQuadrant(e: Edges, arc: ClipArc): HandlePoint | null {
  const x = arc.sx < 0 ? e.left : e.right;
  const y = arc.sy < 0 ? e.top : e.bottom;
  const beyondX = arc.sx < 0 ? x < arc.cx : x > arc.cx;
  const beyondY = arc.sy < 0 ? y < arc.cy : y > arc.cy;
  if (!beyondX || !beyondY) return null;
  return { x, y };
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link fitsInClip} still calls it (plan §7, `S48-1a`); deleted with `fitsInClip` in `S48-1b`.** Nothing in the shipped model refuses a placement for violating an arc — clipping is the browser's job now (plan §2).
 */
function violatesArc(e: Edges, arc: ClipArc): boolean {
  const p = cornerInArcQuadrant(e, arc);
  if (p === null) return false;
  return Math.hypot(p.x - arc.cx, p.y - arc.cy) > arc.r + 1e-9;
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} still calls it (plan §7, `S48-1a`); deleted with `placeHandle` in `S48-1b`.** "Clip, don't push" (plan §2) — the shipped model pushes nothing.
 *
 * Pushes a SQUARE hit target out of every rounded corner it overlaps, along the radius — the shortest translation that satisfies the arc, so the anchor envelope is spent as slowly as possible.
 */
function pushOutOfArcs(e: Edges, clip: EffectiveClip): Edges {
  let out = e;
  for (const arc of clip.arcs) {
    const p = cornerInArcQuadrant(out, arc);
    if (p === null) continue;
    const dx = p.x - arc.cx;
    const dy = p.y - arc.cy;
    const d = Math.hypot(dx, dy);
    if (d <= arc.r + 1e-9 || d === 0) continue;
    const shiftX = arc.cx + (dx / d) * arc.r - p.x;
    const shiftY = arc.cy + (dy / d) * arc.r - p.y;
    out = {
      left: out.left + shiftX,
      top: out.top + shiftY,
      right: out.right + shiftX,
      bottom: out.bottom + shiftY,
    };
  }
  return out;
}

/**
 * ⚠ **TRANSITIONAL, retained only because {@link placeHandle} still calls it (plan §7, `S48-1a`); deleted with `placeHandle` in `S48-1b`.** The shipped model has no coverage floor and trims no band (plan §1) — {@link buildHandleRegions} emits a band spanning its edge exactly, always.
 *
 * Trims a STRIP's long axis SYMMETRICALLY until it clears the clip rect and every arc.
 *
 * Symmetric rather than per-end, and that is load-bearing: an asymmetric trim slides the strip's centre along its own edge, and §3.12 clause 4 measures that centre against the edge MIDPOINT. A 10 % one-sided trim of a 500 px edge would move the centre 25 px and fail the envelope while the coverage ratio still read 90 %. Trimming both ends by the larger amount keeps the centre put and makes the coverage ratio the only thing that can refuse the strip.
 */
function trimStripSymmetrically(e: Edges, clip: EffectiveClip, horizontal: boolean): Edges {
  const centre = horizontal ? (e.left + e.right) / 2 : (e.top + e.bottom) / 2;
  const half = horizontal ? (e.right - e.left) / 2 : (e.bottom - e.top) / 2;
  let trim = 0;

  if (horizontal) {
    trim = Math.max(trim, clip.left - e.left, e.right - clip.right);
  } else {
    trim = Math.max(trim, clip.top - e.top, e.bottom - clip.bottom);
  }

  for (const arc of clip.arcs) {
    // The strip's two long edges, each tested against this arc's band of the circle. `fixed` is the
    // coordinate on the SHORT axis (already final); the arc then bounds how far the LONG axis may run.
    const fixedCoords = horizontal ? [e.top, e.bottom] : [e.left, e.right];
    const fixedSign = horizontal ? arc.sy : arc.sx;
    const fixedCentre = horizontal ? arc.cy : arc.cx;
    const longSign = horizontal ? arc.sx : arc.sy;
    const longCentre = horizontal ? arc.cx : arc.cy;
    for (const fixed of fixedCoords) {
      const dFixed = fixed - fixedCentre;
      const beyondFixed = fixedSign < 0 ? dFixed < 0 : dFixed > 0;
      if (!beyondFixed) continue;
      // |dFixed| > r means this long edge lies outside the arc's band altogether, which the short-axis
      // rect clamp has already ruled out; nothing here can rescue it, and nothing here should try.
      if (Math.abs(dFixed) > arc.r) continue;
      const span = Math.sqrt(Math.max(0, arc.r * arc.r - dFixed * dFixed));
      if (longSign < 0) {
        trim = Math.max(trim, longCentre - span - (centre - half));
      } else {
        trim = Math.max(trim, centre + half - (longCentre + span));
      }
    }
  }

  const newHalf = half - Math.max(0, trim);
  if (horizontal) {
    return { left: centre - newHalf, right: centre + newHalf, top: e.top, bottom: e.bottom };
  }
  return { left: e.left, right: e.right, top: centre - newHalf, bottom: centre + newHalf };
}

/** A handle that has been placed — the exact numbers the renderer writes, plus what admitted it. */
export interface HandlePlacement {
  compass: HandleCompass;
  /** Layer-relative hit-target box. */
  left: number;
  top: number;
  width: number;
  height: number;
  /** The hit target's centre — the point `elementFromPoint` is asked about. */
  centre: HandlePoint;
  /** The element point this handle is anchored to (clause 4's reference). */
  anchor: HandlePoint;
  /**
   * ⚠ **TRANSITIONAL — constant 1 for every region {@link buildHandleRegions} emits, retained for the lab's `order-walk.ts` alone (plan §7, `S48-1a`); deleted in `S48-1b`.** Nothing in the new model trims a band, so this field carries no information while it waits; it used to be, for a strip, the share of its edge the placed box still spanned after {@link placeHandle}'s clip trim.
   */
  edgeCoverage: number;
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** {@link buildHandleRegions} is the ported region builder and `admitHandles` calls that, not this — the push-and-clip mechanism below is dead code kept only for the lab's `order-walk.ts`, which still calls it (plan §2, "clip, don't push").
 *
 * Places ONE handle, then moves it the least amount that puts it wholly inside the effective clip. A corner is CENTRED on its compass point and translates (pushing out of a rounded arc); a strip hangs OUTSIDE its edge (R42-D1, {@link stripBandEdges}), translates on its short axis and trims symmetrically on its long one.
 *
 * "Outside wins at the frame boundary" is exactly what this refuses to do: a handle centred on a flush edge would hang half-outside the clip, where `#dsh-ring-layer`'s `overflow: hidden` eats it and no pointer can reach it (S42-1 acceptance 4c's RED-when).
 */
export function placeHandle(
  box: HandleRect,
  compass: HandleCompass,
  clip: EffectiveClip,
): HandlePlacement {
  const anchor = compassPoint(box, compass);
  const size = hitSizeFor(box, compass);
  let edges = centredOn(anchor, size);
  let edgeCoverage = 1;

  if (isCornerHandle(compass)) {
    edges = translateIntoRect(edges, clip);
    edges = pushOutOfArcs(edges, clip);
    edges = translateIntoRect(edges, clip);
  } else {
    const horizontal = compass === "n" || compass === "s";
    // R42-D1 — the short axis is NOT centred on the edge: the band hangs off the outside of it.
    const band = stripBandEdges(box, compass);
    edges = horizontal
      ? { ...edges, top: band.near, bottom: band.far }
      : { ...edges, left: band.near, right: band.far };
    // Short axis first: the trim below reads the strip's long edges, so they must already sit where
    // they will finally sit.
    const shortOnly = horizontal
      ? { ...edges, left: anchor.x - 1e6, right: anchor.x + 1e6 }
      : { ...edges, top: anchor.y - 1e6, bottom: anchor.y + 1e6 };
    const shifted = translateIntoRect(shortOnly, clip);
    edges = horizontal
      ? { ...edges, top: shifted.top, bottom: shifted.bottom }
      : { ...edges, left: shifted.left, right: shifted.right };
    const edgeLength = horizontal ? box.width : box.height;
    edges = trimStripSymmetrically(edges, clip, horizontal);
    const placedLength = horizontal ? edges.right - edges.left : edges.bottom - edges.top;
    edgeCoverage = edgeLength <= 0 ? 0 : Math.max(0, placedLength) / edgeLength;
  }

  const width = Math.max(0, edges.right - edges.left);
  const height = Math.max(0, edges.bottom - edges.top);
  return {
    compass,
    left: edges.left,
    top: edges.top,
    width,
    height,
    centre: { x: edges.left + width / 2, y: edges.top + height / 2 },
    anchor,
    edgeCoverage,
  };
}

/**
 * ⚠ **TRANSITIONAL, retained exported-and-uncalled for the lab alone (plan §7, `S48-1a`); deleted in `S48-1b`.** Nothing calls this — the model never refuses a placement for failing to fit (plan §1/§2).
 *
 * True when the placed box lies wholly inside the clip rect AND clears every rounded corner.
 */
export function fitsInClip(placement: HandlePlacement, clip: EffectiveClip): boolean {
  const e: Edges = {
    left: placement.left,
    top: placement.top,
    right: placement.left + placement.width,
    bottom: placement.top + placement.height,
  };
  const eps = 1e-6;
  if (e.left < clip.left - eps || e.right > clip.right + eps) return false;
  if (e.top < clip.top - eps || e.bottom > clip.bottom + eps) return false;
  return !clip.arcs.some((arc) => violatesArc(e, arc));
}

/** Which axes §3.3's layer 2 leaves writable. A handle needs EVERY axis it writes. */
export interface WritableAxes {
  width: boolean;
  height: boolean;
}

export interface AdmissionInput {
  /** The selected element's border box, layer-relative. */
  box: HandleRect;
  /** Transitional through S48-1b: callers no longer read clipping into the geometry model. */
  clip?: EffectiveClip;
  axes: WritableAxes;
}

/** A pure region emitted by the corner-ramp model. */
export type HandleRegion = HandlePlacement;

/** Linear corner ramp, clamped at the owner's two endpoints. */
export function rampCornerAt(
  size: number,
  narrowPx: number = CORNER_RAMP_NARROW_PX,
  narrowCornerPx: number = CORNER_RAMP_NARROW_CORNER_PX,
  widePx: number = CORNER_RAMP_WIDE_PX,
  wideCornerPx: number = CORNER_RAMP_WIDE_CORNER_PX,
): number {
  if (size <= narrowPx) return narrowCornerPx;
  if (size >= widePx) return wideCornerPx;
  return narrowCornerPx + ((size - narrowPx) / (widePx - narrowPx)) * (wideCornerPx - narrowCornerPx);
}

/** The corner square's side, driven isotropically by the box's short side. */
export function effectiveCornerSize(
  box: HandleRect,
  narrowPx: number = CORNER_RAMP_NARROW_PX,
  narrowCornerPx: number = CORNER_RAMP_NARROW_CORNER_PX,
  widePx: number = CORNER_RAMP_WIDE_PX,
  wideCornerPx: number = CORNER_RAMP_WIDE_CORNER_PX,
): number {
  return rampCornerAt(Math.min(box.width, box.height), narrowPx, narrowCornerPx, widePx, wideCornerPx);
}

/**
 * Builds four corner squares centred on their geometric corners, followed by four full-edge bands. The bands are production rectangles, not the lab's rounded capsules, and straddle each border by half their thickness.
 */
export function buildHandleRegions(
  box: HandleRect,
  narrowPx: number = CORNER_RAMP_NARROW_PX,
  narrowCornerPx: number = CORNER_RAMP_NARROW_CORNER_PX,
  widePx: number = CORNER_RAMP_WIDE_PX,
  wideCornerPx: number = CORNER_RAMP_WIDE_CORNER_PX,
  bandPx: number = HANDLE_BAND_PX,
): HandleRegion[] {
  const corner = effectiveCornerSize(box, narrowPx, narrowCornerPx, widePx, wideCornerPx);
  const halfCorner = corner / 2;
  const halfBand = bandPx / 2;
  const right = box.left + box.width;
  const bottom = box.top + box.height;
  const region = (compass: HandleCompass, left: number, top: number, width: number, height: number): HandleRegion => ({
    compass,
    left,
    top,
    width,
    height,
    centre: { x: left + width / 2, y: top + height / 2 },
    anchor: compassPoint(box, compass),
    edgeCoverage: 1,
  });
  return [
    region("nw", box.left - halfCorner, box.top - halfCorner, corner, corner),
    region("ne", right - halfCorner, box.top - halfCorner, corner, corner),
    region("se", right - halfCorner, bottom - halfCorner, corner, corner),
    region("sw", box.left - halfCorner, bottom - halfCorner, corner, corner),
    region("n", box.left, box.top - halfBand, box.width, bandPx),
    region("e", right - halfBand, box.top, bandPx, box.height),
    region("s", box.left, bottom - halfBand, box.width, bandPx),
    region("w", box.left - halfBand, box.top, bandPx, box.height),
  ];
}

/**
 * THE MODEL REFUSES NOTHING (plan §1). Builds the eight regions ({@link buildHandleRegions}) and filters them by {@link handleAxes} alone — a handle whose complete write set is unwritable is not emitted, and nothing else is: no separation clause, no clip test, no coverage floor. §3.3's writability filter is still the FIRST and only filter; the returned set is (admitted by axis) ∩ (the eight ported regions), and it is a constant eight whenever both axes are writable.
 *
 * Overlap between two admitted regions is not decided here: {@link HANDLE_ADMISSION_ORDER} resolves it for a caller asking "which one owns this pixel" (plan §4.1), and `use-resize-handles.ts`'s `RESIZE_CORNER_Z` / `RESIZE_STRIP_Z` pair resolves it in the DOM.
 *
 * `AdmissionInput.clip` is read by nothing (plan §2) — clipping is `#dsh-ring-layer` and `#dsh-frame`'s `overflow: hidden`, not a computation this function performs.
 */
export function admitHandles({ box, axes }: AdmissionInput): HandlePlacement[] {
  const regions = new Map(buildHandleRegions(box).map((region) => [region.compass, region]));
  const admitted: HandlePlacement[] = [];
  for (const compass of HANDLE_ADMISSION_ORDER) {
    const writes = handleAxes(compass);
    if (writes.width && !axes.width) continue;
    if (writes.height && !axes.height) continue;

    admitted.push(regions.get(compass)!);
  }
  return admitted;
}
