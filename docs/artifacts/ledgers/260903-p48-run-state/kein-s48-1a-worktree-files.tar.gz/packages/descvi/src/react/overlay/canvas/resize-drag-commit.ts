/**
 * resize-drag-commit.ts — the GESTURE's three sizing entry points (phase-42 S42-3; plan §3.10, §3.11, §2.6, V3-C3).
 *
 * These three plus the panel's two in `../panel/sizing-commit.ts` are the entire published caller set of `serializeSizing` (G42-1's five-site fence).
 * They exist as pure functions for the same reason the panel's do: a gesture that composes its own string is a second serializer, and the failure that produces is not a wrong pixel but an AMBIGUOUS element state — two live sizing tokens on one axis, read differently depending on which the parser reached first.
 *
 * ⚠ NEITHER PREVIEW NOR COMMIT TAKES A `mode`.
 * The drag writes Fixed and the double-click writes Hug; a `mode` parameter would widen the drag's write surface past the contract it was reviewed under, and it would do it invisibly — every existing row would keep passing.
 *
 * ⚠ PREVIEW AND COMMIT ARE THE SAME COMPUTATION, AND THEY ARE TWO FUNCTIONS ANYWAY, EACH SPELLING ITS OWN CALL.
 * They differ only in DESTINATION (the controller draft vs. the POST), never in the string, and V3-C3's one-serializer rule is what guarantees that.
 * The duplicated body is not an oversight and must not be "cleaned up" into a shared helper: G42-1(a) counts PLAINLY-SPELLED call sites and pins one inside each named exported function, so a shared private helper would leave two of the three published entry points invisible to the fence that exists to see them.
 * The panel's own pair (`commitSizingMode` / `commitSizingValue`) carries the same duplication for the same reason.
 *
 * ⚠ AND THE PRICE IS NAMED, because a gate cell claims otherwise: the two bodies are BYTE-IDENTICAL, so G42-1(b)'s pairing of `previewResize` against `commitResize` is TAUTOLOGICAL and is not parity evidence.
 * What that leg really measures is each of them against the PANEL's `commitSizingValue`, which is a different composer reached by a different route; the preview-vs-commit half is there because the fence counts one call site per published function, not because it can fail.
 * The pairing that is NOT near-tautological in that table is `commitEdgeHug` against `commitSizingMode({mode:'hug'})` — it crosses from a compass to an axis, which is a mapping that can be wrong and has been.
 *
 * ⚠ SO IS A SHIFT-LOCKED EDGE, AND THAT IS WHY THE ORDER RULE IS NOT A CORNER RULE (§3.10, S42-4).
 * The aspect lock derives the axis the handle does NOT drive, so an E-handle Shift drag writes width AND height through the same two chained calls — invisibly to any row that reads rendered geometry instead of the string.
 * `aspectLock` is therefore an input to {@link previewResize} and {@link commitResize} rather than a fourth entry point: a separate locked entry point would be a sixth `serializeSizing` call site, and the fence counts one site per published function.
 *
 * ⚠ A CORNER IS TWO SERIALIZER CALLS, IN A RULED ORDER: WIDTH THEN HEIGHT (§3.10).
 * `serializeSizing` takes ONE axis and ONE `currentClassName` and returns the WHOLE composed className, so the committed BYTES depend on which axis goes first; the second call receives the first's output as its `currentClassName`.
 * The loop below is that order, and it sits INSIDE one entry point so the five-site pin still counts one call site per published function.
 *
 * SaaS-seam: overlay-CLIENT code — NO `node:*` / `process` / `fs`.
 */
import {
  serializeSizing,
  type ParentContext,
  type SizingAxis,
  type SizingWriteResult,
} from "../engine/tailwind-class-model";
// The compass vocabulary is the RENDERER's, imported rather than restated: S42-1 stamps these eight
// ids on `data-dsh-handle`, and a second spelling here could drift from the set that actually exists.
import type { HandleCompass } from "./handle-geometry";

export type { HandleCompass };

/** The four EDGE handles — the only ones a double-click may Hug (§3.10: one edge, one axis). */
export type EdgeCompass = "n" | "e" | "s" | "w";

export function isEdgeCompass(compass: string): compass is EdgeCompass {
  return compass === "n" || compass === "e" || compass === "s" || compass === "w";
}

export function isHandleCompass(compass: string): compass is HandleCompass {
  return isEdgeCompass(compass) || compass === "ne" || compass === "nw" || compass === "se" || compass === "sw";
}

/** The element's border box as it measured at ARM time. §3.11: it is read once, never per move. */
export interface StartBox {
  width: number;
  height: number;
}

export interface ResizeDragCommitBase {
  handle: HandleCompass;
  /** Measured once, at arm time (§3.11). Every move composes from THIS, never from the live box. */
  startBox: StartBox;
  /** Total client-x travel since pointerdown — never the per-move increment (§3.11). */
  dx: number;
  /** Total client-y travel since pointerdown. */
  dy: number;
  parentContext: ParentContext;
  /**
   * The ARMED BASELINE — the controller's confirmed string as of the arming moment (§3.7(b)), never a preview string and never `selectedEl.className`.
   * Re-reading the live attribute per move is the compounding mistake §3.11 bans, and it passes every other gate in this phase.
   */
  currentClassName: string | null;
  /**
   * §3.10's ASPECT LOCK — Shift, as it stood on THIS pointer event (S42-4).
   *
   * ⚠ IT IS AN INPUT TO THE WRITE, NEVER A LATCH. The machine reads the modifier off every move event and passes what it read; a lock captured at pointerdown would make a mid-drag press inert and a mid-drag release permanent, which is acceptance 2's RED-when.
   * Absent and `false` are the same answer, so every unshifted caller and every pre-S42-4 row keeps its exact bytes.
   */
  aspectLock?: boolean;
}

export interface EdgeHugCommitInput {
  handle: EdgeCompass;
  parentContext: ParentContext;
  currentClassName: string | null;
}

/**
 * §3.10's eight-direction table, as data.
 * `w`/`h` are the SIGN each axis' delta carries for that handle; a `0` means the handle does not write that axis at all.
 *
 * ⚠ THE SIGNS ARE THE WHOLE CONTRACT.
 * "All eight handles preserve *drag outward grows, drag inward shrinks*" is expressible in flow; a fixed opposite edge is not, and the plan states the divergence rather than hiding it — on a west or north drag the box grows AWAY from the cursor, from its flow origin.
 * An implementation where all eight perform the same right-edge width increase passes every other gate in this phase, which is why this table is gated directly.
 */
const HANDLE_DELTA_SIGN: Record<HandleCompass, { w: -1 | 0 | 1; h: -1 | 0 | 1 }> = {
  e: { w: 1, h: 0 },
  w: { w: -1, h: 0 },
  s: { w: 0, h: 1 },
  n: { w: 0, h: -1 },
  se: { w: 1, h: 1 },
  sw: { w: -1, h: 1 },
  ne: { w: 1, h: -1 },
  nw: { w: -1, h: -1 },
};

/** The axis a single-axis (edge) handle writes. Corners write both and are never asked. */
const EDGE_AXIS: Record<EdgeCompass, SizingAxis> = { e: "w", w: "w", n: "h", s: "h" };

/**
 * The axis pair a handle writes, in §3.10's RULED order: **width first, then height**.
 * A single-axis handle yields one entry; a corner yields two, and the second call takes the first's composed className as its `currentClassName`.
 */
function axesFor(handle: HandleCompass): SizingAxis[] {
  const sign = HANDLE_DELTA_SIGN[handle];
  const out: SizingAxis[] = [];
  if (sign.w !== 0) out.push("w");
  if (sign.h !== 0) out.push("h");
  return out;
}

/**
 * The requested px for one axis: the start dimension plus the signed total delta, rounded ONCE (§3.10) before it reaches the serializer.
 *
 * ⚠ NO CLAMP HERE.
 * A request of `0` or less is floored at 1 px INSIDE the serializer (`clampSizingValue`), which is the same path the panel's numeric input takes — V3-C5.
 * A second clamp on this side would be a second policy, and the first one to drift would win silently.
 */
function requestedPx(input: ResizeDragCommitBase, axis: SizingAxis): number {
  const sign = HANDLE_DELTA_SIGN[input.handle];
  return axis === "w"
    ? Math.round(input.startBox.width + sign.w * input.dx)
    : Math.round(input.startBox.height + sign.h * input.dy);
}

/** The raw, UNROUNDED dimension one axis would take from the handle's own delta. The ratio is taken from this rather than from the rounded px, so the derived axis inherits one rounding rather than two. */
function rawPx(input: ResizeDragCommitBase, axis: SizingAxis): number {
  const sign = HANDLE_DELTA_SIGN[input.handle];
  return axis === "w" ? input.startBox.width + sign.w * input.dx : input.startBox.height + sign.h * input.dy;
}

/** The start box's dimension on one axis. */
function startPx(input: ResizeDragCommitBase, axis: SizingAxis): number {
  return axis === "w" ? input.startBox.width : input.startBox.height;
}

/**
 * §3.10's aspect-lock axis roles: which axis DRIVES the locked resize, and which is DERIVED from it.
 *
 * ⚠ IT IS RE-DERIVED PER MOVE, NEVER LATCHED. On a corner the dominant axis is the one with the larger absolute delta, so a drag whose dominant component crosses back through zero re-selects on the NEW magnitudes — the lock does not stay bound to the axis it started on.
 * ⚠ THE TIE GOES TO WIDTH (`abs(dx) === abs(dy)`), which is the same axis precedence as the corner composition order, so one rule covers both and a diagonal drag has one answer rather than two.
 * An EDGE handle never consults the deltas: its dominant axis is the one it writes, and the lock derives the other.
 */
export function aspectLockAxes(input: Pick<ResizeDragCommitBase, "handle" | "dx" | "dy">): {
  dominant: SizingAxis;
  derived: SizingAxis;
} {
  const sign = HANDLE_DELTA_SIGN[input.handle];
  const dominant: SizingAxis =
    sign.w === 0 ? "h" : sign.h === 0 ? "w" : Math.abs(input.dy) > Math.abs(input.dx) ? "h" : "w";
  return { dominant, derived: dominant === "w" ? "h" : "w" };
}

/**
 * The requested px for one axis UNDER THE LOCK (§3.10).
 *
 * The dominant axis is exactly what it would be unlocked; the derived axis is the START ratio applied to it — `startDerived × (rawDominant / startDominant)`, rounded once.
 * ⚠ THE SIGN IS THE DOMINANT AXIS' SCALE SIGN, NOT THE RAW POINTER SIGN, and the ratio form is what delivers that rather than a second rule: on an NE drag with `dx > 0, dy < 0` the width scale is > 1, so the derived height GROWS even though the pointer moved up. A derived axis that followed its own handle sign would shrink there and silently break the ratio the lock exists to preserve.
 *
 * ⚠ A DEGENERATE START DIMENSION HAS NO RATIO, and the fallback is stated rather than left to `Infinity`: a zero-width (or zero-height) start box makes the scale undefined, so the derived axis holds its START DIMENSION.
 * ⚠ THAT IS NOT THE UNLOCKED BEHAVIOUR, and an earlier draft of this comment said it was. A LOCKED write always composes BOTH axes, so a degenerate E drag still writes the derived axis — at the start height — whereas the UNLOCKED one writes no height token at all. The two are different strings, which is why the case is gated rather than described.
 *
 * ⚠ AND THE SCALE MAY BE NEGATIVE, which is ROUTINE rather than exotic: any W or N drag past the flow origin inverts it, and the derived axis then requests a negative px. Nothing here floors it — V3-C5's 1 px clamp lives INSIDE the serializer, the same path the panel's numeric input takes, so both axes land on the floor and the ratio the lock exists to preserve is gone. That outcome is ACCEPTED (a box cannot be dragged through itself) and it is gated so it stays a decision rather than an accident.
 */
function lockedPx(input: ResizeDragCommitBase, axis: SizingAxis, dominant: SizingAxis): number {
  if (axis === dominant) return requestedPx(input, axis);
  const startDominant = startPx(input, dominant);
  const startDerived = startPx(input, axis);
  if (!Number.isFinite(startDominant) || startDominant === 0) return Math.round(startDerived);
  return Math.round(startDerived * (rawPx(input, dominant) / startDominant));
}

/**
 * The axes ONE write composes, in §3.10's ruled width-then-height order.
 * Under the lock that is ALWAYS both, whatever the handle: a Shift-locked EDGE is a two-axis operation exactly as a corner is, and its committed bytes depend on the same order.
 */
function writeAxes(input: ResizeDragCommitBase): SizingAxis[] {
  return input.aspectLock === true ? ["w", "h"] : axesFor(input.handle);
}

/** The px one axis of one write requests — the lock's arithmetic when it is engaged, the plain delta when it is not. */
function writeValue(input: ResizeDragCommitBase, axis: SizingAxis): number {
  return input.aspectLock === true ? lockedPx(input, axis, aspectLockAxes(input).dominant) : requestedPx(input, axis);
}

/**
 * The per-move write: Fixed on the handle's axis (or axes), composed from the armed baseline and the TOTAL delta — never from the previous preview's output (§3.11).
 *
 * A refusal is a value the caller must handle (V3-C3): on a variant-shadowed axis this returns `{ ok: false, reason: 'element-axis-controlled-by-variant' }` and the gesture writes nothing.
 * On a corner whose FIRST axis refuses, the second is never attempted — a half-written corner is a state no gate could name.
 * ⚠ THE SAME IS TRUE OF A REFUSED LOCK, and it is what makes §3.10's cross-product implementable: a locked call whose DERIVED axis is blocked refuses as a whole and writes nothing, so the machine can fall back to the unlocked call and surface the reason instead of stalling.
 */
export function previewResize(input: ResizeDragCommitBase): SizingWriteResult {
  let composed: string = input.currentClassName ?? "";
  for (const axis of writeAxes(input)) {
    const result = serializeSizing({
      axis,
      mode: "fixed",
      value: writeValue(input, axis),
      parentContext: input.parentContext,
      currentClassName: composed,
    });
    if (!result.ok) return result;
    composed = result.className;
  }
  return { ok: true, className: composed };
}

/**
 * The pointerup write.
 * Byte-identical to {@link previewResize} for the same inputs — and it is RECOMPUTED at pointerup rather than read back off the controller's last preview, which is what G42-1(d) asserts against a production route.
 */
export function commitResize(input: ResizeDragCommitBase): SizingWriteResult {
  let composed: string = input.currentClassName ?? "";
  for (const axis of writeAxes(input)) {
    const result = serializeSizing({
      axis,
      mode: "fixed",
      value: writeValue(input, axis),
      parentContext: input.parentContext,
      currentClassName: composed,
    });
    if (!result.ok) return result;
    composed = result.className;
  }
  return { ok: true, className: composed };
}

/**
 * The EDGE double-click: Hug on that edge's axis, one call, one POST (§3.10, acceptance 12).
 * It takes no delta and no start box — a Hug is a mode, not a measurement — and it takes no `mode` either, for the reason in this module's header.
 */
export function commitEdgeHug(input: EdgeHugCommitInput): SizingWriteResult {
  return serializeSizing({
    axis: EDGE_AXIS[input.handle],
    mode: "hug",
    value: null,
    parentContext: input.parentContext,
    currentClassName: input.currentClassName,
  });
}

/**
 * The axis (or axes) a handle writes, IN §3.10's ruled order, published so a gate can pair a row against the table.
 * Distinct from `handle-geometry.ts`'s `handleAxes`, which answers a different question (does this compass touch each axis at all) for the writable-axis gate; this one answers in serializer order and is what the write is built from.
 */
export function sizingAxesFor(handle: HandleCompass): SizingAxis[] {
  return axesFor(handle);
}

/** The signed unit each axis' delta carries for a handle — §3.10's table, published for the gate. */
export function handleDeltaSign(handle: HandleCompass): { w: -1 | 0 | 1; h: -1 | 0 | 1 } {
  return HANDLE_DELTA_SIGN[handle];
}
