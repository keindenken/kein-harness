/**
 * spacing-affordance-geometry.test.ts — the VITEST half of G44-9's two arms, the render floors as counts, the ceiling, G44-4's scope and §3.8's derived universe-B formula (phase-44 S44-3).
 *
 * ⚠ **THIS IS NOT THE GATE, IT IS THE GATE'S OTHER HALF, AND SAYING SO IS THE POINT.** G44-9's own row lives in `e2e/spacing-gesture.spec.ts` and probes with `document.elementFromPoint` over a real layout — which is the only instrument that can see a rendered node take a click. What lives HERE is the arithmetic those probes rest on, in a runner where a mutation can be applied and observed in under a second. The two are not redundant: a browser row cannot fail on a scene the fixture screen does not carry, and this file can carry any scene at all; a vitest row cannot see a z-index, a `pointer-events` cascade, or a node that renders where the arithmetic says it should not.
 *
 * THE SCENES ARE THE FIXTURE SCREEN's, by number — `lab/tests/spacing-nesting`'s 320×120 containers with 120×40 children — so a row that goes RED here names a container a live probe can be pointed at.
 */
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { RESIZE_CORNER_Z, RESIZE_STRIP_Z } from "../canvas/use-resize-handles";
import {
  GAP_STRIP_HIT_BAND_PX,
  GAP_STRIP_RENDER_FLOOR_PX,
  PAD_EDGE_HIT_BAND_PX,
  PAD_EDGE_RENDER_FLOOR_PX,
  SPACING_APRON_Z,
  SPACING_HATCH_Z,
  SPACING_STRIP_Z,
  expectedSpacingAffordanceCount,
  placeSpacingAffordances,
  type SpacingRect,
  type SpacingSceneInput,
} from "../canvas/spacing-affordance-geometry";
import { POINTER_DRAG_THRESHOLD_PX } from "../canvas/pointer-thresholds";

/**
 * A 320×120 container with two children laid out in a row, `gap` px apart. The fixture screen's shape.
 *
 * ⚠ THE CHILDREN ARE LAID OUT INSIDE THE CONTENT BOX, which is what a browser does and what an earlier draft of this helper did not — it kept them 120 px wide whatever the padding, so a 32 px-padded scene put a child 24 px into its own right band and the last row below went RED. That RED was the HELPER's defect and not the placement rule's, but the shape it produced is real and has a live instance, so it is kept as its own row (`⚠ A CHILD THAT OVERFLOWS ITS OWN CONTENT BOX`) rather than being tidied out of existence.
 */
function rowScene(overrides: Partial<SpacingSceneInput> & { gapPx: number }): SpacingSceneInput {
  const gap = overrides.gapPx;
  const padding = { top: 0, right: 0, bottom: 0, left: 0, ...(overrides.padding ?? {}) };
  const box = overrides.box ?? { left: 0, top: 0, width: 320, height: 120 };
  const contentWidth = box.width - padding.left - padding.right;
  const childWidth = Math.min(120, (contentWidth - gap) / 2);
  return {
    box,
    gapEnabled: true,
    padEnabled: true,
    axis: "row",
    children: [
      { left: box.left + padding.left, top: box.top + padding.top, width: childWidth, height: 40 },
      { left: box.left + padding.left + childWidth + gap, top: box.top + padding.top, width: childWidth, height: 40 },
    ],
    ...overrides,
    // ⚠ AFTER the spread, both of them: `padding` is normalised above from a PARTIAL override, and `gapPx` is what the children's layout was computed from — letting either be re-applied by the spread would make the scene internally inconsistent, which is how a geometry row goes green against a scene no browser produces.
    padding,
    gapPx: gap,
  };
}

const rightOf = (r: SpacingRect): number => r.left + r.width;
const bottomOf = (r: SpacingRect): number => r.top + r.height;

/** Does `a` share any interior area with `b`? Touching edges is NOT an overlap — a band ends where a child begins. */
function overlaps(a: SpacingRect, b: SpacingRect): boolean {
  return a.left < rightOf(b) && rightOf(a) > b.left && a.top < bottomOf(b) && bottomOf(a) > b.top;
}

describe("S44-3 — the spacing affordances' geometry", () => {
  it("⚠ G44-3's Cmd ARM — the gesture reads NO Cmd/Ctrl, asserted on SOURCE because the behavioural RED-when cannot land", () => {
    // ⚠ **THE PLAN'S RED-WHEN FOR THIS ROW IS "bind Cmd → the parent-climb selection row in the shipped shield suite fires", AND IT CANNOT BE APPLIED — measured, not assumed.** The climb is resolved in the shield's CLICK arm, and that arm already takes ROW D on any `data-dsh-handle` target: suppression kept, resolution SKIPPED. So on a spacing affordance no climb happens today, with or without Cmd, and the shipped climb rows (`selection.test.ts`'s resolver rows and `alignment-write.spec.ts`'s Cmd-click) never press an affordance at all. A behavioural row would assert "the selection is unchanged", which is already true under both arms of the mutation and therefore discriminates nothing.
    //
    // What IS falsifiable is the CLAIM — that this gesture never reads the modifier. The scan is the same instrument the caller fences use, for the same reason: an output gate cannot see a modifier that is read but happens to be unheld in every row.
    // RED-when, applied and observed: add `metaKey: e.metaKey` to `modifiersOf` → this fires.
    const ROOT = resolve(fileURLToPath(import.meta.url), "..", "..", "canvas");
    for (const file of ["use-spacing-drag.ts", "spacing-drag-commit.ts"]) {
      const source = readFileSync(resolve(ROOT, file), "utf8")
        // Comments are stripped first: this file's own docblocks discuss Cmd at length, and a raw substring scan would be reporting the prose rather than the code.
        .replace(/\/\*[\s\S]*?\*\//g, "")
        .replace(/(^|[^:])\/\/[^\n]*/g, "$1");
      expect(source, `${file} reads metaKey`).not.toMatch(/metaKey/);
      expect(source, `${file} reads ctrlKey`).not.toMatch(/ctrlKey/);
    }
    // NON-VACUITY: the scan finds the modifiers it DOES read, so the two absences above are facts about the source and not about a regex that never matches.
    const drag = readFileSync(resolve(ROOT, "use-spacing-drag.ts"), "utf8");
    expect(drag).toMatch(/shiftKey/);
    expect(drag).toMatch(/altKey/);
  });

  it("INSTRUMENT CONTROL: the placement pass can report a NON-EMPTY set, and the overlap predicate can report TRUE", () => {
    // A zero result is evidence only once the instrument has been shown able to produce a non-zero one — and every FLOOR row below asserts a zero.
    expect(placeSpacingAffordances(rowScene({ gapPx: 12, padding: { top: 16, right: 16, bottom: 16, left: 16 } })))
      .toHaveLength(5);
    // …and the child-box predicate the G44-9 row rests on is not a function that always answers `false`.
    expect(overlaps({ left: 0, top: 0, width: 10, height: 10 }, { left: 5, top: 5, width: 10, height: 10 })).toBe(true);
    expect(overlaps({ left: 0, top: 0, width: 10, height: 10 }, { left: 10, top: 0, width: 10, height: 10 })).toBe(false);
  });

  it("⚠ THE FIXTURE's FLOOR-REGIME SUBJECTS ARE PINNED TO THE FLOOR's ACTUAL VALUE, never to the literal 4", () => {
    // ⚠ **BOTH FLOORS ARE ALIASES OF `POINTER_DRAG_THRESHOLD_PX` (architect WC-4), SO A CHANGE THERE MOVES THEM SILENTLY — and every fixture subject was chosen against the number 4.** `spacing-below-floor` is 2 px (below), `gap-thin` is 6 and `pad-thin` is 8 (above, and strictly inside their ceilings). Raise the shared threshold to 8 and `gap-thin` stops being a CLAMP subject and becomes a FLOOR one — every clamp row would then be asserting an absence, silently, and G44-9b's arm would have nothing to fail on. That is the same shape MF-3 filed against r1's `p-[2px]`, arriving through the constant instead of through the fixture.
    // This row is the tripwire: it states the REGIME each subject must be in, in terms of the live value.
    expect(2, "`spacing-below-floor` must stay BELOW the floor").toBeLessThan(GAP_STRIP_RENDER_FLOOR_PX);
    expect(2).toBeLessThan(PAD_EDGE_RENDER_FLOOR_PX);
    expect(6, "`gap-thin` must stay strictly inside FLOOR < band < CEILING").toBeGreaterThanOrEqual(GAP_STRIP_RENDER_FLOOR_PX);
    expect(6).toBeLessThan(GAP_STRIP_HIT_BAND_PX);
    expect(8, "`pad-thin` must stay strictly inside FLOOR < band < CEILING").toBeGreaterThanOrEqual(PAD_EDGE_RENDER_FLOOR_PX);
    expect(8).toBeLessThan(PAD_EDGE_HIT_BAND_PX);
    // …and `gap-large` must stay ABOVE its ceiling, or the CEILING row and the apron term lose their subject.
    expect(40).toBeGreaterThan(GAP_STRIP_HIT_BAND_PX);
  });

  it("the SUPPRESSION RULE is an inequality against the resize family's own constants, not a pair of literals", () => {
    // RED-when: raise `SPACING_STRIP_Z` to 44 → this fires here AND the corner probe fires in the browser row.
    // Two places on purpose: this one names the RULE, the browser one measures the CONSEQUENCE, and a reader who changes a number meets the rule first.
    expect(SPACING_STRIP_Z).toBeLessThan(RESIZE_STRIP_Z);
    expect(RESIZE_STRIP_Z).toBeLessThan(RESIZE_CORNER_Z);
    expect(SPACING_STRIP_Z).toBeLessThan(RESIZE_CORNER_Z);
    expect(SPACING_APRON_Z).toBeLessThan(SPACING_STRIP_Z);
    expect(SPACING_HATCH_Z).toBeLessThan(SPACING_APRON_Z);
  });

  it("⚠ G44-9's WRAP ARM — a pair that straddles a flex line mints NO band, and that is what stops it landing inside a child", () => {
    // ⚠ **MEASURED BEFORE THE FIX, with a positive control (architect MF-2).** `gapBands` pairs children in DOM order; on a wrapping container the pair across the break is not separated by a gap at all, so the midpoint of their facing edges falls in the MIDDLE of the container. The band landed at `left 94, width 12, height 120` and overlapped BOTH children — P44-4 verbatim, with 7 corpus literals carrying the shape OUTSIDE this phase's own fixture (8 counting it — the qualifier the fixture screen's own header requires of every number measured over the corpus).
    // RED-when: delete the `sameFlexLine` guard → the band returns and the overlap assertions below fire.
    const wrapped: SpacingSceneInput = {
      ...rowScene({ gapPx: 12 }),
      children: [
        { left: 0, top: 0, width: 200, height: 40 },
        { left: 0, top: 52, width: 200, height: 40 },
      ],
    };
    expect(placeSpacingAffordances(wrapped).filter((a) => a.kind === "gap")).toEqual([]);
    expect(expectedSpacingAffordanceCount(wrapped)).toBe(0);
    // NON-VACUITY, and it is the control the measurement needed: the SAME gap, the SAME container, two children that DO share a line — one band, and it lies between them.
    const flat: SpacingSceneInput = {
      ...wrapped,
      children: [
        { left: 0, top: 0, width: 100, height: 40 },
        { left: 112, top: 0, width: 100, height: 40 },
      ],
    };
    const [band] = placeSpacingAffordances(flat);
    expect(band?.kind).toBe("gap");
    for (const child of flat.children) expect(overlaps(band!.hit, child)).toBe(false);
    // …and a THREE-child wrapping container mints exactly the bands whose pairs share a line — one, not two.
    const three: SpacingSceneInput = {
      ...wrapped,
      children: [
        { left: 0, top: 0, width: 120, height: 40 },
        { left: 132, top: 0, width: 120, height: 40 },
        { left: 0, top: 52, width: 120, height: 40 },
      ],
    };
    expect(placeSpacingAffordances(three).filter((a) => a.kind === "gap").map((a) => a.id)).toEqual(["gap:0"]);
  });

  it("⚠ THE CROSS EXTENT IS THE PAIR's OWN UNION — a band never reaches across another flex line", () => {
    // The second half of the wrap fix, and it has its own failing shape: with the cross extent taken from the CONTENT BOX, the band between two items on line 1 spans the whole container height and lies on top of every item on lines 2 and 3. RED-when: restore the content-box cross extent → this fires.
    const threeLines: SpacingSceneInput = {
      ...rowScene({ gapPx: 12 }),
      children: [
        { left: 0, top: 0, width: 120, height: 30 },
        { left: 132, top: 0, width: 120, height: 30 },
        { left: 0, top: 42, width: 120, height: 30 },
        { left: 0, top: 84, width: 120, height: 30 },
      ],
    };
    const [band] = placeSpacingAffordances(threeLines).filter((a) => a.kind === "gap");
    expect(band, "the line-1 pair still mints a band").toBeDefined();
    // It covers line 1's cross extent and NOTHING below it.
    expect(band!.hit.top).toBe(0);
    expect(band!.hit.height).toBe(30);
    for (const child of threeLines.children.slice(2)) {
      expect(overlaps(band!.hit, child), `the band reaches into ${JSON.stringify(child)}`).toBe(false);
    }
  });

  it("the TWO FLOORS are ONE number and BOTH are tied to the drag threshold — the symmetry §3.7.3 rules", () => {
    // RED-when: give the padding family its own floor, or restore r1's zero-test on either side. The tie is the ruling: there is no property of padding that makes a 2 px inward band grabbable when a 2 px gap band is not, because the reason is the classifier and the human finger and neither knows which property it is on.
    expect(GAP_STRIP_RENDER_FLOOR_PX).toBe(POINTER_DRAG_THRESHOLD_PX);
    expect(PAD_EDGE_RENDER_FLOOR_PX).toBe(POINTER_DRAG_THRESHOLD_PX);
  });

  // ── G44-9a, the FLOOR arm ────────────────────────────────────────────────────────────────────────
  it("G44-9a — `gap-zero-flex` and `pad-flush-parent`: a ZERO band renders NOTHING of either family", () => {
    // Fixture ⑧ `flex` (no gap token) and ⑪ `flex p-0` with flush children — the same scene, since a zero gap and a zero padding are what both carry.
    const scene = rowScene({ gapPx: 0 });
    expect(placeSpacingAffordances(scene)).toEqual([]);
    expect(expectedSpacingAffordanceCount(scene)).toBe(0);
  });

  it("⚠ G44-9a's SECOND RED-when — `spacing-below-floor` (2 px, NOT zero) renders NOTHING either", () => {
    // Fixture ⑮ `flex gap-[2px] p-[2px]`. THIS is the row a `band <= 0` implementation fails and a `band < FLOOR` one passes; every subject whose band is exactly 0 is green under BOTH, which is why the plan minted this container. RED-when: replace `band < FLOOR` with `band <= 0` in either family → the count here is 5.
    const scene = rowScene({ gapPx: 2, padding: { top: 2, right: 2, bottom: 2, left: 2 } });
    expect(placeSpacingAffordances(scene)).toEqual([]);
    expect(expectedSpacingAffordanceCount(scene)).toBe(0);
    // …and the floor is a THRESHOLD, not a range: exactly AT the floor the affordance is admitted.
    const atFloor = rowScene({
      gapPx: GAP_STRIP_RENDER_FLOOR_PX,
      padding: {
        top: PAD_EDGE_RENDER_FLOOR_PX,
        right: PAD_EDGE_RENDER_FLOOR_PX,
        bottom: PAD_EDGE_RENDER_FLOOR_PX,
        left: PAD_EDGE_RENDER_FLOOR_PX,
      },
    });
    expect(expectedSpacingAffordanceCount(atFloor)).toBe(5);
  });

  it("acceptance 4 — `pad-zero-explicit` renders EXACTLY ONE padding handle, the top one", () => {
    // Fixture ⑥ `p-0 pt-4`: 16 px on top, 0 on the other three. A count, not a presence check — "at least one" would be green with all four rendered, which is the mutation this row exists to see.
    const scene = rowScene({ gapPx: 0, padding: { top: 16, right: 0, bottom: 0, left: 0 } });
    const placed = placeSpacingAffordances(scene);
    expect(placed.filter((a) => a.kind === "pad").map((a) => a.edge)).toEqual(["top"]);
    expect(placed.filter((a) => a.kind === "gap")).toEqual([]);
  });

  // ── G44-9b, the CLAMP arm ────────────────────────────────────────────────────────────────────────
  it("G44-9b — `gap-thin` (6 px): the hit band is the MEASURED band, and no part of it is inside a child", () => {
    // Fixture ⑨ `flex gap-[6px]`. 6 is strictly inside `4 < gap < 16`, which is what makes BOTH mutations observable here — at 0 the floor fires first and `min(0, 16)` is a no-op.
    const scene = rowScene({ gapPx: 6 });
    const [band] = placeSpacingAffordances(scene);
    expect(band?.hit.width).toBe(6);
    expect(band?.hit.width).not.toBe(GAP_STRIP_HIT_BAND_PX);
    // RED-when: replace `min(band, CEILING)` with `CEILING` → the band is 16 and reaches 5 px into EACH neighbouring child, which is precisely what this loop sees.
    for (const child of scene.children) {
      expect(overlaps(band!.hit, child), `hit ${JSON.stringify(band!.hit)} vs child ${JSON.stringify(child)}`).toBe(false);
    }
    // The arithmetic of that mutation, stated so the row's own claim is checkable rather than asserted: a 16 px band centred at 123 spans 115→131, and the children end at 120 and begin at 126.
    const mutated: SpacingRect = { ...band!.hit, left: 123 - GAP_STRIP_HIT_BAND_PX / 2, width: GAP_STRIP_HIT_BAND_PX };
    expect(scene.children.filter((child) => overlaps(mutated, child))).toHaveLength(2);
  });

  it("G44-9b — `pad-thin` (8 px): the hit band is 8, not the 12 ceiling", () => {
    // Fixture ⑩ `p-[8px]`. 8 is strictly inside `4 < band < 12`; r1's `p-[2px]` was BELOW the floor r2 ruled, so it rendered nothing and was green under the clamp mutation too.
    const scene = rowScene({ gapPx: 0, padding: { top: 8, right: 8, bottom: 8, left: 8 } });
    const top = placeSpacingAffordances(scene).find((a) => a.edge === "top");
    expect(top?.hit.height).toBe(8);
    expect(top?.hit.height).not.toBe(PAD_EDGE_HIT_BAND_PX);
    // Below the ceiling there is no apron: the hatch and the hit are the same rect, so the popup has no opening surface on this subject and G44-1's row must not be pointed at it.
    expect(top?.aprons).toEqual([]);
  });

  // ── acceptance 5, the CEILING ────────────────────────────────────────────────────────────────────
  it("acceptance 5 — `gap-large` (40 px): the DRAG band is the ceiling, the hatch is 40, and two aprons fill the rest", () => {
    // Fixture ⑫ `flex gap-[40px]`. RED-when: drop the ceiling → the drag band matches the gap, and a 200 px gap becomes a 200 px hot region. That mutation is INVISIBLE on `gap-thin`, and `gap-thin`'s is invisible here.
    const scene = rowScene({ gapPx: 40 });
    const [band] = placeSpacingAffordances(scene);
    expect(band?.hit.width).toBe(GAP_STRIP_HIT_BAND_PX);
    expect(band?.hatch.width).toBe(40);
    expect(band?.aprons.map((a) => a.width)).toEqual([12, 12]);
    // The apron is the popup's opening surface (acceptance 8) and it lies WHOLLY INSIDE the measured band, so G44-9's constraint is untouched by it — asserted rather than argued.
    for (const apron of band!.aprons) {
      for (const child of scene.children) expect(overlaps(apron, child)).toBe(false);
    }
  });

  // ── G44-4, the scope ─────────────────────────────────────────────────────────────────────────────
  it("G44-4 — N children give N−1 bands, and the query is the container's OWN children", () => {
    // RED-when: widen the query to the grandparent → the band count stops being a function of THIS container's child list. The row asserts the function, which is what a widened query breaks first.
    for (const n of [2, 3, 5]) {
      const scene: SpacingSceneInput = {
        ...rowScene({ gapPx: 12 }),
        children: Array.from({ length: n }, (_, i) => ({ left: i * 132, top: 0, width: 120, height: 40 })),
      };
      expect(placeSpacingAffordances(scene).filter((a) => a.kind === "gap")).toHaveLength(n - 1);
    }
    // A single child has no band at all — the degenerate member, stated so it is not rediscovered.
    const lone: SpacingSceneInput = { ...rowScene({ gapPx: 12 }), children: [{ left: 0, top: 0, width: 120, height: 40 }] };
    expect(placeSpacingAffordances(lone).filter((a) => a.kind === "gap")).toEqual([]);
  });

  // ── The REFUSAL guard — the `snpvar` ruling ──────────────────────────────────────────────────────
  it("⚠ A REFUSED FAMILY RENDERS NOTHING, WHICH IS WHAT MAKES `pad-variant` UNREACHABLE RATHER THAN A CLAMP SUBJECT", () => {
    // Fixture ⑬ `p-2 md:p-8` — `snpvar`, the ONE live container measured with a child reaching 24 px into its own 32 px bottom band. `spacingFamilyRefusal("pad", ...)` answers `spacing-controlled-by-variant` on it, §3.11 rules that this phase mints NO non-operable spacing marker, and `use-resize-handles.ts` already renders ABSENCE on a refused axis — so the honest rendering is nothing at all, and the C9 universe-B formula subtracts its four edges rather than counting them.
    // RED-when: drop the refusal guard from the scene → four padding handles render over a container whose write is refused, taking the drill-down surface and giving nothing back.
    const padRefused = rowScene({ gapPx: 12, padding: { top: 32, right: 32, bottom: 32, left: 32 }, padEnabled: false });
    expect(placeSpacingAffordances(padRefused).map((a) => a.kind)).toEqual(["gap"]);
    expect(expectedSpacingAffordanceCount(padRefused)).toBe(1);
    // ── The GAP side, and ⚠ ITS SUBJECT CANNOT BE `not-flex` — a failed probe, corrected in this lane ──
    //
    // The obvious subject is fixture ⑭ `block p-4` (padding enabled, gap refused `gap-requires-flex-container`).
    // It is USELESS as a guard subject and the reason is §3.8's own r3 finding one level down: a non-flex container's `columnGap` computes to `"normal"` and thence to 0, so the FLOOR fires before the guard is ever consulted. **MEASURED: with the gap refusal guard deleted, a `gapPx: 0` scene stays GREEN** — the probe reported the answer it expected while testing nothing, which is exactly the shape this project's standing discipline calls a failed probe.
    //
    // The subject that DOES discriminate is a VARIANT-SHADOWED flex container — `flex gap-2 md:gap-8` — which refuses `spacing-controlled-by-variant` while computing a real, above-floor gap. RED-when: drop the gap refusal guard → this scene renders a band over a container whose gap write is refused.
    const gapRefused = rowScene({ gapPx: 12, padding: { top: 16, right: 16, bottom: 16, left: 16 }, gapEnabled: false });
    expect(new Set(placeSpacingAffordances(gapRefused).map((a) => a.kind))).toEqual(new Set(["pad"]));
    // Non-vacuity: the SAME scene with the guard open renders a band, so the absence above is a fact about the guard and not about a scene that had nothing to show.
    expect(placeSpacingAffordances({ ...gapRefused, gapEnabled: true }).filter((a) => a.kind === "gap")).toHaveLength(1);
    // …and the `not-flex` reading is asserted as the CHARACTERISATION it is, so the next reader meets the measurement rather than repeating it: on that container BOTH rules give zero, and only one of them is the reason. ⚠ No fixture container carries the discriminating shape today; this scene is authored here.
    const notFlex = rowScene({ gapPx: 0, padding: { top: 16, right: 16, bottom: 16, left: 16 }, gapEnabled: false });
    expect(placeSpacingAffordances(notFlex).filter((a) => a.kind === "gap")).toEqual([]);
    expect(placeSpacingAffordances({ ...notFlex, gapEnabled: true }).filter((a) => a.kind === "gap")).toEqual([]);
  });

  // ── §3.8's derived count ─────────────────────────────────────────────────────────────────────────
  it("§3.8 — the derived universe-B count equals the number of OPERABLE NODES the pass places, on every scene above", () => {
    // The formula and the placement pass are two statements of one rule, and this row is what stops them drifting apart. It is NOT the Playwright row: that one re-implements the arithmetic against the numbers a browser measured, which is the second implementation the gate needs.
    const scenes: SpacingSceneInput[] = [
      rowScene({ gapPx: 0 }),
      rowScene({ gapPx: 2, padding: { top: 2, right: 2, bottom: 2, left: 2 } }),
      rowScene({ gapPx: 6 }),
      rowScene({ gapPx: 40 }),
      rowScene({ gapPx: 12, padding: { top: 16, right: 16, bottom: 16, left: 16 } }),
      rowScene({ gapPx: 0, padding: { top: 16, right: 0, bottom: 0, left: 0 } }),
      rowScene({ gapPx: 12, padding: { top: 32, right: 32, bottom: 32, left: 32 }, padEnabled: false }),
    ];
    for (const scene of scenes) {
      const placed = placeSpacingAffordances(scene);
      const operable = placed.reduce((total, a) => total + 1 + a.aprons.length, 0);
      expect(expectedSpacingAffordanceCount(scene), JSON.stringify({ gap: scene.gapPx, padding: scene.padding })).toBe(
        operable,
      );
    }
    // Non-vacuity: at least one of those scenes carries an apron, so the third term is exercised rather than being uniformly zero across the whole list.
    expect(scenes.some((s) => placeSpacingAffordances(s).some((a) => a.aprons.length > 0))).toBe(true);
  });

  it("⚠ A CHILD THAT OVERFLOWS ITS OWN CONTENT BOX IS INSIDE ITS PARENT'S PADDING BAND, AND THE CLAMP DOES NOT SAVE IT — a MEASURED SHORTFALL, recorded", () => {
    // ⚠ **THIS IS THE ONE PLACE §3.7's CLAMP DOES NOT DELIVER §3.6.3's PROMISE, and it is stated rather than hidden.** The padding clamp bounds the band by the ERGONOMICS ceiling, not by where the children happen to be — so on a container whose child overflows its content box (an absolute child, a negative margin, a `min-width` the flow could not honour) the inward band and the child's border box really do intersect, and a press in that overlap takes the drill-down click G44-9 exists to protect.
    //
    // **WHY IT IS NOT GATED INTO A FIX HERE:** the phase measured the live population and it is ONE container, `snpvar` (`p-2 md:p-8`, a child 24 px into a 32 px bottom band), and that container's padding family is REFUSED — so no affordance renders on it and the overlap is unreachable in fact. Guarding the geometry against a shape with no reachable instance would be an unfalsifiable clause of exactly the kind §3.6.3 demotes to a comment. What is gated is the reachable half: the refusal guard row above.
    //
    // RED-when for the SHORTFALL's own statement: give a future container an overflowing child AND a writable padding family → this row's `true` becomes the live defect, and the row is where the next lane meets it.
    const scene: SpacingSceneInput = {
      ...rowScene({ gapPx: 0, padding: { top: 32, right: 32, bottom: 32, left: 32 } }),
      children: [{ left: 0, top: 88 - 24, width: 320, height: 56 }],
    };
    const bottom = placeSpacingAffordances(scene).find((a) => a.edge === "bottom");
    expect(bottom?.hit.height).toBe(PAD_EDGE_HIT_BAND_PX);
    expect(overlaps(bottom!.hit, scene.children[0]!)).toBe(true);
  });

  it("no part of ANY hit surface lies inside a child's border box, across every scene above — G44-9's whole claim", () => {
    // ⚠ **THE WRAPPING SCENES ARE IN THIS POPULATION, AND UNTIL THE CLOSURE AUDIT THEY WERE NOT — the row's title said "ANY" over a population that excluded the only shape that could falsify it.** Every scene built by `rowScene` is single-line by construction, so before the wrap guard existed this loop was green on all twelve of them while the defect sat one `it()` above, in the two scenes the WRAP ARM row owns. A universal claim whose population cannot contain its own counter-example is the MF-3 blindness in its purest form, and it survived the very round that fixed the defect. The two wrapped scenes are therefore built HERE too rather than only being asserted over there. **RED-when: delete the `sameFlexLine` guard from `gapBands` → this row fires alongside the WRAP ARM row, which is the whole point of it being universal.**
    const scenes: SpacingSceneInput[] = [];
    for (const gapPx of [6, 12, 40]) {
      for (const pad of [0, 8, 16, 32]) {
        scenes.push(rowScene({ gapPx, padding: { top: pad, right: pad, bottom: pad, left: pad } }));
      }
    }
    // The two-line subject: two full-width children on separate lines. The band the DOM-order pairing would mint between them lands in the middle of the container and overlaps BOTH.
    scenes.push({
      ...rowScene({ gapPx: 12 }),
      children: [
        { left: 0, top: 0, width: 200, height: 40 },
        { left: 0, top: 52, width: 200, height: 40 },
      ],
    });
    // The three-line subject: the line-1 pair DOES mint a band, and the cross-extent clamp is what keeps it off the items on lines 2 and 3.
    scenes.push({
      ...rowScene({ gapPx: 12 }),
      children: [
        { left: 0, top: 0, width: 120, height: 30 },
        { left: 132, top: 0, width: 120, height: 30 },
        { left: 0, top: 42, width: 120, height: 30 },
        { left: 0, top: 84, width: 120, height: 30 },
      ],
    });
    // NON-VACUITY: the population really does contain a multi-line member, so the widening is not decorative.
    expect(scenes.some((sc) => sc.children.some((c, i) => i > 0 && c.top >= sc.children[i - 1]!.top + sc.children[i - 1]!.height))).toBe(true);
    for (const scene of scenes) {
      for (const affordance of placeSpacingAffordances(scene)) {
        for (const rect of [affordance.hit, ...affordance.aprons]) {
          for (const child of scene.children) {
            expect(overlaps(rect, child), `${affordance.id} ${JSON.stringify(rect)} vs ${JSON.stringify(child)}`).toBe(
              false,
            );
          }
        }
      }
    }
  });
});
