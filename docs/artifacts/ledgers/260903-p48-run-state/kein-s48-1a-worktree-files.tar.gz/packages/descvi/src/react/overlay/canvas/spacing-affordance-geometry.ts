/**
 * spacing-affordance-geometry.ts — the gap strip's and the padding edge handles' FOUR constants and the pure placement rule they parameterise (phase-44 S44-3; plan §3.6, §3.7, §3.8, G44-4, G44-9).
 *
 * WHY A PURE MODULE, SEPARATE FROM THE HOOK THAT PAINTS IT. The same reason `handle-geometry.ts` is separate from `use-resize-handles.ts`: the floor rule and the clamp rule are the two things G44-9's arms are aimed at, and an arm that can only be fired through a browser is an arm that gets fired once. Everything here is a function of measured numbers, so the floors and the clamps have a vitest oracle as well as a Playwright one.
 *
 * ⚠ THE BAND'S EXTENT COMES FROM THE COMPUTED `gap` / `padding` PROPERTY, NEVER FROM THE GEOMETRIC DISTANCE BETWEEN TWO CHILDREN, and that is a ruling rather than an implementation convenience. On a `justify-between` container the free space between two children is large while the computed gap is 0 — that is the whole of the Auto state — so a band measured geometrically would render a 80 px gap strip on `gap-auto`, which is exactly the absence G44-2 arm (c) asserts and exactly the "render it to make it discoverable" fix S44-P4 exists to turn RED. The computed property is also what §3.8's universe-B formula counts, so the gate and the renderer are reading one channel rather than two that agree today.
 *
 * ⚠ AND THE BAND'S CENTRE COMES FROM THE GEOMETRY, WHICH IS THE OTHER HALF OF THE SAME RULING. On an ordinary container the two answers coincide exactly: the facing edges of two adjacent children are `gap` apart, so a band of width `gap` centred on their midpoint IS the region bounded by them, which is what §3.6.1 says the hatch paints. On a `justify-between` container carrying a real `gap-*` (the `gap-auto-collateral` shape) they differ, and the band sits centred in the free space rather than filling it. That is stated rather than hidden: the alternative — filling the free space — would paint a hatch claiming a gap value the container does not have, and the alternative to THAT — refusing to render — would remove the one canvas subject the fold's own gate arm (G44-2 arm (b)) has.
 *
 * SaaS-seam: overlay-CLIENT code — NO `node:*` / `process` / `fs`.
 */
import type { SpacingEdge } from "../engine/spacing-class-model";
import { SPACING_EDGES } from "../engine/spacing-class-model";
import { POINTER_DRAG_THRESHOLD_PX } from "./pointer-thresholds";

/**
 * The gap strip's hit band on the gap's OWN axis, in CSS px — an ERGONOMICS CEILING, not a decidability extent.
 *
 * Its extent belongs only to the empty region BETWEEN two elements. Sharing it with a resize surface would tie an inward affordance's ergonomics to an unrelated border interaction.
 *
 * ⚠ RULED AT 16 IN THE S44-3 BRIEF, WHICH IS THE VALUE §3.6.2 PROPOSED — the low end of the parent's 16–24 band. The clamp below is what makes the ceiling reachable only on a container with a genuinely large gap, so the number buys ergonomics on the rare wide container and costs nothing on the common narrow one; the first live feel on `lab/tests/spacing-nesting` found no reason to move it. Because the ruling did NOT raise the ceiling, `e2e/spacing-cascade.spec.ts`'s `LARGEST_HIT_EXTENT_PX` — a neutral file that deliberately does not import this symbol — keeps the 16 it was written against.
 *
 * ⚠ **THE CEILING IS ALSO THE POPUP'S ADMISSION TEST, AND THAT COST IS RECORDED HERE RATHER THAN SOLVED (critic M-6 / architect WC-2, carried by the plan's 2026-08-21 §3.8 erratum).** The popup opens from an APRON, and an apron exists only where the measured band EXCEEDS its ceiling — so on every container at or below 16 px of gap there is no numeric popup on the canvas at all, and the panel field is the only route to a typed value. **As-of census, under §2.4's counting rule and re-measured after this round's code stopped moving — EXCLUDING this phase's own fixture, which the screen's header requires of every carrier of one of its numbers: 7 of 118 live gap tokens (~6%) clear this ceiling, and 139 of 331 padding tokens (~42%) clear the padding one.** (Counting the fixture in, 8 of 126 and 144 of 345 — the same two percentages.) So the canvas popup is, in practice, a padding affordance with a rare gap case — not the general second route §3.9's prose reads like. **This is NOT fixed here.** Adding a second opening gesture (a sub-threshold strip press, a modifier, a long press) is a UX question with a modifier budget already spent, and it is ROUTED TO THE S44-3 DESIGNER SIGN-OFF rather than decided by an implementation lane. The number moves with `src/app/**`; nothing asserts it.
 */
export const GAP_STRIP_HIT_BAND_PX = 16;

/**
 * Below this measured gap, in CSS px, NO gap affordance is rendered at all — the canvas shows nothing and the panel's gap field is the only route (§3.6.4).
 *
 * ⚠ TIED TO {@link POINTER_DRAG_THRESHOLD_PX}: a band narrower than the classification threshold cannot be grabbed without the press resolving as a click anyway, so an affordance below it would take the drill-down surface and give nothing back. The tie is to the human finger and to the classifier, neither of which knows which CSS property it is pointing at — which is why {@link PAD_EDGE_RENDER_FLOOR_PX} carries this same sentence rather than a different rule.
 *
 * ⚠ THE TEST IS `band < FLOOR`, NEVER `band <= 0`. The two are indistinguishable on every subject whose band is exactly zero, which was every floor subject the plan's first two revisions had; `spacing-below-floor` (`flex gap-[2px] p-[2px]`) exists to separate them, and G44-9a's second RED-when is that mutation.
 */
export const GAP_STRIP_RENDER_FLOOR_PX = POINTER_DRAG_THRESHOLD_PX;

/**
 * The padding edge handle's hit band, measured INWARD from the border box, in CSS px — an ergonomics ceiling on the same terms as {@link GAP_STRIP_HIT_BAND_PX}.
 *
 * ⚠ 12 MATCHES THE RESIZE STRIPS' ERGONOMICS NUMBER WITHOUT SHARING ITS SYMBOL (§3.7.2). The two bands sit on OPPOSITE SIDES of the same edge — the resize strip hangs outside it, this one reaches inside it — so a shared constant would tie an inward clamp to an outward band and one of the two would have to move for the other's reason.
 *
 * ⚠ **THE OPPOSITE-SIDES ARGUMENT HOLDS FOR THE EDGE STRIPS AND NOT FOR THE CORNERS, and the difference is a suppression rule rather than a geometry one (architect MF-3 / critic M-5).** A phase-42 CORNER chip is 14 px centred on the box corner, so it reaches ~7 px OUTSIDE and ~7 px INSIDE — and the inside half lands in this family's band on both of that corner's edges. The two really do claim the same pixels. **RESIZE WINS, ALWAYS**, and it is now stated rather than left to an accident: see {@link SPACING_STRIP_Z} for the rule, the paired constants and the row that pins it.
 */
export const PAD_EDGE_HIT_BAND_PX = 12;

/**
 * Below this measured padding, in CSS px, that edge renders NO handle (§3.7.3) — and the zero case is this floor's degenerate member rather than a separate rule.
 *
 * ⚠ TIED TO {@link POINTER_DRAG_THRESHOLD_PX}: a band narrower than the classification threshold cannot be grabbed without the press resolving as a click anyway, so an affordance below it would take the drill-down surface and give nothing back. The tie is to the human finger and to the classifier, neither of which knows which CSS property it is pointing at — which is why {@link GAP_STRIP_RENDER_FLOOR_PX} carries this same sentence rather than a different rule.
 *
 * ⚠ THE SYMMETRY IS THE RULING, and it replaces r1's zero-test. There is no property of padding that makes a 2 px inward band grabbable when a 2 px gap band is not, so the two families get one floor for one reason stated in one wording.
 */
export const PAD_EDGE_RENDER_FLOOR_PX = POINTER_DRAG_THRESHOLD_PX;

/**
 * **THE SUPPRESSION RULE: WHERE THE TWO CANVAS FAMILIES CLAIM THE SAME PIXEL, RESIZE WINS.**
 *
 * ⚠ **STATED AS A RULE BECAUSE IT WAS TRUE BY ACCIDENT (architect MF-3 / critic M-5).** A phase-42 CORNER chip is 14 px centred on the element's box corner, so ~7 px of it lies INSIDE the border box — inside this family's padding bands, on both of that corner's edges. The first draft gave the spacing strip `z-index: 42`, which happens to be *below* the corner's 43 and *tied* with the resize EDGE strip's 42 (resolved in the spacing layer's favour by DOM order, harmlessly, because those two never overlap). So resize won at the corners for no stated reason, and any later edit to either number would have flipped a live gesture with nothing to catch it.
 *
 * The rule and its reason: **the resize handle is the affordance the user came for at a corner** — it is the one with a glyph pointing at that corner, it is the shipped gesture, and a spacing band merely happens to extend under it. A coin-flip press between two families is worse than an absent affordance (§3.7.4's own argument), so the whole spacing family now sits strictly BELOW every resize handle, and the numbers are named on both sides so the ordering is a comparison rather than a coincidence. `use-resize-handles.ts` carries the other half — {@link "./use-resize-handles".RESIZE_STRIP_Z} and `RESIZE_CORNER_Z` — and its docblock points back here.
 *
 * ⚠ **THE PADDING BANDS' OWN CORNER OVERLAP IS SETTLED SEPARATELY AND NOT BY z — see {@link padSlab}.**
 */
export const SPACING_HATCH_Z = 39;
/** The popup's opening apron — below the drag strip, because a press that could be either should drag. */
export const SPACING_APRON_Z = 40;
/** The drag strip. Strictly below `RESIZE_STRIP_Z`; the test asserts the inequality, not the literals. */
export const SPACING_STRIP_Z = 41;

/** A layer-relative rect, in the coordinate space `#dsh-ring-layer` establishes — the rings' own space. */
export interface SpacingRect {
  left: number;
  top: number;
  width: number;
  height: number;
}

/** Which family an affordance belongs to, and therefore which entry point its drag commits through. */
export type SpacingAffordanceKind = "gap" | "pad";

/**
 * What one operable node in the spacing layer IS — the DRAG strip, or the POPUP apron beside it.
 *
 * ⚠ **THE APRON IS A RULING THIS STORY MAKES, AND IT IS STATED HERE RATHER THAN LEFT TO THE RENDERER, because it adds a term to §3.8's universe-B count formula** (carried by the plan's 2026-08-21 erratum). Three of the story's own acceptance rows constrain the geometry jointly and only this shape satisfies all three:
 *
 *  - acc 3's CLAMP arm and acc 5's CEILING row both probe with `elementFromPoint` and both name the mutation `min(band, CEILING) → CEILING`, so the node those probes see MUST be sized by the clamped hit band. A root sized to the measured band would leave the CLAMP mutation invisible on `gap-thin`, which is the exact blindness MF-3 filed against r0.
 *  - acc 8 needs an OPERABLE surface in `hatch \ hit` — "the hatched region outside the drag strip" — and that region is non-empty exactly when the measured band exceeds its family's ceiling.
 *
 * So there are two operable nodes on such an affordance and one on every other, and the count formula's apron term is the number of affordances whose band exceeds their ceiling. The apron lies WHOLLY INSIDE the measured band, so what the ceiling bounds is the DRAG surface — which is what acc 5's "a 200 px gap becomes a 200 px hot region" is about.
 *
 * ⚠ **"AND THE MEASURED BAND CONTAINS NO CHILD BY CONSTRUCTION" WAS THE FIRST DRAFT'S SENTENCE AND IT IS FALSE — QUALIFIED HERE RATHER THAN REPEATED.** It holds for a GAP band between two children on one flex line (this module now refuses to mint any other kind — see {@link sameFlexLine}). It does NOT hold for a PADDING band whose child overflows its own content box: the clamp bounds the band by the ergonomics ceiling, not by where the children are. That shortfall has its own row, named so it can be found rather than rediscovered — `⚠ A CHILD THAT OVERFLOWS ITS OWN CONTENT BOX IS INSIDE ITS PARENT'S PADDING BAND, AND THE CLAMP DOES NOT SAVE IT` in `__tests__/spacing-affordance-geometry.test.ts` — and its one live instance (`snpvar`) is unreachable because its padding family is refused.
 */
export type SpacingAffordanceRole = "strip" | "apron";

export interface SpacingAffordance {
  kind: SpacingAffordanceKind;
  /**
   * The stable per-affordance id, and it is what the drag reads back off the node.
   *
   * `gap:<n>` — the band between the container's nth and (n+1)th own children, zero-based. `pad:<edge>` — that edge's inward handle. Stable across a re-anchor so a node holding pointer capture keeps its identity, which is the same reason the resize furniture keys its nodes by compass.
   */
  id: string;
  /** The padding edge this affordance writes, for `kind: "pad"` only. */
  edge?: SpacingEdge;
  /** The HIT rect — clamped by the family's ceiling, and never larger than the band it names. */
  hit: SpacingRect;
  /** The measured band, in CSS px, BEFORE the ceiling clamp: what the panel field would show. */
  bandPx: number;
  /** The HATCH rect — the measured band painted exactly (§3.6.1, §3.7.1). Hover-driven; the hit rect is not. */
  hatch: SpacingRect;
  /**
   * The POPUP apron rects — the parts of {@link SpacingAffordance.hatch} the {@link SpacingAffordance.hit} strip does not cover. EMPTY unless the measured band exceeds the family's ceiling; two rects when it does, one on each side of the centred strip.
   */
  aprons: readonly SpacingRect[];
}

/**
 * What one placement pass measures. Every field is a number the caller read off the DOM in one pass, so this module can be exercised without a browser and the gate's arms have a vitest oracle as well as a live one.
 */
export interface SpacingSceneInput {
  /** The selected container's BORDER box, layer-relative. */
  box: SpacingRect;
  /** The four computed padding values, in CSS px. */
  padding: Record<SpacingEdge, number>;
  /** The computed `column-gap` / `row-gap`, in CSS px. A non-flex container reports 0 here (see `gapEnabled`). */
  gapPx: number;
  /**
   * Is the GAP family writable on this container at all — `false` on a non-flex container (`gap-requires-flex-container`) and on a variant-shadowed one (`spacing-controlled-by-variant`).
   *
   * ⚠ THIS IS A REFUSAL CHANNEL AND NOT A GEOMETRY ONE, and it is threaded rather than re-derived for the reason `use-resize-handles.ts` threads the panel's own refusal: an affordance rendered over a target whose write is refused takes the drill-down surface and gives nothing back, and §3.11 rules that this phase mints NO non-operable spacing marker — so the honest rendering of a refusal is absence.
   */
  gapEnabled: boolean;
  /** The same, for the PADDING family. `p-2 md:p-8` is `false` here — the variant shadows the base layer. */
  padEnabled: boolean;
  /** The container's flex main axis. Decides whether a gap band is a vertical strip or a horizontal one. */
  axis: "row" | "column";
  /**
   * The container's OWN element children's border boxes, layer-relative, in DOM order — G44-4's whole scope.
   * Never a descendant, never a sibling: the query that produced these is `element.children`, and widening it to the grandparent is that gate's RED-when.
   */
  children: readonly SpacingRect[];
}

function clampRect(rect: SpacingRect): SpacingRect {
  return { ...rect, width: Math.max(0, rect.width), height: Math.max(0, rect.height) };
}

/** The container's CONTENT box — the border box less its four computed paddings. */
function contentBox(scene: SpacingSceneInput): SpacingRect {
  return clampRect({
    left: scene.box.left + scene.padding.left,
    top: scene.box.top + scene.padding.top,
    width: scene.box.width - scene.padding.left - scene.padding.right,
    height: scene.box.height - scene.padding.top - scene.padding.bottom,
  });
}

/**
 * Are these two adjacent children on the SAME flex line?
 *
 * ⚠ **THE TEST IS CROSS-AXIS OVERLAP, AND IT IS WHAT STOPS A WRAPPED PAIR FROM MINTING A BAND — the defect this function exists to prevent was MEASURED, with a positive control (architect MF-2).** `gapBands` pairs children in DOM ORDER, and on a wrapping container the pair that straddles a line break is not separated by a gap at all: the second child starts back at the line's leading edge, so the "band" between their facing edges is computed from a midpoint that lies in the MIDDLE OF THE CONTAINER. Measured on a `flex flex-wrap` scene with two full-width children on two lines, the band landed at `left 94, width 12, height 120` and **overlapped BOTH children** — P44-4 verbatim, and the corpus carries 7 such literals OUTSIDE this phase's own fixture (8 counting it — the qualifier the fixture screen's header requires), so it is a live shape rather than a constructed one.
 *
 * Two children on one line always overlap on the cross axis (a flex line's items share its cross extent); two on different lines never do, because the line boxes are disjoint by construction. That is the whole test, and it needs no line-box arithmetic of its own.
 */
function sameFlexLine(a: SpacingRect, b: SpacingRect, axis: "row" | "column"): boolean {
  return axis === "row"
    ? a.top < b.top + b.height && a.top + a.height > b.top
    : a.left < b.left + b.width && a.left + a.width > b.left;
}

/**
 * The gap bands, one per adjacent pair of the container's OWN children that share a flex line (G44-4).
 *
 * ⚠ **THE CROSS EXTENT IS THE PAIR'S OWN UNION, CLAMPED TO THE CONTENT BOX — NOT THE CONTENT BOX ITSELF.** The content box was the first draft's choice and it is wrong on any container with more than one line: a band spanning the whole content height reaches across every OTHER line, so on a three-line container the band between two items on line 1 lies on top of the items on lines 2 and 3. Clamping to `union(first, second)` on the cross axis makes the band describe the region it actually names. On a single-line container the two answers coincide exactly, which is why the defect survived every subject the fixture screen carried before the sixteenth container.
 *
 * ⚠ AND THE UNION IS STILL CLAMPED TO THE CONTENT BOX, which is what keeps the two families from overlapping each other: a band reaching past the content box would reach into the very padding bands this same pass places, and two hit surfaces in one region with no modifier to separate them is a coin flip on every press — §3.7.4's own argument, applied to this phase's own pair rather than to phase-42's.
 */
function gapBands(scene: SpacingSceneInput): SpacingAffordance[] {
  if (!scene.gapEnabled) return [];
  if (scene.gapPx < GAP_STRIP_RENDER_FLOOR_PX) return [];
  const hitBand = Math.min(scene.gapPx, GAP_STRIP_HIT_BAND_PX);
  const overhang = (scene.gapPx - hitBand) / 2;
  const content = contentBox(scene);
  const out: SpacingAffordance[] = [];
  for (let i = 0; i + 1 < scene.children.length; i += 1) {
    const first = scene.children[i]!;
    const second = scene.children[i + 1]!;
    // A wrapped pair has no band between it — see {@link sameFlexLine}.
    if (!sameFlexLine(first, second, scene.axis)) continue;
    const common = { kind: "gap", id: `gap:${i}`, bandPx: scene.gapPx } as const;
    if (scene.axis === "row") {
      const centre = (first.left + first.width + second.left) / 2;
      const start = centre - scene.gapPx / 2;
      const top = Math.max(content.top, Math.min(first.top, second.top));
      const bottom = Math.min(content.top + content.height, Math.max(first.top + first.height, second.top + second.height));
      const height = Math.max(0, bottom - top);
      out.push({
        ...common,
        hit: clampRect({ left: centre - hitBand / 2, top, width: hitBand, height }),
        hatch: clampRect({ left: start, top, width: scene.gapPx, height }),
        aprons:
          overhang <= 0
            ? []
            : [
                clampRect({ left: start, top, width: overhang, height }),
                clampRect({
                  left: centre + hitBand / 2,
                  top,
                  width: overhang,
                  height,
                }),
              ],
      });
    } else {
      const centre = (first.top + first.height + second.top) / 2;
      const start = centre - scene.gapPx / 2;
      // The column axis takes the SAME union clamp, on the other axis. A `flex-col flex-wrap` container is rarer than a wrapping row and is exactly as capable of producing the defect, so the two arms stay symmetric.
      const left = Math.max(content.left, Math.min(first.left, second.left));
      const right = Math.min(content.left + content.width, Math.max(first.left + first.width, second.left + second.width));
      const width = Math.max(0, right - left);
      out.push({
        ...common,
        hit: clampRect({ left, top: centre - hitBand / 2, width, height: hitBand }),
        hatch: clampRect({ left, top: start, width, height: scene.gapPx }),
        aprons:
          overhang <= 0
            ? []
            : [
                clampRect({ left, top: start, width, height: overhang }),
                clampRect({
                  left,
                  top: centre + hitBand / 2,
                  width,
                  height: overhang,
                }),
              ],
      });
    }
  }
  return out;
}

/**
 * The inward slab for one edge, between `from` and `to` CSS px measured inward from the BORDER box.
 *
 * ⚠ THE STRIP IS FLUSH TO THE BORDER BOX AND NOT CENTRED IN THE BAND, unlike the gap's — so a clamped padding affordance has ONE apron (the inner remainder) where a clamped gap band has two. The asymmetry follows from the geometry rather than from a choice: a gap band is bounded on both sides by a child, and a padding band on one side only.
 *
 * ⚠ **THE FOUR EDGE SLABS OVERLAP EACH OTHER AT EVERY CORNER, AND DOM ORDER DECIDES — NOT z (architect MF-3's second half).** `top` and `bottom` span the element's FULL WIDTH and `left`/`right` its full height, so a 16 px-padded box has four 12 px squares at its corners claimed by two edges each. They are placed in {@link SPACING_EDGES}' order — top, right, bottom, left — and all carry {@link SPACING_STRIP_Z}, so the LAST one placed wins the hit: **left beats bottom beats right beats top at a shared corner.** Stated rather than tuned, and deliberately NOT solved by mitring the slabs into trapezoids: a mitre would make each edge's hit region a different shape from the band it paints, and §3.7.4's whole argument is that a hit surface must name the region it describes. The cost is small and bounded — a corner press adjusts one of the two edges the pointer is plainly between — and it is the same cost phase-42 accepted when its corner chips paint above its edge strips.
 */
function padSlab(scene: SpacingSceneInput, edge: SpacingEdge, from: number, to: number): SpacingRect {
  const { box } = scene;
  const depth = to - from;
  switch (edge) {
    case "top":
      return clampRect({ left: box.left, top: box.top + from, width: box.width, height: depth });
    case "bottom":
      return clampRect({ left: box.left, top: box.top + box.height - to, width: box.width, height: depth });
    case "left":
      return clampRect({ left: box.left + from, top: box.top, width: depth, height: box.height });
    case "right":
      return clampRect({ left: box.left + box.width - to, top: box.top, width: depth, height: box.height });
  }
}

function padEdges(scene: SpacingSceneInput): SpacingAffordance[] {
  if (!scene.padEnabled) return [];
  const out: SpacingAffordance[] = [];
  for (const edge of SPACING_EDGES) {
    const band = scene.padding[edge];
    if (band < PAD_EDGE_RENDER_FLOOR_PX) continue;
    const hitDepth = Math.min(band, PAD_EDGE_HIT_BAND_PX);
    out.push({
      kind: "pad",
      id: `pad:${edge}`,
      edge,
      bandPx: band,
      hit: padSlab(scene, edge, 0, hitDepth),
      hatch: padSlab(scene, edge, 0, band),
      aprons: band > hitDepth ? [padSlab(scene, edge, hitDepth, band)] : [],
    });
  }
  return out;
}

/**
 * THE PLACEMENT PASS — every spacing affordance this container admits, gap bands first and padding edges after, in {@link SPACING_EDGES}' order.
 *
 * ⚠ THE RETURNED SET IS THE SET OF OPERABLE NODES, AND IT IS UNCONDITIONAL ON HOVER (§3.8's ruling). The hatch is hover-driven and the hit target is not: you cannot hover onto a surface that only exists once you are already hovering it, and C9's universe B is a scan of the RESTING DOM. A hover-gated hit target makes that scan find zero against a derived expectation, and makes the affordance unreachable in the live smoke as well.
 *
 * ⚠ **THAT EXPECTED COUNT IS NOT `bands + edges`, AND THIS DOCBLOCK SAID IT WAS UNTIL THE CLOSURE AUDIT CAUGHT IT — three functions above the correction, in the same file.** §3.8's original two-term formula is falsified by this module's own behaviour on four counts (the refusal guard, the apron term, the wrap term, and the flex guard), and restating it here made this file a carrier of the very claim it corrects. **The count is {@link expectedSpacingAffordanceCount} and nothing else** — do not re-derive it in prose, here or anywhere: a second spelling of a formula is how the first one goes stale.
 */
export function placeSpacingAffordances(scene: SpacingSceneInput): SpacingAffordance[] {
  return [...gapBands(scene), ...padEdges(scene)];
}

/**
 * §3.8's universe-B expected COUNT, derived from the same scene the renderer places from — published so the gate can state the formula it iterates rather than a literal.
 *
 * ⚠ IT IS DELIBERATELY NOT `placeSpacingAffordances(scene).length` DRESSED UP: the Playwright universe-B row re-implements this arithmetic against the numbers IT measured, exactly as `e2e/resize-handles.spec.ts` re-implements §3.12's admission rule. What this export is for is the vitest half, where a derived expectation and the placement pass ARE the same module and the row's job is the FORMULA — the flex guard, the two floors, the refusal guard and the apron term — rather than the placement.
 *
 * ⚠ **THE FORMULA CARRIES THREE TERMS §3.8's ORIGINAL TEXT DOES NOT. The first two are carried by the plan's 2026-08-21 erratum; the third arrived with the sixteenth fixture container in the same round:**
 *
 *  1. **THE REFUSAL GUARD**, `gapEnabled` / `padEnabled`. §3.8's own r3 revision made the FLEX guard explicit for exactly this reason — the zero it produced was an accident of `getComputedStyle` coercing a non-flex container's `columnGap` to `"normal"`, not a statement of the rule. The variant shadow is the same shape one refusal along: `p-2 md:p-8` refuses `spacing-controlled-by-variant`, §3.11 rules that this phase mints NO non-operable spacing marker, and `use-resize-handles.ts` already renders ABSENCE on a refused axis. So a refused family contributes zero, and the fixture's `pad-variant` container (`snpvar`) — the one live element whose child reaches 24 px into its own 32 px bottom band — is UNREACHABLE rather than a free CLAMP subject.
 *  2. **THE APRON TERM** — see {@link SpacingAffordanceRole}. An affordance whose measured band exceeds its family ceiling carries the popup's opening surface beside its drag strip: two aprons for a gap band (the strip is centred), one for a padding edge (the strip is flush).
 *  3. **THE WRAP TERM** — the band count is the number of adjacent pairs that SHARE A FLEX LINE, not `children − 1`. On a single-line container the two are equal, which is why `children − 1` survived every subject the fixture carried before `gap-wrap`. See {@link sameFlexLine}.
 */
export function expectedSpacingAffordanceCount(scene: SpacingSceneInput): number {
  const pairsOnOneLine = scene.children.reduce(
    (total, child, i) =>
      i + 1 < scene.children.length && sameFlexLine(child, scene.children[i + 1]!, scene.axis) ? total + 1 : total,
    0,
  );
  const bands = scene.gapEnabled && scene.gapPx >= GAP_STRIP_RENDER_FLOOR_PX ? pairsOnOneLine : 0;
  const gapAprons = bands > 0 && scene.gapPx > GAP_STRIP_HIT_BAND_PX ? bands * 2 : 0;
  const liveEdges = scene.padEnabled
    ? SPACING_EDGES.filter((edge) => scene.padding[edge] >= PAD_EDGE_RENDER_FLOOR_PX)
    : [];
  const padAprons = liveEdges.filter((edge) => scene.padding[edge] > PAD_EDGE_HIT_BAND_PX).length;
  return bands + gapAprons + liveEdges.length + padAprons;
}
