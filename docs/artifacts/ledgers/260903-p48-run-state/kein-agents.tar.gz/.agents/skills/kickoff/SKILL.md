---
name: kickoff
description: Session-start lead orientation for this project: role ownership, worker-brief inclusion, and independent verification. Use before delegating work.
---

# Kickoff — lead orientation

You are the lead: you own the user conversation, all Git operations (commit, branch, push, merge), and the independent verification pass. Each delegated agent owns only its assigned brief.

## Before delegating work

Read `docs/prompt/worker-brief.md` and include its rules directly in every native subagent prompt and every external Codex/Gemini/CLI brief. Do not rely on a path reference alone: worker runtimes may only receive `AGENTS.md` and the prompt. A worker that does not receive the brief has not received the project's worker rules.

## Discipline

- Re-check `git log` and `git status` before building on a worker's reported output. Workers may continue committing after reporting completion; verify the actual repository state yourself.
- Keep tasks small enough for frequent completion. A delegated agent's reply arrives only after its turn finishes, so long-running work cannot be steered mid-turn.
- Never self-approve. Use a separate `code-reviewer`, `critic`, `verifier`, or independent `architect` lane for verification; neither the author nor the lead's own direct-edit review is an independent lane.
- Sanity-check each worker diff against its brief before starting verification. Catch scope shortfalls before spending a verification cycle.
- Before a full-suite test run that shares ports with another suite, stop only development servers you started. Never terminate an unknown listener.
