# Task S48-1a — correction round 3 (the radius ruling applied; the reorder gated)

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`, HEAD `5a53259`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations; read-only git is fine; paste actual results; leave no scratch file in the repository; never touch another worktree). Run long commands in the FOREGROUND with a long timeout, output to a log under `/private/tmp/claude-501/`, and capture the real exit code; never pipe the command itself through `tail`/`head`. You alone may start dev servers / Playwright (:3001/:7331) in this round; check `lsof -nP -iTCP:3001 -iTCP:7331 -sTCP:LISTEN` before and after and leave nothing listening.

Task package: `.agents/kein/runs/execute/S48-1a-task.md`; previous rounds: `S48-1a-correction-r2.md`, reports `.agents/kein/reports/260903-031250-executor.md` (round 1) and `260903-045258-executor.md` (round 2). The working tree carries round 2's uncommitted result (15 modified files + the new `e2e/region-set-instrument.spec.ts`). Everything round 2 completed stands; this round has exactly two items.

## 1. The lead's ruling on A1 — apply plan §6.1

Round 2's A1 stopped correctly. The lead has ruled and recorded the ruling in the plan: read `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` **§6.1 "The radius reading, recorded"** in full before touching anything. In short: the reading (hit-testing is clipped to the padding-box RECTANGLE, not to the curve) is the third of §6's three named values, §6 already prices its consequence, production is untouched, and the oracles drop the arc. Apply it:

1. **The oracles' clip model becomes the padding-box rectangle** of `#dsh-frame` intersected with `#dsh-ring-layer`'s rect. Remove the arc from every reachable-surface computation in `e2e/resize-handles.spec.ts` (`arcsOf`, the arc branch of `pointInClip`/whatever the clip predicate is called now, the arc-aware margin logic). Keep a one-paragraph comment where the arc used to be, stating the measured reading and citing plan §6.1 — do not narrate the drafting. Every comment or docblock in the four e2e files and the two overlay tests that states the arc premise ("clips to the rounded shape", "padding-box arc", "radius 11/13", "outside the arc") is amended or removed; grep for `arc`, `radius`, `rounded` across the changed files and dispose of each hit.
2. **Re-run `G48-4`'s per-handle classification under the rectangle** on all three small fixtures (`1×1 at the rounded corner`, `1×100 flush left`, and the third) and RECORD the split in the row's comment and in your report — which handles take identity, which take the union floor. Where the round-1 classification said "empty (clip)" for `n`/`w` on the rounded-corner fixture, the rectangle says otherwise; measure, do not predict.
3. **Convert the STOP pin into a standing passing row** — retitle it to state the fact (e.g. "G48-4 radius reading — the frame's rounded corner does NOT clip hit-testing (measured 2026-09-03; plan §6.1)"), drop `test.fail`, and assert the reading: the probe at padding-radius + margin returns the `nw` handle, and the probe just past the frame's rectangular corner does not. Log the measured `#dsh-frame`/`#dsh-ring-layer` rects, border width and radius as before. Its RED lever is the browser starting to clip hits to the curve; state that in the row's comment.
4. **The identity golden**: retitle and status change → hand-edit `distribution` back to `failed: 2` (plus whatever `passed` becomes), regenerate with `pnpm test:e2e:update-identities`, review the diff line by line and paste it.
5. **Tracker**: add one line to `docs/e3/tracker.md`'s phase-48 disposition table recording the reading and its rule (the row was RE-DERIVED under plan §6.1), English, unwrapped, anchors not line numbers.

If, while applying this, a measurement contradicts §6.1 (for example the rectangle turns out not to be the padding box either), STOP and report; do not reconcile.

## 2. Gate the conditional reorder at unit level (replaces round 2's B4 gap)

Round 2 established that the e2e leg cannot change the rendered set without a source write the handles spec forbids. The comparison `desiredOrder` vs the host's current `[data-dsh-handle]` order in `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts` is new production code with no gate. Add a row (or two) to `packages/descvi/src/react/overlay/__tests__/resize-handle-layer.test.tsx`, where the selected target's className is a render input:

- (a) render with one axis blocked by a variant-prefixed sizing class so the set is a subset; rerender with both axes writable; assert the host's `[data-dsh-handle]` sibling order equals the reverse priority sequence of the eight (state the eight compass names as literals, import no production constant).
- (b) rerender with an unchanged set (a size-only change) and assert `host.appendChild` was not called (spy on the host node's `appendChild` between the two renders).
- Drive both RED and paste: make the reorder unconditional → (b) fails; break the comparison (e.g. compare against a shuffled order) → (a) fails. Restore and show the diff is clean.
- Amend the `G48-9` e2e leg's comment to point at this unit row for the history-dependence path, so the gap round 2 recorded is closed by name.

## After the corrections

Re-run and paste: the focused unit suites; `node scripts/check-citation-anchors.mjs`; `pnpm typecheck`; `pnpm test:e2e` in full (re-run a failed file once; report both; expect exactly the two pre-existing held pins); `pnpm gates` (tail + exit code); `git diff --exit-code .descvi/screens.json`; `git diff --stat -- src/app/sandbox/handle-lab` (empty); the byte-identical lines (`grep -c` each, expect 1: `export const HANDLE_ADMISSION_ORDER: readonly HandleCompass[] = [`, `function boundsViolations(handles: HandleRecord[], element: Rect): string[] {`, `expect(boundsViolations(scene.handles, scene.element)).toEqual([]);`, ` * NODES ARE REUSED, NOT REBUILT. A handle keeps its identity across remeasures, keyed by compass.`, `export function compassPoint(box: HandleRect, compass: HandleCompass): HandlePoint {`); `git status --porcelain`; `lsof` after.

## Report

Write the full report to `.agents/kein/reports/<yymmdd-HHMMSS>-executor.md`: per item what changed and the evidence (the G48-4 split under the rectangle recorded verbatim, the standing row's output, both RED outputs for the reorder gate, the golden diff), anything that reached a STOP, anything you reversed from the plan or this brief with the source that forced it. Return the path and a short summary.
