# Task S48-1a — correction round 4

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`, HEAD `5a53259`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations; read-only git is fine; paste actual results; leave no scratch file in the repository; never touch another worktree). Run long commands in the FOREGROUND with a long timeout (600000), output to a log under `/private/tmp/claude-501/`, capture the real exit code; never pipe the command itself through `tail`/`head`; never launch pnpm/playwright as a background task. You alone may start dev servers / Playwright (:3001/:7331) this round; check `lsof -nP -iTCP:3001 -iTCP:7331 -sTCP:LISTEN` before and after and leave nothing listening.

Task package: `.agents/kein/runs/execute/S48-1a-task.md`; plan `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` (§6 for each gate's specification; §6.1 — re-read it, the lead extended it this round). The working tree carries round 3's uncommitted result (report `.agents/kein/reports/260903-053041-executor.md`). Three fresh reviewers read it: the model, the transitional path, the byte-identical lines, the §6.1 application to production, the UNTOUCHED rows, EG-1/EG-2 and every driven RED were found sound and are NOT to be reworked. Every item below is a consolidated required correction; do all of them in this round and report each with evidence.

## A. Important

### A1. `G48-4` must run over all fifteen fixtures the plan assigns, and assert something for every handle
§6 assigns the row "over all twelve 4b fixtures and 4c's three"; the shipped `fixtures` array in the `G48-4` test holds four (`300×120 comfortable`, `1×100 flush left`, `100×1 flush top`, `1×1 at the rounded corner`). Extend it to 4b's twelve plus 4c's three (`300×120` may stay as the controls' host). Then close the two assertion holes: (i) a fallback handle that is a BAND is skipped (`if (boxCorner === null) continue;`) — §6 gives every fallback handle "the union floor plus the canonical-owner assertion": for every fallback handle, corner or band, assert some point of `rect ∩ clip` returns some `[data-dsh-handle]` node (the per-handle union floor); keep the canonical-owner probe as the corner-specific extra. (ii) `predictedReachable` is computed and reported but never confronted with the browser (`if (!predictedReachable) continue;`) — assert the classification against `elementFromPoint` so a port that clipped more, or less, than predicted is caught. Re-run, and update BOTH the in-test split comment and `docs/e3/tracker.md`'s "re-measured split" paragraph to the full fifteen-fixture table (which handles take identity, which the union floor, per fixture). Drive one RED for the new union-floor arm (e.g. shift a band off its edge on a flush fixture) and paste it.

### A2. `G48-3` browser half: assert the tolerance you declare
`e2e/resize-handles.spec.ts#    const tolerance = 0.02;` is declared as the measured maximum rounded up, but the assertions use `toBeCloseTo(anchor.x, 1)` (±0.05) and `tolerance + 0.05` (0.07). Assert `tolerance` itself — `expect(Math.abs(centre.x - anchor.x)).toBeLessThanOrEqual(tolerance)` and the same for y and the distance leg — and drop the bare `+ 0.05`; or re-declare the tolerance as the value actually enforced with the run that justifies it. Same defect in `acceptance 4b`: its per-rect `toBeCloseTo(…, 0)` (±0.5) is described as "the sub-pixel tolerance this row's sibling measured" — rewrite the comment to name its own 0.5 px tolerance and why it is looser. And `setFixture`'s settle poll says "EXACT equality (§6, G48-3)" while its predicate is `d > 0.5`: make the words match the number.

### A3. Delete the tautology row in `e2e/region-set-instrument.spec.ts`
`expect(true).toBe(true)` inside the row titled "`affordanceCentre`'s outputs and `G44-8`'s offsets — cross-referenced to `EG-1`, not re-measured" cannot go RED (`AGENTS.md`). Delete the row and put its cross-reference prose in the file's module docblock; regenerate `e2e/fixtures/expected-identities.json` (hand-edit `distribution` first, then `pnpm test:e2e:update-identities`, review and paste the diff).

### A4. The conditional reorder carries no comment; §4.1 requires the condition stated at the guard
At the loop in `use-resize-handles.ts` (`const desiredOrder = […].reverse().filter(…)` through the `appendChild` line) add the block comment §4.1 asks for: why reverse priority is the sibling sequence; why the comparison is conditional (the placement pass runs on every pointermove of a live drag and the moved node is the one holding `setPointerCapture`); the two levers that can change the rendered set (the axis filter and `chipEditorDisabled`). Amend the module docblock's continuation under `NODES ARE REUSED, NOT REBUILT` to mention the reorder — the anchored line itself stays byte-identical.

### A5. Unit-oracle deletions need a named reason and a tracker entry
Against `git show 5a53259:packages/descvi/src/react/overlay/__tests__/handle-geometry.test.ts`, the rows on `buildEffectiveClip` ("the effective clip is the INTERSECTION, arcs included", two rows), `R42-D1 — the strip band is a SEPARATE, smaller number than the decidability extent`, and the 16–24 half of the constants row are gone while their subjects are still exported this commit; neither `AGENTS.md` reason applies, and `docs/e3/tracker.md`'s disposition table has no entry for this file at all. Either restore them under the same `⚠ TRANSITIONAL` marking used for `hitSizeFor`, or add rows to the tracker table naming the disposition and the permitted reason for each. While editing the table add the two §2.1 entries it omits: the `acceptance 4 + 9` coverage loop's RE-POINT to `G48-8`, and the constants (`HIT_EXTENT` → the ramp bound, `STRIP_BAND` 12 → 10).

## B. Minor (do them; they are small)

### B1. `HANDLE_BAND_PX`'s declaration must carry the owner statement §4 requires
The docblock is one clause. Write at the declaration that the 8-vs-10 choice is the designer's, that `10` is a starting default and not a ruling, and that it is the number `G48-11` and the drill-down / swallowed-affordance records are priced against.

### B2. `G48-9` corners-before-bands leg: probe the pocket
Add `expect(ownerAt(regions, HANDLE_ADMISSION_ORDER, 1, 4.75)).toBe("sw")` (or an equivalent interior sample of `x ∈ [0,2) × y ∈ (4,5]` on the 6×6 fixture) beside the list-index assertion, and re-drive the `n`-ahead-of-`sw` lever against it.

### B3. Arc premise in two remaining comments
`handle-geometry.ts`'s `FRAME_CORNER_RADIUS_PX` docblock ("§2.1: this is where the two clip rects diverge") and `e2e/resize-handles.spec.ts`'s `// ── and the ROUNDED corner, where the two clip rects diverge (§2.1) ──` — re-derive both to the rectangle reading per plan §6.1 (the fixture stays as the layer-origin/quantisation case); at `FRAME_CORNER_RADIUS_PX` note that its value (12) is unverified against the shipped `rounded-xl` (measured 14) and that only the lab reads it.

### B4. `G44-9a` / `G44-9` Leg 1 golden: state the derivation
Beside `RESIZE_HITS_BY_OID` and Leg 1's pinned multiset, state how each entry follows from the parent's own box and the 5 px band reach (which handle claims which probe), so a future RED reads as "the band widened" or "the fixture moved".

### B5. EG-1 probe 2 depth
Probe 2 was taken at `hitDepth − 1.5` with the margin borrowed from `G48-4`; the plan asks for `hitDepth` with the delta measured and the aiming margin chosen from it. Take the reading at `hitDepth` on `snpthn`'s `pad:top`, record the delta beside `affordancePaddingDeepestPoint`'s `MARGIN`, or state at that declaration that the value is borrowed from `G48-4`'s measurement and why the transfer is sound.

### B6. Unit `G48-3`: the IEEE decision
`toBeCloseTo(…, 9)` is a ±5e-10 tolerance, not "bare equality"; and both fractional-extent fixtures sit at the origin where recovery is exact by construction. Move one fractional fixture off the origin (e.g. `{ left: 220, top: 180, width: 23, height: 100 }`) and either keep the 9-digit tolerance with a one-line note that it is an IEEE-recovery allowance, or switch to `toBe`.

### B7. Optional probe, §4.1's capture assumption
If cheap: apply the unconditional-reorder mutant once and run `e2e/resize-write.spec.ts`'s `G48-9` mid-drag row, recording whether the gesture still commits; otherwise record in the report that the probe was deliberately not taken and the assumption stands.

### B8. Unwrap
New or rewritten comments and docblocks in this change are hard-wrapped mid-sentence (the ten `⚠ TRANSITIONAL` docblocks, the `CORNERS OUTRANK BANDS BY CONSTRUCTION` paragraph, the `G48-4`/`G48-9` block comments). Unwrap the prose you added or rewrote; leave pre-existing wrapped prose you did not touch.

### B9. Tracker DELETE row format
The `clipOf` / `arcsOf` row in `docs/e3/tracker.md`'s disposition table argues reason 1 in substance but does not carry the explicit `` `AGENTS.md` reason 1: the code it covered is gone `` phrase the other three DELETE rows use. Add it. While there, add one line noting that the region-set instrument's cross-reference to EG-1 lives in its module docblock (after A3 deletes the stub row).

## After the corrections

Re-run and paste: the focused unit suites; `node scripts/check-citation-anchors.mjs`; `pnpm typecheck`; `pnpm test:e2e` in full (re-run a failed file once; report both; expect exactly the two pre-existing held pins); `pnpm gates` (tail + exit code); `git diff --exit-code .descvi/screens.json`; `git diff --stat -- src/app/sandbox/handle-lab` (empty); the five byte-identical lines (`grep -c` each, expect 1); `git status --porcelain`; `lsof` after.

## Report
Write the full report to `.agents/kein/reports/<yymmdd-HHMMSS>-executor.md`: per item A1…B8 what changed and the evidence (the fifteen-fixture G48-4 split verbatim, the union-floor RED, the golden diff), anything that reached a STOP, anything you reversed from the plan or this brief with the source that forced it. Return the path and a short summary.
