# phase-48 — B-Q5 handle admission: requirements for the plan

This file is the run's input record. It states what the owner decided and what the lead established from source; the plan is what turns it into work. It is written by the lead, whom no lane reviews, so a lane reading it treats every "from source" claim as something to re-verify, not as evidence.

## Task

Replace descvi's resize-handle admission model with the owner's tentative spec (2026-09-02), on branch `phase-48-kein`. The deliverable is `packages/**`; `src/app/**` changes exist only to verify.

## Owner decisions that bind the plan

1. **Model (2026-09-02, tentative, real use will judge):** narrow ≤ 20 px → corner hit 8 · wide ≥ 80 px → corner hit 16 · linear ramp between, driven by the **short side** (`min(w, h)`), corner stays square · side bands **straddle** the box edge · band thickness **10**. Structure is excalidraw-desktop's: corner regions tested first, then one band per side running the whole edge, **no size predicate anywhere, no handle is ever refused**. The lab's executable statement of this is `src/app/sandbox/handle-lab/owner-spec.ts` (`OWNER_SPEC`, `OWNER_SPEC_RAMP`) over `src/app/sandbox/handle-lab/candidate.ts`.
2. **Acceptance criteria (owner's words, made falsifiable in the lab, each proven able to go RED):** ① narrow — with a 10 px short side all eight handles are still grabbable (RED at corner 10: the two corner squares meet and e/w vanish). ② wide — aiming at a vertex grabs the diagonal; "at a vertex" = within `POINTER_DRAG_THRESHOLD_PX` of the geometric corner (RED at corner 5: 61.4 % diagonal occupancy instead of 100 %).
3. **Band 8 vs 10 is a designer's call, not this phase's.** Ship 10 as the starting default, keep it a single owner-adjustable constant, and do not present 10 as a ruling. Known fact: band 8 keeps criterion ① only down to a 9 px short side.
4. **Chip paint vs hit (2026-09-02, this session):** `HANDLE_CHIP_PX = 10` stays the ceiling; the painted chip is `min(HANDLE_CHIP_PX, corner hit)`. Elements whose short side is ≥ 35 px keep the 10 × 10 chip the owner ratified on 2026-08-27; below that the chip shrinks with the hit so nothing painted is ungrabbable. Hit floor 10 was considered and is ruled out: it fails criterion ① at a 10 px side.
5. **Clip regime (owner, 2026-08-27, recorded in the B-Q5 backlog row item (8)):** off-screen is not canvas — a handle at the screen's own edge is **clipped, not pushed inward**. Today `translateIntoRect` in `handle-geometry.ts` pushes. The plan must say what the new model does at the frame clip and what becomes of `translateIntoRect`; whatever it does must be consistent with this ruling.
6. **Out of scope, by owner ruling:** candidate (i) outside placement and candidate (ii) excalidraw-style `ㄱ`/`ㄴ` corner brackets — recorded as a tied pair in the backlog, judged by real use, not measured now. The band 8-vs-10 choice (item 3). KI-47.
7. **In scope as a rider (owner, this session):** the ~45 bare `file.tsx:NNN` pins across `e2e/*.ts` left by phase-47 (`docs/handoff/260831-phase-47-close.md`) are cleaned in the same story that reopens those files for re-pinning.

## What the lead established from source (re-verify before relying on it)

- `admitHandles` has exactly one production caller: `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts` (`admitHandles({ box, clip, axes })`, guarded by `axes.width || axes.height`). Chip paint there writes `HANDLE_CHIP_PX` directly and is independent of the hit rect.
- Constant consumers outside `handle-geometry.ts` (grep over `packages e2e src docs` for the six exported names): `use-resize-handles.ts`; `packages/descvi/src/react/overlay/__tests__/handle-geometry.test.ts` (333 lines — re-derives the separation clause, i.e. a third implementation of the admission rule; the clause is going away so this is a rewrite, not an edit); the lab files under `src/app/sandbox/handle-lab/`; docs `docs/e3/tracker.md`, `docs/handoff/260825-phase-46-consensus-rounds.md`, `docs/post-loop-backlog.md`. `spacing-affordance-geometry.ts` and its test mention the names only in docblocks and own `GAP_STRIP_HIT_BAND_PX = 16` — no import coupling. `e2e/spacing-cascade.spec.ts` mentions only the gap constant.
- Hand-copied constants: `e2e/resize-handles.spec.ts` (1078 lines) carries `const HIT_EXTENT = 20;` and `const STRIP_BAND = 12;` — a fourth implementation of the rule. `packages/descvi/src/react/overlay/__tests__/resize-handle-layer.test.tsx` asserts `chip.style.width` / `height` `toBe("10px")` literally.
- The ramp reaches 10 px at short side 35 (8 + (35 − 20) · 8/60 = 10). Under decision 4 this is where the painted chip stops shrinking.
- Straddle bands overlap padding-handle hit surfaces on 51.7 % of the measured scene (outside: 12.7 %, today's 15.1 %) — `src/app/sandbox/handle-lab/spacing-overlap.ts`. The owner accepted straddle knowing this. What is **not** established: which surface wins when a resize band and a spacing affordance overlap in production. The plan must find that from the overlay's actual hit/stacking order and state it.
- Inheritance from phase-46 that the new model makes moot: the constant-split reversal (1) and the closed-form/monotonicity findings (3) hinge on the separation clause, which the new model does not have. `handle-geometry.ts` still carries the written ruling `Owner-adjustable, but it must stay a single number` and ralplan-phase-42 §3.12 clause 1 still binds; the plan must **declare** that these are superseded and say why, rather than let the clause disappear silently. Inheritance (2) band pricing and (5) free-regime corner placement are done (`.omc/research/phase48-strip-band-pricing.md`, `.omc/research/phase48-bq5-corner-placement.md`).

## Repository constraints the plan must obey

- `AGENTS.md` in full — in particular: gates must be able to go RED; cite by anchor never by line number (`node scripts/check-citation-anchors.mjs` scans `.omc/plans`, so the plan itself is under the gate); `pnpm gates` is the gate set; UI change needs a real `descvi:dev` smoke or Playwright; artifact byte-identity (`.descvi/screens.json`); doc updates in their own commits.
- Lead standing rules that shape the plan: a defect names the site probed, not the population — enumerate classes from source; a ruling falsifies prose too — every doc whose *reason* the new model moves gets swept (`docs/architecture.md`, `docs/e3/tracker.md`, the B-Q5 backlog row, `docs/known-issues.md` if it carries admission claims); one production caller is the surface.
- Everything under `.omc/` is English. No hard-wrapped prose.

## Sources

- `docs/post-loop-backlog.md` row `| B-Q5 |` — the full decision record, including the owner's words.
- `.omc/research/phase48-prior-art-small-element-policy.md`, `phase48-strip-band-pricing.md`, `phase48-bq5-corner-placement.md`, `.omc/research/phase46-bq5-admission-measurement.md`.
- `.omc/plans/ralplan-phase-42-resize-handles.md` §3.12 (the model being replaced) and `.omc/plans/ralplan-phase-46-ring-furniture-restyle.md` §8 (the excision).
- Lab: `src/app/sandbox/handle-lab/` — `candidate.ts` (model + probes), `owner-spec.ts` (criteria as measurements), `policies.ts` (`cornerFirstBandRegions`, `hitTestRegions`), `spacing-overlap.ts`.
