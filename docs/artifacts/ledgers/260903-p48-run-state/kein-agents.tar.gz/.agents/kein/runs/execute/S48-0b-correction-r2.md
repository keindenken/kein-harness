# Task S48-0b — correction round 2 (docs only)

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`, HEAD `07ab8afee101`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations; read-only git is fine; paste actual results; a zero is evidence only once the instrument produced a non-zero; leave no scratch file in the repository).

## State of the tree

The tree carries the UNCOMMITTED round-1 result of S48-0b: nine documents (+71/−71) whose doomed citations were converted to `git show 07ab8afee101:path#anchor` form, with the plant fully reverted (no change under packages/, e2e/, src/, scripts/). Run `git diff --stat` to confirm. The round-1 task package is `.agents/kein/runs/execute/S48-0b-task.md`; the plan section is `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` §7 `S48-0b`.

## The defect — the plant missed a class member the plan itself names

Two live citations to a line INSIDE `boundsViolations`' body remain unconverted: `.omc/plans/ralplan-phase-46-ring-furniture-restyle.md` and `.omc/research/phase48-strip-band-pricing.md` both cite `e2e/resize-handles.spec.ts#if (short < 16 || short > 24) out.push(` (the research doc spells the `||` as `\|\|` inside a table cell). Plan §7's per-file list names "the corner 16–24 line" as doomed in both documents, separately from the function's signature (which you did convert). Your plant deleted the signature but not this body line, so the line was never blanked, both spans stayed resolvable, and the 96-violation RED list contains neither — the instrument was silent over exactly the member it was built to catch.

## A second miss of the same class

`.omc/plans/ralplan-phase-48-bq5-handle-admission.md` cites, twice, `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#const placements = axes.width || axes.height ? admitHandles({ box, clip, axes }) : [];` in bare form. Plan §7's own-plan disposition lists "the `placements` call line" among the plan's doomed anchors, and §2 says S48-1a stops passing `clip` at that call site, so the line's text changes. Convert both occurrences. The same reasoning applies to any other cited CALL SITE or helper BODY line S48-1a/S48-1b changes — the class is lines the rewrites kill, wherever they sit.

## Two judgment calls to make from the plan, and to state

- `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` cites `src/app/sandbox/handle-lab/order-walk.ts#      Math.hypot(placement.centre.x - placement.anchor.x, placement.centre.y - placement.anchor.y) >` (the anchor-envelope clause of the retired walk). §7 names only two `order-walk.ts` spans as doomed, but S48-1b repairs that file, whose "entire subject is the retired order-plus-thresholds walk". Decide from §7 S48-1b whether that line survives the repair; if it plausibly dies, convert it and say so; if you leave it live, say why.
- The two `HANDLE_ADMISSION_ORDER` declaration-line citations (`.omc/specs/v3-layout-panel-visual-spec.md` and `src/app/sandbox/handle-lab/page.tsx`) stay LIVE: the list keeps its name (§4) and S48-1a will be instructed to keep the declaration line `export const HANDLE_ADMISSION_ORDER: readonly HandleCompass[] = [` byte-identical. Do not convert them; `page.tsx` is out of scope regardless.

## What to do

1. **Re-derive the doomed class per suite file as LINES, not functions.** For each of the five suite files (`handle-geometry.test.ts`, `e2e/resize-handles.spec.ts`, `e2e/resize-write.spec.ts`, `e2e/resize-handle-shield.spec.ts`, `e2e/spacing-gesture.spec.ts`) list every cited anchor into it (the derived query's output restricted to that file) and, for each, decide from plan §2.1 / §7 S48-1a / §8 whether the cited LINE survives the rewrite or dies — a helper whose signature survives can still lose body lines (the `boundsViolations` corner leg is rewritten; its signature stays), and a row whose title survives can lose its assertions. Paste the per-anchor table (anchor → survives / dies → converted? yes/no).
2. **Convert every doomed span still in bare form** — at minimum the two `if (short < 16 || short > 24) out.push(` citations — to the frozen single-span form with the same sha `07ab8afee101`, anchor text byte-identical (keep the `\|\|` spelling where the span sits in a table cell, as the gate normalises pipes). Decide and state the disposition of `.omc/plans/ralplan-phase-46-ring-furniture-restyle.md`'s citation of `e2e/resize-handles.spec.ts#expect(boundsViolations(scene.handles, scene.element)).toEqual([]);` — does that call line survive §2.1's rewrite of the acceptance 4 + 9 row (the checker call stays while its legs move) or die? Convert it only if it dies; say which and why.
3. **Re-run the plant with body-level blanking.** Snapshot outside the repository as before; this time plant the END STATE at the granularity of LINES: delete every retiring symbol, apply the §8 docblock amendments, and for each rewritten helper or row in the five suite files blank every cited line the rewrite kills — including lines inside surviving functions — not only signatures or whole rows. Show the plant RED against a copy where your new conversions are reverted (the new spans must appear as fresh violations — paste them), then GREEN with all conversions in place. Revert by copy-back and verify with `git status --porcelain` and `git diff --stat` identical to the pre-plant baseline (paste both).
4. Final: `node scripts/check-citation-anchors.mjs` GREEN (paste); `git diff --exit-code .descvi/screens.json` clean; `git diff --stat` shows only documents. Skip `pnpm gates` — the lead runs it serially; say so.

## Report

Write your full report to the report path the command gives you: the per-anchor survives/dies table for the five files; the list of newly converted spans; the fresh RED entries and the GREEN; the pre-plant and post-revert outputs; anything you reversed from this brief and why.
