# Task S48-1a — continuation of the SAME implementation round (round 1)

You are the Executor continuing ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`, HEAD `5a53259`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations; read-only git is fine; paste actual results; leave no scratch file in the repository).

**The task package is unchanged: `.agents/kein/runs/execute/S48-1a-task.md`. Read it in full first, including its final section "Carried forward from the S48-0b review".** This file only tells you where the previous executor stopped and how to get past the environment fault that stopped it.

## Where the previous executor stopped

Report: `.agents/kein/reports/260903-013933-executor.md`. The working tree carries its UNCOMMITTED partial result — six files, all inside the task's scope: `packages/descvi/src/react/overlay/canvas/handle-geometry.ts`, `use-resize-handles.ts`, `spacing-affordance-geometry.ts` (the permitted `GAP_STRIP_HIT_BAND_PX` docblock only) and the three overlay unit tests. Items 1 and 2 of "What done is" and part of item 3 are implemented; the focused unit tests (74) pass, `pnpm --filter descvi typecheck` passes, `node scripts/check-citation-anchors.mjs` is GREEN on the real changed tree, `.descvi/screens.json` is clean, the lab is untouched. Build on that edit set — review it critically against the plan's §4/§4.1/§5 as you go and fix what is wrong rather than restarting, and say in your report what you changed in it and why.

Still to do, in full: the rest of item 3 (the docblocks in `resize-drag-commit.ts`, `e2e/resize-handles.spec.ts`, `e2e/spacing-gesture.spec.ts`), items 4, 5, 6 and 7 — every gate implemented AND driven RED with the mutant diff and failure output pasted, every §2.1 red row disposed under §8.1 with the written FIX rejection, EG-1 and EG-2 run and pasted verbatim, `pnpm test:e2e` green, `pnpm gates` (see below), the report.

## The environment fault, and how to get past it

The previous run could not start Playwright's web server: `Error: EMFILE: too many open files, watch` from chokidar. The cause is the shell you are given: it is a login shell without a profile and its SOFT open-file limit is the macOS default (256); the HARD limit is `unlimited`, so you may raise it yourself. Every `exec` you run is a fresh shell, so the raise does not persist between commands.

**Prefix EVERY command that runs `pnpm`, `vitest`, `playwright`, `node scripts/…` or a dev server with `ulimit -n 65536 && `.** Confirm once at the start with `ulimit -n 65536 && ulimit -Sn` (expect `65536`) and paste it. If, with the prefix in place, any command still fails with EMFILE, STOP at once and report the exact command and output — do not work around it any other way, and do not spend more than one retry on it.

## Dev servers

The e2e suite starts its own servers on :3001 and :7331 (the task package's dev-server note governs: kill a foreign holder of those ports if you find one, say which PID/port, and leave nothing of your own running afterwards). Before you start, check `lsof -nP -iTCP:3001 -iTCP:7331 -sTCP:LISTEN` and paste it.

## Gates

`pnpm gates` — run it yourself with the `ulimit` prefix and paste the tail. If it still trips EMFILE in one step, say exactly which step and what else passed; the lead re-runs the set serially either way. Nothing else in item 7 may be skipped.

## Report

Write the full report the task package's "Report" section demands to the report path the command gives you, and additionally: the `ulimit` confirmation line; every command that needed the prefix and still misbehaved; what you kept, changed, or discarded from the previous executor's edit set, with reasons. Signal completion normally when done.
