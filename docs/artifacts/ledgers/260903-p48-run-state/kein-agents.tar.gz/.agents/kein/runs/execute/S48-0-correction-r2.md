# Task S48-0 — correction round 2 (docs only)

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations of any kind — no add/commit/stash/checkout; read-only git such as `git diff`/`git show` is fine; paste actual results; say loudly what you reversed).

## State of the tree

The tree carries an UNCOMMITTED round-1 implementation of S48-0: `docs/e3/tracker.md` (+10 lines, a new `### phase-48 — B-Q5 admission-model supersession declarations (S48-0, 2026-09-02)` section before `## BUG-7`) and `docs/post-loop-backlog.md` (+2 lines, a new `| ↳ B-Q5 / S48-0 | … |` line after a blank line at the end of section B's table). Run `git diff` to see it. The round-1 content — the three declarations, their figures, the owner attributions, the inheritance dispositions, the two module anchors — was verified correct against the plan and the research docs by two independent reviewers. Do NOT rewrite it; correct exactly the two defects below and the three small tidy-ups, and change nothing else.

The task's plan text: `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` §7 `S48-0` and §8's entries for the two files. The completion condition is unchanged: docs/e3/tracker.md has a phase-48 section AND the `| B-Q5 |` row of docs/post-loop-backlog.md carries the three declarations (distinct in kind) and the inheritance dispositions; no other file changes.

## Defect 1 — the backlog declaration is an orphaned line, not part of the B-Q5 row (both reviewers)

The added `| ↳ B-Q5 / S48-0 | … |` line sits after a BLANK line following the `undo-history-loss` row, so under GFM it is not a table row at all (a blank line terminates the table; a lone pipe line with no header/delimiter is a paragraph of literal `|` text). And the plan's disposition for this file is the `| B-Q5 |` row ITSELF — "REWRITTEN … gains the disposition of every inherited item (§7, S48-0)" — while the completion condition says "the B-Q5 row … carries". **Correction (lead decision): fold the declaration text INTO the existing `| B-Q5 |` row's third (상태) cell**, appended at the end of that cell as a clearly marked block — e.g. begin it with `**⚠ S48-0 선언 (2026-09-02)**` — and DELETE the separate `↳` line and the blank line you added. The row must remain a single line (GFM table rows are one line). Match the row's register: it is Korean prose with English technical terms, so write the folded block in Korean with the English symbols, gate names, figures and dates kept verbatim (the two module anchors stay as exact `path#text` citations). Preserve every number and attribution from your round-1 text.

## Defect 2 — the tracker asserts as permanent something this phase deletes (Critic)

The tracker section says of the constant-split ruling's two sites: "neither is edited because the latter is a shipped plan record." Only the phase-42 plan clause is left unedited (a shipped plan is a record). The module site — the docblock at `packages/descvi/src/react/overlay/canvas/handle-geometry.ts#Owner-adjustable, but it must stay a single number` (it is `HANDLE_HIT_PX`'s docblock) — is DELETED by this phase in `S48-1b` along with `HANDLE_HIT_PX`, and the outwardness docblock (`…#WHY IT IS OUTWARD, WHICH IS THE RULING'S REAL CONTENT.`, `STRIP_HIT_BAND_PX`'s) likewise. Rewrite the sentence to what is true: the phase-42 plan clause is left as a record; the module docblocks are live sites this phase deletes with their constants in `S48-1b`, which is exactly why the rulings are declared here FIRST (pre-mortem S4). Do not remove the anchor citations themselves — S48-0b will convert them to the frozen form before the symbols go; you are correcting the prose claim only. Apply the same correction to the folded backlog text if it makes the same claim.

## Three small tidy-ups (non-blocking, do them in the same pass)

- Name the inheritance scope explicitly — "items (1), (3), (4), (5), (8)" — so the discharge list cannot be read as covering all eight.
- Write "197 flush pairs" (the research doc's population), not "197 pairs".
- Where the third declaration states the band's 5 px per-edge inset of the reorder surface, also name the corner inset (`cornerExtent / 2`, deeper than the band where the ramp exceeds 10) as plan §3 does.

## Verification you must run and paste

1. Render check for the table: show that the `| B-Q5 |` row is still ONE line and that no `↳ B-Q5 / S48-0` line or stray blank line remains inside section B's table (`grep -n '↳ B-Q5' docs/post-loop-backlog.md` → nothing; `grep -c '^| B-Q5 |' docs/post-loop-backlog.md` → 1). If Python is available with a markdown library, render and confirm the row is inside `<table>`; otherwise show the contiguous table lines around the row.
2. `node scripts/check-citation-anchors.mjs` — GREEN, tail pasted.
3. `pnpm gates` — tail pasted (serial; if a file-watcher EMFILE failure appears after all tests pass, say so and re-run once).
4. `git diff --exit-code .descvi/screens.json` clean; `git diff --stat` shows only the two files.

## Report

Write your full report to the report path the command gives you: the exact corrections made, the verification outputs pasted verbatim, anything you reversed from this brief and why.
