# Task S48-0 — Declare the superseded rulings (docs only)

You are the Executor for ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (a git worktree on branch `phase-48-kein`). Read and obey `AGENTS.md` (repository rules) and `docs/prompt/worker-brief.md` (worker rules: you own no git — no add/commit/stash/checkout; leave changes uncommitted; check your own work as hard as you can and never approve it; when the brief and reality disagree, settle what source settles and say LOUDLY what you reversed; paste actual results, never claim a pass you did not run).

## The plan this task comes from

`.omc/plans/ralplan-phase-48-bq5-handle-admission.md` — Approved. Read §1, §3, §7 (the `S48-0` story, first), §8's `docs/post-loop-backlog.md` and `docs/e3/tracker.md` entries, and the B-Q5 row of `docs/post-loop-backlog.md` (the row that starts with `| B-Q5 |`). The research docs the declarations cite: `.omc/research/phase48-straddle-drilldown-cost.md`, `.omc/research/phase48-strip-band-pricing.md`, `.omc/research/phase48-bq5-corner-placement.md`.

## Scope

Exactly two files: `docs/e3/tracker.md` and `docs/post-loop-backlog.md`. No other file changes. No code.

## What to write

Plan §7 `S48-0` specifies it; in summary, and each distinct in KIND:

1. **R42-D1's constant split — a mootness declaration.** The two sites holding the ruling (`handle-geometry.ts#Owner-adjustable, but it must stay a single number` and clause 1 of §3.12 in `.omc/plans/ralplan-phase-42-resize-handles.md`) are declared superseded because the new model has no separation clause, so the constant the ruling protected no longer decides anything. State the reason, not a preference.
2. **R42-D1's outwardness — a PRICED reversal.** Quote the drill-down passage (`handle-geometry.ts#WHY IT IS OUTWARD, WHICH IS THE RULING'S REAL CONTENT.`), state that the ruling's own instrument was re-run on the replacement (`.omc/research/phase48-straddle-drilldown-cost.md`: 628/324 reproduced; today's 721/335; mean flush-child shadowing 4.5 % → 25.8 % at band 10, 20.8 % at band 8; pairs > 50 % shadowed 3 → 32 / 14; fully unreachable 0 → 1 — `shop/member-detail` oid `morsj0`, 55×6 in 654×6; the new corners alone a pure recovery 4.5 % → 1.0 %, 197 pairs strictly better, none worse, so the whole added cost is the band's), and the owner's 2026-09-02 ruling: accept and record, on the tentative-spec / real-use-will-judge basis; band placement stays closed.
3. **The third cession and the clause-5 erratum.** The reorder gesture's armable surface is the selected element minus every resize hit region (the shield's handle branch returns before the reorder entry point); the straddling band insets it 5 px per edge and empties it at short side ≤ 10; owner 2026-09-02: accept, record, and MEASURE (EG-1's reorder-armable residue reading counts the ≤ 10 class the B-Q5 row's population figures — 227/298 leaves ≤ 20 px, 117 ≤ 16 — leave uncounted); the panel's ↑/↓ handoff is the non-drag route. The §3.12 clause-5 erratum (in `e2e/resize-write.spec.ts`'s G42-6b docblock) is a routed question whose premise this phase removes: the non-empty floor stops being emergent (eight is unconditional on the box) while a subject outside the clip still renders nothing reachable because clipping is the browser's.
4. **Every inheritance item the B-Q5 row hands the phase is marked discharged**, with what discharges it: item (4) → the mootness declaration; items (1) and (3) → fall with the separation clause; item (5) → discharged by TAKING the band lever, priced by `.omc/research/phase48-strip-band-pricing.md` and `.omc/research/phase48-straddle-drilldown-cost.md`; item (8) second half → `.omc/research/phase48-bq5-corner-placement.md` (0.000 px); first half (clip, don't push) → plan §2 and G48-3.

Where: `docs/e3/tracker.md` gains a phase-48 section carrying the declarations; the B-Q5 row gains them too (it is the decision record a reader meets). Match each file's existing register. Do NOT pre-write S48-3's full sweep (outcome, gate names, EG-1 records) — only what §7 `S48-0` assigns to this story. Do not edit `.omc/plans/ralplan-phase-42-resize-handles.md` (a shipped plan is a record).

## Rules that bind the edit

- Cite code by ANCHOR only: `` `path/to/file.ts#<exact source text>` `` occurring exactly once in the target; never a line number in any spelling. The citation gate scans `docs/` and will fail on a bad anchor.
- English prose in these files is fine; the backlog row is written in Korean with English terms — match the row's existing style.
- No hard-wrapped prose: one paragraph = one line.
- Do not narrate the plan's drafting; state facts and cite external sources (the plan, the research docs, the owner's dated rulings).
- Do not start or stop any dev server.

## Completion condition

The two files carry the three declarations and the inheritance dispositions as above; the declarations exist before any code commit deletes the docblocks carrying the reversed rulings; nothing else changes.

## Verification you must run and paste

1. `node scripts/check-citation-anchors.mjs` — must print `citation gate: GREEN` with 0 violations; paste the tail.
2. `pnpm gates` — the repository's gate set (parses CI's verify job); paste the final lines. It takes several minutes; use a long timeout. If a gate fails for a reason unrelated to your two files, say so with the output rather than fixing it.
3. `git diff --exit-code .descvi/screens.json` — must be clean (exit 0).
4. `git diff --stat` — must list only `docs/e3/tracker.md` and `docs/post-loop-backlog.md`.
5. A RED-ability check of the citation gate on your own edit: temporarily corrupt one anchor you added, run the gate, paste the violation line, restore it, run again GREEN. This proves your new anchors are actually checked.

## Report

Write your full report to the report path the command gives you: what you changed (per file, per declaration), the verification outputs pasted verbatim, anything the plan or this brief got wrong that you had to settle from source (loudly), and anything you could not settle. Self-verification is not approval; a reviewer will read the diff.
