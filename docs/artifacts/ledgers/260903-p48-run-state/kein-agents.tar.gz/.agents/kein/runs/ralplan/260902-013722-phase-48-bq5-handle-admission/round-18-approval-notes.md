# Round 18 — approving round: non-blocking items carried to execution

Both lanes returned PASS on review hash `36a033d87c92d59968ea4aa079d9189a2ac6956c87f5e09afd8ba73ca195a534`. Neither lane raised a MUST_FIX. The items below are the UNCERTAINTY entries from that round; none changes scope, architecture, acceptance semantics, or an Evidence Gate's bounded paths, and each is something the executor should carry into the story it touches rather than something the plan must be reopened for.

## From the Architect lane

- **S48-0's declaration count is stated inconsistently inside its own story** — "TWO written rulings" / "Both declarations land in the tracker" vs two different items each called "the third" (the reorder cession; the §3.12 clause-5 erratum). Every item's content and owning commit is enumerated elsewhere, so nothing is orphaned; the executor should land S48-0 from one explicit list of its contents and state whether the reorder cession's declaration (as distinct from its measured numbers) is in it.
- **Chromium border-radius hit-clipping** remains an unverified premise until G48-4's three-valued reading is run and recorded before S48-1 is reported green — the plan already binds this.
- **§4's "a point chosen from nw's rect alone lies inside all four"** overstates: (−3.5, −3.5) is in nw's [−4,4]² and outside se's [−3,5]². The rule it motivates (probe the exclusive region) is unaffected.
- **The artifact byte-identity "pair"** understates CI's `verify`, which also runs `node scripts/check-extract-outcome.mjs`; harmless since the instruction is to run `pnpm gates`.
- **§8's READOUT_ELEMENT_GAP_PX amendment framing** ("from 5 px past … to a 1 px overlap") — the shipped docblock already states the 1 px overlap; the substantive amendment (1 px becomes a maximum, holding only at short side ≥ 35) is stated correctly in the next sentence.

## From the Critic lane

- **G48-9's browser-margin paragraph calls the 6×6 contested pocket "2 × 1 px"**; the corner-versus-corner region derived six lines earlier is [2,4]², i.e. 2 × 2 (the 2 × 1 pocket belongs to the corners-before-bands leg). Conservative direction; reconcile before using it as the fallback test.
- **`acceptance 5 — every handle's own centre hits THAT node`** in `e2e/resize-handles.spec.ts` has no disposition; derived to stay green and true (corner centres become box corners where the corner square at z 43 beats the bands; band centres are 150 px clear of any corner square). Record it as NO CHANGE when S48-1a first drives the suite.
- **G48-9's browser half drives 6×6 through `setFixture`**, which has not been exercised at that size (4b's smallest is 1×1, so the mechanism is demonstrated); note it when the row is written.

## Earlier rounds' non-blocking items already folded

Rounds 1–17's UNCERTAINTY entries were folded into the plan text by revision; their disposition is in the plan body, not here.
