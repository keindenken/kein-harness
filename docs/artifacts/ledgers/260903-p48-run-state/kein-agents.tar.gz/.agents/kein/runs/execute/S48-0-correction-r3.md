# Task S48-0 — correction round 3 (docs only, small)

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations of any kind; read-only git is fine; paste actual results; say loudly what you reversed). Do NOT leave any scratch file inside the repository (a previous round left a stray file named `0` in the repo root — write nothing outside `.agents/kein/`).

## State of the tree

`docs/e3/tracker.md` (+10) and `docs/post-loop-backlog.md` (the `| B-Q5 |` row edited in place, one line) carry the round-2 S48-0 text, verified correct in every figure and attribution by two reviewers. Correct exactly the items below; change nothing else.

## Defect — item (8)'s two halves are inverted (both files)

The B-Q5 row itself defines item (8)'s halves: **first half** = the corner handle sits outside its own vertex (`꼭짓점보다 너무 바깥에 앉아 있고`), which the row already records as measured and answered at 0.000 px by `.omc/research/phase48-bq5-corner-placement.md`; **second half** = the handle at the screen's own edge is pushed inward (`안쪽으로 밀리는 것도 틀렸다`), answered by clip-rather-than-push (phase-48 plan §2 and `G48-3`). The round-2 text says the opposite in both files (tracker: "item (8)'s second half is discharged by `.omc/research/phase48-bq5-corner-placement.md` (0.000 px) and its first half, clip rather than push, by phase-48 plan §2 and `G48-3`"; backlog: "(8)의 second half는 … corner-placement … first half는 … clip rather than push"). **Swap the ordinals in both files** so the FIRST half → corner-placement research (0.000 px) and the SECOND half → plan §2 / `G48-3`. The inversion originates in the plan's §7 S48-0 paragraph; the lead will correct the plan separately — do NOT edit the plan.

## Two tidy-ups in the same pass

1. **Item (2) — monotonicity is false — falls with the separation clause too.** The B-Q5 row's item (2) is a property of the retired separation walk (lowering the separation distance admits an earlier strip that evicts a later one). Under a model with no separation clause it has no subject, exactly like items (1) and (3). Add (2) to the "fall with the separation clause" set in both files and restate the scope as items (1), (2), (3), (4), (5), (8); state that (6) (the population counts) and (7) (the phase-46 measurement pointer) remain live facts/pointers rather than discharged items — (6) is used by the third declaration. This is a lead-authorised factual adjustment within scope; say in your report that the brief added (2).
2. **The Korean mootness sentence drops the ruling's stated purpose.** The tracker copy keeps "the ruling existed to stop two gate rows predicting different furniture for the same fixture while the protected constant decided admission"; the folded backlog block says only that the constant protected separation while it decided admission. Add the purpose clause to the Korean block so the primary record carries the reason, not only the conclusion.

## Verification you must run and paste

1. `grep -n -o '(8)[^.]*\.' docs/e3/tracker.md docs/post-loop-backlog.md` — paste; both must read first half → corner-placement, second half → clip/G48-3.
2. `grep -c '^| B-Q5 |' docs/post-loop-backlog.md` → 1, and the row is still one line (`awk 'NR==169{print length($0)}' docs/post-loop-backlog.md` or equivalent).
3. `node scripts/check-citation-anchors.mjs` — GREEN, tail pasted.
4. `git diff --exit-code .descvi/screens.json` clean; `git diff --stat` shows only the two files; `git status --porcelain` shows no new untracked file outside `.agents/kein/`.
5. Skip `pnpm gates` — the lead runs it serially (the worker sandbox hits EMFILE watcher errors); say so in the report rather than claiming it.

## Report

Write your full report to the report path the command gives you: the exact edits (before/after for the (8) sentences), the verification outputs pasted verbatim, and anything you reversed from this brief.
