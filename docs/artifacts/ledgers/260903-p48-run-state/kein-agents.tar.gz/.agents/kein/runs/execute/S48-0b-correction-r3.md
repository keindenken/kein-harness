# Task S48-0b — correction round 3 (docs only, small)

You are the Executor correcting ONE task of phase-48 in the descvi repository. Working directory and repository root: `/Users/kein/Documents/workspace/dev/worktree/repo/phase-48-kein` (branch `phase-48-kein`, HEAD `07ab8afee101`). Read and obey `AGENTS.md` and `docs/prompt/worker-brief.md` (no git mutations; read-only git is fine; paste actual results; leave no scratch file in the repository).

## State of the tree

The tree carries the UNCOMMITTED S48-0b result after two rounds: nine documents (+76/−76), 101 citations frozen to `git show 07ab8afee101:path#anchor`, plant reverted, gate GREEN. Packages: `.agents/kein/runs/execute/S48-0b-task.md`, `-correction-r2.md`. Plan section: `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` §7 `S48-0b`.

## Two spans still bare whose target lines this phase changes

1. **`compassPoint`'s signature.** `.omc/research/phase48-bq5-corner-placement.md` cites `packages/descvi/src/react/overlay/canvas/handle-geometry.ts#export function compassPoint(box: HandleRect, compass: HandleCompass): HandlePoint {` in bare form. Plan §7's per-file entry for that document names `compassPoint`'s signature as "affected". Its only production caller is inside the retiring placement path (`placeHandle`), and S48-1a's port may keep, rename or retire it. Freeze the span (the frozen form is correct whether or not the line survives — a record cites the tree it measured), and say in your report that you froze it because the plan lists it as affected and its survival is S48-1a's choice.
2. **The node-loop append line.** `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` cites `packages/descvi/src/react/overlay/canvas/use-resize-handles.ts#      if (existing === null) host.appendChild(node);` in bare form, in the very §4.1 paragraph that specifies replacing that line's behaviour with a conditional reorder. Freeze it.

## Sweep once more for the same shape

Before planting, re-sweep the derived query's output for any other bare span of the shape "a current-code CALL SITE or helper BODY line that §2/§4.1/§7/§8 describe replacing" — in `use-resize-handles.ts` (the node loop, the `#dsh-frame` measurement, the chip-size write), `handle-geometry.ts` (`placeHandle`'s body, `hitSizeFor`'s body, `admitHandles`' clause lines), and the two oracles — and convert what you find, listing each with its reason. Paste the sweep's output even when it finds nothing new.

## Extend the plant and re-prove

Re-run the line-granular end-state plant (snapshot outside the repository as before) with these two lines — and anything the sweep added — blanked in addition to everything the round-2 plant blanked. Show RED with only the new conversions reverted, and PASTE THE LITERAL GATE OUTPUT (the `anchor NOT FOUND … hits=0` lines), not a prose summary — the round-2 report summarised its RED in prose and the reviewer had to reproduce it. Then GREEN with them in place; revert by copy-back and paste `git status --porcelain` and `git diff --stat` identical to the pre-plant baseline.

## One factual correction to the plan, lead-authorised, in the same pass

In `.omc/plans/ralplan-phase-48-bq5-handle-admission.md` §7's S48-0b per-file entry for `.omc/specs/v3-layout-panel-visual-spec.md`, the parenthetical "`HANDLE_ADMISSION_ORDER` (its declaration line changes)" contradicts §4 and the same section's own-plan bullet ("the list keeps its name (§4), so its two declaration-line citations stay live"). Replace the parenthetical with "(its declaration line `export const HANDLE_ADMISSION_ORDER: readonly HandleCompass[] = [` stays byte-identical — §4; S48-1a is bound to keep it, because the lab's `page.tsx` cites it and no story may edit that file)". Change nothing else in the plan's prose. Report this edit loudly as a lead-authorised factual correction.

## Final

`node scripts/check-citation-anchors.mjs` GREEN (paste); `git diff --exit-code .descvi/screens.json` clean; `git diff --stat` shows only documents; `git status --porcelain` shows no stray file. Skip `pnpm gates` (the lead runs it serially); say so.

## Report

Write your full report to the report path the command gives you: the two conversions, the plan parenthetical before/after, the RED (two fresh hits) and GREEN, the pre/post revert outputs, anything you reversed.
